# Say it, see it: Netomi ADX with GPT-Live

A voice agent that builds the page while you talk. It's a local demo of Netomi ADX: a GPT-Live (`gpt-live-1`) voice session, with the **Decisions API** classifying intent as the visitor speaks. The fitting UI cards render instantly on the page, and the voice describes them instead of reading every detail aloud.

Two scenarios ship with it:

- **Airline rebooking (Delta-branded mock):** a cancelled flight, rebooking options, a nonstop comparison, a hotel question, vouchers and a boarding pass.
- **Rockwell Automation "My Orders" (B2B mock):** a delayed drive, a line-down timeline (23 days down to 3), an in-stock replacement, and a confirmed plan.

All customer, booking and order data is invented. The brands appear as text wordmarks and colours only. This is an internal demo; don't share it outside Netomi.

## Run it locally

You need:
- **Node 20 or newer.**
- **Chrome** (or another Chromium browser).
- **Headphones.** Without them the agent hears itself.
- **An OpenAI API key with access to `gpt-live-1`.**

```bash
git clone <this repo> && cd say-it-see-it
cp .env.example .env        # then set OPENAI_API_KEY (or OPENAI_ENV_FILE)
npm install                 # one dependency: ws
npm start                   # http://localhost:5178
```

Then open:
- Airline (Delta): http://localhost:5178
- Rockwell: http://localhost:5178/?scenario=rockwell
- Every card, with no voice (for a visual walkthrough): add `&preview=99`, e.g. http://localhost:5178/?scenario=rockwell&preview=99

Click the **Netomi button** at the bottom right to start talking, and click it again to hang up. The small **^** button opens the conversation panel: captions, and what the Decisions API understood.

The key stays on the server. The browser streams microphone audio to the local server, and the server relays it to GPT-Live.

## How it works

```
browser mic ──► server.mjs ──► GPT-Live (gpt-live-1)
                    │  decision.event on every transcript update
                    │     └─ confident intent ─► mock backend ─► cards to the page
                    │  client delegation ─► same backend result ─► facts for the voice to say
page ◄── cards, captions ──┘   taps on cards ─► backend ─► cards + what the voice says
```

| Part | Files |
|---|---|
| Voice session relay (Decisions, delegation, taps) | `lib/live.mjs` |
| Scenarios: instructions, Decisions questions, intent → action | `lib/scenarios/*.mjs` |
| Mock backends: each action returns `{ say, ui }` | `lib/backend.mjs` (airline), `lib/backend-rockwell.mjs` |
| Pages and cards | `public/pages/*.js`, `public/cards*.js` |
| Card renderer and theming, adapted from adxGenUI (adxWebSdk) | `public/adx/`, `lib/adx/` |
| Brands (colours, type, agent name, voice) | `brands/*.json` |

The scripts, talking points and the sources for each Delta fact are in [DEMO.md](DEMO.md).

## Tests

Nothing in the tests plays sound.

- `node test/e2e.mjs`, or `SCENARIO=rockwell node test/e2e.mjs`, with the server running. It streams scripted speech into a real GPT-Live session and checks that decisions fire and the expected cards arrive. On macOS, generate the audio first with `test/make-audio.sh`.
- `node test/screenshot.mjs rockwell 0 2 99` takes screenshots of `?preview=N` in muted headless Chrome.

## Hosted copy

`deploy-vm.sh` ships the app to a VM behind Caddy with Basic auth. Set `ADX_VM_HOST` (and `ADX_VM_KEY` if needed). See DEMO.md for the one-time server setup. Each session is capped at 3 concurrent and 10 minutes.
