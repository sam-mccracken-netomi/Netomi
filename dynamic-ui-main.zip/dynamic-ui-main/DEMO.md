# Say it, see it (Netomi ADX demos)

Two scenarios run on the same server, voice engine and card renderer:

- **Airline rebooking, Delta** (default): http://localhost:5178. The original fictional Skyline Air is at `?brand=skyline`.
- **Rockwell Automation "ADX with S2S"** (B2B order portal): http://localhost:5178/?scenario=rockwell. The [Rockwell section](#rockwell-automation-adx-with-s2s) is below.

## Airline rebooking (Delta)

A customer on Delta's **My Trips** page (a mock: text "DELTA" wordmark, Delta-like navy and red, no Delta logo or assets). Their flight **DL 2328 ATL → ORD**, tonight at 6:50 PM from Gate B12, was **cancelled for crew availability**. The voice is **Riley, Delta's virtual assistant** (a neutral name, not a real Delta product), and the page builds the rebooking beside the conversation. Everything about the customer and booking is mock.

## Setup and run

Requirements: Node 20+ (tested on 24), Chrome or another Chromium browser, and a microphone with headphones (headphones stop the agent hearing itself).

```bash
cd /Users/zain/Documents/code/netomi/adx-demo/say-it-see-it
npm install        # one dependency: ws
npm start          # http://localhost:5178
```

The OpenAI key is never copied into this project. `.env` sets `OPENAI_ENV_FILE`, which points at `delta-seat-demo/.env.local`, and the server reads `OPENAI_API_KEY` from that file. You can put `OPENAI_API_KEY=...` in `.env` instead. The browser never sees the key.

Open http://localhost:5178, click the **Netomi orb** (bottom-right), allow the microphone, and wait for the greeting. Click the orb again to end the session (it hangs up).

**The orb:**
- **Idle:** the Netomi mark.
- **Listening:** a slow breathing glow that follows your mic level.
- **Speaking:** rings radiate with GPT-Live's real output level.
- **Thinking:** a quiet arc while a request is with the backend.

The **^** button above the orb opens the conversation panel (captions, the agent, "What ADX understood") without interrupting the session. Collapsed is the default, and one live caption line appears beside the orb while the agent speaks. To check a state without a session, add `?orb=listening|speaking|thinking|open|caption` (comma-separated, combinable with `?preview=N`); this produces no audio.

Options:
- **Brand:** `http://localhost:5178/?brand=northwind` (or `BRAND=northwind npm start`) re-themes the page and the voice. Brands are JSON files in `brands/`, in adxGenUI's brand-profile shape (colours, typography, shape), plus the agent name, voice and hotel name.
- **The "What ADX understood" box** (in the conversation panel) shows the live Decisions output and which card it triggered. Untick it for a cleaner customer view.
- **Session logs:** each session writes `logs/session-*.jsonl` with every decision, delegation, backend action, card and transcript fragment.

### Airline happy path (Delta, about 80 seconds)

Before the conversation, the page shows the trip and "Your options for DL 2328": Rebook on another flight, Request a refund, Hotel & meal vouchers, Delta eCredit. The first card from the conversation takes that space over.

| # | Visitor says | What appears | Agent says, roughly |
|---|---|---|---|
| 0 | *(clicks the orb)* | | "Hey Jordan, I see your flight to Chicago was cancelled, and I'm so sorry. How can I help?" |
| 1 | "My flight to Chicago got cancelled. What are my options?" | Disruption summary: cancelled for crew availability (within Delta's control); rebook at no cost, hotel and meal vouchers if stuck overnight away from home, or a refund to the original form of payment. Below it, three options. | "I've put three options up for you. The earliest leaves tonight at 9:40 with a connection in Detroit. Which works for you?" |
| 2 | "Is there anything nonstop?" | The two nonstops are compared side by side: DL 1872 at 7:15 AM (Delta Main, no extra cost) against DL 2563 at 11:35 AM (Main sold out, Delta Comfort +$64). | "Two nonstops tomorrow, side by side. The 7:15 is no extra cost." |
| 3 | "I'll take the 7:15 tomorrow morning." | DL 1872 shows "Seat 19C held"; one-tap **"Need a hotel tonight?"** | "19C is held on the 7:15. Do you need a hotel tonight?" |
| 4 | "Yes please." *(or tap)* | Hotel voucher (ATL airport partner hotel, shuttle from Ground Transportation, Domestic Terminal), $15 meal voucher, confirm bar | "One night's booked, plus a fifteen dollar meal voucher. Shall I confirm the new flight?" |
| 5 | "Yes, go ahead and confirm it." | Boarding pass: DL 1872, Gate B12, boarding 6:35 AM, seat 19C, Zone Sky Priority, confirmation GB7ZYV | "You're all set. Your boarding pass is up, and it's in the Fly Delta app too. Boarding starts at 6:35 at gate B12." |

**Variations:**
- "Can I just get a refund?" gives a refund of the unflown portion to the original form of payment.
- "Can I get an eCredit instead?" gives a Delta eCredit, valid five years.
- The Rebook, Request a refund and Delta eCredit tiles work like saying it, once the session has started.

### Delta facts used, and where they come from

| Fact | Source |
|---|---|
| Cancellation: "we automatically try to rebook you"; options in Fly Delta or My Trips; cancel for a refund of the unflown portion (plus pre-paid seats and bag fees) or an eCredit valid 5 years; automatic refund to the original payment method if no action in 24 hours | delta.com "Cancel or Refund Your Flight", in `delta-seat-demo/knowledge/delta_help_snippets.json` |
| Hotel and meals: only when the cancellation is "an issue caused by Delta (within our control)" and the customer is "inconvenienced overnight while away from your home or destination"; **not for weather** or ATC delays, and not in the home or destination city | Same page. **So the cause is crew availability, not weather, and the passenger lives in Chicago and is stuck overnight in Atlanta.** |
| Cabin names: Delta Main (Basic), **Delta Comfort** (the 2026 name for Comfort+), Delta First, Delta Premium Select, Delta One | delta.com fares and onboard pages in the same knowledge file |
| Fly Delta app (rebook cancelled flights), SkyMiles and Medallion, eCredit and delta.com/redeem | Same knowledge file |
| GB7ZYV is a fake Delta test booking | `knowledge-base/findings/voice-demo-lines.md` (Delta test instance) |
| DL 2328 appears in our Delta testing | `delta-seat-demo/src/agent.py` (bot_note) and `findings/voice-demo-lines.md` |
| Persona: DELTA_PERSONA ("warm, upbeat and a little playful, like a favourite gate agent…") plus our demo lines' energy wording | `delta-seat-demo/src/agent.py` and `profiles/+19383565865.json`. The Delta EP profile's "Energy" section isn't in the local repo. |

**Plausible but not from a source (mock):**
- The schedules and arrival times (ATL→ORD is about 2 hours with a 1-hour time change), the aircraft (A220-300, 737-900ER, A321), the gates (B12, A17, T8), the via-Detroit routing, and the $64 Delta Comfort difference.
- Gold Medallion boarding with Sky Priority.
- The $15 meal voucher amount and the "ATL airport partner hotel" name (deliberately generic, not a real hotel).

**Talking points:**
- **The cards arrive while the visitor is still talking.** GPT-Live's Decisions API classifies intent on every word. In testing, the options card was on screen after "...got cancelled. What", before "are my options".
- **The voice refers to the screen and doesn't read out every time and fare.** The facts it says and the cards come from the same backend result, so they can't disagree.
- **Taps feed back into the conversation.** Tap a flight, the hotel answer or Confirm, and the agent responds to it.
- **The cards are predefined templates filled with data.** They render through adxGenUI's renderer and brand theming, with no free-form UI generation, so they're instant and always on-brand.

**Variations that work:**
- "What's the earliest I can get there?" gives the earliest flight compared with the best nonstop.
- "No, I'm staying local." skips the hotel; the meal voucher is still issued.
- Tap "Choose this flight" on any card instead of speaking.

To reset, reload the page; each session starts fresh.

## Rockwell Automation: "ADX with S2S"

A signed-in buyer opens **My Orders** after a delivery-date change. Order **8100234571** shows the delayed line: 2 × PowerFlex 753 drives now arriving Fri 13 Nov instead of Thu 22 Oct, because of a supplier shortage on a power module. The rest of the order is ready or delivered. The voice (Sam) is concise industrial support: it points to the screen and says dates short ("Saturday", "Friday the thirteenth").

As the conversation goes, the page builds a **Line 4 workspace** right under the order header: a dark band with white cards inside. Its hero is a **downtime timeline**: today → the PowerFlex 755 in stock (Sat 24 Oct) → the RMA drive back (Wed 4 Nov) → the delayed 753s (Fri 13 Nov).
- The red "Line 4 down" bar and the **23 days of downtime** counter shrink to **3 days** and turn green when the replacement is chosen.
- A step rail in the header tracks the progress: Status → Impact → Fix → Confirmed.
- Every turn scrolls its card into view and pulses it.

All the data is invented ("today" is Wed 21 Oct 2026), apart from the order number, which matches what testers say on the Rockwell phone line. That includes the customer (Northfield Packaging Co.), the buyer (Dana Whitfield), the plant (Riverside Plant, Line 4), RMA-5521938, replacement order 8100236127, the tracking number and the specialist (Jordan Kim). The brand is a text wordmark with neutral red/grey styling from `brands/rockwell.json`; no Rockwell logo or assets are used.

Open http://localhost:5178/?scenario=rockwell and click the orb. To see every card without a voice session, use `?scenario=rockwell&preview=6` (or `preview=1` to `5` for each step).

### Happy path (about 75 seconds; the specialist turn is optional, about 90 seconds with it)

| # | Buyer says | What changes on screen | Agent says, roughly |
|---|---|---|---|
| 0 | *(clicks the orb)* | | "Hi Dana, how can I help?" |
| 1 | "What's going on with order 8100234571?" (or "Why is my drive delayed?") | The delayed line **expands**: a status card (was Thu 22 Oct → **Fri 13 Nov**, the reason, the rest of the order) and the micro-question **"Is this part holding up your production line?"** (Yes / No / Not sure). Rail: Status. | "Those drives are now due Friday the thirteenth, about three weeks late, a power module shortage. Details are next to the delayed line. Is it holding up your production line?" |
| 2 | "Yes, it's holding up line four." *(or tap **Yes**)* | The table collapses to one row, and the **Line 4 workspace** opens: the **23 days of downtime** timeline, the fastest fix (an in-stock PowerFlex 755, arriving Sat 24 Oct, +$1,140 per drive), and the options ranked by restart date. Rail: Impact. | "I've pulled up the Line 4 workspace. The fastest fix is an in-stock PowerFlex 755, here Saturday, about eleven hundred more per drive. Want it?" |
| 3 | "Yes, do it." / "Can you get me the replacement that's in stock?" *(or tap **Use the in-stock 755**)* | **The money shot:** the bar shrinks to Sat 24 Oct and turns green, and the counter runs from **23 down to 3 days** ("20 days sooner"). Below it, the delayed 753 is compared with the in-stock 755, with a confirm band. Rail: Fix. | "Two 755s here Saturday, cutting downtime to three days, $2,280 more. Can I confirm?" |
| 4 | "Yes, place it." *(or tap **Place replacement order**)* | The plan locks in: a green **"Line 4 restarts Sat 24 Oct"** banner, replacement order 8100236127, the original line cancelled at no charge, and links for the swap. Rail: Confirmed. | "Done. You restart Saturday, and the delayed drives are cancelled. Want the rest of the order shipped now?" |
| 5 | "Yes." / "And ship the rest of the order now, please." | The plan adds "Rest of the order shipping today", with tracking, arriving Fri 23 Oct | "Done. Those ship today and arrive Friday, no extra freight." |
| 6 *(optional)* | "Can I talk to a drives specialist about the setup?" | Handoff card: **Jordan Kim**, Drives Application Engineer, with an avatar, "joining in about 2 minutes", and context chips (the order, the RMA, Line 4 down since Wed 21 Oct, the replacement, this conversation). It's mocked; there's no real transfer. | "Jordan Kim is joining in about two minutes and already has your order, repair and line status." |

**Variations:**
- "Just place the replacement order" said cold stages and places it in one step.
- "No" to the offer stands down.
- "No, it's not holding up the line" keeps the date and offers to ship the rest.
- "Can you expedite it?" turns the bar amber at ~Thu 5 Nov ("not guaranteed").
- Every option also works by tap.

## How it works

```
browser mic ─PCM 24 kHz─► server.mjs ─session.input_audio.append─► GPT-Live (gpt-live-1)
speaker     ◄────────────            ◄─session.output_audio.delta──
                              │  decision.event (every input-transcript delta)
                              │     └─ confident intent ─► mock backend ─► cards to the page (fast path)
                              │  session.delegation.created (client delegation)
                              │     └─ same backend result ─► session.commentary.append (the facts to say)
page ◄── cards, captions, decisions ──┘        taps ─► backend ─► cards + commentary
```

- `lib/live.mjs`: the GPT-Live session relay, the same for every scenario. It handles Decisions (the fast path), client delegation (the facts), taps, and settling a delegation until its decision has landed.
- `lib/scenarios/*.mjs`: one per scenario. Each holds the voice instructions (built on `common.mjs`, OpenAI's delegation template from delta-seat-demo), the Decisions questions, the decision-to-action mapping, the keyword fallback and the taps.
- `lib/backend.mjs` (airline) and `lib/backend-rockwell.mjs`: the mocked backends. Each action returns `{ say, ui }`.
- `public/pages/*.js`: each scenario's page (the trip page, or the order portal with an inline anchor under the delayed line).
- Cards: `public/cards.js` (airline) and `public/cards-b2b.js` (Rockwell: step rail, order status, downtime timeline, fix offer, part comparison, plan, ranked options, handoff, with inline SVG product art). Both are registered in adxGenUI's renderer and theming (`public/adx/`, copied from adxWebSdk). The Rockwell scenario also uses adxGenUI's `micro_elicit` (the line question) and `cta_banner` (the confirm step) as they are, with its B2B styles (`public/adx/gx-b2b.css`). `lib/adx/b2b.js` is copied as a reference for those element shapes.

## Tests (no human microphone; nothing is played out loud)

- `node test/e2e.mjs`, `SCENARIO=rockwell node test/e2e.mjs`, or the Rockwell variants `SCENARIO=rockwell SCRIPT=rockwell-offer` ("Yes, I think do it" after the offer) and `SCRIPT=rockwell-cold` ("Just place the replacement order") (server running): acts as the browser over the WebSocket. It streams the scripted lines (`test/make-audio.sh`, macOS `say`) into a real GPT-Live session and checks that decisions fire, delegations reach the backend and the expected cards arrive. Agent audio is received and discarded.
- `SIZES=1280x720,1440x900 node test/screenshot.mjs rockwell 0 1 2 3 4 5 6`: screenshots of `?preview=N` (the first N happy-path steps straight from the mock backend). There's no voice session and no microphone, and Chrome runs with `--mute-audio`. `?preview=99` also works in your own browser to see every card without talking.
- `node test/browser.mjs` (airline): headless Chrome with a fake microphone fed from the same lines. It checks the cards in the real page's DOM and saves screenshots to `logs/browser-*/`. Chrome is launched with `--mute-audio`, and the page's `?silent=1` keeps agent audio away from the speakers.

## Hosted on the VM (s2s-demo-bridge)

- **Delta:** https://adx.34-85-206-188.sslip.io/
- **Rockwell:** https://adx.34-85-206-188.sslip.io/?scenario=rockwell
- **Login:** Basic auth, user `adx`. The password is only in Zain's macOS Keychain: `security find-generic-password -s adx-demo-vm -a adx -w`. This login is separate from the S2S portal's.

**What runs where**

| Piece | Where |
|---|---|
| Service | `adx-demo` (systemd), user `adx`, `127.0.0.1:8090`, Node 22.11.0 in `/opt/node` (not system-wide; the Python bridges are untouched) |
| App | `/opt/adx-demo/releases/<timestamp>/`, with `/opt/adx-demo/current` pointing at the live one |
| Session logs | `/opt/adx-demo/logs/` |
| OpenAI key | Extracted on the VM from `/opt/s2s/app/.env.local` into `/etc/adx-demo/adx.env` (`root:adx 640`, that key only). The `adx` user can't read the S2S env file. |
| Caddy | Its own site block `adx.34-85-206-188.sslip.io` (basic_auth, reverse_proxy to 8090, which carries the `/live` WebSocket, same security headers). The S2S portal block is unchanged. Backup: `/etc/caddy/Caddyfile.bak-adx-20261021`. |

**Spend guards** (`server.mjs`):
- At most **3 concurrent voice sessions** (`MAX_SESSIONS`); extra visitors are told the demo is busy.
- Each session is capped at **10 minutes** (`MAX_SESSION_MIN`).

**Update / roll back** (from this folder; the local copy is the source of truth):

```bash
./deploy-vm.sh            # ship a new release, restart only adx-demo (keeps the last 5)
./deploy-vm.sh rollback   # back to the previous release
./deploy-vm.sh status     # state, releases, recent log lines
```

To take the site down entirely:
1. Restore the backup Caddyfile: `sudo cp /etc/caddy/Caddyfile.bak-adx-20261021 /etc/caddy/Caddyfile`.
2. Run `sudo systemctl reload caddy`.
3. Run `sudo systemctl disable --now adx-demo`.

To rotate the password:
1. Run `caddy hash-password` on the VM, giving it the new password on stdin.
2. Replace the hash in the `adx` block of the Caddyfile.
3. Validate, then reload Caddy.
4. Update the Keychain entry.
