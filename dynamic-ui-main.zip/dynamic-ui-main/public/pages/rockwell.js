// The Rockwell scenario's page: a B2B "My Orders" portal, order 8100234571 after a
// delivery-date change. Cards render into anchors on the page, never far below it:
//   rail         the step rail in the order header (Status → Impact → Fix → Confirmed)
//   delayed-line inline under the delayed order line (status + the line question)
//   ws-hero/ws-main/ws-options  the "Line 4 workspace", right under the order header;
//                once it opens, the order table collapses to one compact row
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
const STATUS = { delayed: ["Delayed", "bad"], ready: ["Ready to ship", "ok"], shipped: ["Delivered", "muted"] };

export default {
  title: (b) => `My Orders · ${b.name}`,
  promo: "Customer portal · Account 40-118276 · demo data",
  nav: () => ["Products", "Support", "*My Orders", "Quotes", "Returns & Repairs", "Downloads"],
  user: ({ page }) => ({ initials: page.account.buyer.first[0] + page.account.buyer.last[0], name: `${page.account.buyer.first} ${page.account.buyer.last[0]}.` }),
  canvasTitle: () => "",
  empty: () => "",
  hint: "<i>“What's going on with order 8100234571?”</i> or <i>“Why is my drive delayed?”</i>",
  top: ({ page: { account: a, order: o } }) => {
    const d = o.lines[0];
    return `
    <div class="rw-head">
      <div class="rw-title">
        <div class="crumbs">My Orders <span>/</span> <b>${esc(o.number)}</b></div>
        <h1>Order ${esc(o.number)} <span class="chip chip-warn">${esc(o.status)}</span></h1>
        <div class="rw-meta">${esc(a.company)} · ${esc(a.plant)} · ${esc(o.po)} · placed ${esc(o.placed)}</div>
      </div>
      <div class="rw-rail" data-anchor="rail"></div>
    </div>
    <div class="rw-compact">
      <span class="gx-st gx-st-bad">Delayed</span> <b>Line ${esc(d.ln)} · ${esc(d.qty)} × PowerFlex 753</b> now ${esc(d.now)}
      <span class="rw-sep"></span>${o.lines.filter((l) => l.status === "ready").length} lines ready to ship · ${o.lines.filter((l) => l.status === "shipped").length} delivered
      <button class="rw-toggle" onclick="document.body.classList.toggle('show-lines')">Order lines</button>
    </div>
    <div class="rw-lines">
      <div class="notice"><b>Delivery date changed</b> for line ${esc(d.ln)} (${esc(d.qty)} × PowerFlex 753): ${esc(d.was)} → <b>${esc(d.now)}</b></div>
      <div class="lines-wrap">
        <table class="lines">
          <thead><tr><th>Line</th><th>Catalog no.</th><th>Description</th><th>Qty</th><th>Delivery</th><th>Status</th></tr></thead>
          <tbody>${o.lines.map((l) => {
            const [label, tone] = STATUS[l.status];
            return `<tr class="${l.status === "delayed" ? "is-delayed" : ""}">
              <td>${esc(l.ln)}</td><td><code>${esc(l.cat)}</code></td><td>${esc(l.name)}${l.reason ? `<small>${esc(l.reason)}</small>` : ""}</td><td>${esc(l.qty)}</td>
              <td>${l.status === "delayed" ? `<s>${esc(l.was)}</s><b class="late">${esc(l.now)}</b>` : esc(l.note)}</td>
              <td><span class="gx-st gx-st-${tone}">${esc(label)}</span></td></tr>` +
              (l.anchor ? `<tr class="anchor-row"><td colspan="6"><div class="anchor" data-anchor="${esc(l.anchor)}"></div></td></tr>` : "");
          }).join("")}</tbody>
        </table>
      </div>
    </div>
    <section class="ws" aria-label="${esc(a.line)} workspace">
      <header class="ws-band">
        <div><small>${esc(a.plant)} · ${esc(a.lineKind)}</small><h2>${esc(a.line)} workspace</h2></div>
        <span class="ws-live"><i></i>Live · updated just now</span>
      </header>
      <div class="ws-body">
        <div data-anchor="ws-hero"></div>
        <div class="ws-grid"><div data-anchor="ws-main" class="ws-main"></div><div data-anchor="ws-options"></div></div>
      </div>
    </section>`;
  },
  // fixture lines for ?orb=open screenshots only (taken from a harness run's transcript)
  sampleCaptions: [
    ["agent", "Hi Dana, how can I help today?"],
    ["user", "What's going on with order 8100234571? Why is my drive delayed?"],
    ["agent", "Those two PowerFlex 753 drives are now due Friday the thirteenth, about three weeks late, because of a power module shortage. Is this holding up your production line?"],
    ["user", "Yes, it's holding up line four."],
    ["agent", "I've pulled up the Line 4 workspace. Your fastest option is an in-stock PowerFlex 755, here Saturday. Do you want it?"],
  ],
  order: ["rail", "status", "line_q", "hero", "handoff", "plan", "fix", "confirm_q", "options"],
  half: [],
  intents: {
    asks_order_status: "order status", line_down: "line is down", line_not_down: "line not down", not_sure: "not sure",
    wants_alternative_part: "wants alternative", places_replacement_order: "place replacement", wants_expedite: "wants expedite", wants_ship_rest_now: "ship rest now",
    wants_specialist: "wants specialist", confirms: "yes, do it", affirm: "yes", negate: "no", other: "listening…",
  },
  actions: { status: "showing order status", line: "opening the line workspace", alternative: "staging the replacement", place: "placing the replacement", confirm: "placing the order", ship_rest: "shipping the rest", expedite: "requesting expedite", specialist: "bringing in a specialist", decline: "standing down" },
};
