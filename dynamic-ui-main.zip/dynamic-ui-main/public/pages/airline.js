// The airline scenario's page: "Manage my trip" with the cancelled flight.
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
const PLANE = `<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M21 16v-2l-8-5V3.5a1.5 1.5 0 0 0-3 0V9l-8 5v2l8-2.5V19l-2 1.5V22l3.5-1 3.5 1v-1.5L13 19v-5.5z"/></svg>`;

export default {
  title: (b) => (b.dataset === "delta" ? `My Trips · ${b.name}` : `Manage my trip · ${b.name}`),
  promo: "Travel advisory: storms in the Midwest are affecting some flights today.",
  nav: (b) => (b.dataset === "delta" ? ["Book", "Check In", "*My Trips", "Flight Status", "SkyMiles"] : ["Book", "*My trips", "Check in", "Flight status", `${b.name.split(" ")[0]} Rewards`]),
  user: ({ trip }) => ({ initials: trip.passenger.first[0] + trip.passenger.last[0], name: `${trip.passenger.first} ${trip.passenger.last[0]}.` }),
  // before the conversation the space is ordinary self-service; the first card from the
  // conversation takes it over (app.js), and the heading switches to canvasTitleLive
  canvasTitle: ({ trip }) => `Your options for ${trip.cancelled.flight}`,
  canvasTitleLive: "Your rebooking",
  empty: (b, { trip } = {}) => {
    const delta = b.dataset === "delta";
    const I = {
      rebook: '<path d="M21 16v-2l-8-5V3.5a1.5 1.5 0 0 0-3 0V9l-8 5v2l8-2.5V19l-2 1.5V22l3.5-1 3.5 1v-1.5L13 19v-5.5z" fill="currentColor"/>',
      refund: '<path d="M3 7h18v10H3z" fill="none" stroke="currentColor" stroke-width="2"/><circle cx="12" cy="12" r="2.5" fill="none" stroke="currentColor" stroke-width="2"/><path d="M6 10v4M18 10v4" stroke="currentColor" stroke-width="2"/>',
      hotel: '<path d="M7 13a3 3 0 1 0 0-6 3 3 0 0 0 0 6zm12-6h-8v7H3V5H1v15h2v-3h18v3h2v-9a4 4 0 0 0-4-4z" fill="currentColor"/>',
      credit: '<path d="M4 6h16v12H4z" fill="none" stroke="currentColor" stroke-width="2"/><path d="M4 10h16" stroke="currentColor" stroke-width="2"/><path d="M7 14h4" stroke="currentColor" stroke-width="2"/>',
    };
    const tile = (k, title, line, act) => `<button class="opt-tile"${act ? ` data-act="${act}" data-label="${title}"` : ""}><span class="opt-ic"><svg viewBox="0 0 24 24" aria-hidden="true">${I[k]}</svg></span><b>${title}</b><span>${line}</span><i aria-hidden="true">›</i></button>`;
    return `<div class="opt-tiles">
      ${tile("rebook", "Rebook on another flight", delta ? "At no cost, on the next available Delta flights" : "Free on any available flight to Chicago", "show_options")}
      ${tile("refund", delta ? "Request a refund" : "Get a refund", delta ? "To your original form of payment" : "Full refund to your original payment", delta ? "refund" : "")}
      ${tile("hotel", delta ? "Hotel &amp; meal vouchers" : "Hotel &amp; meals", delta ? "When you're stuck overnight away from home" : "Covered if you're staying overnight")}
      ${tile("credit", delta ? "Delta eCredit" : "Travel credit", delta ? "Keep the value for a future trip, valid 5 years" : "Keep the value for a future trip, plus a bonus", delta ? "ecredit" : "")}
    </div>`;
  },
  hint: "<i>“My flight got cancelled. What are my options?”</i>",
  top: ({ trip }) => `
    <div class="crumbs">My trips <span>/</span> <b>${esc(trip.record)}</b></div>
    <h1>${trip.recordLabel === "Confirmation #" ? "Trip details" : "Manage my trip"}</h1>
    <article class="trip">
      <div class="trip-main">
        <div class="trip-top"><span class="chip chip-bad">Cancelled</span><span class="trip-meta">${esc(trip.cancelled.flight)} · ${esc(trip.cancelled.date)} · ${esc(trip.cancelled.depart)}${trip.cancelled.gate ? ` · Gate ${esc(trip.cancelled.gate)}` : ""}</span></div>
        <div class="trip-route">
          <div><b>${esc(trip.from.code)}</b><small>${esc(trip.from.city)}</small></div>
          <div class="trip-line"><span></span>${PLANE}<span></span></div>
          <div class="right"><b>${esc(trip.to.code)}</b><small>${esc(trip.to.city)}</small></div>
        </div>
      </div>
      <dl class="trip-facts">
        <div><dt>Passenger</dt><dd>${esc(trip.passenger.first)} ${esc(trip.passenger.last)}</dd></div>
        <div><dt>${esc(trip.recordLabel || "Booking")}</dt><dd>${esc(trip.record)}</dd></div>
        <div><dt>Original seat</dt><dd>${esc(trip.cancelled.seat)}${trip.cancelled.cabin ? ` · ${esc(trip.cancelled.cabin)}` : ""}</dd></div>
        ${trip.passenger.program === "SkyMiles" ? `<div><dt>SkyMiles</dt><dd class="tier">${esc(trip.passenger.tier)}</dd></div>` : ""}
      </dl>
    </article>`,
  // fixture lines for ?orb=open screenshots only (taken from a harness run's transcript)
  sampleCaptions: [
    ["agent", "Hi Jordan, I see your flight to Chicago was cancelled. I'm really sorry. How can I help?"],
    ["user", "Hi, my flight to Chicago got cancelled. What are my options?"],
    ["agent", "I've put three options on the screen; the earliest leaves tonight at nine forty with one stop in Denver. Which works for you?"],
    ["user", "Is there anything nonstop?"],
    ["agent", "Sure, I've put a comparison up for you. The seven fifteen tomorrow morning looks best."],
  ],
  order: ["disruption", "boarding_pass", "options", "compare", "hotel_q", "voucher_hotel", "voucher_meal", "confirm_q"],
  half: ["voucher_hotel", "voucher_meal"],
  intents: {
    rebooking_options: "wants options", nonstop: "wants nonstop", earliest: "wants earliest", choose_option: "picking a flight",
    hotel_yes: "needs a hotel", hotel_no: "no hotel", confirm: "confirm", affirm: "yes", negate: "no", other: "listening…",
  },
  actions: { show_options: "showing options", nonstop: "comparing nonstops", earliest: "comparing earliest", choose: "holding seat", hotel: "booking hotel", confirm: "confirming" },
};
