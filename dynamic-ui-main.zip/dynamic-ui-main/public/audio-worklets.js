// AudioWorklet processors. The AudioContext runs at 24 kHz, GPT-Live's PCM rate.

// Microphone: posts Float32 blocks to the main thread.
class MicProcessor extends AudioWorkletProcessor {
  process(inputs) {
    const ch = inputs[0] && inputs[0][0];
    if (ch) this.port.postMessage(ch.slice(0));
    return true;
  }
}
registerProcessor("mic-processor", MicProcessor);

// Speaker: plays queued Int16 PCM; drops the backlog if it grows past 1.5 s so the
// voice never lags far behind the conversation. Reports the output level.
class PlayerProcessor extends AudioWorkletProcessor {
  constructor() {
    super();
    this.queue = [];
    this.cur = null;
    this.pos = 0;
    this.queued = 0;
    this.level = 0;
    this.n = 0;
    this.port.onmessage = (e) => {
      if (e.data === "flush") { this.queue = []; this.cur = null; this.queued = 0; return; }
      const pcm = new Int16Array(e.data);
      this.queue.push(pcm);
      this.queued += pcm.length;
      while (this.queued > sampleRate * 1.5 && this.queue.length > 1) this.queued -= this.queue.shift().length;
    };
  }
  process(_inputs, outputs) {
    const out = outputs[0][0];
    let sum = 0;
    for (let i = 0; i < out.length; i++) {
      if (!this.cur || this.pos >= this.cur.length) {
        this.cur = this.queue.shift() || null;
        this.pos = 0;
        if (!this.cur) { out[i] = 0; continue; }
        this.queued -= this.cur.length;
      }
      const v = this.cur[this.pos++] / 32768;
      out[i] = v;
      sum += v * v;
    }
    this.level = Math.max(Math.sqrt(sum / out.length), this.level * 0.85);
    if (++this.n % 6 === 0) this.port.postMessage(this.level);
    return true;
  }
}
registerProcessor("player-processor", PlayerProcessor);
