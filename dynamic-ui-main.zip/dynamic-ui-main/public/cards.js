// Airline card templates for Say it, see it, registered as extra element types in
// adxGenUI's renderer (adx/components.js). The backend fills them with data; the page
// never generates free-form UI. Buttons carry data-act so a tap goes back to the
// conversation (see app.js).
import { esc, registerRenderer, renderElement } from "./adx/components.js";

const plane = `<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M21 16v-2l-8-5V3.5a1.5 1.5 0 0 0-3 0V9l-8 5v2l8-2.5V19l-2 1.5V22l3.5-1 3.5 1v-1.5L13 19v-5.5z"/></svg>`;
const icon = {
  hotel: `<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M7 13a3 3 0 1 0 0-6 3 3 0 0 0 0 6zm12-6h-8v7H3V5H1v15h2v-3h18v3h2v-9a4 4 0 0 0-4-4z"/></svg>`,
  meal: `<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M11 9H9V2H7v7H5V2H3v7c0 2.1 1.7 3.9 3.8 4V22h2.5v-9c2.1-.1 3.7-1.9 3.7-4V2h-2v7zm5-3v8h2.5v8H21V2c-2.8 0-5 2.2-5 4z"/></svg>`,
};

const route = (from, to, mid) => `<div class="gx-route"><b>${esc(from)}</b><span class="gx-route-line">${mid ? `<i>${esc(mid)}</i>` : ""}${plane}</span><b>${esc(to)}</b></div>`;

registerRenderer("disruption_summary", (el) => `
  <div class="gx-disrupt gx-sev-${esc(el.severity)}">
    <div class="gx-disrupt-head">
      <span class="gx-pill gx-pill-bad">${esc(el.eyebrow)}</span>
      <span class="gx-muted">${esc(el.flight)} · ${esc(el.date)} · ${esc(el.reason)}</span>
    </div>
    <h3>${esc(el.headline)}</h3>
    <div class="gx-disrupt-route">
      <div><small>${esc(el.from.city)}</small><s>${esc(el.depart)}</s></div>
      ${route(el.from.code, el.to.code)}
      <div class="gx-right"><small>${esc(el.to.city)}</small><s>${esc(el.arrive)}</s></div>
    </div>
    <ul class="gx-protect">${el.protections.map((p) => `<li>${esc(p)}</li>`).join("")}</ul>
  </div>`, "Disruption summary");

registerRenderer("flight_options", (el) => `
  <section class="gx-flights">
    <div class="gx-flights-head"><div><div class="gx-eyebrow">${esc(el.eyebrow)}</div><h3>${esc(el.heading)}</h3></div><p class="gx-muted">${esc(el.subheading)}</p></div>
    <div class="gx-flights-row">${el.options.map((o) => `
      <article class="gx-flight ${o.state ? "is-" + esc(o.state) : ""}" data-n="${o.n}">
        <div class="gx-flight-top"><span class="gx-tag">${esc(o.label)}</span><span class="gx-muted">${esc(o.flight)}</span></div>
        <div class="gx-flight-date">${esc(o.date)}</div>
        <div class="gx-times"><b>${esc(o.depart)}</b>${route("", "", o.stops ? "1 stop" : "Nonstop")}<b>${esc(o.arrive)}${o.arriveNote ? `<sup>${esc(o.arriveNote)}</sup>` : ""}</b></div>
        <div class="gx-flight-meta"><span>${o.stops ? `via ${esc(o.via)}` : "Nonstop"}</span><span>${esc(o.duration)}</span></div>
        ${o.cabin ? `<div class="gx-flight-cabin">${esc(o.cabin)}<span>${esc(o.aircraft)}</span></div>` : ""}
        <div class="gx-flight-foot">
          <span class="gx-seats ${o.seatsLeft <= 3 ? "is-low" : ""}">${o.seatsLeft} seats left</span>
          <span class="gx-fare ${o.fareDiff ? "is-up" : ""}">${esc(o.fare)}</span>
        </div>
        ${o.state === "held" ? `<div class="gx-held">Seat ${esc(o.seat)} held for you</div>`
          : o.state === "confirmed" ? `<div class="gx-held gx-ok">Confirmed · seat ${esc(o.seat)}</div>`
          : o.state === "dimmed" ? "" : `<button class="gx-cta gx-choose" data-act="choose" data-value="${o.n}" data-label="Choose ${esc(o.depart)}">Choose this flight</button>`}
      </article>`).join("")}
    </div>
  </section>`, "Rebooking options");

registerRenderer("flight_compare", (el) => `
  <section class="gx-compare">
    <div class="gx-eyebrow">${esc(el.eyebrow)}</div><h3>${esc(el.heading)}</h3>
    <table>
      <thead><tr><th></th>${el.columns.map((c) => `<th class="${c.n === el.recommend ? "is-rec" : ""}">${c.n === el.recommend ? `<span class="gx-tag">Recommended</span>` : `<span class="gx-tag gx-tag-quiet">${esc(c.label)}</span>`}<b>${esc(c.depart)}</b><small>${esc(c.flight)}</small></th>`).join("")}</tr></thead>
      <tbody>${el.rows.map((r) => `<tr><td>${esc(r.label)}</td>${r.values.map((v, i) => `<td class="${r.best === i ? "is-best" : ""}">${esc(v)}</td>`).join("")}</tr>`).join("")}</tbody>
      <tfoot><tr><td></td>${el.columns.map((c) => `<td><button class="gx-cta ${c.n === el.recommend ? "" : "gx-cta-ghost"}" data-act="choose" data-value="${c.n}" data-label="Choose ${esc(c.depart)}">Choose ${esc(c.depart)}</button></td>`).join("")}</tr></tfoot>
    </table>
  </section>`, "Comparison");

registerRenderer("voucher", (el) => `
  <div class="gx-voucher gx-voucher-${esc(el.kind)}">
    <div class="gx-voucher-icon">${icon[el.kind] || ""}</div>
    <div class="gx-voucher-body">
      <div class="gx-eyebrow">${esc(el.eyebrow)}</div>
      <h3>${esc(el.title)}</h3>
      <p class="gx-muted">${esc(el.detail)}</p>
      <ul>${el.lines.map((l) => `<li>${esc(l)}</li>`).join("")}</ul>
    </div>
    <div class="gx-voucher-stub"><small>Code</small><b>${esc(el.code)}</b><span>${esc(el.value)}</span></div>
  </div>`, "Voucher");

registerRenderer("confirm_bar", (el) => `
  <div class="gx-confirm">
    <div><div class="gx-eyebrow">${esc(el.eyebrow)}</div><h3>${esc(el.headline)}</h3><p class="gx-muted">${esc(el.body)}</p></div>
    <button class="gx-cta" data-act="${esc(el.action)}" data-label="${esc(el.ctaLabel)}">${esc(el.ctaLabel)}</button>
  </div>`, "Confirm bar");

// a decorative, deterministic 2D code (not scannable)
function code(seed) {
  let h = 2166136261;
  for (const ch of seed) h = Math.imul(h ^ ch.charCodeAt(0), 16777619);
  const n = 21, cells = [];
  for (let y = 0; y < n; y++) for (let x = 0; x < n; x++) {
    const finder = (x < 7 && y < 7) || (x >= n - 7 && y < 7) || (x < 7 && y >= n - 7);
    let on;
    if (finder) { const fx = x >= n - 7 ? x - (n - 7) : x, fy = y >= n - 7 ? y - (n - 7) : y; on = fx === 0 || fy === 0 || fx === 6 || fy === 6 || (fx >= 2 && fx <= 4 && fy >= 2 && fy <= 4); }
    else { h ^= h << 13; h ^= h >>> 17; h ^= h << 5; on = (h >>> 0) % 100 < 46; }
    if (on) cells.push(`<rect x="${x}" y="${y}" width="1" height="1"/>`);
  }
  return `<svg viewBox="-1 -1 23 23" class="gx-bp-code" aria-label="Boarding pass code">${cells.join("")}</svg>`;
}

registerRenderer("boarding_pass", (el) => `
  <div class="gx-bp">
    <div class="gx-bp-main">
      <div class="gx-bp-top"><span class="gx-eyebrow">${esc(el.eyebrow)}</span><span class="gx-pill gx-pill-ok">Confirmed</span></div>
      <div class="gx-bp-route">
        <div><b>${esc(el.from.code)}</b><small>${esc(el.from.city)}</small></div>
        ${route("", "", el.flight)}
        <div class="gx-right"><b>${esc(el.to.code)}</b><small>${esc(el.to.city)}</small></div>
      </div>
      <dl class="gx-bp-grid">
        <div><dt>Passenger</dt><dd>${esc(el.passenger)}</dd></div>
        <div><dt>Date</dt><dd>${esc(el.date)}</dd></div>
        <div><dt>Departs</dt><dd>${esc(el.depart)}</dd></div>
        <div><dt>Boarding</dt><dd>${esc(el.boarding)}</dd></div>
        <div><dt>Gate</dt><dd>${esc(el.gate)}</dd></div>
        <div><dt>Seat</dt><dd>${esc(el.seat)}</dd></div>
        <div><dt>${esc(el.groupLabel || "Group")}</dt><dd>${esc(el.group)}</dd></div>
        <div><dt>${esc(el.recordLabel || "Booking")}</dt><dd>${esc(el.record)}</dd></div>
      </dl>
    </div>
    <div class="gx-bp-stub">${code(el.record + el.flight + el.seat)}<small>${esc(el.flight)} · ${esc(el.seat)}</small></div>
  </div>`, "Boarding pass");

/** A backend card → HTML through adxGenUI's renderElement (which sets --accent from
 *  accentColor, so the brand's accent is the default). */
export function renderCard(card, brandAccent) {
  const { accentColor, ...element } = card;
  return renderElement({ accentColor: accentColor || brandAccent, element });
}
