// Say it, see it: the page. Themes itself from the brand profile (adxGenUI theming),
// relays the mic to the local server, plays the agent, shows captions, and renders the
// cards the conversation sends (adxGenUI renderer + cards.js templates).
import { hydrate, setCurrency } from "./adx/components.js";
import { themeVars, loadFonts } from "./adx/theme.js";
import { renderCard } from "./cards.js";
import "./cards-b2b.js";
import airlinePage from "./pages/airline.js";
import rockwellPage from "./pages/rockwell.js";
import { startAudio } from "./audio.js";

const $ = (id) => document.getElementById(id);
const params = new URLSearchParams(location.search);
const brandId = params.get("brand") || "";
const scenarioId = params.get("scenario") || "";
const query = () => { const q = new URLSearchParams(); if (scenarioId) q.set("scenario", scenarioId); if (brandId) q.set("brand", brandId); const s = q.toString(); return s ? `?${s}` : ""; };
let brand, cfg, P, ws, audio, muted = false;

// ---- page --------------------------------------------------------------------------
async function init() {
  cfg = await (await fetch(`/api/config${query()}`)).json();
  brand = cfg.brand;
  P = cfg.scenario === "rockwell" ? rockwellPage : airlinePage;
  document.body.dataset.scenario = cfg.scenario;
  document.body.dataset.brand = brand.id;
  for (const [k, v] of Object.entries(themeVars(brand))) document.body.style.setProperty(k, v);
  loadFonts(brand);
  setCurrency("$");
  document.title = P.title(brand);
  $("promo").textContent = P.promo;
  if (brand.logoSvg) { $("logo-mark").innerHTML = brand.logoSvg; $("logo-mark").classList.add("is-svg"); }
  else $("logo-mark").textContent = brand.logoMark || "";
  $("logo-mark").hidden = !brand.logoMark && !brand.logoSvg;
  $("logo-text").textContent = brand.logoText || brand.name;
  $("nav").innerHTML = P.nav(brand).map((n) => `<a${n[0] === "*" ? ' class="on"' : ""}>${n.replace(/^\*/, "")}</a>`).join("");
  const u = P.user(cfg);
  $("avatar").textContent = u.initials;
  $("user-name").textContent = u.name;
  $("page-top").innerHTML = P.top(cfg);
  $("canvas-title").textContent = P.canvasTitle(cfg);
  $("empty").innerHTML = P.empty(brand, cfg);
  $("nx-ask").textContent = `Ask ${brand.agentName}`;
  $("hint").innerHTML = P.hint;
  for (const el of document.querySelectorAll(".agent-name")) el.textContent = brand.agentName;
  $("agent-sub").textContent = brand.agentTitle || `${brand.name} assistant`;
  $("talk").onclick = () => (ws ? stop() : start());
  $("orb").onclick = () => (ws ? stop() : start()); // the orb starts and ends the session
  $("nx-expand").onclick = () => openPanel(!$("nx").classList.contains("open"));
  $("nx-close").onclick = () => openPanel(false);
  loadLogos();
  if (params.has("orb")) forceOrb(params.get("orb"));
  $("mute").onclick = () => { muted = !muted; audio?.setMuted(muted); $("mute").textContent = muted ? "Unmute" : "Mute"; $("mute").classList.toggle("on", muted); };
  $("show-signals").onchange = (e) => document.body.classList.toggle("hide-signals", !e.target.checked);
  hydrate(document.querySelector(".page"));
  document.querySelector(".page").addEventListener("click", onCanvasClick);
  if (params.has("autostart")) start();
  if (params.has("preview")) preview(Number(params.get("preview")) || 99);
}

// ---- session -----------------------------------------------------------------------
async function start() {
  setState("Connecting…", "busy");
  orb("thinking");
  $("talk").classList.add("on");
  $("talk-label").textContent = "End";
  try {
    audio = await startAudio({
      raw: params.has("rawmic"),
      silent: params.has("silent"),
      onMicFrame: (buf) => ws?.readyState === 1 && ws.send(buf),
      onLevel: onAgentLevel,
      onMicLevel: (l) => { const v = Math.min(1, l * 8).toFixed(3); $("talk").style.setProperty("--mic", v); $("nx").style.setProperty("--mic", v); },
    });
  } catch (e) {
    setState("Microphone blocked", "bad");
    reset();
    return;
  }
  ws = new WebSocket(`${location.protocol === "https:" ? "wss" : "ws"}://${location.host}/live${query()}`);
  ws.binaryType = "arraybuffer";
  ws.onmessage = (m) => (typeof m.data === "string" ? onMessage(JSON.parse(m.data)) : audio?.play(m.data));
  ws.onclose = () => { setState("Ended", ""); reset(); };
  $("mute").hidden = false;
  $("captions").innerHTML = "";
}

// ?preview=N: the first N steps of the happy path, straight from the mock backend; no
// voice session and no audio (for checking the cards' look)
async function preview(n) {
  const steps = await (await fetch(`/api/preview${query()}`)).json();
  for (const st of steps.slice(0, n)) applyUi(st);
  if (!forced) setState("Preview (no voice)", "");
}

// ending hangs up (closes the session); the orb goes back to idle
function stop() { ws?.close(); reset(); setState("Ended", ""); }
function reset() {
  audio?.stop().catch(() => {});
  audio = null; ws = null;
  $("talk").classList.remove("on");
  $("talk-label").textContent = "Talk";
  $("mute").hidden = true;
  $("live-dot").classList.remove("on");
  orb("idle");
}
function setState(text, cls) { $("state").textContent = text; $("state").className = `state ${cls || ""}`; }

function onMessage(e) {
  switch (e.type) {
    case "status":
      if (e.state === "live") { setState("Listening", "ok"); $("live-dot").classList.add("on"); orb("listening"); }
      else if (e.state === "error" || e.state === "closed") {
        setState(e.state === "error" ? (e.message && e.message.length < 90 ? e.message : "Connection error") : "Ended", e.state === "error" ? "bad" : "");
        if (e.state === "error" && e.message) openPanel(true); // e.g. "the demo is busy"
      }
      break;
    case "caption": caption(e.role, e.delta, e.start_ms); break;
    case "decision": signal(e); break;
    case "delegation": setState("Checking…", "busy"); thinkingUntil = performance.now() + 4000; orb("thinking"); break;
    case "answered": setState("Listening", "ok"); break;
    case "ui": applyUi(e); break;
  }
}

// ---- the orb: idle → listening → speaking / thinking ------------------------------
let orbState = "idle", speakingUntil = 0, thinkingUntil = 0, forced = false;
function orb(state) {
  if (forced) return;
  orbState = state;
  $("nx").dataset.state = state;
  $("orb").setAttribute("aria-label", state === "idle" ? "Talk to the assistant" : "End the conversation");
}
// the agent's real output level (from the player worklet) drives the speaking rings
function onAgentLevel(l) {
  const v = Math.min(1, l * 6);
  $("nx").style.setProperty("--lvl", v.toFixed(3));
  if (!ws) return;
  const now = performance.now();
  if (v > 0.04) { speakingUntil = now + 450; thinkingUntil = 0; }
  const next = now < speakingUntil ? "speaking" : now < thinkingUntil ? "thinking" : "listening";
  if (next !== orbState && orbState !== "idle") orb(next);
}
function openPanel(open) {
  $("nx").classList.toggle("open", open);
  $("nx-panel").setAttribute("aria-hidden", String(!open));
  $("nx-expand").setAttribute("aria-expanded", String(open));
  $("nx-expand-label").textContent = open ? "Hide conversation" : "Show conversation";
  if (open) $("captions").scrollTop = $("captions").scrollHeight;
}
// one live caption line beside the collapsed orb
let peekTimer;
function peek(text) {
  const el = $("nx-caption");
  el.textContent = text.length > 90 ? "…" + text.slice(-88) : text;
  el.classList.add("on");
  clearTimeout(peekTimer);
  peekTimer = setTimeout(() => el.classList.remove("on"), 3500);
}
async function loadLogos() {
  const [mark, word] = await Promise.all(["/brand/netomi-mark.svg", "/brand/netomi-wordmark.svg"].map(async (u) => (await fetch(u)).text().catch(() => "")));
  document.querySelectorAll(".nx-logo").forEach((el) => (el.innerHTML = mark));
  document.querySelectorAll(".nx-wordmark").forEach((el) => (el.innerHTML = word));
}
// ?orb=listening|speaking|thinking|open (comma-separated): show a state for screenshots,
// with no session and no audio; "speaking" gets a synthetic level so the rings move
function forceOrb(spec) {
  const want = spec.split(",");
  const state = want.find((w) => ["listening", "speaking", "thinking"].includes(w));
  if (state) { orb(state); forced = true; }
  if (state === "speaking") {
    let t = 0;
    setInterval(() => { t += 0.12; $("nx").style.setProperty("--lvl", (0.35 + 0.3 * Math.abs(Math.sin(t)) + 0.15 * Math.sin(t * 3.1)).toFixed(3)); }, 50);
  }
  if (state === "listening") $("nx").style.setProperty("--mic", "0.25");
  if (want.includes("open")) {
    openPanel(true);
    // fixture captions so the panel can be checked visually (not a real conversation)
    if (P.sampleCaptions) { $("captions").innerHTML = ""; for (const [role, text] of P.sampleCaptions) { capLast = null; caption(role, text); } }
    setState(state ? state[0].toUpperCase() + state.slice(1) : "Ready", "ok");
  }
  if (want.includes("caption") && P.sampleCaptions) peek(P.sampleCaptions.at(-1)[1]);
}

// ---- captions ----------------------------------------------------------------------
let capLast = null;
function caption(role, delta, startMs) {
  const box = $("captions");
  const gap = capLast && capLast.role === role && startMs != null && capLast.end != null ? startMs - capLast.end : 0;
  if (!capLast || capLast.role !== role || gap > 1500) {
    const p = document.createElement("p");
    p.className = `cap cap-${role}`;
    p.innerHTML = `<small>${role === "agent" ? brand.agentName : "You"}</small><span></span>`;
    box.append(p);
    capLast = { role, el: p.querySelector("span") };
  }
  capLast.el.textContent += delta;
  capLast.end = startMs != null ? startMs + 200 : capLast.end;
  if (role === "agent") { setState("Speaking", "ok"); peek(capLast.el.textContent); }
  box.scrollTop = box.scrollHeight;
}

// ---- what the Decisions API understood ----------------------------------------------
function signal(e) {
  $("signals").hidden = false;
  const chips = [];
  const i = e.answers.intent, o = e.answers.option;
  if (i) chips.push(`<span class="sig ${i.choice === "other" ? "quiet" : ""}">${P.intents[i.choice] || i.choice}<b>${Math.round(i.confidence * 100)}%</b></span>`);
  if (o && o.choice !== "none") chips.push(`<span class="sig">${o.choice.replace("_", " ")}<b>${Math.round(o.confidence * 100)}%</b></span>`);
  $("signal-chips").innerHTML = chips.join("");
  if (e.fired) {
    const [name] = e.fired.split(":");
    const line = document.createElement("div");
    line.innerHTML = `<b>→ ${P.actions[name] || name}</b> while you were still talking`;
    $("signal-log").prepend(line);
    while ($("signal-log").children.length > 3) $("signal-log").lastChild.remove();
  }
}

// ---- cards -------------------------------------------------------------------------
const cardsById = new Map();
const rank = (id) => P.order.indexOf(id);
const allSlots = () => [...document.querySelectorAll(".page .slot:not(.leaving)")];

// a card with `anchor` renders inline in that spot of the page (e.g. under the delayed
// order line); the rest go to the canvas
function applyUi({ upsert = [], remove = [] }) {
  for (const id of remove) {
    const el = document.querySelector(`.page [data-card="${id}"]`);
    if (el) { el.classList.add("leaving"); setTimeout(() => el.remove(), 260); }
    cardsById.delete(id);
  }
  let focus = null;
  const changed = [];
  for (const card of upsert) {
    const had = cardsById.get(card.id);
    cardsById.set(card.id, card);
    const host = (card.anchor && document.querySelector(`[data-anchor="${card.anchor}"]`)) || $("canvas");
    let slot = host.querySelector(`[data-card="${card.id}"]:not(.leaving)`);
    const fresh = !slot;
    if (fresh) {
      slot = document.createElement("div");
      slot.className = `slot entering${P.half.includes(card.id) ? " half" : ""}`;
      slot.dataset.card = card.id;
      const next = [...host.querySelectorAll(".slot:not(.leaving)")].find((s) => rank(s.dataset.card) > rank(card.id));
      host.insertBefore(slot, next || null);
      requestAnimationFrame(() => requestAnimationFrame(() => slot.classList.remove("entering")));
    } else if (card.type === "micro_elicit" && had && (had.answered ?? null) === (card.answered ?? null)) {
      continue; // unchanged question: keep its local state
    } else {
      slot.classList.remove("updated");
      void slot.offsetWidth;
      slot.classList.add("updated");
    }
    slot.innerHTML = renderCard(card, brand.colors.accent);
    animate(slot, card.id);
    if (card.type === "micro_elicit" && card.answered != null) showAnswered(slot, card);
    if (card.type !== "step_rail") changed.push(slot);
    focus = focus || (fresh ? slot : null);
  }
  // the turn's key card (the backend lists it first) is brought into view and pulses;
  // falls back to the first new card (airline)
  if (cfg.scenario !== "airline" && changed.length) focus = changed[0];
  // the first card from the conversation takes over the page's own options block
  if ([...cardsById.values()].some((c) => !c.anchor) && !$("empty").classList.contains("gone")) {
    $("empty").classList.add("gone");
    $("adx-badge").hidden = false;
    if (P.canvasTitleLive) $("canvas-title").textContent = P.canvasTitleLive;
  }
  if (focus) setTimeout(() => {
    const tall = focus.offsetHeight > innerHeight * 0.55;
    focus.scrollIntoView({ behavior: REDUCED ? "auto" : "smooth", block: cfg.scenario === "airline" ? "nearest" : tall ? "start" : "center" });
    if (cfg.scenario !== "airline") { focus.classList.remove("pulse"); void focus.offsetWidth; focus.classList.add("pulse"); }
  }, 120);
  ws?.readyState === 1 && ws.send(JSON.stringify({ type: "rendered", ids: allSlots().map((s) => s.dataset.card) }));
}

// values that animate from what they were: bar widths (data-w, %) and counters (data-count)
const REDUCED = matchMedia("(prefers-reduced-motion: reduce)").matches;
const lastValues = new Map();
function animate(slot, id) {
  slot.querySelectorAll("[data-w]").forEach((el, i) => {
    const key = `${id}:w${i}`, to = Number(el.dataset.w), from = lastValues.get(key) ?? to;
    lastValues.set(key, to);
    if (REDUCED || from === to) return;
    el.style.transition = "none";
    el.style.width = `${from}%`;
    void el.offsetWidth;
    el.style.transition = "";
    requestAnimationFrame(() => (el.style.width = `${to}%`));
  });
  slot.querySelectorAll("[data-count]").forEach((el, i) => {
    const key = `${id}:c${i}`, to = Number(el.dataset.count), from = lastValues.get(key) ?? to;
    lastValues.set(key, to);
    if (REDUCED || from === to) return;
    const t0 = performance.now(), dur = 1400;
    const step = (t) => {
      const k = Math.min(1, (t - t0) / dur), e = 1 - Math.pow(1 - k, 3);
      el.textContent = Math.round(from + (to - from) * e);
      if (k < 1) requestAnimationFrame(step);
    };
    el.textContent = from;
    requestAnimationFrame(step);
  });
}

// an answer given by voice: show adxGenUI's own answered state (and its follow-on card)
function showAnswered(slot, card) {
  const i = (card.choices || []).findIndex((c) => c.value === card.answered);
  const btn = slot.querySelector(`.gx-choice[data-i="${i}"]`);
  if (!btn) return;
  btn.setAttribute("aria-pressed", "true");
  const submit = slot.querySelector(".gx-submit");
  if (submit) { submit.disabled = false; submit.click(); }
}

function onCanvasClick(e) {
  const btn = e.target.closest("button, .gx-ctab-btn");
  const slot = e.target.closest(".slot");
  if (!btn) return;
  if (!slot) { if (btn.dataset.act) tap({ action: btn.dataset.act, label: btn.dataset.label }); return; } // page tiles
  const card = cardsById.get(slot.dataset.card);
  // one-tap micro-question (adxGenUI micro_elicit): the tap is the answer
  const choice = btn.closest(".gx-choice");
  if (choice) {
    const pick = card?.choices?.[Number(choice.dataset.i)];
    if (card?.oneTap && pick) {
      slot.querySelector(".gx-submit")?.click(); // adxGenUI's own "answered" state
      card.answered = pick.value;
      tap({ action: card.oneTap, value: pick.value, label: pick.label });
    }
    return;
  }
  // adxGenUI's B2B call-to-action band
  if (btn.classList.contains("gx-ctab-btn") && card?.tapAction) return tap({ action: card.tapAction, label: card.ctaLabel });
  if (btn.dataset.act) tap({ action: btn.dataset.act, value: btn.dataset.value, label: btn.dataset.label });
}

function tap(msg) {
  if (ws?.readyState !== 1) {
    // no conversation yet: point to the orb rather than act
    $("nx").classList.remove("nudge"); void $("nx").offsetWidth; $("nx").classList.add("nudge");
    setTimeout(() => $("nx").classList.remove("nudge"), 1600);
    return;
  }
  ws.send(JSON.stringify({ type: "tap", ...msg }));
}

window.__demo = { cards: () => allSlots().map((s) => s.dataset.card) };
init();
