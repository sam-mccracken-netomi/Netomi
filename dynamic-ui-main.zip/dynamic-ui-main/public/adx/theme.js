// Copied from adxWebSdk/adxGenUI/public/site.js (2026-10-21): brand profile -> CSS variables.
import { color } from "./components.js";
const cssFont = (family, fallback) =>
  [String(family || "").replace(/[;{}<>]/g, ""), fallback ? `"${fallback}"` : "", '"Helvetica Neue", Helvetica, Arial, sans-serif']
    .filter(Boolean)
    .join(", ");

export function themeVars(b) {
  const c = b.colors;
  const t = b.typography;
  const s = b.shape;
  return {
    "--b-bg": color(c.background), "--b-surface": color(c.surface), "--b-text": color(c.text), "--b-muted": color(c.mutedText),
    "--b-border": color(c.border), "--b-primary": color(c.primary), "--b-primary-text": color(c.primaryText),
    "--b-secondary": color(c.secondary), "--b-accent": color(c.accent), "--b-sale": color(c.sale),
    "--b-promo-bg": color(c.promoBarBackground), "--b-promo-text": color(c.promoBarText),
    "--b-footer-bg": color(c.footerBackground), "--b-footer-text": color(c.footerText), "--b-rating": color(c.rating),
    "--b-font": cssFont(t.fontFamily, t.fallbackFont),
    "--b-heading-font": cssFont(t.headingFontFamily || t.fontFamily, t.headingFallbackFont || t.fallbackFont),
    "--b-heading-weight": t.headingWeight,
    "--b-heading-case": t.headingUppercase ? "uppercase" : "none",
    "--b-size": `${t.baseFontSize || 14}px`,
    "--b-btn-radius": { pill: "999px", rounded: "6px", square: "0px" }[s.buttonShape] || "999px",
    "--b-btn-case": s.buttonUppercase ? "uppercase" : "none",
    "--b-card-radius": `${s.cardRadius}px`,
    "--b-img-bg": color(s.imageBackground),
    "--b-img-aspect": s.imageAspect === "portrait" ? "3 / 4" : "1 / 1",
    "--b-align": s.cardTextAlign === "center" ? "center" : "left",
    "--b-justify": s.cardTextAlign === "center" ? "center" : "flex-start",
  };
}

export function loadFonts(b) {
  for (const family of new Set([b.typography.fallbackFont, b.typography.headingFallbackFont].filter(Boolean))) {
    const id = `font-${family.replace(/\W/g, "")}`;
    if (document.getElementById(id)) continue;
    const link = Object.assign(document.createElement("link"), {
      id,
      rel: "stylesheet",
      href: `https://fonts.googleapis.com/css2?family=${encodeURIComponent(family).replace(/%20/g, "+")}:wght@400;500;600;700;800&display=swap`,
    });
    document.head.append(link);
  }
}
