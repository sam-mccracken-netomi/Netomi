// B2B (Rockwell "ADX with S2S") card templates, registered in adxGenUI's renderer next to
// its own elements. The Rockwell backend also uses adxGenUI's micro_elicit (the line
// question) and cta_banner (the confirm step) unchanged.
//
// Animated values: an element with data-w="<pct>" (bar width) or data-count="<n>" is
// animated from its previous value by app.js, so the downtime bar visibly shrinks.
import { esc, registerRenderer } from "./adx/components.js";

const STATUS = { delayed: ["Delayed", "bad"], ready: ["Ready to ship", "ok"], shipped: ["Delivered", "muted"] };
const chip = (s) => { const [l, t] = STATUS[s] || [s, "muted"]; return `<span class="gx-st gx-st-${t}">${esc(l)}</span>`; };

// simple product illustrations (inline SVG, no external assets)
export const ART = {
  drive: (tone = "#2f2f2f") => `<svg viewBox="0 0 80 100" class="gx-art" aria-hidden="true">
    <rect x="8" y="4" width="64" height="92" rx="5" fill="${tone}"/><rect x="8" y="4" width="64" height="14" rx="5" fill="#000" opacity=".25"/>
    <rect x="18" y="24" width="44" height="22" rx="2" fill="#0d1a12"/><rect x="21" y="27" width="24" height="5" rx="1" fill="#5fe08a"/><rect x="21" y="35" width="16" height="4" rx="1" fill="#5fe08a" opacity=".6"/>
    <circle cx="54" cy="35" r="5" fill="#c4161c"/>
    ${[56, 62, 68, 74, 80].map((y) => `<rect x="18" y="${y}" width="44" height="3" rx="1.5" fill="#fff" opacity=".22"/>`).join("")}
  </svg>`,
  controller: () => `<svg viewBox="0 0 100 80" class="gx-art" aria-hidden="true">
    <rect x="4" y="8" width="92" height="64" rx="4" fill="#3a3a3a"/>
    ${[0, 1, 2, 3, 4, 5].map((i) => `<rect x="${10 + i * 14}" y="14" width="11" height="52" rx="2" fill="${i === 0 ? "#c4161c" : "#575757"}"/><rect x="${12 + i * 14}" y="18" width="7" height="3" fill="#5fe08a" opacity="${i % 2 ? 0.9 : 0.5}"/>`).join("")}
  </svg>`,
};
const ICON = {
  drive: '<path d="M6 3h12v18H6z" fill="none" stroke="currentColor" stroke-width="2"/><path d="M9 7h6v4H9z" fill="currentColor"/>',
  truck: '<path d="M3 6h11v9H3zM14 9h4l3 3v3h-7z" fill="none" stroke="currentColor" stroke-width="2"/><circle cx="7" cy="17" r="2" fill="currentColor"/><circle cx="17" cy="17" r="2" fill="currentColor"/>',
  x: '<path d="M6 6l12 12M18 6L6 18" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"/>',
  clock: '<circle cx="12" cy="12" r="9" fill="none" stroke="currentColor" stroke-width="2"/><path d="M12 7v5l3 2" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>',
  doc: '<path d="M6 3h8l4 4v14H6z" fill="none" stroke="currentColor" stroke-width="2"/><path d="M9 12h6M9 16h6" stroke="currentColor" stroke-width="2"/>',
  file: '<path d="M4 7h16v12H4z" fill="none" stroke="currentColor" stroke-width="2"/><path d="M4 7l3-3h6l2 3" fill="none" stroke="currentColor" stroke-width="2"/>',
  wrench: '<path d="M14 6a4 4 0 0 0 5 5l-8 8-3-3 8-8a4 4 0 0 0-2-2z" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/>',
};
const icon = (k) => `<svg viewBox="0 0 24 24" class="gx-ic" aria-hidden="true">${ICON[k] || ""}</svg>`;

registerRenderer("step_rail", (el) => `
  <ol class="gx-rail">${el.steps.map((s, i) => `<li class="${i + 1 < el.active ? "is-done" : i + 1 === el.active ? "is-active" : ""}"><span>${i + 1 < el.active ? "✓" : i + 1}</span>${esc(s)}</li>`).join("")}</ol>`, "Step rail");

registerRenderer("order_status", (el) => `
  <div class="gx-ost">
    <div class="gx-ost-art">${ART.drive()}</div>
    <div class="gx-ost-body">
      <div class="gx-eyebrow">${esc(el.eyebrow)}</div>
      <h3>${esc(el.headline)}</h3>
      <div class="gx-ost-dates">
        <div><small>Was</small><s>${esc(el.was)}</s></div>
        <div class="gx-ost-arrow">→</div>
        <div><small>Now</small><b>${esc(el.now)}</b></div>
        <span class="gx-st gx-st-bad">${esc(el.slip)}</span>
      </div>
      <p><b>${esc(el.reason)}.</b> ${esc(el.detail)}</p>
      <div class="gx-ost-rest">${el.rest.map((l) => `<span>${chip(l.status)} ${esc(l.qty)} × ${esc(l.name)}</span>`).join("")}</div>
    </div>
  </div>`, "Order status");

const pct = (d, axis) => ((d / axis) * 100).toFixed(2);
registerRenderer("downtime_timeline", (el) => `
  <section class="gx-tl gx-tl-${esc(el.tone)}${el.locked ? " is-locked" : ""}">
    <div class="gx-tl-head">
      <div class="gx-tl-count"><b data-count="${el.counter}">${el.counter}</b><span>${esc(el.unit)}</span></div>
      <div class="gx-tl-cap">
        ${el.locked ? `<span class="gx-tl-lock">✓ Locked in</span>` : ""}
        <h3>${esc(el.caption)}</h3>
        ${el.saved ? `<span class="gx-tl-saved">${esc(el.saved)}</span>` : `<p>${esc(el.waiting)}</p>`}
      </div>
    </div>
    <div class="gx-tl-axis">
      <div class="gx-tl-track">
        ${el.ghostTo ? `<div class="gx-tl-ghost" style="width:${pct(el.ghostTo, el.axisDays)}%"></div>` : ""}
        <div class="gx-tl-bar" data-w="${pct(el.to, el.axisDays)}" style="width:${pct(el.to, el.axisDays)}%"><span>${esc(el.line)} down</span></div>
      </div>
      ${el.markers.map((m) => `<div class="gx-tl-mark gx-tl-${esc(m.kind)}" style="left:${pct(m.d, el.axisDays)}%"><i></i><b>${esc(m.label)}</b><small>${esc(m.date)}</small></div>`).join("")}
      <div class="gx-tl-ticks">${el.ticks.map(([t, d]) => `<span style="left:${pct(d, el.axisDays)}%">${esc(t)}</span>`).join("")}</div>
    </div>
  </section>`, "Downtime timeline");

registerRenderer("fix_offer", (el) => `
  <div class="gx-fix">
    <div class="gx-fix-art">${ART.drive("#2f2f2f")}<span class="gx-st gx-st-ok">In stock</span></div>
    <div class="gx-fix-body">
      <div class="gx-eyebrow">${esc(el.eyebrow)}</div>
      <h3>${esc(el.title)}</h3><code>${esc(el.cat)}</code>
      <dl>${el.facts.map(([k, v]) => `<div><dt>${esc(k)}</dt><dd>${esc(v)}</dd></div>`).join("")}</dl>
      <p>${esc(el.note)}</p>
    </div>
    <button class="gx-cta" data-act="${esc(el.act)}" data-label="${esc(el.cta)}">${esc(el.cta)}</button>
  </div>`, "Fix offer");

registerRenderer("part_compare", (el) => `
  <section class="gx-pc">
    <div class="gx-eyebrow">${esc(el.eyebrow)}</div>
    <div class="gx-pc-grid">
      <div class="gx-pc-labels"><span></span>${el.labels.map((l) => `<span>${esc(l)}</span>`).join("")}</div>
      ${el.cols.map((c) => `<div class="gx-pc-col gx-pc-${esc(c.tone)}">
        <div class="gx-pc-top">${ART.drive(c.tone === "ok" ? "#2f2f2f" : "#9a9a9a")}<div><span class="gx-st gx-st-${esc(c.tone)}">${esc(c.tag)}</span><b>${esc(c.title)}</b><code>${esc(c.cat)}</code></div></div>
        ${c.rows.map((r, i) => `<span${i < 2 ? ' class="big"' : ""}>${esc(r)}</span>`).join("")}
      </div>`).join("")}
    </div>
  </section>`, "Part comparison");

registerRenderer("plan_locked", (el) => `
  <section class="gx-plan">
    ${el.banner ? `<div class="gx-plan-banner"><span class="gx-done-icon">✓</span><div><small>Plan confirmed</small><b>${esc(el.banner)}</b></div></div>` : `<div class="gx-plan-banner is-plain"><div><small>Plan</small><b>Requested so far</b></div></div>`}
    <ul>${el.items.map((i) => `<li>${icon(i.icon)}<div><b>${esc(i.title)}</b><span>${esc(i.detail)}</span></div>${i.eta ? `<em>${esc(i.eta)}</em>` : "<em></em>"}</li>`).join("")}</ul>
    ${el.resources.length ? `<div class="gx-plan-res"><small>For the swap</small>${el.resources.map((r) => `<a>${icon(r.icon)}${esc(r.title)}</a>`).join("")}</div>` : ""}
  </section>`, "Plan");

registerRenderer("ranked_actions", (el) => `
  <section class="gx-ranked">
    <div class="gx-ranked-head"><div class="gx-eyebrow">${esc(el.eyebrow)}</div><h3>${esc(el.heading)}</h3></div>
    <ol>${el.options.map((o) => `
      <li class="${o.done ? "is-done" : ""}${o.best ? " is-best" : ""}">
        <span class="gx-rank">${o.rank}</span>
        <div class="gx-ranked-tx"><b>${esc(o.title)}</b><p>${esc(o.detail)}</p></div>
        <span class="gx-impact gx-impact-${esc(o.tone)}">${esc(o.impact)}</span>
        ${o.done ? `<span class="gx-st gx-st-ok">${esc(o.done)}</span>` : `<button class="gx-cta ${o.best ? "" : "gx-cta-ghost"}" data-act="${esc(o.act)}" data-label="${esc(o.title)}">Choose</button>`}
      </li>`).join("")}
    </ol>
  </section>`, "Ranked actions");

registerRenderer("handoff", (el) => `
  <section class="gx-handoff">
    <div class="gx-avatar">${esc(el.initials)}<i></i></div>
    <div class="gx-handoff-tx">
      <div class="gx-eyebrow">${esc(el.eyebrow)}</div>
      <h3>${esc(el.name)} <span>· ${esc(el.role)}</span></h3>
      <p><b>${esc(el.eta)}.</b> ${esc(el.note)}</p>
      <div class="gx-ctx">${el.context.map((c) => `<span>✓ ${esc(c)}</span>`).join("")}</div>
    </div>
  </section>`, "Specialist handoff");
