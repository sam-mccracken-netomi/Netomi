// Browser audio for the relay: mic → 24 kHz Int16 PCM in 100 ms frames; agent PCM → speaker.
export async function startAudio({ onMicFrame, onLevel, onMicLevel, raw = false, silent = false }) {
  const ctx = new AudioContext({ sampleRate: 24000 });
  await ctx.audioWorklet.addModule("/audio-worklets.js");
  const stream = await navigator.mediaDevices.getUserMedia({
    // raw: no browser processing (for test harnesses feeding a file as the mic)
    audio: raw ? { echoCancellation: false, noiseSuppression: false, autoGainControl: false } : { echoCancellation: true, noiseSuppression: true, autoGainControl: true, channelCount: 1 },
  });
  const src = ctx.createMediaStreamSource(stream);
  const mic = new AudioWorkletNode(ctx, "mic-processor");
  const FRAME = 2400; // 100 ms at 24 kHz
  let buf = new Int16Array(FRAME), fill = 0, muted = false;
  mic.port.onmessage = (e) => {
    const f = e.data;
    let sum = 0;
    for (let i = 0; i < f.length; i++) {
      const s = muted ? 0 : Math.max(-1, Math.min(1, f[i]));
      sum += s * s;
      buf[fill++] = s < 0 ? s * 0x8000 : s * 0x7fff;
      if (fill === FRAME) { onMicFrame(buf.buffer); buf = new Int16Array(FRAME); fill = 0; }
    }
    onMicLevel?.(Math.sqrt(sum / f.length));
  };
  src.connect(mic);
  // the mic worklet needs a path to the destination to keep running; keep it silent
  const sink = ctx.createGain();
  sink.gain.value = 0;
  mic.connect(sink).connect(ctx.destination);

  const player = new AudioWorkletNode(ctx, "player-processor");
  player.port.onmessage = (e) => onLevel?.(e.data);
  // silent (test harnesses): the agent's audio is decoded but never reaches the speakers
  if (!silent) player.connect(ctx.destination);
  else { const z = ctx.createGain(); z.gain.value = 0; player.connect(z).connect(ctx.destination); }

  return {
    play: (arrayBuffer) => player.port.postMessage(arrayBuffer, [arrayBuffer]),
    flush: () => player.port.postMessage("flush"),
    setMuted: (m) => (muted = m),
    async stop() {
      stream.getTracks().forEach((t) => t.stop());
      await ctx.close();
    },
  };
}
