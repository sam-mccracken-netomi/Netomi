// Screenshots of the cards in ?preview mode: no voice session, no microphone, no audio
// (Chrome is also launched with --mute-audio). For checking the look of a scenario.
//   node test/screenshot.mjs rockwell 2 6 3:orb=speaking   # scenario, then preview steps (with options)
import { spawn } from "node:child_process";
import { writeFileSync, mkdirSync, mkdtempSync } from "node:fs";
import { join } from "node:path";
import { tmpdir } from "node:os";
import { loadEnv, ROOT } from "../lib/env.mjs";

loadEnv();
const PORT = Number(process.env.PORT || 5178);
const [scenario = "airline", ...counts] = process.argv.slice(2);
const CHROME = process.env.CHROME || "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome";
const ARGS = ["--headless=new", "--mute-audio", "--remote-debugging-port=9341", `--user-data-dir=${mkdtempSync(join(tmpdir(), "sayit-shot-"))}`, "--no-first-run", "about:blank"];
if (!ARGS.includes("--mute-audio")) throw new Error("refusing to launch Chrome without --mute-audio");
const OUT = join(ROOT, "logs", `shots-${scenario}-${Date.now()}`);
mkdirSync(OUT, { recursive: true });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const chrome = spawn(CHROME, ARGS, { stdio: "ignore" });
let target;
for (let i = 0; i < 50 && !target; i++) { await sleep(200); try { target = (await (await fetch("http://127.0.0.1:9341/json/list")).json()).find((t) => t.type === "page"); } catch {} }
const cdp = new WebSocket(target.webSocketDebuggerUrl);
await new Promise((r) => (cdp.onopen = r));
let seq = 0; const pending = new Map(); const logs = [];
cdp.onmessage = (m) => { const x = JSON.parse(m.data); if (x.id) { pending.get(x.id)?.(x); pending.delete(x.id); } else if (x.method === "Runtime.exceptionThrown") logs.push(x.params.exceptionDetails.exception?.description || x.params.exceptionDetails.text); else if (x.method === "Log.entryAdded" && x.params.entry.level === "error") logs.push(x.params.entry.text); };
const send = (method, params = {}) => new Promise((r) => { const id = ++seq; pending.set(id, r); cdp.send(JSON.stringify({ id, method, params })); });
await send("Runtime.enable"); await send("Log.enable"); await send("Page.enable"); await send("Network.enable");
// BASE_URL=https://adx.… ADX_AUTH=user:password  (for the VM behind Caddy basic_auth)
const BASE = process.env.BASE_URL || `http://localhost:${PORT}`;
if (process.env.ADX_AUTH) await send("Network.setExtraHTTPHeaders", { headers: { Authorization: "Basic " + Buffer.from(process.env.ADX_AUTH).toString("base64") } });
// SIZES="1280x720,1440x900" (default also adds a phone); FULL=1 captures the whole page
const SIZES = (process.env.SIZES || "1440x1000,390x844m").split(",").map((x) => { const m = x.match(/(\d+)x(\d+)(m?)/); return [+m[1], +m[2], !!m[3]]; });
for (const [w, h, mobile] of SIZES) {
  await send("Emulation.setDeviceMetricsOverride", { width: w, height: h, deviceScaleFactor: mobile ? 2 : 1, mobile });
  for (const n of counts.length ? counts : ["0", "99"]) {
    // "3:orb=speaking,open" → ?preview=3&orb=speaking,open (orb states are forced, no audio)
    const [step, extra] = n.split(":");
    await send("Page.navigate", { url: `${BASE}/?scenario=${scenario}${step !== "0" ? `&preview=${step}` : ""}${extra ? `&${extra}` : ""}` });
    await sleep(3200); // the page scrolls to the step's key card, as it does live
    const r = await send("Page.captureScreenshot", { format: "png", captureBeyondViewport: !!process.env.FULL });
    writeFileSync(join(OUT, `${w}x${h}-step${n.replace(/[:=,]/g, "_")}.png`), Buffer.from(r.result.data, "base64"));
  }
}
console.log(OUT, logs.length ? "\nerrors:\n" + logs.join("\n") : "(no page errors)");
cdp.close(); chrome.kill(); process.exit(0);
