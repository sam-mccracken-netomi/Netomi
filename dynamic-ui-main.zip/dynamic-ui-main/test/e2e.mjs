// End-to-end test without a human microphone. Acts as the browser on ws://.../live:
// streams the pre-generated visitor lines (test/audio, from test/make-audio.sh) into the
// real GPT-Live session in real time, with silence in between as a mic would send, and
// waits for the agent to finish each reply. Then checks that decisions fired, that
// delegations reached the mocked backend, and that the expected cards arrived.
//
//   npm start            # in another terminal
//   node test/e2e.mjs    # PORT and BRAND from .env / env

import { readFileSync, writeFileSync, mkdirSync } from "node:fs";
import { join } from "node:path";
import { loadEnv, ROOT } from "../lib/env.mjs";

loadEnv();
const PORT = Number(process.env.PORT || 5178);
const SCENARIO = process.env.SCENARIO || "airline";
const BRAND = process.env.BRAND || "";
const ROCKWELL = [
  { wav: "rw-1-status", expect: ["status", "line_q"], action: /status/ },
  { wav: "rw-2-linedown", expect: ["hero", "fix", "options"], action: /line_yes/ },
  { wav: "rw-3-alt", expect: ["confirm_q"], action: /alternative/ },
  { wav: "rw-4-confirm", expect: ["plan"], action: /confirm_alternative/ },
  { wav: "rw-5-shiprest", expect: ["plan"], action: /ship_rest/ },
  { wav: "rw-6-specialist", expect: ["handoff"], action: /specialist/ },
  { wav: "rw-7-thanks", expect: [], action: null },
];
// "Yes, I think do it" after the voice offers the replacement (Zain's session 3, 2026-10-21)
const ROCKWELL_OFFER = [
  { wav: "rw-1-status", expect: ["status", "line_q"], action: /status/ },
  { wav: "rw-2-linedown", expect: ["hero", "fix", "options"], action: /line_yes/ },
  { wav: "rw-yes-do-it", expect: ["confirm_q"], action: /^alternative$/ },
  { wav: "rw-place-it", expect: ["plan"], action: /confirm_alternative/ },
];
// "Just place the replacement order" said cold, as the first request
const ROCKWELL_COLD = [
  { wav: "rw-cold-place", expect: ["hero", "plan"], action: /confirm_alternative/ },
];
const AIRLINE = [
  { wav: "1-options", expect: ["disruption", "options"], action: /show_options/ },
  { wav: "2-nonstop", expect: ["compare"], action: /nonstop/ },
  { wav: "3-choose", expect: ["hotel_q"], action: /choose/ },
  { wav: "4-hotel", expect: ["voucher_hotel", "voucher_meal", "confirm_q"], action: /hotel_yes/ },
  { wav: "5-confirm", expect: ["boarding_pass"], action: /confirm/ },
  { wav: "6-thanks", expect: [], action: null },
];
const SCRIPT = process.env.SCRIPT || SCENARIO; // rockwell | rockwell-offer | rockwell-cold | airline
const STEPS = { rockwell: ROCKWELL, "rockwell-offer": ROCKWELL_OFFER, "rockwell-cold": ROCKWELL_COLD, airline: AIRLINE }[SCRIPT];

function pcm(path) {
  const b = readFileSync(path);
  for (let off = 12; off < b.length; ) {
    const id = b.toString("ascii", off, off + 4), size = b.readUInt32LE(off + 4);
    if (id === "data") return b.subarray(off + 8, off + 8 + size);
    off += 8 + size + (size % 2);
  }
  throw new Error("no data chunk in " + path);
}

const t0 = Date.now();
const now = () => ((Date.now() - t0) / 1000).toFixed(1);
const say = (...a) => console.log(now().padStart(6), ...a);
const cards = new Map();
const events = [];
let lastAgentWords = 0, agentSaid = "", callerSaid = "", answered = 0, liveUp = false;
let speaking = null; // the PCM being sent now, if any

const ws = new WebSocket(`ws://localhost:${PORT}/live?harness=e2e&scenario=${SCENARIO}${BRAND ? `&brand=${BRAND}` : ""}`);
ws.binaryType = "arraybuffer";
ws.onmessage = (m) => {
  if (typeof m.data !== "string") return; // agent audio: not played here
  const e = JSON.parse(m.data);
  events.push({ t: now(), ...e });
  if (e.type === "status") { say("status", e.state, e.message || ""); if (e.state === "live") liveUp = true; }
  if (e.type === "caption" && e.role === "agent") { lastAgentWords = Date.now(); agentSaid += e.delta; }
  if (e.type === "caption" && e.role === "user") callerSaid += e.delta;
  if (e.type === "decision" && e.fired) say(`DECISION fired ${e.fired}`, JSON.stringify(e.answers));
  if (e.type === "delegation") say(`DELEGATION ${e.id} "${e.text}"`);
  if (e.type === "answered") { answered++; say(`ANSWERED via ${e.how}: ${e.action}`); }
  if (e.type === "ui") {
    for (const c of e.upsert) cards.set(c.id, c);
    for (const id of e.remove || []) cards.delete(id);
    say(`UI (${e.source}) +[${e.upsert.map((c) => c.id)}] -[${e.remove || []}]`);
  }
};

// one 100 ms frame every 100 ms: the utterance if one is playing, silence otherwise
const FRAME = 4800, SILENCE = Buffer.alloc(FRAME);
setInterval(() => {
  if (ws.readyState !== 1) return;
  if (speaking && speaking.off < speaking.buf.length) {
    ws.send(speaking.buf.subarray(speaking.off, speaking.off + FRAME));
    speaking.off += FRAME;
  } else ws.send(SILENCE);
}, 100);

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
async function agentDone(minAnswered, maxMs = 30000) {
  const start = Date.now();
  while (Date.now() - start < maxMs) {
    const quiet = Date.now() - lastAgentWords > 2200 && lastAgentWords > 0;
    if (quiet && answered >= minAnswered && Date.now() - start > 2500) return true;
    await sleep(200);
  }
  return false;
}
function flushSpeech(label) {
  if (agentSaid.trim()) say(`AGENT: ${agentSaid.trim()}`);
  if (callerSaid.trim()) say(`HEARD (${label}): ${callerSaid.trim()}`);
  agentSaid = ""; callerSaid = "";
}

const results = [];
ws.onopen = async () => {
  while (!liveUp) await sleep(100);
  await agentDone(0, 15000); // the greeting
  flushSpeech("greeting");
  for (const step of STEPS) {
    const before = answered;
    const buf = pcm(join(ROOT, "test", "audio", step.wav + ".wav"));
    say(`>>> visitor says ${step.wav} (${(buf.length / 48000).toFixed(1)} s)`);
    const startedAt = Date.now();
    speaking = { buf, off: 0 };
    await sleep((buf.length / 48000) * 1000);
    const ok = await agentDone(step.action ? before + 1 : before, 30000);
    flushSpeech(step.wav);
    const missing = step.expect.filter((id) => !cards.has(id));
    results.push({ step: step.wav, agentFinished: ok, missing, ms: Date.now() - startedAt });
    if (missing.length) say(`!!! missing cards after ${step.wav}: ${missing}`);
    const acted = events.filter((e) => (e.type === "answered" || e.type === "ui") && Number(e.t) * 1000 >= startedAt - t0).map((e) => e.action);
    if (step.action && !acted.some((a) => step.action.test(a))) { missing.push(`action ${step.action}`); say(`!!! expected action ${step.action}, got ${acted}`); }
  }
  await sleep(1500);
  ws.close();
  const decisions = events.filter((e) => e.type === "decision");
  const fired = decisions.filter((e) => e.fired);
  const delegations = events.filter((e) => e.type === "delegation");
  const answers = events.filter((e) => e.type === "answered");
  const summary = {
    decisionEvents: decisions.length,
    decisionsThatFiredUI: fired.map((e) => ({ t: e.t, action: e.fired })),
    delegations: delegations.length,
    answers: answers.map((e) => ({ t: e.t, how: e.how, action: e.action })),
    finalCards: [...cards.keys()],
    steps: results,
    pass: results.every((r) => !r.missing.length),
  };
  mkdirSync(join(ROOT, "logs"), { recursive: true });
  writeFileSync(join(ROOT, "logs", `e2e-${SCRIPT}-${Date.now()}.json`), JSON.stringify({ summary, events }, null, 1));
  console.log("\n" + JSON.stringify(summary, null, 1));
  process.exit(summary.pass ? 0 : 1);
};
ws.onerror = () => { console.error("Can't reach the server on port " + PORT + ". Start it with: npm start"); process.exit(2); };
