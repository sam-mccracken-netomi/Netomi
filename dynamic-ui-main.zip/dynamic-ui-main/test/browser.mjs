// Full-stack test in a real browser, no human microphone: headless Chrome's fake audio
// device plays the visitor's lines (test/audio, joined with pauses) as the microphone, the
// page autostarts, and we watch the cards render in the DOM and take screenshots.
//
//   npm start               # in another terminal
//   node test/browser.mjs   # screenshots and a summary in logs/browser-<time>/
//
// Uses the installed Google Chrome over the DevTools protocol (no extra packages).

import { spawn } from "node:child_process";
import { readFileSync, writeFileSync, mkdirSync, mkdtempSync } from "node:fs";
import { join } from "node:path";
import { tmpdir } from "node:os";
import { loadEnv, ROOT } from "../lib/env.mjs";

loadEnv();
const PORT = Number(process.env.PORT || 5178);
const BRAND = process.env.BRAND || "";
const CHROME = process.env.CHROME || "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome";
const OUT = join(ROOT, "logs", `browser-${Date.now()}`);
mkdirSync(OUT, { recursive: true });

// pauses (s) before each line: time for the greeting, then for each reply
const SCRIPT = [[7, "1-options"], [15, "2-nonstop"], [14, "3-choose"], [13, "4-hotel"], [14, "5-confirm"], [14, "6-thanks"], [9, null]];
const CHECKPOINTS = [["options", "1-options"], ["compare", "2-nonstop"], ["hotel_q", "3-choose"], ["voucher_hotel", "4-hotel"], ["boarding_pass", "5-confirm"]];

function pcm(path) {
  const b = readFileSync(path);
  for (let off = 12; off < b.length; ) {
    const id = b.toString("ascii", off, off + 4), size = b.readUInt32LE(off + 4);
    if (id === "data") return b.subarray(off + 8, off + 8 + size);
    off += 8 + size + (size % 2);
  }
}
function wav(data, rate = 24000) {
  const h = Buffer.alloc(44);
  h.write("RIFF", 0); h.writeUInt32LE(36 + data.length, 4); h.write("WAVE", 8); h.write("fmt ", 12);
  h.writeUInt32LE(16, 16); h.writeUInt16LE(1, 20); h.writeUInt16LE(1, 22); h.writeUInt32LE(rate, 24);
  h.writeUInt32LE(rate * 2, 28); h.writeUInt16LE(2, 32); h.writeUInt16LE(16, 34); h.write("data", 36); h.writeUInt32LE(data.length, 40);
  return Buffer.concat([h, data]);
}
const parts = [];
for (const [pause, line] of SCRIPT) {
  parts.push(Buffer.alloc(Math.round(pause * 24000) * 2));
  if (line) parts.push(pcm(join(ROOT, "test", "audio", `${line}.wav`)));
}
const convo = join(OUT, "visitor.wav");
writeFileSync(convo, wav(Buffer.concat(parts)));
const total = parts.reduce((n, p) => n + p.length, 0) / 48000;

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const profile = mkdtempSync(join(tmpdir(), "sayit-chrome-"));
const chrome = spawn(CHROME, [
  // --mute-audio: the agent's voice must never play on this machine's speakers
  "--headless=new", "--mute-audio", "--remote-debugging-port=9339", `--user-data-dir=${profile}`, "--no-first-run", "--window-size=1440,1000",
  "--use-fake-ui-for-media-stream", "--use-fake-device-for-media-stream",
  ...(process.env.NOFILE ? [] : [`--use-file-for-fake-audio-capture=${convo}${process.env.LOOP ? "" : "%noloop"}`]),
  // the sandboxed audio service can't read the file on macOS: capture was silent with it on
  ...(process.env.SANDBOX ? [] : ["--disable-features=AudioServiceSandbox"]),
  "--autoplay-policy=no-user-gesture-required", "about:blank",
], { stdio: "ignore" });

let target;
for (let i = 0; i < 50 && !target; i++) {
  await sleep(200);
  try { target = (await (await fetch("http://127.0.0.1:9339/json/list")).json()).find((t) => t.type === "page"); } catch {}
}
if (!target) { console.error("Chrome didn't start"); process.exit(2); }

const cdp = new WebSocket(target.webSocketDebuggerUrl);
await new Promise((r) => (cdp.onopen = r));
let seq = 0;
const pending = new Map();
const logs = [];
cdp.onmessage = (m) => {
  const msg = JSON.parse(m.data);
  if (msg.id && pending.has(msg.id)) { pending.get(msg.id)(msg); pending.delete(msg.id); return; }
  if (msg.method === "Runtime.consoleAPICalled") logs.push(`[console.${msg.params.type}] ${msg.params.args.map((a) => a.value ?? a.description).join(" ")}`);
  if (msg.method === "Runtime.exceptionThrown") logs.push(`[exception] ${msg.params.exceptionDetails.exception?.description || msg.params.exceptionDetails.text}`);
  if (msg.method === "Log.entryAdded") logs.push(`[log.${msg.params.entry.level}] ${msg.params.entry.text}`);
};
const send = (method, params = {}) => new Promise((r) => { const id = ++seq; pending.set(id, r); cdp.send(JSON.stringify({ id, method, params })); });
const evaluate = async (expr) => (await send("Runtime.evaluate", { expression: expr, returnByValue: true })).result?.result?.value;
const shot = async (name, full = false) => {
  const r = await send("Page.captureScreenshot", { format: "png", captureBeyondViewport: full });
  writeFileSync(join(OUT, `${name}.png`), Buffer.from(r.result.data, "base64"));
};

await send("Runtime.enable"); await send("Log.enable"); await send("Page.enable");
await send("Emulation.setDeviceMetricsOverride", { width: 1440, height: 1000, deviceScaleFactor: 1, mobile: false });
await send("Page.navigate", { url: `http://localhost:${PORT}/?autostart=1&silent=1${process.env.RAWMIC ? "&rawmic=1" : ""}${BRAND ? `&brand=${BRAND}` : ""}` });
const t0 = Date.now();
console.log(`page loaded; visitor audio ${total.toFixed(0)} s; screenshots in ${OUT}`);
await sleep(3000);
await shot("00-start");

const seen = new Map();
let i = 0;
while ((Date.now() - t0) / 1000 < Number(process.env.MAX_S || total + 6)) {
  const cards = (await evaluate("window.__demo && window.__demo.cards()")) || [];
  for (const c of cards) if (!seen.has(c)) { seen.set(c, ((Date.now() - t0) / 1000).toFixed(1)); console.log(`${seen.get(c).padStart(6)} s  card rendered: ${c}`); }
  for (const [card, name] of CHECKPOINTS) {
    if (seen.has(card) && !seen.has("shot:" + card)) {
      seen.set("shot:" + card, true);
      await sleep(1800); // let the entrance animation and any companion cards land
      await evaluate(`document.querySelector('[data-card="${card}"]')?.scrollIntoView({block:'center'})`);
      await sleep(300);
      await shot(`${String(++i).padStart(2, "0")}-${name}`);
    }
  }
  await sleep(400);
}
const finalCards = (await evaluate("window.__demo.cards()")) || [];
const captions = await evaluate(`[...document.querySelectorAll('#captions .cap')].map(p => p.querySelector('small').textContent + ': ' + p.querySelector('span').textContent)`);
const signals = await evaluate(`document.getElementById('signal-log').innerText`);
await evaluate("window.scrollTo(0,0)");
await shot("99-final-page", true);
await send("Emulation.setDeviceMetricsOverride", { width: 390, height: 844, deviceScaleFactor: 2, mobile: true });
await sleep(800);
await shot("99-final-mobile", true);

const expected = ["disruption", "options", "voucher_hotel", "voucher_meal", "boarding_pass"];
const summary = {
  firstSeen: Object.fromEntries([...seen].filter(([k]) => !k.startsWith("shot:"))),
  finalCards, missing: expected.filter((c) => !finalCards.includes(c)), captions, signals, browserLogs: logs,
};
writeFileSync(join(OUT, "summary.json"), JSON.stringify(summary, null, 1));
console.log(JSON.stringify(summary, null, 1));
cdp.close();
chrome.kill();
process.exit(summary.missing.length ? 1 : 0);
