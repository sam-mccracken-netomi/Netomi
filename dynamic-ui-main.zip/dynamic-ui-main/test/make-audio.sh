#!/bin/sh
# Pre-generates the visitor's lines as 24 kHz mono 16-bit WAVs with macOS `say`
# (no model involved). Output: test/audio/*.wav
set -e
cd "$(dirname "$0")"
mkdir -p audio
VOICE="${VOICE:-Samantha}"
line() { say -v "$VOICE" -r 175 -o "audio/$1.aiff" "$2" && afconvert -f WAVE -d LEI16@24000 -c 1 "audio/$1.aiff" "audio/$1.wav" && rm "audio/$1.aiff"; }
line 1-options   "Hi. My flight to Chicago got cancelled. What are my options?"
line 2-nonstop   "Is there anything nonstop?"
line 3-choose    "I'll take the seven fifteen tomorrow morning."
line 4-hotel     "Yes please, that would be great."
line 5-confirm   "Yes, go ahead and confirm it."
line 6-thanks    "That's everything. Thank you!"
# Rockwell scenario
line rw-1-status     "Hi. What's going on with order 8 1 0 0 2 3 4 5 7 1? Why is my drive delayed?"
line rw-2-linedown   "Yes. It's holding up line four."
line rw-3-alt        "Can you get me the replacement that's in stock?"
line rw-4-confirm    "Yes, place the order."
line rw-5-shiprest   "And ship the rest of the order now, please."
line rw-6-specialist "Can I talk to a drives specialist about the setup?"
line rw-7-thanks     "That's all. Thanks."
# Rockwell: accepting the voice's offer with a bare yes, and placing the order cold
line rw-yes-do-it    "Yes, I think do it."
line rw-place-it     "Yes, place it."
line rw-cold-place   "Just place the replacement order."
ls -1 audio/*.wav
