#!/bin/zsh
# Deploy Say it, see it to the GCP VM s2s-demo-bridge, as its own service, separate from the
# S2S bridges and portal. Safe to re-run: the first run also installs Node (in /opt/node, not
# touching Python), the `adx` system user and the systemd unit; every run ships a new release.
#
#   ./deploy-vm.sh             deploy the local copy (the source of truth) as a new release
#   ./deploy-vm.sh rollback    point `current` back to the previous release and restart
#   ./deploy-vm.sh status      service state, releases, recent log lines
#
# Layout on the VM:
#   /opt/adx-demo/releases/<timestamp>/   app files + node_modules (read-only to the service)
#   /opt/adx-demo/current -> releases/…   what the service runs
#   /opt/adx-demo/logs/                   session logs (LOG_DIR)
#   /etc/adx-demo/adx.env                 OPENAI_API_KEY only, extracted on the VM from
#                                         /opt/s2s/app/.env.local (root:adx 640); never printed
#   /etc/systemd/system/adx-demo.service  User=adx, 127.0.0.1:8090
# Caddy (site adx.34-85-206-188.sslip.io, basic_auth) is set up once by hand; see DEMO.md.
set -euo pipefail
HOST=${ADX_VM_HOST:?set ADX_VM_HOST, e.g. you@vm-ip}
KEY=${ADX_VM_KEY:-~/.ssh/google_compute_engine}
SSH=(ssh -i $KEY -o BatchMode=yes -o ConnectTimeout=15 -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o LogLevel=ERROR $HOST)
NODE_VERSION=v22.11.0
PORT=8090
cd "$(dirname "$0")"

remote() { "${SSH[@]}" "sudo bash -s" ; }

case "${1:-deploy}" in
status)
  "${SSH[@]}" 'systemctl is-active adx-demo; ls -1 /opt/adx-demo/releases | tail -5; readlink /opt/adx-demo/current; sudo journalctl -u adx-demo -n 15 --no-pager'
  exit 0 ;;
rollback)
  remote <<'EOF'
set -euo pipefail
cd /opt/adx-demo/releases
cur=$(basename "$(readlink -f /opt/adx-demo/current)")
prev=$(ls -1 | sort | awk -v c="$cur" '$0 < c' | tail -1)
[ -n "$prev" ] || { echo "no earlier release than $cur"; exit 1; }
ln -sfn "/opt/adx-demo/releases/$prev" /opt/adx-demo/current.new && mv -T /opt/adx-demo/current.new /opt/adx-demo/current
systemctl restart adx-demo; sleep 2; systemctl is-active adx-demo
echo "rolled back: $cur -> $prev"
EOF
  exit 0 ;;
esac

# ---- package the local copy (no logs, no node_modules, no .env, no test audio) ------------
REL=$(date -u +%Y%m%dT%H%M%SZ)
TAR=$(mktemp -t adx-demo).tgz
tar -czf "$TAR" --exclude='.DS_Store' server.mjs package.json package-lock.json lib public brands DEMO.md
scp -q -i $KEY -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o LogLevel=ERROR "$TAR" "$HOST:/tmp/adx-demo-$REL.tgz"
rm -f "$TAR"

remote <<EOF
set -euo pipefail
REL=$REL; NODE_VERSION=$NODE_VERSION; PORT=$PORT

# Node, self-contained in /opt/node (checksum-verified official build; no apt, no Python touched)
if [ ! -x /opt/node/bin/node ] || [ "\$(/opt/node/bin/node --version)" != "\$NODE_VERSION" ]; then
  cd /tmp
  f=node-\$NODE_VERSION-linux-x64.tar.xz
  curl -fsSLO https://nodejs.org/dist/\$NODE_VERSION/\$f
  curl -fsSL https://nodejs.org/dist/\$NODE_VERSION/SHASUMS256.txt | grep " \$f\\\$" | sha256sum -c -
  mkdir -p /opt/node-\$NODE_VERSION && tar -xJf \$f -C /opt/node-\$NODE_VERSION --strip-components=1 && rm -f \$f
  ln -sfn /opt/node-\$NODE_VERSION /opt/node
fi

# its own system user and folders
id adx >/dev/null 2>&1 || useradd --system --home-dir /opt/adx-demo --no-create-home --shell /usr/sbin/nologin adx
mkdir -p /opt/adx-demo/releases /opt/adx-demo/logs /etc/adx-demo
chown adx:adx /opt/adx-demo/logs

# the OpenAI key only, read from the S2S env file on the VM (never printed)
umask 027
{ grep -E '^OPENAI_API_KEY=' /opt/s2s/app/.env.local | head -1; } > /etc/adx-demo/adx.env.new
grep -q '^OPENAI_API_KEY=.' /etc/adx-demo/adx.env.new || { echo "OPENAI_API_KEY not found"; exit 1; }
chown root:adx /etc/adx-demo/adx.env.new && chmod 640 /etc/adx-demo/adx.env.new && mv /etc/adx-demo/adx.env.new /etc/adx-demo/adx.env

# the release
D=/opt/adx-demo/releases/\$REL
mkdir -p \$D && tar -xzf /tmp/adx-demo-\$REL.tgz -C \$D && rm -f /tmp/adx-demo-\$REL.tgz
cd \$D && PATH=/opt/node/bin:\$PATH npm ci --omit=dev --no-audit --no-fund --loglevel=error
chown -R root:root \$D && chmod -R a+rX \$D

# the service
cat > /etc/systemd/system/adx-demo.service <<UNIT
[Unit]
Description=Netomi ADX demo (Say it, see it): Delta and Rockwell
After=network-online.target
Wants=network-online.target

[Service]
User=adx
Group=adx
WorkingDirectory=/opt/adx-demo/current
EnvironmentFile=/etc/adx-demo/adx.env
Environment=HOST=127.0.0.1 PORT=\$PORT LOG_DIR=/opt/adx-demo/logs MAX_SESSIONS=3 MAX_SESSION_MIN=10 NODE_ENV=production
ExecStart=/opt/node/bin/node server.mjs
Restart=on-failure
RestartSec=3
NoNewPrivileges=true
ProtectSystem=strict
ProtectHome=true
PrivateTmp=true
ReadWritePaths=/opt/adx-demo/logs
MemoryMax=512M

[Install]
WantedBy=multi-user.target
UNIT
systemctl daemon-reload
ln -sfn \$D /opt/adx-demo/current.new && mv -T /opt/adx-demo/current.new /opt/adx-demo/current
systemctl enable adx-demo >/dev/null 2>&1
systemctl restart adx-demo
sleep 2
systemctl is-active adx-demo
curl -fsS -o /dev/null -w "local check: %{http_code}\n" http://127.0.0.1:\$PORT/api/config
# keep the five newest releases
ls -1d /opt/adx-demo/releases/* | sort | head -n -5 | xargs -r rm -rf
echo "deployed \$REL"
EOF
