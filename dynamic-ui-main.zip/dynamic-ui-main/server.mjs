// Say it, see it: a small local server.
//  - serves the page (public/)
//  - GET /api/config: the brand and the mocked trip, for the first paint
//  - WS  /live: one GPT-Live session per visitor, relayed (audio both ways, captions,
//    decisions, and the UI cards the mocked backend returns)
// The OpenAI key stays here; GPT-Live's /v1/live/sessions doesn't accept browser
// ephemeral tokens (tested 2026-10-21), so the audio is relayed.

import http from "node:http";
import { readFileSync, existsSync, mkdirSync, appendFileSync } from "node:fs";
import { join, extname, resolve } from "node:path";
import { WebSocketServer } from "ws";
import { loadEnv, ROOT } from "./lib/env.mjs";
import { LiveSession } from "./lib/live.mjs";
import { getScenario, SCENARIOS } from "./lib/scenarios/index.mjs";

loadEnv();
const PORT = Number(process.env.PORT || 5178);
const PUBLIC = join(ROOT, "public");
const LOGS = process.env.LOG_DIR || join(ROOT, "logs"); // the VM service sets LOG_DIR
mkdirSync(LOGS, { recursive: true });

// ?scenario=airline (default) or ?scenario=rockwell; ?brand= overrides the scenario's brand
function setup(params) {
  const scenario = getScenario(params.get("scenario"));
  const brand = loadBrand(params.get("brand") || (scenario.id === "airline" ? process.env.BRAND : null) || scenario.defaultBrand);
  return { scenario, brand, backend: scenario.createBackend(brand) };
}

function loadBrand(id) {
  const safe = String(id || "skyline").replace(/[^a-z0-9_-]/gi, "");
  const file = join(ROOT, "brands", `${safe}.json`);
  return JSON.parse(readFileSync(existsSync(file) ? file : join(ROOT, "brands", "skyline.json"), "utf8"));
}

const TYPES = { ".html": "text/html; charset=utf-8", ".js": "text/javascript; charset=utf-8", ".mjs": "text/javascript; charset=utf-8", ".css": "text/css; charset=utf-8", ".json": "application/json", ".svg": "image/svg+xml", ".png": "image/png" };

const server = http.createServer((req, res) => {
  const url = new URL(req.url, "http://localhost");
  if (url.pathname === "/api/config") {
    const { scenario, brand, backend } = setup(url.searchParams);
    res.writeHead(200, { "Content-Type": "application/json", "Cache-Control": "no-store" });
    return res.end(JSON.stringify({ scenario: scenario.id, scenarios: Object.keys(SCENARIOS), brand, trip: backend.trip, page: backend.page?.() }));
  }
  if (url.pathname === "/api/preview") {
    // the scenario's happy path run straight through the mock backend: the UI ops in order,
    // so the page can show its cards with no voice session (no audio at all)
    const { scenario, backend } = setup(url.searchParams);
    const steps = (scenario.preview || []).map((a) => { const r = backend.run(...a); return { action: r.action, upsert: r.ui, remove: r.remove, say: r.say }; });
    res.writeHead(200, { "Content-Type": "application/json", "Cache-Control": "no-store" });
    return res.end(JSON.stringify(steps));
  }
  const path = resolve(PUBLIC, "." + (url.pathname === "/" ? "/index.html" : decodeURIComponent(url.pathname)));
  if (!path.startsWith(PUBLIC) || !existsSync(path)) {
    res.writeHead(404);
    return res.end("Not found");
  }
  res.writeHead(200, { "Content-Type": TYPES[extname(path)] || "application/octet-stream", "Cache-Control": "no-store" });
  res.end(readFileSync(path));
});

const wss = new WebSocketServer({ server, path: "/live" });
let n = 0;
// spend guards: anyone with the page can open voice sessions on our OpenAI key
const MAX_SESSIONS = Number(process.env.MAX_SESSIONS || 3); // concurrent voice sessions
const MAX_SESSION_MIN = Number(process.env.MAX_SESSION_MIN || 10); // minutes per session
let active = 0;

wss.on("connection", (client, req) => {
  if (active >= MAX_SESSIONS) {
    client.send(JSON.stringify({ type: "status", state: "error", message: "The demo is busy (too many live sessions). Try again in a minute." }));
    console.log(`refused a session: ${active} already live (max ${MAX_SESSIONS})`);
    return client.close(1013, "busy");
  }
  active++;
  const url = new URL(req.url, "http://localhost");
  const { scenario, brand, backend } = setup(url.searchParams);
  const id = `${new Date().toISOString().replace(/[:.]/g, "-")}-${++n}`;
  const logFile = join(LOGS, `session-${id}.jsonl`);
  const t0 = Date.now();
  const log = (kind, data = {}) => appendFileSync(logFile, JSON.stringify({ t: +((Date.now() - t0) / 1000).toFixed(3), kind, ...data }) + "\n");
  const toClient = (msg) => client.readyState === 1 && client.send(JSON.stringify(msg));
  console.log(`[${id}] visitor connected (${scenario.id}, brand ${brand.id}); log: ${logFile}`);
  log("visitor", { scenario: scenario.id, brand: brand.id, harness: url.searchParams.get("harness") || null });

  const live = new LiveSession({ scenario, brand, backend, apiKey: process.env.OPENAI_API_KEY, log });
  live.on("status", (s) => { toClient({ type: "status", ...s }); if (s.state !== "live") console.log(`[${id}] ${s.state}${s.message ? ": " + s.message : ""}`); else console.log(`[${id}] GPT-Live session ${s.session}`); });
  live.on("audio", (buf) => client.readyState === 1 && client.send(buf, { binary: true }));
  live.on("caption", (c) => toClient({ type: "caption", ...c }));
  live.on("decision", (d) => toClient({ type: "decision", ...d }));
  live.on("delegation", (d) => toClient({ type: "delegation", ...d }));
  live.on("answered", (d) => toClient({ type: "answered", ...d }));
  live.on("ui", (u) => toClient({ type: "ui", ...u }));
  live.connect();

  client.on("message", (data, isBinary) => {
    if (isBinary) return live.pushAudio(data);
    let msg;
    try { msg = JSON.parse(String(data)); } catch { return; }
    if (msg.type === "tap") { log("tap", msg); live.tap(msg); }
    else if (msg.type === "rendered") log("rendered", { ids: msg.ids });
  });
  const cap = setTimeout(() => {
    toClient({ type: "status", state: "error", message: `Sessions end after ${MAX_SESSION_MIN} minutes. Click the orb to start again.` });
    log("session_time_cap", { minutes: MAX_SESSION_MIN });
    client.close(1000, "time cap");
  }, MAX_SESSION_MIN * 60 * 1000);
  client.on("close", () => { clearTimeout(cap); active--; log("visitor_left"); live.close(); console.log(`[${id}] visitor left (${active} live)`); });
});

server.listen(PORT, process.env.HOST || "0.0.0.0", () => console.log(`Say it, see it: http://localhost:${PORT}  (airline; Rockwell: /?scenario=rockwell; other airline brand: /?brand=northwind)`));
