// Probe: open a raw GPT-Live session (client delegation + a Decisions trigger), stream a
// WAV file in real time as the caller, and print every server event type (audio deltas
// counted, not printed). Usage: node scripts/probe.mjs test/audio/probe.wav [seconds]
import { readFileSync } from "node:fs";
import { loadEnv } from "../lib/env.mjs";

loadEnv();
const wav = process.argv[2];
const runFor = Number(process.argv[3] || 25) * 1000;
const url = "wss://api.openai.com/v1/live/sessions";
const ws = new WebSocket(url, { headers: { Authorization: `Bearer ${process.env.OPENAI_API_KEY}` } });
const t0 = Date.now();
const s = () => ((Date.now() - t0) / 1000).toFixed(2);
let audioDeltas = 0;

function pcmFromWav(path) {
  const b = readFileSync(path);
  let off = 12;
  while (off < b.length) {
    const id = b.toString("ascii", off, off + 4), size = b.readUInt32LE(off + 4);
    if (id === "data") return b.subarray(off + 8, off + 8 + size);
    off += 8 + size + (size % 2);
  }
  throw new Error("no data chunk");
}

ws.addEventListener("open", () => {
  console.log(s(), "open");
  ws.send(JSON.stringify({
    type: "session.start",
    session: {
      model: "gpt-live-1",
      instructions: "You are a friendly airline assistant for Skyline Air. Delegate every request about flights or bookings to the backend. Greet briefly when asked.",
      audio: { format: { type: "audio/pcm", rate: 24000 }, output: { voice: "marin" } },
      delegation: { type: "client" },
      triggers: [{
        type: "decisions",
        event_type: "session.input_transcript.delta",
        decisions: {
          ...(process.env.DECISION_MODEL ? { model: process.env.DECISION_MODEL } : {}),
          questions: [
            { type: "choice", name: "wants_rebooking", instructions: "Does the customer want to see rebooking options for their disrupted flight?", choices: [{ value: "yes" }, { value: "no" }, { value: "unknown" }] },
          ],
        },
      }],
    },
  }));
});

ws.addEventListener("message", (m) => {
  const e = JSON.parse(m.data);
  if (e.type === "session.output_audio.delta") { audioDeltas++; return; }
  const brief = JSON.stringify(e).slice(0, 400);
  console.log(s(), brief);
  if (e.type === "session.started") {
    ws.send(JSON.stringify({ type: "session.commentary.append", delegation_id: null, content: "Greet the customer now in one short sentence. Do not wait for them to speak first. After that, pause and listen." }));
    setTimeout(stream, 3000);
  }
  if (e.type === "session.delegation.created") {
    const id = e.delegation?.id;
    setTimeout(() => ws.send(JSON.stringify({ type: "session.commentary.append", delegation_id: id, content: "There are three rebooking options now on the customer's screen: the earliest leaves at 2:05 PM with one stop, and a nonstop leaves at 4:15 PM. Tell them briefly and point to the screen." })), 800);
  }
});
ws.addEventListener("close", (e) => { console.log(s(), "close", e.code, e.reason, "audio deltas:", audioDeltas); process.exit(0); });
ws.addEventListener("error", (e) => console.log(s(), "error", e.message));

async function stream() {
  const pcm = pcmFromWav(wav);
  const chunk = 2400 * 2; // 100 ms
  const silence = Buffer.alloc(chunk);
  console.log(s(), "streaming caller audio", (pcm.length / 48000).toFixed(1), "s");
  for (let i = 0; i < pcm.length; i += chunk) {
    ws.send(JSON.stringify({ type: "session.input_audio.append", audio: pcm.subarray(i, i + chunk).toString("base64") }));
    await new Promise((r) => setTimeout(r, 100));
  }
  // keep the input stream alive with silence, as a microphone would
  const iv = setInterval(() => ws.readyState === 1 && ws.send(JSON.stringify({ type: "session.input_audio.append", audio: silence.toString("base64") })), 100);
  setTimeout(() => { clearInterval(iv); ws.send(JSON.stringify({ type: "session.close" })); }, runFor);
}
