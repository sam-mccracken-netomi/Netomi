// Change a shopper's home address in Adobe RT-CDP, the way a CRM would (the "Talk to Website
// Customer Records" dataset), then wait until the profile shows it. The assistant picks the
// new one up on the next page load, conversation or Refresh on the settings page.
//   node scripts/rtcdp-zip.mjs <email> <zip> [city] [state]
//   node scripts/rtcdp-zip.mjs taylor@example.com 75201 Dallas TX
import { loadEnv } from "../server/env.mjs";
import { createRtcdp } from "../server/rtcdp.mjs";

loadEnv();
const [email, zip, city = "", state = ""] = process.argv.slice(2);
if (!email || !zip) { console.log("usage: node scripts/rtcdp-zip.mjs <email> <zip> [city] [state]"); process.exit(1); }
const cdp = createRtcdp();
if (!cdp.configured() || !cdp.crmConfigured()) { console.log("RT-CDP isn't set up: run node scripts/rtcdp-setup.mjs"); process.exit(1); }

const fmt = (a) => (a ? [a.city, [a.state, a.zip].filter(Boolean).join(" ")].filter(Boolean).join(", ") : "(none)");
const before = await cdp.profile(email);
console.log(`now in Adobe: ${fmt(before.address)}`);

let r;
for (let i = 0; i < 20; i++) {
  r = await cdp.saveAddress(email, { zip, city, state });
  if (r.ok || !/wrong flowId/.test(r.error || "")) break;
  console.log("  the customer records dataflow isn't active at the inlet yet; trying again in 30 s");
  await new Promise((res) => setTimeout(res, 30000));
}
if (!r.ok) { console.log(`write failed: ${r.status} ${String(r.error).slice(0, 400)}`); process.exit(1); }
console.log(`sent ${fmt({ zip, city, state })}; waiting for the profile…`);
const t0 = Date.now();
while (Date.now() - t0 < 5 * 60e3) {
  await new Promise((res) => setTimeout(res, 5000));
  const p = await cdp.profile(email);
  if (p.address?.zip === String(zip)) {
    console.log(`profile updated after ${Math.round((Date.now() - t0) / 1000)} s: ${fmt(p.address)} (and ${p.facts.length} preferences from the assistant, untouched)`);
    process.exit(0);
  }
}
console.log("sent, but the profile doesn't show it yet after 5 minutes");
process.exit(1);
