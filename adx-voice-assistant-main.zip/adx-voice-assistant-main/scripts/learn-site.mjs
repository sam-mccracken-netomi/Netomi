// Builds a site's knowledge base from this machine: opens a (visible) Chrome with the
// extension in a fresh temporary profile, turns it on for the site and runs "Learn".
// The same as clicking Learn in the chat panel; useful when you just want the index built.
//   npm start   # in another terminal
//   node scripts/learn-site.mjs https://www.sephora.com/
import { join } from "node:path";
import { sleep } from "../test/lib/chrome.mjs";
import { launchWithExtension, attach, findTarget } from "../test/lib/extension.mjs";
import { ROOT } from "../server/env.mjs";

const START = process.argv[2] || "https://www.sephora.com/";
const site = new URL(START).hostname.replace(/^www\./, "");
const ext = await launchWithExtension({ path: join(ROOT, "extension"), headless: !!process.env.HEADLESS, args: ["--window-size=1280,860", "--mute-audio"] });
try {
  const page = await attach((await findTarget(ext.port, (t) => t.type === "page")).webSocketDebuggerUrl);
  await page.send("Page.enable");
  await page.send("Page.navigate", { url: START });
  await sleep(6000);
  const title = await page.evaluate("document.title");
  console.log(`page: ${title}`);
  if (/access denied|forbidden|just a moment/i.test(title)) throw new Error(`${site} blocked this browser (${title})`);
  const sw = await attach((await findTarget(ext.port, (t) => t.type === "service_worker" && t.url.includes(ext.id))).webSocketDebuggerUrl);
  const tabId = await sw.evaluate(`chrome.tabs.query({}).then((ts) => ts.find((t) => t.url && t.url.includes(${JSON.stringify(site)}))?.id)`);
  await sw.evaluate(`toggleTab({ id: ${tabId} }).then(() => true)`);
  await sleep(1500);
  const t0 = Date.now();
  sw.evaluate(`learnSite(${tabId}).then(() => true)`).catch(() => {});
  let st;
  for (let i = 0; i < 400; i++) {
    await sleep(1500);
    st = await (await fetch(`http://localhost:5179/knowledge/${site}/status`)).json();
    const ui = await page.evaluate(`document.querySelector("talk-to-website")?.shadowRoot.querySelector(".kb-text")?.textContent`).catch(() => "");
    if (i % 6 === 0) console.log(`${((Date.now() - t0) / 1000).toFixed(0).padStart(4)}s  ${ui}`);
    if (st.pages && st.updatedAt > t0) break;
    if (/couldn't learn/i.test(await page.evaluate(`document.querySelector("talk-to-website")?.shadowRoot.querySelector(".toast")?.textContent || ""`).catch(() => ""))) throw new Error("learning failed (see the panel)");
  }
  console.log(`learned ${site}: ${st.pages} pages, ${st.chunks} passages in ${((Date.now() - t0) / 1000).toFixed(0)} s`);
} finally {
  ext.proc.kill();
}
