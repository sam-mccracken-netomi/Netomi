// Writes the widget bundle and the voice engine into the Chrome extension (an unpacked
// extension can't reference files outside its folder). Runs before `npm start`.
import { copyFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { ROOT } from "../server/env.mjs";
import { bundle } from "../server/bundle.mjs";

writeFileSync(join(ROOT, "extension", "widget.js"), bundle());
copyFileSync(join(ROOT, "client", "voice.js"), join(ROOT, "extension", "voice.js"));
console.log("extension/widget.js and extension/voice.js updated");
