#!/bin/sh
# Builds dist/Talk to Website.app and dist/TalkToWebsite.dmg: a menu-bar app with the relay
# server and its Node runtime inside, the Chrome extension, and the knowledge bases in
# data/knowledge as seeds. Apple Silicon; unsigned (ad-hoc), so recipients approve it once
# in System Settings → Privacy & Security → Open Anyway.
#
# The OpenAI key (and the Adobe RT-CDP credentials, if set) from .env are bundled INSIDE the
# app: anyone with the app can read them.
# Share it only with people you trust, and rotate the key when you're done.
#   sh scripts/package-mac.sh
set -e
cd "$(dirname "$0")/.."
ROOT=$(pwd)
VERSION=$(node -p 'require("./package.json").version')
OUT="$ROOT/dist"
APP="$OUT/Talk to Website.app"
BUILD="$OUT/.build"
rm -rf "$APP" "$BUILD" "$OUT/TalkToWebsite.dmg"
mkdir -p "$APP/Contents/MacOS" "$APP/Contents/Resources/app" "$APP/Contents/Resources/seed/knowledge" "$BUILD/AppIcon.iconset"

echo "→ the widget bundle"
node scripts/build.mjs

echo "→ the menu-bar app"
swiftc -O -target arm64-apple-macos11.0 mac/main.swift -o "$APP/Contents/MacOS/Talk to Website"

echo "→ the icon"
swiftc mac/icon.swift -o "$BUILD/icon" && "$BUILD/icon" "$BUILD/icon.png"
for s in 16 32 128 256 512; do
  sips -z $s $s "$BUILD/icon.png" --out "$BUILD/AppIcon.iconset/icon_${s}x${s}.png" >/dev/null
  sips -z $((s*2)) $((s*2)) "$BUILD/icon.png" --out "$BUILD/AppIcon.iconset/icon_${s}x${s}@2x.png" >/dev/null
done
iconutil -c icns "$BUILD/AppIcon.iconset" -o "$APP/Contents/Resources/AppIcon.icns"

echo "→ Node $(node -v) and the server"
cp "$(command -v node)" "$APP/Contents/Resources/node"
R="$APP/Contents/Resources/app"
cp -R server client extension package.json "$R/"
mkdir -p "$R/node_modules" && cp -R node_modules/ws "$R/node_modules/"
grep -E '^\s*OPENAI_API_KEY\s*=' .env > "$R/.env" || { echo "No OPENAI_API_KEY in .env"; exit 1; }
# Adobe RT-CDP (memory sync): its credentials and IDs too, when they're set. Like the OpenAI
# key, anyone with the app can read them: share it only with trusted people, rotate after.
grep -E '^REPORTS_URL=.+' .env >> "$R/.env" || true  # where problem reports go
if grep -qE '^AEP_CLIENT_SECRET=.+' .env; then
  grep -E '^AEP_[A-Z_]+=' .env >> "$R/.env"
  echo "  (Adobe RT-CDP credentials bundled)"
fi
[ -d data/knowledge ] && cp data/knowledge/*.json "$APP/Contents/Resources/seed/knowledge/" 2>/dev/null || true

cat > "$APP/Contents/Info.plist" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>CFBundleName</key><string>Talk to Website</string>
  <key>CFBundleDisplayName</key><string>Talk to Website</string>
  <key>CFBundleIdentifier</key><string>com.netomi.talktowebsite</string>
  <key>CFBundleExecutable</key><string>Talk to Website</string>
  <key>CFBundleIconFile</key><string>AppIcon</string>
  <key>CFBundlePackageType</key><string>APPL</string>
  <key>CFBundleShortVersionString</key><string>$VERSION</string>
  <key>CFBundleVersion</key><string>$VERSION</string>
  <key>LSMinimumSystemVersion</key><string>11.0</string>
  <key>LSUIElement</key><true/>
  <key>NSHighResolutionCapable</key><true/>
  <key>LSApplicationCategoryType</key><string>public.app-category.productivity</string>
</dict></plist>
PLIST

echo "→ ad-hoc signature"
codesign --force --deep --sign - "$APP"

echo "→ the disk image"
STAGE="$BUILD/dmg"
mkdir -p "$STAGE"
cp -R "$APP" "$STAGE/"
ln -s /Applications "$STAGE/Applications"
cat > "$STAGE/Read Me First.txt" <<TXT
Talk to Website $VERSION

1. Drag "Talk to Website" into Applications.
2. Open it. macOS will say it can't verify the developer: open System Settings → Privacy & Security, scroll down, and click "Open Anyway" next to Talk to Website (once).
3. A waveform icon appears in the menu bar, and a window shows how to add the Chrome extension:
   chrome://extensions → Developer mode → Load unpacked → the "Chrome Extension" folder it shows you.
4. On a website (e.g. sephora.com), click the extension's icon to turn it on, then hold Option+Space and talk, or click the orb.

Keep the app running while you use the assistant (it's in the menu bar, not the Dock).
TXT
hdiutil create -volname "Talk to Website" -srcfolder "$STAGE" -ov -format UDZO "$OUT/TalkToWebsite.dmg" >/dev/null
rm -rf "$BUILD"
echo
du -sh "$APP" "$OUT/TalkToWebsite.dmg"
echo "done: $OUT/TalkToWebsite.dmg"
