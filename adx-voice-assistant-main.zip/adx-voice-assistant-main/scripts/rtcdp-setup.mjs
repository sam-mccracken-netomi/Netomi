// One-time Adobe RT-CDP setup for memory sync. Safe to run again: it finds what exists by
// name and only creates what's missing, then writes the IDs into .env.
//   1. field group "Talk to Website Preferences" (_<tenant>.talkToWebsite: typed fields + facts[])
//   2. schema "Talk to Website Profiles" (XDM Individual Profile + person name + personal email
//      + the field group), personalEmail.address as the primary Email identity, Profile on
//   3. dataset "Talk to Website Profiles" (Profile and Identity on)
//   4. HTTP API streaming connection (authenticated) + source/target connections + dataflow
//   5. dataset "Talk to Website Customer Records" + its dataflow: the home address, as a CRM
//      would send it (scripts/rtcdp-zip.mjs); the assistant reads it and never writes it
//
//   node scripts/rtcdp-setup.mjs
import { readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { ROOT, loadEnv } from "../server/env.mjs";
import { createRtcdp, TYPED } from "../server/rtcdp.mjs";

loadEnv();
const cdp = createRtcdp();
const T = cdp.tenant();
if (!T) throw new Error("AEP_TENANT_ID is blank");
const NAME = "Talk to Website Profiles";
const FG_TITLE = "Talk to Website Preferences";
const HTTP_API = { id: "bc7b00d6-623a-4dfc-9fdb-f1240aeadaeb", version: "1.0" }; // HTTP API streaming source
const DATA_LAKE = { id: "c604ff05-7f1a-43c0-8e18-33bf874cb11c", version: "1.0" }; // dataset target
const STREAM_FLOW = { id: "d8a6f005-7eaf-4153-983e-e8574508b877", version: "1.0" }; // HTTP API → dataset
const XED = "application/vnd.adobe.xed+json", XED_ID = "application/vnd.adobe.xed-id+json", XED_FULL = "application/vnd.adobe.xed-full+json;version=1";

function setEnv(key, value) {
  const f = join(ROOT, ".env");
  let s = readFileSync(f, "utf8");
  s = new RegExp(`^${key}=.*$`, "m").test(s) ? s.replace(new RegExp(`^${key}=.*$`, "m"), `${key}=${value}`) : `${s.replace(/\n?$/, "\n")}${key}=${value}\n`;
  writeFileSync(f, s);
  process.env[key] = value;
}
const must = (r, what) => { if (!r.ok) throw new Error(`${what}: ${r.status} ${JSON.stringify(r.body).slice(0, 600)}`); return r.body; };
const say = (...a) => console.log(...a);

// ---- 1. field group ---------------------------------------------------------------------------
const str = (title, description) => ({ type: "string", title, description });
const fields = {
  skinType: str("Skin type", "e.g. Oily, Dry, Combination"),
  skinConcerns: str("Skin concerns", "e.g. Acne, Redness, Fine lines"),
  foundationShade: str("Foundation shade", "e.g. 220 Beige (Estée Lauder Double Wear)"),
  undertone: str("Undertone", "Warm, Cool, Neutral, Olive"),
  coverage: str("Coverage preference", "Light, Medium, Full"),
  finish: str("Finish preference", "Matte, Dewy, Satin, Natural"),
  preferredBrands: str("Preferred brands", "Brands they like"),
  avoids: str("Avoids", "Ingredients or product types they avoid"),
  scentPreferences: str("Scent preferences", "e.g. Fragrance-free, Floral"),
  hairType: str("Hair type", "e.g. Curly, Fine, Thick"),
  budget: str("Budget", "e.g. Under $40"),
  allergies: str("Allergies", "Ingredients they said they're allergic to, e.g. Shea butter, Fragrance"),
  facts: {
    type: "array", title: "Facts", description: "Everything the assistant learned, one entry per attribute; new kinds of attribute need no schema change",
    items: { type: "object", properties: {
      key: str("Key", "snake_case attribute name, e.g. coverage"), label: str("Label", "Readable name"), value: str("Value", "The value"),
      kind: str("Kind", "stated (they said it) or inferred (from what they did)"), confidence: { type: "number", title: "Confidence", description: "0 to 1" },
      evidence: str("Evidence", "Why we believe it"), site: str("Site", "Where it was learned, e.g. sephora.com"),
      updatedAt: { type: "string", format: "date-time", title: "Updated at" },
    } },
  },
  lastSite: str("Last site", "The site of the last update"),
  updatedAt: { type: "string", format: "date-time", title: "Updated at", description: "When the assistant last wrote this" },
};
if (Object.values(TYPED).some((f) => !fields[f])) throw new Error("a typed field is missing from the field group");

const fgs = must(await cdp.api("GET", `/data/foundation/schemaregistry/tenant/fieldgroups?property=title==${encodeURIComponent(FG_TITLE)}`, { accept: XED_ID }), "list field groups");
let fgId = fgs.results?.[0]?.["$id"];
if (fgId) {
  say(`field group: exists ${fgId}`);
  // fields added since it was created (adding is allowed on a Profile schema; nothing is removed)
  const cur = must(await cdp.api("GET", `/data/foundation/schemaregistry/tenant/fieldgroups/${encodeURIComponent(fgId)}`, { accept: XED }), "read field group");
  const have = cur.definitions?.talkToWebsite?.properties?.[`_${T}`]?.properties?.talkToWebsite?.properties || {};
  const missing = Object.keys(fields).filter((k) => !have[k]);
  if (missing.length) {
    must(await cdp.api("PATCH", `/data/foundation/schemaregistry/tenant/fieldgroups/${encodeURIComponent(fgId)}`, { accept: XED, body: missing.map((k) => ({ op: "add", path: `/definitions/talkToWebsite/properties/_${T}/properties/talkToWebsite/properties/${k}`, value: fields[k] })) }), "add fields");
    say(`field group: added ${missing.join(", ")}`);
  }
} else {
  const fg = must(await cdp.api("POST", "/data/foundation/schemaregistry/tenant/fieldgroups", { accept: XED, body: {
    title: FG_TITLE, description: "What the Talk to Website voice assistant learned about a shopper (stated and inferred preferences)",
    type: "object", "meta:intendedToExtend": ["https://ns.adobe.com/xdm/context/profile"],
    definitions: { talkToWebsite: { properties: { [`_${T}`]: { type: "object", properties: { talkToWebsite: { type: "object", title: "Talk to Website", description: "Shopper preferences from the voice assistant", properties: fields } } } } } },
    allOf: [{ $ref: "#/definitions/talkToWebsite" }],
  } }), "create field group");
  fgId = fg["$id"];
  say(`field group: created ${fgId}`);
}

// ---- 2. schema -------------------------------------------------------------------------------
const schemas = must(await cdp.api("GET", `/data/foundation/schemaregistry/tenant/schemas?property=title==${encodeURIComponent(NAME)}`, { accept: XED_ID }), "list schemas");
let schema = schemas.results?.[0];
let schemaId = schema?.["$id"];
if (schemaId) say(`schema: exists ${schemaId}`);
else {
  schema = must(await cdp.api("POST", "/data/foundation/schemaregistry/tenant/schemas", { accept: XED, body: {
    title: NAME, description: "Shoppers known to the Talk to Website voice assistant, by email", type: "object",
    allOf: [
      { $ref: "https://ns.adobe.com/xdm/context/profile" },
      { $ref: "https://ns.adobe.com/xdm/context/profile-person-details" },
      { $ref: "https://ns.adobe.com/xdm/context/profile-personal-details" },
      { $ref: fgId },
    ],
  } }), "create schema");
  schemaId = schema["$id"];
  say(`schema: created ${schemaId}`);
}
setEnv("AEP_SCHEMA_ID", schemaId);
const enc = encodeURIComponent(schemaId);

// primary identity: personalEmail.address in the Email namespace
const descs = must(await cdp.api("GET", `/data/foundation/schemaregistry/tenant/descriptors?property=xdm:sourceSchema==${encodeURIComponent(schemaId)}`, { accept: "application/vnd.adobe.xdm-v2+json" }), "list descriptors");
const hasIdentity = (descs.descriptors || descs.results || []).some((d) => d["@type"] === "xdm:descriptorIdentity" || String(d).includes("descriptorIdentity"));
if (hasIdentity) say("identity: personalEmail.address already the primary identity");
else {
  must(await cdp.api("POST", "/data/foundation/schemaregistry/tenant/descriptors", { accept: XED, body: {
    "@type": "xdm:descriptorIdentity", "xdm:sourceSchema": schemaId, "xdm:sourceVersion": 1, "xdm:sourceProperty": "/personalEmail/address",
    "xdm:namespace": process.env.AEP_IDENTITY_NAMESPACE || "Email", "xdm:property": "xdm:code", "xdm:isPrimary": true,
  } }), "set primary identity");
  say("identity: personalEmail.address set as the primary Email identity");
}

// Profile on (the "union" tag)
const full = must(await cdp.api("GET", `/data/foundation/schemaregistry/tenant/schemas/${enc}`, { accept: XED }), "read schema");
if ((full["meta:immutableTags"] || []).includes("union")) say("schema: already enabled for Profile");
else {
  must(await cdp.api("PATCH", `/data/foundation/schemaregistry/tenant/schemas/${enc}`, { accept: XED, body: [{ op: "add", path: "/meta:immutableTags", value: ["union"] }] }), "enable schema for Profile");
  say("schema: enabled for Profile");
}

// ---- 3. dataset ------------------------------------------------------------------------------
const dss = must(await cdp.api("GET", `/data/foundation/catalog/dataSets?name=${encodeURIComponent(NAME)}&properties=name,schemaRef,tags`), "list datasets");
let datasetId = Object.keys(dss || {}).find((id) => dss[id].schemaRef?.id === schemaId);
if (datasetId) say(`dataset: exists ${datasetId}`);
else {
  const r = must(await cdp.api("POST", "/data/foundation/catalog/dataSets", { body: {
    name: NAME, description: "Records streamed by the Talk to Website relay (one per shopper per update)",
    schemaRef: { id: schemaId, contentType: XED_FULL },
    tags: { unifiedProfile: ["enabled:true"], unifiedIdentity: ["enabled:true"] },
  } }), "create dataset");
  datasetId = String(r[0]).replace(/^@\/dataSets\//, "");
  say(`dataset: created ${datasetId} (Profile on)`);
}
setEnv("AEP_DATASET_ID", datasetId);

// ---- 4. streaming connection and dataflow ----------------------------------------------------
const conns = must(await cdp.api("GET", `/data/foundation/flowservice/connections?property=name==${encodeURIComponent(NAME)}`), "list connections");
let base = (conns.items || []).find((c) => c.connectionSpec?.id === HTTP_API.id);
if (!base) {
  const r = must(await cdp.api("POST", "/data/foundation/flowservice/connections", { body: {
    name: NAME, description: "The Talk to Website relay streams shopper preferences here",
    auth: { specName: "Streaming Connection", params: { sourceId: NAME, dataType: "xdm", name: NAME, authenticationRequired: true } },
    connectionSpec: HTTP_API,
  } }), "create streaming connection");
  base = must(await cdp.api("GET", `/data/foundation/flowservice/connections/${r.id}`), "read streaming connection").items[0];
  say(`streaming connection: created ${base.id}`);
} else say(`streaming connection: exists ${base.id}`);
const inletId = base.auth?.params?.inletId;
if (!inletId) throw new Error("the streaming connection has no inlet yet; run this again in a minute");
setEnv("AEP_STREAMING_CONNECTION_ID", inletId);

const flows = must(await cdp.api("GET", `/data/foundation/flowservice/flows?property=name==${encodeURIComponent(NAME)}`), "list dataflows");
let flow = (flows.items || [])[0];
if (!flow) {
  const src = must(await cdp.api("POST", "/data/foundation/flowservice/sourceConnections", { body: { name: `${NAME} source`, baseConnectionId: base.id, connectionSpec: HTTP_API } }), "create source connection");
  const tgt = must(await cdp.api("POST", "/data/foundation/flowservice/targetConnections", { body: {
    name: `${NAME} target`, connectionSpec: DATA_LAKE,
    data: { format: "parquet_xdm", schema: { id: schemaId, version: XED_FULL } }, params: { dataSetId: datasetId },
  } }), "create target connection");
  const f = must(await cdp.api("POST", "/data/foundation/flowservice/flows", { body: {
    name: NAME, description: "Talk to Website relay → Talk to Website Profiles dataset", flowSpec: STREAM_FLOW,
    sourceConnectionIds: [src.id], targetConnectionIds: [tgt.id],
  } }), "create dataflow");
  flow = { id: f.id };
  say(`dataflow: created ${flow.id}`);
} else say(`dataflow: exists ${flow.id}`);
setEnv("AEP_DATAFLOW_ID", flow.id);

// ---- 5. customer records (stands in for a CRM: the home address, which the assistant only reads)
const CRM = "Talk to Website Customer Records";
const crmDss = must(await cdp.api("GET", `/data/foundation/catalog/dataSets?name=${encodeURIComponent(CRM)}&properties=name,schemaRef`), "list datasets");
let crmDataset = Object.keys(crmDss || {}).find((id) => crmDss[id].schemaRef?.id === schemaId);
if (crmDataset) say(`customer records dataset: exists ${crmDataset}`);
else {
  const r = must(await cdp.api("POST", "/data/foundation/catalog/dataSets", { body: {
    name: CRM, description: "Customer records (home address), as a CRM would send them; merged into the same profiles",
    schemaRef: { id: schemaId, contentType: XED_FULL }, tags: { unifiedProfile: ["enabled:true"], unifiedIdentity: ["enabled:true"] },
  } }), "create customer records dataset");
  crmDataset = String(r[0]).replace(/^@\/dataSets\//, "");
  say(`customer records dataset: created ${crmDataset} (Profile on)`);
}
setEnv("AEP_CRM_DATASET_ID", crmDataset);
const crmFlows = must(await cdp.api("GET", `/data/foundation/flowservice/flows?property=name==${encodeURIComponent(CRM)}`), "list dataflows");
let crmFlow = (crmFlows.items || [])[0];
if (!crmFlow) {
  const src = must(await cdp.api("POST", "/data/foundation/flowservice/sourceConnections", { body: { name: `${CRM} source`, baseConnectionId: base.id, connectionSpec: HTTP_API } }), "create source connection");
  const tgt = must(await cdp.api("POST", "/data/foundation/flowservice/targetConnections", { body: {
    name: `${CRM} target`, connectionSpec: DATA_LAKE, data: { format: "parquet_xdm", schema: { id: schemaId, version: XED_FULL } }, params: { dataSetId: crmDataset },
  } }), "create target connection");
  const f = must(await cdp.api("POST", "/data/foundation/flowservice/flows", { body: {
    name: CRM, description: "Customer records → Talk to Website Customer Records dataset", flowSpec: STREAM_FLOW, sourceConnectionIds: [src.id], targetConnectionIds: [tgt.id],
  } }), "create dataflow");
  crmFlow = { id: f.id };
  say(`customer records dataflow: created ${crmFlow.id} (give it a few minutes before the first write)`);
} else say(`customer records dataflow: exists ${crmFlow.id}`);
setEnv("AEP_CRM_DATAFLOW_ID", crmFlow.id);

say(`\nDone. .env has AEP_SCHEMA_ID, AEP_DATASET_ID, AEP_STREAMING_CONNECTION_ID, AEP_DATAFLOW_ID, AEP_CRM_DATASET_ID and AEP_CRM_DATAFLOW_ID.`);
