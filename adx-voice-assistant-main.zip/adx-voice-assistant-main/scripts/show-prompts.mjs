// Writes docs/PROMPTS.md: every prompt the assistant uses, rendered with example values
// (a Sephora visitor who looked at two blushes). Run after changing a prompt.
import { writeFileSync, mkdirSync } from "node:fs";
import { join } from "node:path";
import { ROOT } from "../server/env.mjs";
import { instructions, greeting, nudge } from "../server/persona.mjs";
import { instructions as plannerInstructions, TOOLS, BrowserAgent } from "../server/browser-agent.mjs";
import { prompt } from "../server/prompts.mjs";

const min = 60000;
const visits = [
  { url: "https://www.sephora.com/search?keyword=blush", kind: "search", query: "blush", at: Date.now() - 15 * min },
  { url: "https://www.sephora.com/product/a", kind: "product", brand: "Rare Beauty", name: "Soft Pinch Liquid Blush", price: "$23", at: Date.now() - 10 * min },
  { url: "https://www.sephora.com/product/b", kind: "product", brand: "NARS", name: "Orgasm Blush", price: "$34", at: Date.now() - 1 * min },
];
const page = { url: "https://www.sephora.com/product/b", title: "NARS Orgasm Blush | Sephora", site: "sephora.com", visits };
const earlier = [{ role: "user", text: "Compare the two blushes I looked at" }, { role: "agent", text: "The NARS one is a powder for $34; the Rare Beauty one is a liquid for $23." }];
const snapshot = { text: 'URL: https://www.sephora.com/product/b\nTitle: NARS Orgasm Blush | Sephora\n\nElements:\n[1] searchbox "Search" value=""\n[2] button "Add to Basket"\n…\n\nPage text:\n…' };
const passages = [{ ref: "K1", title: "Returns & Exchanges | Sephora", section: "1. Sephora.com Returns by Mail", text: "(passage text from the knowledge base…)", url: "https://www.sephora.com/beauty/returns-exchanges" }];

const section = (n, title, body) => `## ${n}. ${title}\n\n\`\`\`text\n${body}\n\`\`\`\n`;
const md = [
  "# Prompts and instructions",
  "",
  "Rendered with example values by `node scripts/show-prompts.mjs` (including any edits saved from the extension's settings page). Sources: `server/persona.mjs` (the voice, greetings, nudges), `server/browser-agent.mjs` (the planner), `server/conversation.mjs` (how the planner's answer reaches the voice).",
  "",
  section(1, "Voice (GPT-Live): system instructions", instructions({ name: "Assistant", page, history: [] })),
  section("2a", "Greeting: first click on a site", greeting({ site: "sephora.com", page, visits, history: [], lastAt: null })),
  section("2b", "Greeting: returning visitor", greeting({ site: "sephora.com", page, visits, history: earlier, lastAt: Date.now() - 3 * 60 * min })),
  section("2c", "Nudge: opened another product mid-conversation", nudge({ page, visits })),
  section(3, "Planner (browser agent): system instructions", plannerInstructions()),
  section(4, "Planner tools", TOOLS.map((t) => JSON.stringify(t, null, 2)).join("\n\n")),
  section(5, "Planner: one step's prompt", new BrowserAgent({ page: {} }).prompt("Can I return this if I have opened it?", [{ role: "user", text: "Can I return this if I have opened it?" }], [], snapshot, visits, passages)),
  section(6, "How the planner's answer is handed to the voice", [
    `done:      ${prompt("handoffDone", { say: "<say>" })}`,
    `need_info: ${prompt("handoffNeedInfo", { say: "<say>" })}`,
    `cannot:    ${prompt("handoffCannot", { say: "<say>" })}`,
    `+ a card:  ${prompt("handoffCard")}`,
    `progress:  ${prompt("progress", { note: "<why>" })}   (long tasks: after 7 s, at most every 12 s)`,
    `safety:    ${prompt("safety", { brand: "Sephora" })}   (after the voice service blocks a topic)`,
  ].join("\n")),
].join("\n");
mkdirSync(join(ROOT, "docs"), { recursive: true });
writeFileSync(join(ROOT, "docs", "PROMPTS.md"), md);
console.log("docs/PROMPTS.md written");
