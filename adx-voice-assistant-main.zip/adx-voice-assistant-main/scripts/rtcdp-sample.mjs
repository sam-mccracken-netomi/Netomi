// A sample shopper in RT-CDP, written the way the relay will write memory, then read back
// through the Profile Access API (as the relay will at the start of a conversation).
//   node scripts/rtcdp-sample.mjs [email]        default: john.sample@example.com
//   node scripts/rtcdp-sample.mjs --read [email] only fetch
import { loadEnv } from "../server/env.mjs";
import { createRtcdp } from "../server/rtcdp.mjs";

loadEnv();
const args = process.argv.slice(2);
const readOnly = args[0] === "--read";
const email = (readOnly ? args[1] : args[0]) || "john.sample@example.com";
const cdp = createRtcdp({ log: (k, d) => console.log(k, d) });
if (!cdp.configured()) { console.log("RT-CDP isn't set up yet: run node scripts/rtcdp-setup.mjs first"); process.exit(1); }

const show = (p) => {
  console.log(`  name:   ${p.name || "(none)"}`);
  console.log(`  email:  ${p.email}`);
  console.log(`  typed:  ${JSON.stringify(p.typed)}`);
  console.log(`  facts:`);
  for (const f of p.facts) console.log(`    - ${f.label}: ${f.value}  [${f.kind}${f.kind === "inferred" ? ` ${Math.round(f.confidence * 100)}%` : ""}, ${f.site}] ${f.evidence}`);
};

if (!readOnly) {
  const now = Date.now();
  const facts = [
    { key: "skin_type", label: "Skin type", value: "Oily", kind: "stated", confidence: 0.95, evidence: 'said: "I have really oily skin"', site: "sephora.com", updatedAt: now },
    { key: "coverage", label: "Coverage preference", value: "Light", kind: "stated", confidence: 0.9, evidence: 'said: "I like light coverage"', site: "sephora.com", updatedAt: now },
    { key: "foundation_shade", label: "Foundation shade", value: "220 Beige (Estée Lauder Double Wear)", kind: "stated", confidence: 0.9, evidence: "said their shade", site: "sephora.com", updatedAt: now },
    { key: "budget", label: "Budget", value: "Under $40", kind: "inferred", confidence: 0.6, evidence: "price filter $0-$40 on foundations", site: "sephora.com", updatedAt: now },
    // an attribute with no typed field: kept in facts[] only, no schema change needed
    { key: "lash_style", label: "Lash style", value: "Natural, wispy", kind: "inferred", confidence: 0.5, evidence: "viewed 3 wispy lash products", site: "sephora.com", updatedAt: now },
  ];
  console.log(`writing ${email} …`);
  // a dataflow created minutes ago may not have reached the inlet yet ("wrong flowId")
  let r;
  for (let i = 0; i < 20; i++) {
    r = await cdp.save(email, { name: "John Sample", facts, site: "sephora.com" });
    if (r.ok || !/wrong flowId/.test(r.error || "")) break;
    console.log("  the new dataflow isn't active at the inlet yet; trying again in 30 s");
    await new Promise((res) => setTimeout(res, 30000));
  }
  if (!r.ok) { console.log(`write failed: ${r.status} ${r.error}`); process.exit(1); }
  console.log(`written (validated by Adobe, ${r.status}). Waiting for it to reach the profile…`);
}

const t0 = Date.now();
for (let i = 0; ; i++) {
  const p = await cdp.profile(email);
  if (p.found && (readOnly || p.facts.length)) {
    console.log(`\nprofile found after ${Math.round((Date.now() - t0) / 1000)} s:`);
    show(p);
    break;
  }
  if (Date.now() - t0 > 6 * 60e3) { console.log("not on the profile after 6 minutes; check the dataflow's runs in Sources → Dataflows"); process.exit(1); }
  if (readOnly && !p.found) { console.log("no profile for that email"); process.exit(1); }
  await new Promise((r) => setTimeout(r, 10000));
}
