// The voice, in the extension's offscreen document: it keeps the mic, the speaker and the
// conversation with the relay going while pages load in the tab. It talks only to the
// background worker, which relays to and from the widget in the page.
//
// One voice per site, with its own stored transcript and conversation: switching sites
// ends the conversation and starts clean, so nothing said on one site reaches another.

const SERVER = "ws://localhost:5179"; // the relay (npm start)

const persistFor = (site) => ({
  get(k) { try { return JSON.parse(localStorage.getItem(`ttw:${site}:${k}`)); } catch { return null; } },
  set(k, v) { try { localStorage.setItem(`ttw:${site}:${k}`, JSON.stringify(v)); } catch {} },
});

let port = null;
let voice = null;
let site = null; // the site the voice belongs to
let lastTick = "";

function post(m) { try { port?.postMessage({ site, ...m }); } catch {} }

function connect() {
  port = chrome.runtime.connect({ name: "voice" });
  port.onMessage.addListener(onMessage);
  port.onDisconnect.addListener(() => { port = null; setTimeout(connect, 300); }); // the worker restarted
}

function voiceFor(s, name) {
  if (voice && site === s) return voice;
  if (voice) { voice.stop(); voice.destroy(); }
  site = s;
  voice = TalkVoice.create({
    server: SERVER, name: name || "Assistant", persist: persistFor(s),
    onEvent(type, data) {
      if (type === "state") post({ type: "status", status: voice.status() });
      else if (type === "messages") post({ type: "messages", messages: voice.messages() });
      else if (type === "message") post({ type: "message", ...data });
      else if (type === "notice") post({ type: "notice", ...data });
      else if (type === "page") post({ type: "page", req: data });
      else if (type === "card") post({ type: "card", card: data });
      else if (type === "report.open") post({ type: "report.open" });
    },
  });
  post({ type: "messages", messages: voice.messages() });
  return voice;
}

function onMessage(m) {
  if (m.type === "cmd") {
    const v = voiceFor(m.site, m.name);
    if (typeof v[m.cmd] === "function") v[m.cmd](...(m.args || []));
  } else if (m.type === "sync") {
    // a tab of m.site connected: its transcript and (if it's this voice's site) the live state
    if (voice && site === m.site) {
      post({ type: "status", status: voice.status(), to: m.to });
      post({ type: "messages", messages: voice.messages(), to: m.to });
    } else {
      port?.postMessage({ site: m.site, to: m.to, type: "messages", messages: persistFor(m.site).get("messages") || [] });
      port?.postMessage({ site: m.site, to: m.to, type: "status", status: { session: "off" } });
    }
  } else if (m.type === "page.ready") { if (voice && site === m.site) voice.pageReady(m.page); }
  else if (m.type === "page.gone") voice?.pageGone();
  else if (m.type === "page.response") voice?.respond(m.id, m.ok, m.result);
  else if (m.type === "stop") voice?.stop();
  else if (m.type === "forget") forget(m.site);
}

// start afresh on a site (or, with no site, everywhere): the live conversation ends and its
// transcript and resume state are dropped; the voice-mute preference stays
function forget(s) {
  if (voice && (!s || site === s)) voice.forget();
  const prefix = s ? `ttw:${s}:` : "ttw:";
  for (const k of Object.keys(localStorage)) if (k.startsWith(prefix) && !k.endsWith(":voiceMuted")) localStorage.removeItem(k);
}

// the orb's view and audio level, ~30 times a second while there's something to show
setInterval(() => {
  if (!voice) return;
  const t = voice.tick();
  const key = `${t.view}:${t.level.toFixed(2)}`;
  if (key === lastTick && t.view === "idle") return;
  lastTick = key;
  post({ type: "tick", view: t.view, level: t.level });
}, 33);

connect();
