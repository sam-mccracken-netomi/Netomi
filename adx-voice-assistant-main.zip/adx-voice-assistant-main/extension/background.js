// The extension's coordinator.
//  - Click the toolbar icon to turn the assistant on or off for a site (sephora.com, all of
//    its pages and tabs). While it's on, the widget is injected into every page of that
//    site; it keeps the site's browsing history even when you're not talking.
//  - The voice (mic, speaker, the connection to the relay) lives in an offscreen document,
//    so a page load never interrupts the conversation or a task in progress. The widget in
//    the page draws the orb and runs the page agent.
//  - This worker routes between them: commands and page answers from the tab → voice;
//    state, transcript and page requests from the voice → the tab(s) of the same site only.
//  - One conversation, in one tab: the active tab of the site. Other tabs of the site show
//    the transcript but a resting orb; switch to another tab of the site and the
//    conversation (and any task in progress) moves there and carries on.
// The widget runs in the extension's isolated world, so the page's CSP doesn't block it.

const ENABLED = "enabledSites";
const HTTP = "http://localhost:5179"; // the relay (npm start)
const ui = new Map(); // tabId → { port, site }
const pages = new Map(); // tabId → page info from the widget
let voice = null; // port of the offscreen document
let voiceQueue = [];
let agentTab = null; // the tab the conversation operates
let agentSite = null; // the site of the conversation
let name = "Assistant";
let activeTab = null; // the tab the visitor is looking at (focused window)

// the registrable domain, roughly: www.sephora.com and m.sephora.com are both sephora.com
function siteOf(url) {
  let host;
  try { host = new URL(url).hostname; } catch { return null; }
  const parts = host.replace(/^www\d?\./, "").split(".");
  if (parts.length <= 2 || /^\d+$/.test(parts.at(-1))) return parts.join(".");
  const sld = parts.at(-2);
  return parts.slice(parts.at(-1).length === 2 && /^(co|com|org|net|gov|ac|edu|ne|or)$/.test(sld) ? -3 : -2).join(".");
}

const enabledSites = async () => (await chrome.storage.local.get(ENABLED))[ENABLED] || {};
chrome.storage.session.get(["agentTab", "agentSite"]).then((v) => { agentTab ??= v.agentTab ?? null; agentSite ??= v.agentSite ?? null; });

async function ensureOffscreen() {
  const existing = await chrome.runtime.getContexts({ contextTypes: ["OFFSCREEN_DOCUMENT"] });
  if (existing.length) return;
  await chrome.offscreen.createDocument({
    url: "offscreen.html",
    reasons: ["USER_MEDIA"],
    justification: "A voice conversation with the assistant that continues while pages load in the tab.",
  }).catch((e) => { if (!/single offscreen/i.test(e.message)) throw e; });
}

function toVoice(msg) {
  if (voice) return voice.postMessage(msg);
  voiceQueue.push(msg);
  ensureOffscreen();
}

const OFF = { type: "status", status: { session: "off" } };
const REST = { type: "tick", view: "idle", level: 0 };

function setAgentTab(tabId, site) {
  if (agentTab === tabId && agentSite === site) return;
  if (agentTab != null) toVoice({ type: "page.gone" });
  // the old tab's orb goes to rest: the conversation lives in one tab only
  const old = agentTab !== tabId && ui.get(agentTab);
  if (old) { old.port.postMessage({ site: old.site, ...OFF }); old.port.postMessage({ site: old.site, ...REST }); }
  agentTab = tabId;
  agentSite = site;
  chrome.storage.session.set({ agentTab, agentSite });
  if (ui.has(tabId)) toVoice({ type: "page.ready", site, page: pages.get(tabId) });
}

chrome.runtime.onConnect.addListener((port) => {
  if (port.name === "voice") {
    voice = port;
    for (const m of voiceQueue.splice(0)) port.postMessage(m);
    port.onMessage.addListener(fromVoice);
    port.onDisconnect.addListener(() => { if (voice === port) voice = null; });
    return;
  }
  if (port.name !== "ui" || !port.sender?.tab) return;
  const tabId = port.sender.tab.id;
  const site = siteOf(port.sender.tab.url || port.sender.url);
  ui.set(tabId, { port, site });
  port.onMessage.addListener((m) => fromTab(tabId, site, m));
  port.onDisconnect.addListener(() => {
    if (ui.get(tabId)?.port !== port) return;
    ui.delete(tabId);
    if (tabId === agentTab) toVoice({ type: "page.gone" }); // a page load, or the tab closed
  });
});

function fromTab(tabId, site, m) {
  if (m.type === "hello") {
    pages.set(tabId, m.page);
    if (m.name) name = m.name;
    // the conversation's tab went to another site: that conversation ends here
    if (tabId === agentTab && site !== agentSite) {
      toVoice({ type: "stop" });
      agentTab = agentSite = null;
      chrome.storage.session.set({ agentTab, agentSite });
    }
    toVoice({ type: "sync", site, to: tabId });
    mapSite(tabId, site);
    if (tabId === agentTab) toVoice({ type: "page.ready", site, page: m.page });
    else if (tabId === activeTab) follow(tabId); // e.g. a link that opened in a new tab
  } else if (m.type === "cmd") {
    if (["start", "toggle", "pttDown"].includes(m.cmd)) setAgentTab(tabId, site);
    toVoice({ type: "cmd", cmd: m.cmd, args: m.args, name, site });
  } else if (m.type === "page.update") {
    pages.set(tabId, m.page);
    if (tabId === agentTab) toVoice({ type: "page.ready", site, page: m.page });
  } else if (m.type === "page.response") {
    toVoice(m);
  } else if (m.type === "kb.status") {
    sendKb(site, tabId);
  } else if (m.type === "kb.learn") {
    learnSite(tabId);
  } else if (m.type === "open.settings") {
    chrome.runtime.openOptionsPage();
  } else if (m.type === "offers.status") {
    offersStatus(site).then((status) => ui.get(tabId)?.port.postMessage({ type: "offers", status }));
  } else if (m.type === "offers.scan") {
    scanOffers(tabId);
  } else if (m.type === "memory.learn") {
    // what the visitor did on the site by themselves (the voice may be off): to memory
    fetch(`${HTTP}/memory/${encodeURIComponent(site)}/learn`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ visits: m.visits || [], events: m.events || [] }) }).catch(() => {});
  } else if (m.type === "memory.account") {
    // who's signed in on the site, for the settings page's memory list
    fetch(`${HTTP}/memory/${encodeURIComponent(site)}/account`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ name: m.name, email: m.email, from: m.from }) }).catch(() => {});
  } else if (m.type === "forget") {
    forget(site);
  } else if (m.type === "report") {
    report(tabId, site, m);
  }
}

// a problem report from the widget: the relay finds the site's latest conversation (the
// voice's own id is gone once it ends) and saves the note with its logs
async function report(tabId, site, { reporter, note, page, transcript }) {
  let out;
  try {
    const r = await fetch(`${HTTP}/reports`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ site, reporter, note, page, transcript }) });
    const j = await r.json().catch(() => ({}));
    out = r.ok ? j : { ok: false, error: j.error || `the relay said ${r.status}` };
  } catch {
    out = { ok: false, error: "can't reach the relay (is it running?)" };
  }
  ui.get(tabId)?.port.postMessage({ type: "reported", ...out });
}

// start afresh: forget a site's conversation and browsing history (no site: every site's).
// Which sites are turned on, and the knowledge bases, are kept.
async function forget(site) {
  if (!site || agentSite === site) {
    agentTab = agentSite = null;
    chrome.storage.session.set({ agentTab, agentSite });
  }
  toVoice({ type: "forget", site });
  const prefix = site ? `ttw:${site}:` : "ttw:";
  const keys = Object.keys(await chrome.storage.local.get(null)).filter((k) => k.startsWith(prefix));
  await chrome.storage.local.remove(keys);
  // and what was learned about them, kept on the relay
  fetch(`${HTTP}/memory/${site ? `${encodeURIComponent(site)}/forget` : "forget-all"}`, { method: "POST" }).catch(() => {});
  for (const t of ui.values()) if (!site || t.site === site) t.port.postMessage({ type: "forgotten" });
}
self.forget = forget;

function fromVoice(m) {
  if (m.to != null) {
    // a tab that isn't the conversation's sees the transcript, never the live state
    if (m.type === "status" && m.to !== agentTab) return ui.get(m.to)?.port.postMessage({ ...m, ...OFF });
    return ui.get(m.to)?.port.postMessage(m); // an answer for one tab
  }
  if (m.type === "page") {
    const t = ui.get(agentTab);
    if (t && t.site === m.site) t.port.postMessage(m);
    else toVoice({ type: "page.gone" }); // mid-load: the server waits for the next page
    return;
  }
  if (m.type === "notice" && m.code === "mic-permission") return askForMic();
  // the live state, the orb, cards and notices: only where the conversation is
  if (["card", "status", "tick", "notice", "report.open"].includes(m.type)) {
    const t = ui.get(agentTab);
    if (t && t.site === m.site) t.port.postMessage(m);
    return;
  }
  for (const t of ui.values()) if (t.site === m.site) t.port.postMessage(m); // same site only
}

// The offscreen document can't show the microphone prompt, so the first time a page of
// the extension asks for it; after that the offscreen document has access.
async function askForMic() {
  const url = chrome.runtime.getURL("permission.html");
  const [open] = await chrome.tabs.query({ url });
  if (open) return chrome.tabs.update(open.id, { active: true });
  chrome.tabs.create({ url, active: true });
}

chrome.runtime.onMessage.addListener((m, sender) => {
  if (m?.type === "forget-all" && sender.url?.startsWith(chrome.runtime.getURL(""))) return void forget(null); // the settings page
  if (m?.type !== "mic-granted") return;
  if (sender.tab?.id) chrome.tabs.remove(sender.tab.id);
  if (agentTab != null) chrome.tabs.update(agentTab, { active: true }).catch(() => {});
  for (const t of ui.values()) t.port.postMessage({ type: "notice", text: "Microphone allowed. Hold ⌥ Space or click the orb to talk.", kind: "info" });
});

// ---- turning it on and off per site -------------------------------------------------------
async function inject(tabId) {
  await chrome.scripting.executeScript({
    target: { tabId },
    func: () => { window.TalkWidgetConfig = { ...(window.TalkWidgetConfig || {}), mode: "extension" }; },
  });
  await chrome.scripting.executeScript({ target: { tabId }, files: ["widget.js"] });
}

const badge = (tabId, on) => {
  chrome.action.setBadgeText({ tabId, text: on ? "on" : "" });
  if (on) { chrome.action.setBadgeBackgroundColor({ tabId, color: "#2C2E3D" }); chrome.action.setBadgeTextColor?.({ tabId, color: "#fff" }); }
};

// the toolbar icon (also callable from a test harness through the worker: toggleTab(tab))
async function toggleTab(tab) {
  const url = tab.url || (await chrome.tabs.get(tab.id)).url;
  const site = siteOf(url);
  if (!site) return;
  const sites = await enabledSites();
  const tabs = (await chrome.tabs.query({})).filter((t) => siteOf(t.url) === site);
  if (sites[site]) {
    delete sites[site];
    await chrome.storage.local.set({ [ENABLED]: sites });
    if (agentSite === site) toVoice({ type: "stop" });
    for (const t of tabs) {
      chrome.scripting.executeScript({ target: { tabId: t.id }, func: () => window.__talkWidget?.destroy() }).catch(() => {});
      badge(t.id, false);
    }
    return;
  }
  sites[site] = true;
  await chrome.storage.local.set({ [ENABLED]: sites });
  await ensureOffscreen();
  for (const t of tabs) inject(t.id).then(() => badge(t.id, true)).catch((e) => console.warn("Talk to Website: can't run on this page", e));
}
chrome.action.onClicked.addListener(toggleTab);
self.toggleTab = toggleTab;

// every page of an enabled site gets the widget as soon as its DOM is ready
chrome.webNavigation.onDOMContentLoaded.addListener(async ({ tabId, frameId, url }) => {
  if (frameId !== 0 || crawlTabs.has(tabId) || !(await enabledSites())[siteOf(url)]) return;
  inject(tabId).then(() => badge(tabId, true)).catch(() => {});
});
chrome.webNavigation.onBeforeNavigate.addListener(({ tabId, frameId }) => {
  if (frameId === 0 && tabId === agentTab) toVoice({ type: "page.gone" });
});

chrome.tabs.onRemoved.addListener((tabId) => {
  if (tabId !== agentTab) return;
  // another open tab of the site carries on the conversation; with none left, it ends
  const next = [...ui.entries()].find(([id, t]) => id !== tabId && t.site === agentSite);
  if (next) { agentTab = null; follow(next[0]); } else toVoice({ type: "stop" });
});

// the conversation follows the visitor to whichever tab of its site they're looking at
function follow(tabId) {
  const t = ui.get(tabId);
  if (!t || agentSite == null || t.site !== agentSite || tabId === agentTab) return;
  setAgentTab(tabId, t.site);
  toVoice({ type: "sync", site: t.site, to: tabId }); // its orb and panel pick up the live state
}
async function noteActive(windowId) {
  if (windowId === chrome.windows.WINDOW_ID_NONE) return;
  const [tab] = await chrome.tabs.query({ active: true, windowId }).catch(() => []);
  if (!tab) return;
  activeTab = tab.id;
  follow(tab.id);
}
chrome.tabs.onActivated.addListener(({ tabId, windowId }) => { activeTab = tabId; follow(tabId); noteActive(windowId); });
chrome.windows.onFocusChanged.addListener(noteActive);
chrome.tabs.query({ active: true, lastFocusedWindow: true }).then(([t]) => { if (t) activeTab ??= t.id; }).catch(() => {});

// ---- learning a site's help pages (the local knowledge base) ----------------------------------
// Runs in the visitor's own browser, through their tab on the site, because big retailers
// block automated crawlers. Help pages are found from a few seeds and the help-looking links
// on the current page (footers), then followed two levels deep. Each page is fetched and
// parsed in the visitor's tab; pages that only render with JavaScript get a background tab.
// The text, split by heading, goes to the relay, which indexes it (see server/knowledge.mjs).

const MAX_PAGES = 80;
const SEEDS = {
  "sephora.com": ["/beauty/customer-service", "/beauty/returns-exchanges", "/beauty/shipping-handling", "/beauty/ordering", "/beauty/payment-methods",
    "/beauty/gift-cards", "/beauty/faq", "/beauty/beauty-insider", "/beauty/same-day-delivery", "/beauty/buy-online-pick-up-in-store",
    "/beauty/price-adjustments", "/beauty/auto-replenish", "/beauty/contact-us", "/beauty/sephora-credit-card", "/beauty/beauty-services-faq"],
};
const GENERIC_SEEDS = ["/help", "/faq", "/faqs", "/customer-service", "/support", "/returns", "/shipping", "/pages/faq", "/pages/shipping", "/pages/returns"];
const HELP = /help|faq|return|exchange|refund|shipping|deliver|pick[- ]?up|polic|customer|contact|order|payment|gift[- ]?card|reward|loyal|insider|member|price[- ]?(match|adjust)|terms|warrant|track|cancel|replenish|credit[- ]?card|store[- ]?services|support/i;
const NOT_HELP = /\/(product|products|p|shop|brand|brands|search|s|cart|basket|bag|checkout|account|profile|login|signin|sign-in|register|collections)(\/|$)|\.(pdf|jpe?g|png|gif|zip)$/i;
const learning = new Map(); // site → progress
const crawlTabs = new Set(); // background tabs opened for crawling (no widget, no history)

// self-contained: runs inside the site's tab (executeScript serializes it)
async function grabPage(url) {
  try {
    let doc = document, base = location.href;
    if (url) {
      const r = await fetch(url, { credentials: "include", redirect: "follow" });
      if (!r.ok) return { ok: false, status: r.status };
      base = r.url;
      doc = new DOMParser().parseFromString(await r.text(), "text/html");
    }
    const squash = (t) => String(t || "").replace(/\s+/g, " ").trim();
    const links = [];
    for (const a of doc.querySelectorAll("a[href]")) {
      let href;
      try { href = new URL(a.getAttribute("href"), base).href.split("#")[0]; } catch { continue; }
      if (/^https?:/.test(href)) links.push({ href, text: squash(a.textContent).slice(0, 80) });
    }
    const main = doc.querySelector("main, [role=main], article, #main, #content") || doc.body;
    if (!main) return { ok: false };
    const root = main.cloneNode(true);
    root.querySelectorAll("script,style,noscript,template,svg,nav,header,footer,aside,form,button,select,iframe,[role=navigation],[role=banner],[role=contentinfo]").forEach((n) => n.remove());
    const BLOCK = "h1,h2,h3,h4,h5,h6,p,li,dt,dd,td,th,summary,blockquote,pre,div,section";
    const sections = [];
    let cur = { heading: "", text: [] };
    for (const el of root.querySelectorAll(BLOCK)) {
      if (el.querySelector(BLOCK)) continue; // leaf blocks only: no text counted twice
      const t = squash(el.textContent);
      if (!t) continue;
      if (/^H[1-6]$/.test(el.tagName)) { if (cur.text.length) sections.push(cur); cur = { heading: t.slice(0, 140), text: [] }; continue; }
      if ((el.tagName === "DIV" || el.tagName === "SECTION") && t.length < 25) continue;
      if (cur.text.at(-1) !== t) cur.text.push(t);
    }
    if (cur.text.length) sections.push(cur);
    const out = sections.map((x) => ({ heading: x.heading, text: x.text.join("\n") }));
    return { ok: true, url: base, title: squash(doc.title || doc.querySelector("h1")?.textContent), sections: out, chars: out.reduce((n, x) => n + x.text.length, 0), links };
  } catch (e) {
    return { ok: false, error: String(e?.message || e) };
  }
}

async function inTab(tabId, func, args) {
  try { return (await chrome.scripting.executeScript({ target: { tabId }, func, args }))[0]?.result; } catch { return null; }
}

async function grabInBackgroundTab(url, grab = grabPage) {
  const tab = await chrome.tabs.create({ url, active: false });
  crawlTabs.add(tab.id);
  try {
    await new Promise((resolve) => {
      const done = () => { chrome.tabs.onUpdated.removeListener(onUpd); clearTimeout(t); resolve(); };
      const onUpd = (id, info) => { if (id === tab.id && info.status === "complete") done(); };
      const t = setTimeout(done, 20000);
      chrome.tabs.onUpdated.addListener(onUpd);
    });
    await new Promise((r) => setTimeout(r, 2500)); // client-rendered content
    return await inTab(tab.id, grab, [null]);
  } finally {
    crawlTabs.delete(tab.id);
    chrome.tabs.remove(tab.id).catch(() => {});
  }
}

const tabsOfSite = (site) => [...ui.values()].filter((t) => t.site === site);
function broadcastKb(site, status) { for (const t of tabsOfSite(site)) t.port.postMessage({ type: "kb", status }); }
async function kbStatus(site) {
  if (learning.has(site)) return learning.get(site);
  try { return await (await fetch(`${HTTP}/knowledge/${encodeURIComponent(site)}/status`)).json(); } catch { return { site, pages: 0, offline: true }; }
}
async function sendKb(site, tabId) { ui.get(tabId)?.port.postMessage({ type: "kb", status: await kbStatus(site) }); }

async function learnSite(tabId) {
  const tab = await chrome.tabs.get(tabId);
  const site = siteOf(tab.url);
  if (!site || learning.has(site)) return;
  const origin = new URL(tab.url).origin;
  const progress = { site, learning: true, checked: 0, found: 0 };
  learning.set(site, progress);
  broadcastKb(site, progress);
  const queue = [], seen = new Set(), pages = [];
  const add = (href, depth) => {
    let u;
    try { u = new URL(href, origin); } catch { return; }
    if (siteOf(u.href) !== site || NOT_HELP.test(u.pathname)) return;
    // tracking parameters (Sephora's icid2, utm_…) would make every link a "new" page
    for (const k of [...u.searchParams.keys()]) if (/^(icid\d*|utm_|ref|cm_|_ga|gclid|fbclid|om_|cid)/i.test(k)) u.searchParams.delete(k);
    const key = `${u.hostname.replace(/^www\./, "")}${u.pathname.replace(/\/$/, "")}${u.search}`;
    if (seen.has(key)) return;
    seen.add(key);
    queue.push({ url: `${u.origin}${u.pathname}${u.search}`, depth });
  };
  const helpLink = (l) => { try { return HELP.test(l.text) || HELP.test(new URL(l.href).pathname); } catch { return false; } };
  try {
    for (const p of SEEDS[site] || GENERIC_SEEDS) add(p, 0);
    // help links in this page's header and footer (many sites only render the footer once
    // it's scrolled into view): peek at the bottom, then put the page back where it was
    await inTab(tabId, async () => { const y = scrollY; scrollTo(0, document.body.scrollHeight); await new Promise((r) => setTimeout(r, 1800)); scrollTo(0, document.body.scrollHeight); await new Promise((r) => setTimeout(r, 1200)); scrollTo(0, y); }, []);
    const here = await inTab(tabId, grabPage, [null]);
    for (const l of here?.links || []) if (helpLink(l)) add(l.href, 1);
    let rendered = 0;
    while (queue.length && pages.length < MAX_PAGES) {
      const batch = queue.splice(0, 3);
      const results = await Promise.all(batch.map(async (q) => {
        let r = await inTab(tabId, grabPage, [q.url]);
        if ((!r?.ok || r.chars < 300) && r?.status !== 404 && r?.status !== 410 && rendered < 20) { rendered++; r = (await grabInBackgroundTab(q.url)) || r; }
        return { q, r };
      }));
      for (const { q, r } of results) {
        progress.checked++;
        const clean = (x) => x.replace(/[?#].*$/, "").replace(/\/$/, "");
        if (!r?.ok || r.chars < 150 || pages.some((p) => clean(p.url) === clean(r.url))) continue;
        pages.push({ url: r.url, title: r.title, sections: r.sections });
        progress.found = pages.length;
        if (q.depth < 2) for (const l of r.links) if (helpLink(l)) add(l.href, q.depth + 1);
      }
      broadcastKb(site, progress);
    }
    if (!pages.length) throw new Error("no help pages found");
    broadcastKb(site, { ...progress, learning: true, saving: true });
    const res = await (await fetch(`${HTTP}/knowledge/${encodeURIComponent(site)}/ingest`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ pages }) })).json();
    if (res.error) throw new Error(res.error);
    for (const t of tabsOfSite(site)) t.port.postMessage({ type: "notice", text: `Learned ${res.pages} help pages. Ask me about returns, shipping and more.`, kind: "info" });
  } catch (e) {
    for (const t of tabsOfSite(site)) t.port.postMessage({ type: "notice", text: `Couldn't learn this site's help pages (${e.message}).`, kind: "error" });
  } finally {
    learning.delete(site);
    broadcastKb(site, await kbStatus(site));
  }
}
self.learnSite = learnSite;

// ---- offers: what the site is running now, for the sales side ------------------------------
// "Scan offers" in the chat panel: the site's offer and sale pages are read in this tab, like
// Learn (big retailers block automated browsers), and sent to the relay, which reads them
// into offers (offers.mjs).
const OFFER_SEEDS = {
  "sephora.com": ["/beauty/beauty-offers", "/sale", "/beauty/beauty-insider", "/rewards", "/"],
};
const GENERIC_OFFER_SEEDS = ["/", "/offers", "/deals", "/sale", "/promotions", "/collections/sale", "/pages/offers", "/pages/promotions"];
const OFFER = /\b(offers?|deals?|sale|promo(tion)?s?|coupons?|discounts?|gift with purchase|free gift|savings?|clearance|rewards?|value sets?|% off|bogo)\b|\/(offers?|deals?|sale|promo|promotions|coupons?|clearance|rewards)(\/|$)/i;
const NOT_OFFER = /\/(account|profile|login|signin|sign-in|register|cart|basket|bag|checkout|store-locator|stores|careers|search)(\/|$)|\.(pdf|jpe?g|png|gif|zip)$/i;
const MAX_OFFER_PAGES = 25;
const scanning = new Map(); // site → progress

// self-contained: runs inside the site's tab. Promo banners, the page's text, and product
// tiles with their prices (a crossed-out one is the "was" price).
async function grabOffers(url) {
  try {
    let doc = document, base = location.href;
    const live = !url;
    if (url) {
      const r = await fetch(url, { credentials: "include", redirect: "follow" });
      if (!r.ok) return { ok: false, status: r.status };
      base = r.url;
      doc = new DOMParser().parseFromString(await r.text(), "text/html");
    }
    const squash = (t) => String(t || "").replace(/\s+/g, " ").trim();
    const abs = (h) => { try { return new URL(h, base).href.split("#")[0]; } catch { return null; } };
    const PROMO = /(\$\d|\d+\s?%|free|off\b|gift|save|code|sale|offer|deal|reward|points|ship)/i;
    const banners = new Set();
    for (const el of doc.querySelectorAll('[class*="promo" i], [class*="banner" i], [class*="offer" i], [class*="deal" i], [class*="announcement" i], [class*="marquee" i], [data-at*="promo" i], [data-at*="banner" i], [data-comp*="promo" i], header a, [role="banner"] a')) {
      const t = squash(el.textContent);
      if (t.length >= 8 && t.length <= 240 && PROMO.test(t)) banners.add(t);
      if (banners.size >= 40) break;
    }
    const main = doc.querySelector("main, [role=main], #main, #content") || doc.body;
    if (!main) return { ok: false };
    let text;
    if (live) text = main.innerText;
    else {
      const root = main.cloneNode(true);
      root.querySelectorAll("script,style,noscript,template,svg,iframe").forEach((n) => n.remove());
      const BLOCK = "h1,h2,h3,h4,h5,h6,p,li,dt,dd,td,th,a,span,div,section,button";
      const seen = [];
      for (const el of root.querySelectorAll(BLOCK)) {
        if (el.querySelector(BLOCK)) continue;
        const t = squash(el.textContent);
        if (t && seen.at(-1) !== t) seen.push(t);
      }
      text = seen.join("\n");
    }
    const money = (t) => [...String(t).replace(/,/g, "").matchAll(/\$\s?(\d+(?:\.\d{1,2})?)/g)].map((m) => Number(m[1]));
    const products = [], seenUrls = new Set();
    for (const a of doc.querySelectorAll("a[href]")) {
      const href = abs(a.getAttribute("href"));
      if (!href || seenUrls.has(href.split("?")[0])) continue;
      let path;
      try { path = new URL(href).pathname; } catch { continue; }
      if (!/\/(product|products|p)\/|[-/]P\d{4,}/i.test(path)) continue;
      let tile = a;
      for (let i = 0; i < 5 && tile.parentElement && money(tile.textContent).length === 0; i++) tile = tile.parentElement;
      const prices = money(tile.textContent);
      if (!prices.length || tile.textContent.length > 700) continue;
      let wasEl = tile.querySelector("s, del, strike, [class*='strike' i], [data-at*='strike' i], [class*='original' i], [class*='compare' i]");
      if (!wasEl && live) wasEl = [...tile.querySelectorAll("span, div, p")].find((el) => el.childElementCount === 0 && /\$\d/.test(el.textContent) && getComputedStyle(el).textDecorationLine.includes("line-through"));
      const was = wasEl ? money(wasEl.textContent)[0] : null;
      const price = prices.filter((p) => p !== was).sort((x, y) => x - y)[0];
      const name = squash(a.getAttribute("aria-label") || a.querySelector("img")?.alt || a.textContent || tile.querySelector("img")?.alt).replace(/\$\s?\d[\d.,]*/g, "").slice(0, 140);
      if (!name || !price) continue;
      seenUrls.add(href.split("?")[0]);
      products.push({ name, url: href.split("?")[0], price: `$${price}`, was: was && was > price ? `$${was}` : null });
      if (products.length >= 150) break;
    }
    const links = [];
    for (const a of doc.querySelectorAll("a[href]")) { const href = abs(a.getAttribute("href")); if (href && /^https?:/.test(href)) links.push({ href, text: squash(a.textContent).slice(0, 80) }); }
    return { ok: true, url: base, title: squash(doc.title), banners: [...banners], text: squash(text).length ? text.replace(/[ \t]+/g, " ").replace(/\n{3,}/g, "\n\n").slice(0, 20000) : "", products, links };
  } catch (e) {
    return { ok: false, error: String(e?.message || e) };
  }
}

function broadcastOffers(site, status) { for (const t of tabsOfSite(site)) t.port.postMessage({ type: "offers", status }); }
async function offersStatus(site) {
  if (scanning.has(site)) return scanning.get(site);
  try { return await (await fetch(`${HTTP}/offers/${encodeURIComponent(site)}/status`)).json(); } catch { return { site, offers: 0, offline: true }; }
}

async function scanOffers(tabId) {
  const tab = await chrome.tabs.get(tabId);
  const site = siteOf(tab.url);
  if (!site || scanning.has(site)) return;
  const origin = new URL(tab.url).origin;
  const progress = { site, scanning: true, checked: 0, found: 0 };
  scanning.set(site, progress);
  broadcastOffers(site, progress);
  const queue = [], seen = new Set(), pages = [];
  const add = (href, depth) => {
    let u;
    try { u = new URL(href, origin); } catch { return; }
    if (siteOf(u.href) !== site || NOT_OFFER.test(u.pathname)) return;
    for (const k of [...u.searchParams.keys()]) if (/^(icid\d*|utm_|ref|cm_|_ga|gclid|fbclid|om_|cid)/i.test(k)) u.searchParams.delete(k);
    const key = `${u.hostname.replace(/^www\./, "")}${u.pathname.replace(/\/$/, "")}${u.search}`;
    if (seen.has(key)) return;
    seen.add(key);
    queue.push({ url: `${u.origin}${u.pathname}${u.search}`, depth });
  };
  const offerLink = (l) => { try { return OFFER.test(l.text) || OFFER.test(new URL(l.href).pathname); } catch { return false; } };
  try {
    // this page as it is (its promo strips are often only rendered live), then the seeds
    const here = await inTab(tabId, grabOffers, [null]);
    if (here?.ok) { pages.push(here); add(here.url, 0); queue.pop(); } // marked as seen, not queued
    for (const p of OFFER_SEEDS[site] || GENERIC_OFFER_SEEDS) add(p, 0);
    for (const l of here?.links || []) if (offerLink(l)) add(l.href, 1);
    let rendered = 0;
    while (queue.length && pages.length < MAX_OFFER_PAGES) {
      const batch = queue.splice(0, 3);
      const results = await Promise.all(batch.map(async (q) => {
        let r = await inTab(tabId, grabOffers, [q.url]);
        // client-rendered pages (sale listings) come back nearly empty: render them in a background tab
        if ((!r?.ok || (r.text || "").length < 400 || (!r.products?.length && /sale|deal|offer/i.test(q.url))) && r?.status !== 404 && r?.status !== 410 && rendered < 8) {
          rendered++;
          r = (await grabInBackgroundTab(q.url, grabOffers)) || r;
        }
        return { q, r };
      }));
      for (const { q, r } of results) {
        progress.checked++;
        if (!r?.ok || ((r.text || "").length < 150 && !r.products?.length)) continue;
        pages.push(r);
        progress.found = pages.length;
        if (q.depth < 1) for (const l of r.links) if (offerLink(l)) add(l.href, q.depth + 1);
      }
      broadcastOffers(site, progress);
    }
    if (!pages.length) throw new Error("no offer pages found");
    broadcastOffers(site, { ...progress, saving: true });
    const body = { pages: pages.map(({ links, ok, ...p }) => p) };
    const res = await (await fetch(`${HTTP}/offers/${encodeURIComponent(site)}/ingest`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) })).json();
    if (res.error) throw new Error(res.error);
    for (const t of tabsOfSite(site)) t.port.postMessage({ type: "notice", text: `Found ${res.offers} offers and ${res.drops} price drops on ${res.pages} pages.`, kind: "info" });
  } catch (e) {
    for (const t of tabsOfSite(site)) t.port.postMessage({ type: "notice", text: `Couldn't scan this site's offers (${e.message}).`, kind: "error" });
  } finally {
    scanning.delete(site);
    broadcastOffers(site, await offersStatus(site));
  }
}
self.scanOffers = scanOffers;

// ---- the site's map: its own pages, from its sitemaps -----------------------------------------
// Read in the visitor's tab (robots.txt → Sitemap: lines, or /sitemap.xml), with the site's
// menus, once every few days per site, and kept on the relay (server/sitemap.mjs): the planner
// gets a guide to the site, so common requests go straight to the right page. The assistant only gives links
// to the site's real pages and to what the knowledge base says (server/links.mjs).
const MAP_EVERY_MS = 3 * 24 * 3600 * 1000;
const mapping = new Set();

// self-contained: runs inside the site's tab. The site's menus (header, navigation, footer,
// including hidden mega-menu links): label → URL, and whether it has a search box.
async function grabNav() {
  // footers often render only when scrolled to
  const y = scrollY;
  scrollTo(0, document.body.scrollHeight);
  await new Promise((r) => setTimeout(r, 1500));
  scrollTo(0, y);
  const squash = (t) => String(t || "").replace(/[\u{1F000}-\u{1FAFF}\u{2600}-\u{27BF}\u{FE0F}]/gu, "").replace(/\s+/g, " ").trim();
  const nav = [], seen = new Set();
  const FOOT = "footer, [role=contentinfo], [class*=footer i], [id*=footer i]";
  const zones = document.querySelectorAll(`header, nav, [role=navigation], [role=banner], [class*=header i], [id*=header i], [class*=menu i], [class*=nav i], ${FOOT}`);
  for (const z of zones) {
    if (z.closest("main, [role=main]") && !z.matches(FOOT)) continue; // a product grid's own menus
    const where = z.closest(FOOT) ? "footer" : "header";
    for (const a of z.querySelectorAll("a[href]")) {
      let url;
      try { url = new URL(a.getAttribute("href"), location.href); } catch { continue; }
      if (!/^https?:$/.test(url.protocol) || (url.pathname === "/" && !url.search)) continue;
      const label = squash(a.getAttribute("aria-label") || a.textContent || a.title || a.querySelector("img")?.alt).slice(0, 60);
      if (!label || label.length < 2) continue;
      const k = url.origin + url.pathname;
      if (seen.has(k)) continue;
      seen.add(k);
      nav.push({ label, url: url.href.split("#")[0], where });
      if (nav.length >= 300) break;
    }
  }
  const search = !!document.querySelector('input[type="search"], form[role="search"], input[name="q"], input[name*="search" i], input[placeholder*="search" i], [aria-label*="search" i]');
  return { nav, search };
}

// self-contained: runs inside the site's tab
async function grabSitemaps() {
  const t0 = Date.now(), MAX_URLS = 50000, MAX_FILES = 30, BUDGET = 40000;
  const urls = new Set(), done = new Set();
  const read = async (u) => {
    const r = await fetch(u, { credentials: "include", redirect: "follow" });
    if (!r.ok) return "";
    if (/\.gz($|\?)/i.test(u) && typeof DecompressionStream === "function") {
      const buf = new Uint8Array(await r.clone().arrayBuffer());
      if (buf[0] === 0x1f && buf[1] === 0x8b) return new Response(new Blob([buf]).stream().pipeThrough(new DecompressionStream("gzip"))).text();
    }
    return r.text();
  };
  let queue = [];
  try {
    const robots = await read(`${location.origin}/robots.txt`);
    queue = [...robots.matchAll(/^\s*sitemap:\s*(\S+)/gim)].map((m) => m[1]);
  } catch {}
  if (!queue.length) queue = [`${location.origin}/sitemap.xml`, `${location.origin}/sitemap_index.xml`];
  // pages people ask for (categories, help, brands, stores) before the long product lists
  const rank = (u) => (/product|sku|pdp|item|variant|review|image|video/i.test(u) ? 1 : 0);
  while (queue.length && done.size < MAX_FILES && urls.size < MAX_URLS && Date.now() - t0 < BUDGET) {
    queue.sort((a, b) => rank(a) - rank(b));
    const u = queue.shift();
    if (done.has(u)) continue;
    done.add(u);
    let xml = "";
    try { xml = await read(u); } catch { continue; }
    if (!xml) continue;
    const doc = new DOMParser().parseFromString(xml, "text/xml");
    const locs = (sel) => [...doc.getElementsByTagNameNS("*", sel)].map((n) => n.getElementsByTagNameNS("*", "loc")[0]?.textContent?.trim()).filter(Boolean);
    queue.push(...locs("sitemap").filter((x) => !done.has(x)));
    for (const x of locs("url")) { urls.add(x); if (urls.size >= MAX_URLS) break; }
  }
  return { urls: [...urls], files: done.size, ms: Date.now() - t0 };
}

async function mapSite(tabId, site) {
  if (!site || mapping.has(site) || crawlTabs.has(tabId)) return;
  mapping.add(site);
  try {
    const st = await (await fetch(`${HTTP}/sitemap/${encodeURIComponent(site)}/status`)).json();
    if (st.updatedAt && st.nav && Date.now() - st.updatedAt < MAP_EVERY_MS) return;
    const [menus, r] = await Promise.all([inTab(tabId, grabNav, []), inTab(tabId, grabSitemaps, [])]);
    if (!r && !menus) return;
    await fetch(`${HTTP}/sitemap/${encodeURIComponent(site)}/ingest`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ urls: r?.urls || [], nav: menus?.nav || [], search: !!menus?.search }) });
  } catch {} finally {
    setTimeout(() => mapping.delete(site), 60000); // a failed try waits a minute
  }
}
self.mapSite = mapSite;
