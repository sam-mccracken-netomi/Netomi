// Asks for the microphone on the extension's own origin, which the offscreen document
// (which can't show a prompt) then shares. Closes itself once granted.
async function ask() {
  const msg = document.getElementById("msg");
  try {
    const s = await navigator.mediaDevices.getUserMedia({ audio: true });
    s.getTracks().forEach((t) => t.stop());
    msg.style.color = "#1a7f37";
    msg.textContent = "Thanks! You can close this tab.";
    chrome.runtime.sendMessage({ type: "mic-granted" });
  } catch (e) {
    msg.textContent = e.name === "NotAllowedError" ? "The microphone was blocked. Click the icon in the address bar to allow it, then try again." : `Couldn't open the microphone (${e.message}).`;
  }
}
document.getElementById("allow").onclick = ask;
ask();
