// The prompts settings page: loads the prompts from the relay, edits them, saves them back.
// the relay: this page is served by it at /settings, or opened from the extension
const HTTP = location.protocol.startsWith("http") ? location.origin : "http://localhost:5179";
const $ = (id) => document.getElementById(id);
let prompts = [];
const edits = new Map(); // key → text, while unsaved

function toast(text) {
  $("toast").textContent = text;
  $("toast").classList.add("on");
  setTimeout(() => $("toast").classList.remove("on"), 2200);
}

function server(ok, text) {
  $("server").className = `server ${ok ? "ok" : "bad"}`;
  $("server").lastElementChild.textContent = text;
}

async function load() {
  try {
    const r = await fetch(`${HTTP}/prompts`);
    prompts = await r.json();
    server(true, "Relay connected");
    render();
  } catch {
    server(false, "Relay not reachable");
    $("list").innerHTML = `<p class="empty">Can't reach the relay at ${HTTP}. Start it with <code>npm start</code>, then reload this page.</p>`;
  }
}

function grow(t) { t.style.height = "auto"; t.style.height = `${Math.min(t.scrollHeight + 2, 900)}px`; }

// the prompts, one group (tab) at a time; edits in other tabs are kept until saved
const TAB_KEY = "ttw:promptTab";
let tab = (() => { try { return localStorage.getItem(TAB_KEY); } catch { return null; } })();
const groups = () => [...new Set(prompts.map((p) => p.group))];
const differs = (p) => (edits.get(p.key) ?? p.text) !== p.default;

function renderTabs() {
  const bar = $("tabs");
  bar.textContent = "";
  const gs = groups();
  for (const g of gs) {
    const ps = prompts.filter((p) => p.group === g);
    const b = document.createElement("button");
    b.type = "button";
    b.setAttribute("role", "tab");
    b.setAttribute("aria-selected", String(g === tab));
    b.tabIndex = g === tab ? 0 : -1;
    b.dataset.group = g;
    b.innerHTML = `<span class="dot" hidden></span><span class="t"></span><span class="n"></span>`;
    b.querySelector(".t").textContent = g.replace(/\s*\(.*\)\s*$/, ""); // "Planner (operates the website)" → "Planner"
    b.title = g;
    b.querySelector(".n").textContent = ps.length;
    b.addEventListener("click", () => select(g));
    b.addEventListener("keydown", (e) => {
      const i = gs.indexOf(g), next = { ArrowRight: i + 1, ArrowLeft: i - 1, Home: 0, End: gs.length - 1 }[e.key];
      if (next == null) return;
      e.preventDefault();
      select(gs[(next + gs.length) % gs.length]);
      bar.querySelector('[aria-selected="true"]')?.focus();
    });
    bar.append(b);
  }
  markTabs();
}

// a dot on each tab: customised (soft) or with unsaved changes (accent)
function markTabs() {
  for (const b of $("tabs").children) {
    const ps = prompts.filter((p) => p.group === b.dataset.group);
    const dirty = ps.some((p) => edits.has(p.key) && edits.get(p.key) !== p.text);
    const dot = b.querySelector(".dot");
    dot.hidden = !dirty && !ps.some(differs);
    dot.classList.toggle("dirty", dirty);
    dot.title = dirty ? "Unsaved changes" : "Customised";
  }
}

function select(g) {
  tab = g;
  try { localStorage.setItem(TAB_KEY, g); } catch {}
  for (const b of $("tabs").children) { const on = b.dataset.group === g; b.setAttribute("aria-selected", String(on)); b.tabIndex = on ? 0 : -1; }
  renderList();
}

function render() {
  if (!groups().includes(tab)) tab = groups()[0];
  renderTabs();
  renderList();
}

function renderList() {
  const list = $("list");
  list.textContent = "";
  for (const p of prompts.filter((x) => x.group === tab)) {
    const box = document.createElement("section");
    box.className = "p";
    box.dataset.key = p.key;
    box.innerHTML = `<div class="top"><b></b><span class="tag edited">Edited</span></div>
      <div class="help"></div><textarea spellcheck="false"></textarea>
      <div class="foot"><span class="count"></span><span class="warn"></span><button class="reset" type="button">Reset to default</button></div>`;
    box.querySelector("b").textContent = p.label;
    box.querySelector(".help").textContent = p.help;
    if (p.vars.length) {
      const v = document.createElement("span");
      v.className = "vars";
      v.innerHTML = p.vars.map((x) => `<code>${x}</code>`).join("");
      box.querySelector(".help").append(" Placeholders:", v);
    }
    const ta = box.querySelector("textarea");
    ta.value = edits.get(p.key) ?? p.text;
    ta.addEventListener("input", () => { edits.set(p.key, ta.value); update(box, p); grow(ta); });
    box.querySelector(".reset").addEventListener("click", () => { ta.value = p.default; edits.set(p.key, p.default); update(box, p); grow(ta); });
    list.append(box);
    update(box, p);
    requestAnimationFrame(() => grow(ta));
  }
}

function update(box, p) {
  const text = box.querySelector("textarea").value;
  const dirty = edits.has(p.key) && edits.get(p.key) !== p.text;
  if (edits.has(p.key) && !dirty) edits.delete(p.key);
  box.classList.toggle("dirty", dirty);
  box.querySelector(".edited").hidden = text === p.default;
  box.querySelector(".reset").hidden = text === p.default;
  box.querySelector(".count").textContent = `${text.length.toLocaleString()} characters`;
  const missing = p.vars.filter((v) => !text.includes(v));
  box.querySelector(".warn").textContent = missing.length ? `Missing ${missing.join(", ")}: that part won't be filled in` : "";
  markTabs();
  const n = edits.size;
  $("save").classList.toggle("on", n > 0);
  $("dirtyCount").textContent = `${n} unsaved change${n === 1 ? "" : "s"}`;
}

async function save() {
  if (!edits.size) return;
  try {
    const r = await fetch(`${HTTP}/prompts`, { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ edits: Object.fromEntries(edits) }) });
    const body = await r.json();
    if (!r.ok) throw new Error(body.error || r.status);
    prompts = body;
    edits.clear();
    render();
    $("save").classList.remove("on");
    toast("Saved. Applies from the next turn (voice instructions: next conversation).");
  } catch (e) {
    toast(`Couldn't save: ${e.message}`);
  }
}

$("go").addEventListener("click", save);
$("discard").addEventListener("click", () => { edits.clear(); render(); $("save").classList.remove("on"); });
// history lives in the extension, so this is only offered when the page is opened from it
if (globalThis.chrome?.runtime?.id) {
  $("history").hidden = false;
  $("forgetAll").addEventListener("click", async () => {
    if (!confirm("Forget all conversations and browsing history on every site?")) return;
    await chrome.runtime.sendMessage({ type: "forget-all" }).catch(() => {});
    toast("Forgotten. Every site starts afresh.");
  });
}
addEventListener("keydown", (e) => { if ((e.metaKey || e.ctrlKey) && e.key === "s") { e.preventDefault(); save(); } });
addEventListener("beforeunload", (e) => { if (edits.size) e.preventDefault(); });
load();

// ---- knowledge answers: local, Netomi or both -----------------------------------------------
const NETOMI_FIELDS = ["botId", "refId", "sites", "authUrl", "proxyUrl"];
let savedKnowledge = null;
const mode = () => document.querySelector('input[name="mode"]:checked')?.value || "local";
const formKnowledge = () => ({ mode: mode(), netomi: Object.fromEntries(NETOMI_FIELDS.map((f) => [f, $(f).value.trim()])) });

function showKnowledge(k) {
  savedKnowledge = k;
  document.querySelector(`input[name="mode"][value="${k.mode}"]`).checked = true;
  for (const f of NETOMI_FIELDS) $(f).value = k.netomi[f] || "";
  knowledgeChanged();
}
function knowledgeChanged() {
  const k = formKnowledge();
  $("netomiFields").hidden = k.mode === "local";
  const dirty = JSON.stringify(k) !== JSON.stringify(savedKnowledge);
  const missing = k.mode !== "local" && (!k.netomi.botId || !k.netomi.refId);
  $("kSave").disabled = !dirty;
  $("kStatus").textContent = missing ? "Enter the bot ID and bot ref ID; until then the local knowledge base answers." : dirty ? "Unsaved" : "Saved";
  $("kStatus").className = missing ? "warn" : "";
}
async function loadKnowledge() {
  try { showKnowledge((await (await fetch(`${HTTP}/config`)).json()).knowledge); } catch { $("knowledge").hidden = true; }
}
async function saveKnowledge() {
  try {
    const r = await fetch(`${HTTP}/config`, { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ knowledge: formKnowledge() }) });
    const body = await r.json();
    if (!r.ok) throw new Error(body.error || r.status);
    showKnowledge(body.knowledge);
    toast("Saved. Applies to the next question.");
  } catch (e) {
    toast(`Couldn't save: ${e.message}`);
  }
}
async function testNetomi() {
  const out = $("testOut");
  $("testBtn").disabled = true;
  out.hidden = false;
  out.className = "result wide";
  out.textContent = "Asking Netomi… (this takes a few seconds)";
  try {
    const r = await fetch(`${HTTP}/config/netomi-test`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ question: $("testQ").value, netomi: formKnowledge().netomi }) });
    const b = await r.json();
    if (!r.ok || b.error) throw new Error(b.error || r.status);
    const s = (ms) => (ms == null ? "–" : `${(ms / 1000).toFixed(1)} s`);
    out.innerHTML = `<span class="t"></span>`;
    out.firstChild.textContent = `${b.answered ? "Answered" : "No answer"} · first words ${s(b.firstMs)} · spoken from ${s(b.spokenMs)} · complete ${s(b.totalMs)}`;
    out.append(b.text || "(empty)");
  } catch (e) {
    out.className = "result wide err";
    out.textContent = `Failed: ${e.message}`;
  } finally {
    $("testBtn").disabled = false;
  }
}
document.querySelectorAll('input[name="mode"]').forEach((r) => r.addEventListener("change", knowledgeChanged));
for (const f of NETOMI_FIELDS) $(f).addEventListener("input", knowledgeChanged);
$("kSave").addEventListener("click", saveKnowledge);
$("testBtn").addEventListener("click", testNetomi);
$("testQ").addEventListener("keydown", (e) => { if (e.key === "Enter") testNetomi(); });
loadKnowledge();

// ---- sales & offers -------------------------------------------------------------------------
// per level: name, where it pitches, and how often
const LEVEL_TEXT = {
  1: ["Light", "Where: the bag and checkout (close to a threshold, a code applies), and a product they viewed that got cheaper.", "Once per conversation at most."],
  2: ["Balanced", "Where: the home page (what's running sitewide), the product they're looking at when an offer clearly fits, the bag and checkout, price drops.", "Up to 2 times per conversation, at least 5 minutes apart."],
  3: ["Proactive", "Where: the home page, categories and other pages, searches, products, comparing, the bag and checkout, price drops. Offers are matched to the page and to what they've been looking at lately.", "Up to 3 times per conversation, 3 minutes apart."],
  4: ["Assertive", "Where: the greeting itself, then everywhere Proactive does, with a lower bar for what fits. Points out savings, thresholds and real end dates.", "Up to 5 times per conversation, 2 minutes apart."],
};
let savedSales = null;
const formSales = () => ({ enabled: $("salesOn").checked, level: Number($("level").value) });
function salesChanged() {
  const s = formSales();
  $("levelBox").classList.toggle("off", !s.enabled);
  $("levelName").textContent = LEVEL_TEXT[s.level][0];
  $("levelHelp").innerHTML = "";
  for (const t of LEVEL_TEXT[s.level].slice(1)) { const d = document.createElement("div"); d.textContent = t; $("levelHelp").append(d); }
  const dirty = JSON.stringify(s) !== JSON.stringify(savedSales);
  $("sSave").disabled = !dirty;
  $("sStatus").textContent = dirty ? "Unsaved" : s.enabled ? "On" : "Off";
}
function showSales(s) {
  savedSales = s;
  $("salesOn").checked = s.enabled;
  $("level").value = s.level;
  salesChanged();
}
async function saveSales() {
  try {
    const r = await fetch(`${HTTP}/config`, { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ sales: formSales() }) });
    const body = await r.json();
    if (!r.ok) throw new Error(body.error || r.status);
    showSales(body.sales);
    toast("Saved. Applies right away.");
  } catch (e) {
    toast(`Couldn't save: ${e.message}`);
  }
}

async function loadOfferSites() {
  try {
    const sites = await (await fetch(`${HTTP}/offers`)).json();
    const sel = $("offerSite");
    sel.textContent = "";
    sel.hidden = !sites.length;
    for (const s of sites) sel.append(new Option(`${s.site} (${s.offers})`, s.site));
    if (sites.length) showOffers(sel.value);
    else $("offersCount").textContent = "none yet";
  } catch {}
}
async function showOffers(site) {
  const d = await (await fetch(`${HTTP}/offers/${encodeURIComponent(site)}/list`)).json();
  const when = d.updatedAt ? new Date(d.updatedAt).toLocaleString("en-US", { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" }) : "never";
  $("offersMeta").textContent = `Scanned ${when} from ${d.pages.length} pages: ${d.offers.length} offers, ${d.drops.length} products on sale. Remove anything that's wrong and it won't be mentioned.`;
  $("offersCount").textContent = `${d.offers.length} offers, ${d.drops.length} on sale · ${site}`;
  const ul = $("offerList");
  ul.textContent = "";
  const row = (chip, title, meta, id, dead) => {
    const li = document.createElement("li");
    if (dead) li.className = "dead";
    li.innerHTML = `<div class="o-main"><span class="chip"></span><b></b><div class="o-meta"></div></div><button type="button">Remove</button>`;
    li.querySelector(".chip").textContent = chip;
    li.querySelector("b").textContent = title;
    li.querySelector(".o-meta").textContent = meta;
    li.querySelector("button").addEventListener("click", async () => {
      await fetch(`${HTTP}/offers/${encodeURIComponent(site)}/remove`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id }) });
      showOffers(site);
    });
    ul.append(li);
  };
  for (const o of d.offers) {
    const meta = [o.summary !== o.title ? o.summary : "", o.code ? `code ${o.code}` : "", o.min_spend ? `min $${o.min_spend}` : "", o.who, o.ends ? `ends ${o.ends}` : "", o.live ? "" : "ended"].filter(Boolean).join(" · ");
    row(o.kind.replace(/_/g, " "), o.title, meta, o.id, !o.live);
  }
  for (const x of d.drops.slice(0, 15)) row(`${x.pct}% off`, x.name, `now $${x.price}, was $${x.was}`, x.id, false);
  if (d.drops.length > 15) { const li = document.createElement("li"); li.textContent = `…and ${d.drops.length - 15} more products on sale`; ul.append(li); }
}

$("salesOn").addEventListener("change", salesChanged);
$("level").addEventListener("input", salesChanged);
$("sSave").addEventListener("click", saveSales);
$("offerSite").addEventListener("change", (e) => showOffers(e.target.value));
fetch(`${HTTP}/config`).then((r) => r.json()).then((c) => showSales(c.sales)).catch(() => { $("sales").hidden = true; $("offersSec").hidden = true; });
loadOfferSites();

// ---- memory: the switches, and what we know per site ------------------------------------------
let savedMemory = null;
const formMemory = () => ({ enabled: $("memOn").checked, preselect: $("preOn").checked, rtcdp: $("rtOn").checked });
let rtAvailable = false; // .env has the Adobe credentials and IDs
function memoryChanged() {
  const m = formMemory();
  $("preOn").disabled = !m.enabled;
  $("rtOn").disabled = !m.enabled || !rtAvailable;
  const dirty = JSON.stringify(m) !== JSON.stringify(savedMemory);
  $("mSave").disabled = !dirty;
  $("mStatus").textContent = dirty ? "Unsaved" : m.enabled ? "On" : "Off";
}
function showMemorySettings(m) {
  savedMemory = m;
  $("memOn").checked = m.enabled;
  $("preOn").checked = m.preselect;
  $("rtOn").checked = !!m.rtcdp && rtAvailable;
  if (!rtAvailable) $("rtHelp").textContent = "Not set up: add the Adobe credentials to .env and run node scripts/rtcdp-setup.mjs, then restart the relay.";
  memoryChanged();
}
async function saveConfig(part, done) {
  try {
    const r = await fetch(`${HTTP}/config`, { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify(part) });
    const body = await r.json();
    if (!r.ok) throw new Error(body.error || r.status);
    done(body);
    toast("Saved. Applies right away.");
  } catch (e) {
    toast(`Couldn't save: ${e.message}`);
  }
}

async function loadMemorySites() {
  try {
    const r = await fetch(`${HTTP}/memory`);
    if (!r.ok) throw new Error((await r.json()).error);
    const sites = (await r.json()).filter((s) => s.facts);
    const sel = $("memSite");
    const keep = sel.value;
    sel.textContent = "";
    sel.hidden = !sites.length;
    for (const s of sites) sel.append(new Option(`${s.site} (${s.facts})`, s.site));
    if (sites.some((s) => s.site === keep)) sel.value = keep;
    if (sites.length) showMemory(sel.value);
    else { $("memList").textContent = ""; $("memFoot").hidden = true; $("memMeta").textContent = "Nothing yet. Memories appear here as the visitor talks with the assistant and browses."; }
  } catch (e) {
    $("memMeta").textContent = `Can't show memories here (${e.message}).`;
  }
}
// what the shopper's Adobe RT-CDP profile says right now, in words, with the facts underneath
async function showProfile(site, d) {
  const box = $("rtBox");
  box.hidden = !(d.rtcdp?.on && d.account?.email);
  if (box.hidden) return;
  $("rtText").textContent = "Fetching the profile from Adobe…";
  $("rtDetails").hidden = true;
  $("rtMeta").textContent = "";
  try {
    const r = await fetch(`${HTTP}/memory/${encodeURIComponent(site)}/rtcdp`);
    const p = await r.json();
    if (!r.ok) throw new Error(p.error || r.status);
    if ($("memSite").value && $("memSite").value !== site) return; // another site picked meanwhile
    $("rtText").textContent = p.text || "Nothing to show.";
    const ul = $("rtList");
    ul.textContent = "";
    for (const f of p.facts || []) {
      const li = document.createElement("li");
      li.innerHTML = `<div class="o-main"><span class="chip"></span><b></b><div class="o-meta"></div></div>`;
      const chip = li.querySelector(".chip");
      chip.classList.add(f.kind === "stated" ? "stated" : "inferred");
      chip.textContent = f.kind === "stated" ? "said" : `inferred · ${Math.round((f.confidence || 0) * 100)}%`;
      li.querySelector("b").textContent = `${f.label}: ${f.value}`;
      li.querySelector(".o-meta").textContent = [f.site, f.evidence, f.updatedAt && new Date(f.updatedAt).toLocaleDateString("en-US", { month: "short", day: "numeric" })].filter(Boolean).join(" · ");
      ul.append(li);
    }
    $("rtDetails").hidden = !(p.facts || []).length;
    $("rtMeta").textContent = p.found ? `Fetched just now for ${p.email} (Email identity${p.sandbox ? `, ${p.sandbox} sandbox` : ""}). In Adobe: Customer → Profiles → Browse.` : "";
  } catch (e) {
    $("rtText").textContent = `Couldn't fetch the profile from Adobe (${e.message}).`;
  }
}
// ---- TEMPORARY (demo): change the home address in Adobe ----------------------------------------
function fillZip(a) { $("zipZip").value = a?.zip || ""; $("zipCity").value = a?.city || ""; $("zipState").value = a?.state || ""; }
function openZip() {
  $("zipBox").hidden = false;
  $("zipStatus").textContent = "";
  const site = $("memSite").value;
  $("algStatus").textContent = "";
  if (site) fetch(`${HTTP}/memory/${encodeURIComponent(site)}`).then((r) => r.json()).then((d) => {
    fillZip(d.address);
    $("algValue").value = (d.facts || []).find((f) => f.key === "allergies")?.value || "";
  }).catch(() => {});
}
// allergies: memory and Adobe together, then wait until the profile shows it
async function setAllergies(value) {
  const site = $("memSite").value;
  if (!site) return;
  for (const b of [$("algSave"), $("algRemove")]) b.disabled = true;
  $("algStatus").textContent = value ? "Saving and sending to Adobe…" : "Removing here and in Adobe…";
  try {
    const r = await fetch(`${HTTP}/memory/${encodeURIComponent(site)}/allergies`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ value }) });
    const j = await r.json();
    if (!r.ok) throw new Error(j.error || r.status);
    $("algStatus").textContent = "Sent. Waiting for the profile to show it…";
    const t0 = Date.now();
    while (Date.now() - t0 < 90000) {
      await new Promise((res) => setTimeout(res, 5000));
      const p = await (await fetch(`${HTTP}/memory/${encodeURIComponent(site)}/rtcdp`)).json();
      const now = (p.facts || []).find((f) => f.key === "allergies" && (f.site || site) === site)?.value || "";
      if (now === value) {
        $("algStatus").textContent = `${value ? "Updated" : "Removed"} in Adobe after ${Math.round((Date.now() - t0) / 1000)} s.`;
        await showMemory(site);
        $("zipBox").hidden = false;
        $("algValue").value = value;
        return;
      }
    }
    $("algStatus").textContent = "Sent, but the profile doesn't show it yet. Try Refresh in a minute.";
  } catch (e) {
    $("algStatus").textContent = `Couldn't update: ${e.message}`;
  } finally {
    for (const b of [$("algSave"), $("algRemove")]) b.disabled = false;
  }
}
$("algSave").addEventListener("click", () => { const v = $("algValue").value.replace(/\s+/g, " ").trim(); if (!v) return void ($("algStatus").textContent = "Type an ingredient, or use Remove."); setAllergies(v); });
$("algRemove").addEventListener("click", () => { $("algValue").value = ""; setAllergies(""); });
$("rtBox").querySelector(".top b").addEventListener("dblclick", () => ($("zipBox").hidden ? openZip() : ($("zipBox").hidden = true)));
$("zipSave").addEventListener("click", async () => {
  const site = $("memSite").value;
  const zip = $("zipZip").value.trim();
  if (!site || !zip) return void ($("zipStatus").textContent = "Enter a zip code.");
  $("zipSave").disabled = true;
  $("zipStatus").textContent = "Sending to Adobe…";
  try {
    const r = await fetch(`${HTTP}/memory/${encodeURIComponent(site)}/address`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ zip, city: $("zipCity").value, state: $("zipState").value }) });
    const j = await r.json();
    if (!r.ok) throw new Error(j.error || r.status);
    $("zipStatus").textContent = "Sent. Waiting for the profile to show it…";
    const t0 = Date.now();
    while (Date.now() - t0 < 90000) {
      await new Promise((res) => setTimeout(res, 5000));
      const p = await (await fetch(`${HTTP}/memory/${encodeURIComponent(site)}/rtcdp`)).json(); // also pulls it into memory
      if (p.address?.zip === zip) {
        $("zipStatus").textContent = `Updated in Adobe after ${Math.round((Date.now() - t0) / 1000)} s. Refresh the site's tab and ask again.`;
        await showMemory(site);
        $("zipBox").hidden = false;
        return;
      }
    }
    $("zipStatus").textContent = "Sent, but the profile doesn't show it yet. Try Refresh in a minute.";
  } catch (e) {
    $("zipStatus").textContent = `Couldn't update: ${e.message}`;
  } finally {
    $("zipSave").disabled = false;
  }
});
if (location.hash === "#zip") setTimeout(openZip, 1500);

$("rtRefresh").addEventListener("click", async () => {
  const site = $("memSite").value;
  if (!site) return;
  $("rtText").textContent = "Fetching the profile from Adobe…";
  await fetch(`${HTTP}/memory/${encodeURIComponent(site)}/rtcdp`).catch(() => {}); // pulls it into memory too
  showMemory(site);
});

async function showMemory(site) {
  const d = await (await fetch(`${HTTP}/memory/${encodeURIComponent(site)}`)).json();
  const when = d.updatedAt ? new Date(d.updatedAt).toLocaleString("en-US", { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" }) : "";
  $("memMeta").textContent = `${d.account ? `Signed in as ${d.account.name || d.account.email}. ` : ""}${d.facts.length} things known about the visitor on ${site}${when ? `, last updated ${when}` : ""}. Weak guesses (under 35%) aren't used. Remove anything that's wrong.`;
  $("memFoot").hidden = false;
  showProfile(site, d);
  const ul = $("memList");
  ul.textContent = "";
  // who's signed in on the site (found on its pages; the assistant isn't told)
  if (d.account && (d.account.name || d.account.email)) {
    const a = d.account;
    const li = document.createElement("li");
    li.innerHTML = `<div class="o-main"><span class="chip account">signed in</span><b></b><div class="o-meta"></div></div><button type="button">Remove</button>`;
    li.querySelector("b").textContent = [a.name, a.email].filter(Boolean).join(" · ");
    const from = [a.name && a.from?.name ? `name: ${a.from.name}` : "", a.email && a.from?.email ? `email: ${a.from.email}` : ""].filter(Boolean).join(" · ");
    const missing = !a.email || !/\s/.test(a.name || "") ? " · Open your account page on the site once to add the full name and email." : "";
    const ago = (t) => new Date(t).toLocaleString("en-US", { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" });
    const rt = d.rtcdp || {};
    const sync = !rt.on ? "" : !a.email ? " · RT-CDP: waiting for their email" : rt.error ? ` · RT-CDP: ${rt.error}` : rt.pushedAt || rt.pulledAt ? ` · RT-CDP: ${rt.found === false && !rt.pushedAt ? "no profile yet" : "synced"} ${ago(Math.max(rt.pushedAt || 0, rt.pulledAt || 0))}` : " · RT-CDP: not synced yet";
    li.querySelector(".o-meta").textContent = `${from}${a.seenAt ? ` · ${new Date(a.seenAt).toLocaleDateString("en-US", { month: "short", day: "numeric" })}` : ""}${sync}${missing}`;
    li.querySelector("button").addEventListener("click", async () => {
      await fetch(`${HTTP}/memory/${encodeURIComponent(site)}/remove`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ key: "account" }) });
      loadMemorySites();
    });
    ul.append(li);
  }
  // the home address from their customer record in Adobe (read only: it's changed there)
  if (d.address && (d.address.zip || d.address.city)) {
    const li = document.createElement("li");
    li.innerHTML = `<div class="o-main"><span class="chip account">Adobe profile</span><b></b><div class="o-meta">From their customer record in Adobe Real-Time CDP. Used for store locators, pickup and delivery. Change it in Adobe; Refresh below picks it up.</div></div>`;
    li.querySelector("b").textContent = `Home: ${[d.address.city, [d.address.state, d.address.zip].filter(Boolean).join(" ")].filter(Boolean).join(", ")}`;
    ul.append(li);
  }
  const facts = [...d.facts].sort((a, b) => (b.kind === "stated") - (a.kind === "stated") || b.confidence - a.confidence);
  for (const f of facts) {
    const li = document.createElement("li");
    if (f.confidence < 0.35) li.className = "dead";
    li.innerHTML = `<div class="o-main"><span class="chip"></span><b></b><div class="o-meta"></div></div><button type="button">Remove</button>`;
    const chip = li.querySelector(".chip");
    chip.classList.add(f.kind);
    chip.textContent = f.kind === "stated" ? "said" : `inferred · ${Math.round(f.confidence * 100)}%`;
    li.querySelector("b").textContent = `${f.label}: ${f.value}`;
    li.querySelector(".o-meta").textContent = `${f.evidence}${f.updatedAt ? ` · ${new Date(f.updatedAt).toLocaleDateString("en-US", { month: "short", day: "numeric" })}` : ""}`;
    li.querySelector("button").addEventListener("click", async () => {
      await fetch(`${HTTP}/memory/${encodeURIComponent(site)}/remove`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ key: f.key }) });
      loadMemorySites();
    });
    ul.append(li);
  }
}
$("memOn").addEventListener("change", memoryChanged);
$("rtOn").addEventListener("change", memoryChanged);
$("preOn").addEventListener("change", memoryChanged);
$("mSave").addEventListener("click", () => saveConfig({ memory: formMemory() }, (b) => showMemorySettings(b.memory)));
$("memSite").addEventListener("change", (e) => showMemory(e.target.value));
$("memForget").addEventListener("click", async () => {
  const site = $("memSite").value;
  if (!site || !confirm(`Forget everything known about the visitor on ${site}?`)) return;
  await fetch(`${HTTP}/memory/${encodeURIComponent(site)}/forget`, { method: "POST" });
  loadMemorySites();
});

// ---- the info card's placement (saved as soon as it's picked) ----------------------------------
document.querySelectorAll('input[name="place"]').forEach((r) => r.addEventListener("change", () => saveConfig({ ui: { cardPlacement: r.value } }, () => { $("pStatus").textContent = "Saved. Applies to the next card."; })));
// ---- captions (saved as soon as they're picked) ------------------------------------------------
document.querySelectorAll('input[name="captions"]').forEach((r) => r.addEventListener("change", () => saveConfig({ ui: { captions: r.value } }, () => { $("cStatus").textContent = "Saved. Applies right away."; })));
fetch(`${HTTP}/config`).then((r) => r.json()).then((c) => {
  rtAvailable = !!c.available?.rtcdp;
  showMemorySettings(c.memory);
  const r = document.querySelector(`input[name="place"][value="${c.ui.cardPlacement}"]`);
  if (r) r.checked = true;
  const cp = document.querySelector(`input[name="captions"][value="${c.ui.captions || "bubble"}"]`);
  if (cp) cp.checked = true;
}).catch(() => { $("memorySec").hidden = true; $("display").hidden = true; $("captionsSec").hidden = true; });
loadMemorySites();

// ---- problem reports: what was reported from the widget, with the logs that go with it ----
async function loadReports() {
  try {
    const d = await (await fetch(`${HTTP}/reports`)).json();
    const list = d.reports || [];
    const waiting = list.filter((r) => r.pending).length;
    $("reportsCount").textContent = d.sendsTo ? (waiting ? `${waiting} waiting to send` : "all sent") : list.length ? `${list.length} report${list.length > 1 ? "s" : ""}` : "none yet";
    $("reportsMeta").textContent = d.sendsTo
      ? `To report a problem, open the chat panel and click the flag, or say "report this session". Each one goes to the team's issue tracker (${d.sendsTo}) with that conversation's logs. Ones that couldn't be sent are kept here and retried every few minutes; older ones saved before are listed too.`
      : `To report a problem, open the chat panel and click the flag, or say "report this session". Each one is saved with that conversation's logs in ${d.dir}.`;
    const ul = $("reportList");
    ul.textContent = "";
    for (const r of list) {
      const li = document.createElement("li");
      li.innerHTML = `<div class="r-meta"></div><div class="r-note"></div><a target="_blank">Read the report</a><a>Download logs (.json)</a>`;
      const when = new Date(r.at).toLocaleString("en-US", { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" });
      li.querySelector(".r-meta").textContent = `${r.pending ? `Waiting to send (${r.error || "not sent yet"}) · ` : ""}${when} · ${r.reporter || "anonymous"} · ${r.site || "unknown site"} · ${r.sessions ? `${r.sessions} log file${r.sessions > 1 ? "s" : ""}` : "no conversation logs found"}`;
      li.querySelector(".r-note").textContent = r.note || "(no description)";
      const [txt, json] = li.querySelectorAll("a");
      txt.href = `${HTTP}/reports/${encodeURIComponent(r.id)}.txt`;
      json.href = `${HTTP}/reports/${encodeURIComponent(r.id)}.json`;
      ul.append(li);
    }
  } catch { $("reportsSec").hidden = true; }
}
loadReports();

// ---- the page's own tabs: one section at a time (remembered; #memory etc. opens one) -------------
(() => {
  const KEY = "ttw:settingsPane";
  const panes = [...document.querySelectorAll("#pnav [data-pane]")].map((b) => b.dataset.pane);
  const pick = (name, push) => {
    if (!panes.includes(name)) name = panes[0];
    document.querySelector("main").dataset.pane = name;
    for (const b of document.querySelectorAll("#pnav [data-pane]")) b.setAttribute("aria-selected", String(b.dataset.pane === name));
    try { localStorage.setItem(KEY, name); } catch {}
    if (push) history.replaceState(null, "", `#${name}`);
    window.scrollTo(0, 0);
  };
  document.getElementById("pnav").addEventListener("click", (e) => { const b = e.target.closest("[data-pane]"); if (b) pick(b.dataset.pane, true); });
  document.getElementById("pnav").addEventListener("keydown", (e) => {
    if (!["ArrowLeft", "ArrowRight"].includes(e.key)) return;
    const i = panes.indexOf(document.querySelector("main").dataset.pane), n = panes[(i + (e.key === "ArrowRight" ? 1 : panes.length - 1)) % panes.length];
    pick(n, true);
    document.querySelector(`#pnav [data-pane="${n}"]`).focus();
  });
  addEventListener("hashchange", () => { if (location.hash === "#zip") { pick("memory"); openZip(); } else pick(location.hash.slice(1)); });
  let saved = null;
  try { saved = localStorage.getItem(KEY); } catch {}
  pick(location.hash === "#zip" ? "memory" : location.hash.slice(1) || saved || "knowledge");
})();
