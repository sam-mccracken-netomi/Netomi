/* Talk to Website: the page agent. The server's planner sees the page through snapshot()
 * and operates it through act(), like a person would: it reads what's visible, clicks,
 * types, picks options, and looks again.
 *
 * snapshot() → { url, title, text }: a compact, numbered list of what can be interacted
 *   with (label, value, state, and for repeated buttons like "Add to bag", the product
 *   card they belong to), plus headings, alerts, any open dialog and the main text.
 *   Numbers are valid until the next snapshot.
 * act(actions) → { results, url, navigating, snapshot? }: runs actions in order, waits for
 *   the page to settle after each, and stops early when the page changes underneath.
 */
const TalkPage = (() => {
  "use strict";
  const ROLES = new Set(["button", "link", "checkbox", "radio", "switch", "tab", "menuitem", "menuitemcheckbox", "menuitemradio", "option", "combobox", "searchbox", "textbox", "slider", "spinbutton", "treeitem", "gridcell"]);
  const SKIP = new Set(["SCRIPT", "STYLE", "NOSCRIPT", "TEMPLATE", "HEAD", "META", "LINK", "svg", "SVG", "CANVAS", "VIDEO", "AUDIO", "IFRAME", "OBJECT"]);
  const POINTER_TAGS = new Set(["DIV", "SPAN", "LI", "IMG", "TD", "TR", "P", "H1", "H2", "H3", "H4", "H5", "H6", "LABEL", "SECTION", "ARTICLE", "PICTURE", "FIGURE"]);
  const GENERIC = /^(add|add to (cart|bag|basket)|buy( now)?|book|select|choose|view|view details|details|more|learn more|shop( now)?|quick (view|look|shop)|see (details|more)|continue|\+|−|-|remove|edit|save|compare)$/i;
  const MAX_ELEMENTS = 220;
  const MAX_TEXT = 2500;

  const clean = (s, max = 80) => {
    s = String(s || "").replace(/\s+/g, " ").trim();
    return s.length > max ? s.slice(0, max - 1) + "…" : s;
  };
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  function create({ ignore, highlight }) {
    let byId = new Map();
    let unloading = false;
    let unloadTimer;
    const markUnloading = () => { unloading = true; clearTimeout(unloadTimer); unloadTimer = setTimeout(() => (unloading = false), 4000); };
    addEventListener("beforeunload", markUnloading);
    addEventListener("pagehide", () => (unloading = true));
    // back/forward cache: the same page (and this script) comes back to life; it's live again
    addEventListener("pageshow", (e) => { if (e.persisted) { unloading = false; clearTimeout(unloadTimer); } });

    // ---- staying on this site ---------------------------------------------------------------
    // the agent never takes the visitor to another website, whatever it was told: a "go" or
    // a click on a link to another domain is refused (subdomains of this site are fine)
    const siteOf = (host) => {
      const parts = host.replace(/^www\d?\./, "").split(".");
      if (parts.length <= 2 || /^\d+$/.test(parts.at(-1))) return parts.join(".");
      return parts.slice(parts.at(-1).length === 2 && /^(co|com|org|net|gov|ac|edu|ne|or)$/.test(parts.at(-2)) ? -3 : -2).join(".");
    };
    function stayOnSite(href) {
      let u;
      try { u = new URL(href, location.href); } catch { return; }
      if (!/^https?:$/.test(u.protocol)) return;
      if (siteOf(u.hostname) !== siteOf(location.hostname)) throw new Error(`Blocked: off-site URL (${u.hostname}). Reply that you only see this site (${siteOf(location.hostname)})`);
    }

    // ---- seeing the page ------------------------------------------------------------------
    function visible(el) {
      const r = el.getBoundingClientRect();
      if (r.width < 2 || r.height < 2) return false;
      if (el.checkVisibility) return el.checkVisibility({ opacityProperty: true, visibilityProperty: true });
      const cs = getComputedStyle(el);
      return cs.visibility !== "hidden" && cs.display !== "none" && Number(cs.opacity) > 0.05;
    }

    function interactive(el, insideInteractive) {
      const tag = el.tagName;
      if (tag === "A") return el.hasAttribute("href") || el.hasAttribute("role");
      if (tag === "BUTTON" || tag === "SELECT" || tag === "TEXTAREA" || tag === "SUMMARY") return true;
      if (tag === "INPUT") return el.type !== "hidden";
      const role = el.getAttribute("role");
      if (role && ROLES.has(role)) return true;
      if (el.isContentEditable && el.hasAttribute("contenteditable")) return true;
      if (insideInteractive) return false;
      if (el.hasAttribute("onclick")) return true;
      const ti = el.getAttribute("tabindex");
      if (ti !== null && Number(ti) >= 0 && tag !== "BODY" && tag !== "HTML" && el.childElementCount <= 6) return true;
      // React-style click handlers: the outermost small element with a pointer cursor
      if (POINTER_TAGS.has(tag) && el.childElementCount <= 4) {
        const cs = getComputedStyle(el);
        if (cs.cursor === "pointer" && (!el.parentElement || getComputedStyle(el.parentElement).cursor !== "pointer")) return true;
      }
      return false;
    }

    function collect() {
      const found = [];
      const visit = (node, inside) => {
        for (let el = node.firstElementChild; el; el = el.nextElementSibling) {
          if (SKIP.has(el.tagName) && el.tagName !== "IFRAME") continue;
          if (el === ignore || el.hidden || el.getAttribute("aria-hidden") === "true" || el.inert) continue;
          const hit = interactive(el, inside);
          if (hit) found.push(el);
          visit(el, inside || hit);
          if (el.shadowRoot) visit(el.shadowRoot, inside || hit);
        }
      };
      visit(document.body || document.documentElement, false);
      // same-origin iframes (embedded forms, checkout steps)
      for (const f of document.querySelectorAll("iframe")) {
        try { if (f.contentDocument?.body && visible(f)) visit(f.contentDocument.body, false); } catch {}
      }
      return found;
    }

    function textOf(el, max = 80) {
      if (el.childElementCount > 40) return clean(el.textContent, max);
      return clean(el.innerText || el.textContent, max);
    }

    const junk = (s) => !s || /^(?:\s|undefined|null|NaN|\[object Object\])*$/.test(s); // broken labels some sites ship
    function nameOf(el) {
      const aria = el.getAttribute("aria-label");
      if (!junk(aria)) return clean(aria);
      const by = el.getAttribute("aria-labelledby");
      if (by) {
        const t = by.split(/\s+/).map((id) => el.ownerDocument.getElementById(id)?.textContent || "").join(" ");
        if (!junk(t)) return clean(t);
      }
      const field = el.tagName === "INPUT" || el.tagName === "SELECT" || el.tagName === "TEXTAREA";
      if (field && el.labels?.length) {
        const t = [...el.labels].map((l) => textOf(l)).join(" ");
        if (t.trim()) return clean(t);
      }
      if (field) return clean(el.getAttribute("placeholder") || el.title || el.name || el.id || "", 60);
      const t = textOf(el);
      if (t) return t;
      const img = el.querySelector?.("img[alt]");
      if (img?.alt) return clean(img.alt);
      const svgTitle = el.querySelector?.("svg title")?.textContent || el.querySelector?.("[aria-label]")?.getAttribute("aria-label");
      return clean(el.title || svgTitle || el.getAttribute("name") || el.getAttribute("data-testid") || "", 60);
    }

    function roleOf(el) {
      const r = el.getAttribute("role");
      if (r) return r;
      switch (el.tagName) {
        case "A": return "link";
        case "BUTTON": case "SUMMARY": return "button";
        case "SELECT": return "select";
        case "TEXTAREA": return "textbox";
        case "INPUT": {
          const t = (el.type || "text").toLowerCase();
          if (t === "search") return "searchbox";
          if (["checkbox", "radio"].includes(t)) return t;
          if (["submit", "button", "reset", "image"].includes(t)) return "button";
          if (el.getAttribute("list") || el.getAttribute("aria-autocomplete")) return "combobox";
          return "textbox";
        }
      }
      return el.isContentEditable ? "textbox" : "clickable";
    }

    // the product card (or row) a generic button belongs to
    function contextOf(el, name) {
      let a = el.parentElement;
      for (let i = 0; a && i < 7; i++, a = a.parentElement) {
        const t = clean(a.innerText, 400);
        if (t.length > name.length + 12 && t.length < 400) return clean(t.replace(name, "").trim(), 110);
        if (t.length >= 400) break;
      }
      return "";
    }

    function describe(el, id, name, ctx) {
      const role = roleOf(el);
      const bits = [`[${id}] ${role}`];
      if (name) bits.push(JSON.stringify(name));
      const tag = el.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA") {
        const t = (el.type || "text").toLowerCase();
        if (t === "checkbox" || t === "radio") bits.push(el.checked ? "checked" : "unchecked");
        else if (!["submit", "button", "reset", "image"].includes(t)) {
          if (!["text", "search"].includes(t)) bits.push(`type=${t}`);
          bits.push(`value=${JSON.stringify(t === "password" ? (el.value ? "••••" : "") : clean(el.value, 60))}`);
          const ph = el.getAttribute("placeholder");
          if (ph && clean(ph, 60) !== name) bits.push(`placeholder=${JSON.stringify(clean(ph, 60))}`);
          if (t === "date") bits.push("(format YYYY-MM-DD)");
        }
        if (el.required) bits.push("required");
      } else if (tag === "SELECT") {
        const sel = el.selectedOptions?.[0];
        bits.push(`value=${JSON.stringify(clean(sel?.textContent || "", 40))}`);
        const opts = [...el.options].slice(0, 14).map((o) => clean(o.textContent, 30));
        bits.push(`options: ${opts.join(" | ")}${el.options.length > 14 ? ` | …(${el.options.length} total)` : ""}`);
      } else if (el.isContentEditable) {
        bits.push(`value=${JSON.stringify(clean(el.innerText, 60))}`);
      }
      const ex = el.getAttribute("aria-expanded"), selA = el.getAttribute("aria-selected"), chk = el.getAttribute("aria-checked"), pressed = el.getAttribute("aria-pressed");
      if (ex) bits.push(ex === "true" ? "expanded" : "collapsed");
      if (selA === "true") bits.push("selected");
      if (chk) bits.push(chk === "true" ? "checked" : "unchecked");
      if (pressed === "true") bits.push("pressed");
      if (el.disabled || el.getAttribute("aria-disabled") === "true") bits.push("disabled");
      if (tag === "A" && el.href) {
        try {
          const u = new URL(el.href, location.href);
          const path = u.origin === location.origin ? u.pathname + u.search : u.href;
          if (!/^javascript:/i.test(el.getAttribute("href") || "") && path !== "/#") bits.push(`→ ${clean(path, 70)}`);
        } catch {}
      }
      if (ctx) bits.push(`(in: ${JSON.stringify(ctx)})`);
      return bits.join(" ");
    }

    // a dialog that's actually showing: many sites keep drawers (the cart, menus) in the
    // page, slid off-screen, so "visible" isn't enough; it has to cover part of the screen
    function openDialog() {
      const onScreen = (el) => {
        const r = el.getBoundingClientRect();
        const w = Math.min(r.right, innerWidth) - Math.max(r.left, 0), h = Math.min(r.bottom, innerHeight) - Math.max(r.top, 0);
        return w > 40 && h > 40;
      };
      const cands = [...document.querySelectorAll('dialog[open], [role="dialog"], [role="alertdialog"], [aria-modal="true"]')].filter((d) => visible(d) && onScreen(d));
      return cands.at(-1) || null;
    }

    // the text inside closed accordions, details and inactive tabs: readable without opening
    // them (and so without moving the page)
    function collapsed(root, shown) {
      const out = [], seen = new Set();
      let total = 0;
      const add = (title, el) => {
        if (!el || seen.has(el) || ignore?.contains(el) || el.closest("header, nav, footer, [role='navigation'], [role='banner']")) return;
        if (el.querySelectorAll("input, textarea, select").length >= 2) return; // a form (write a review…), not something to read
        seen.add(el);
        let t = clean(el.textContent, 900);
        if (title && t.startsWith(title)) t = t.slice(title.length).trim();
        if (t.length < 20 || shown.includes(t.slice(0, 60))) return;
        const line = `- ${title || "Section"}: ${t}`;
        if (total + line.length > 3000) return;
        total += line.length;
        out.push(line);
      };
      for (const d of root.querySelectorAll("details:not([open])")) add(clean(d.querySelector("summary")?.textContent || "", 50), d);
      for (const b of root.querySelectorAll('[aria-expanded="false"][aria-controls]')) {
        for (const id of b.getAttribute("aria-controls").split(/\s+/)) add(clean(b.textContent, 50), document.getElementById(id));
      }
      for (const p of root.querySelectorAll('[role="tabpanel"]')) {
        if (visible(p)) continue;
        const by = p.getAttribute("aria-labelledby");
        add(clean((by && document.getElementById(by)?.textContent) || p.getAttribute("aria-label") || "", 50), p);
      }
      // a product's ingredients, wherever the page keeps them (not every accordion is marked up)
      if (!out.some((l) => /^- [^:]*ingredient/i.test(l))) {
        const ing = ingredients(ignore);
        if (ing && !shown.includes(ing.slice(0, 60))) out.push(`- Ingredients: ${ing.slice(0, 1500)}`);
      }
      return out;
    }

    function snapshot() {
      byId = new Map();
      const vh = innerHeight;
      let els = collect().filter(visible);
      const dialog = openDialog();
      if (dialog) els = els.filter((e) => dialog.contains(e)).concat(els.filter((e) => !dialog.contains(e)).slice(0, 25));
      const total = els.length;
      if (els.length > MAX_ELEMENTS) {
        // keep what's on screen, then what's nearest to it
        const dist = (e) => { const r = e.getBoundingClientRect(); return r.bottom < 0 ? -r.bottom : r.top > vh ? r.top - vh : 0; };
        const keep = new Set([...els].sort((a, b) => dist(a) - dist(b)).slice(0, MAX_ELEMENTS));
        els = els.filter((e) => keep.has(e));
      }
      const names = els.map(nameOf);
      const counts = new Map();
      for (const n of names) counts.set(n.toLowerCase(), (counts.get(n.toLowerCase()) || 0) + 1);
      const lines = els.map((el, i) => {
        const id = i + 1;
        byId.set(id, el);
        const n = names[i];
        const ambiguous = !n || GENERIC.test(n) || (counts.get(n.toLowerCase()) > 1 && n.length < 30);
        const r = el.getBoundingClientRect();
        const where = r.bottom < 0 ? " ↑" : r.top > vh ? " ↓" : "";
        return describe(el, id, n, ambiguous ? contextOf(el, n) : "") + where;
      });

      const out = [`URL: ${location.href}`, `Title: ${clean(document.title, 120)}`];
      const loading = loadingHint();
      if (loading) out.push(`Loading: ${loading}. If what you need isn't here yet, use wait.`);
      const heads = [...document.querySelectorAll("h1, h2, h3")].filter(visible).slice(0, 14).map((h) => clean(h.innerText, 70)).filter(Boolean);
      if (heads.length) out.push(`Headings: ${heads.join(" | ")}`);
      const alerts = [...document.querySelectorAll('[role="alert"], [role="status"], [aria-live="assertive"], .error, .alert, [aria-invalid="true"]')]
        .filter((a) => a !== ignore && visible(a)).map((a) => clean(a.getAttribute("aria-invalid") === "true" ? `${nameOf(a)} is invalid` : a.innerText, 140)).filter(Boolean).slice(0, 6);
      if (alerts.length) out.push(`Alerts: ${alerts.join(" | ")}`);
      if (dialog) out.push(`A dialog is open: ${JSON.stringify(clean(dialog.getAttribute("aria-label") || dialog.querySelector("h1,h2,h3")?.innerText || dialog.innerText, 80))}. Its elements are listed first.`);
      out.push(`Scroll: ${Math.round(scrollY)} of ${Math.max(0, document.documentElement.scrollHeight - vh)} px (↑ above / ↓ below the screen)`);
      out.push("", "Elements:", ...lines);
      if (total > els.length) out.push(`(${total - els.length} more elements further away are not listed; scroll to reach them)`);
      const main = document.querySelector('main, [role="main"], #main, #content, article') || document.body;
      const text = clean(main?.innerText || "", MAX_TEXT);
      if (text) out.push("", "Page text:", text);
      // extras (collapsed sections, ingredients): never allowed to break the snapshot
      let hidden = [];
      try { hidden = collapsed(main, text); } catch {}
      if (hidden.length) out.push("", "Collapsed sections (their text, read without opening them):", ...hidden);
      return { url: location.href, title: document.title, text: out.join("\n") };
    }

    // ---- operating the page ----------------------------------------------------------------
    function get(id) {
      const el = byId.get(Number(id));
      if (!el) throw new Error(`no element [${id}] in the last snapshot`);
      if (!el.isConnected) throw new Error(`element [${id}] is gone (the page changed); look again`);
      return el;
    }

    // before acting on it: on screen if it isn't (scrolled no further than needed), no highlight
    async function show(el) {
      const r = el.getBoundingClientRect();
      if (r.bottom < 0 || r.top > innerHeight || r.right < 0 || r.left > innerWidth) {
        el.scrollIntoView({ block: "nearest", inline: "nearest", behavior: "instant" });
        await sleep(60);
      }
    }

    const point = (el) => { const r = el.getBoundingClientRect(); return { clientX: r.left + r.width / 2, clientY: r.top + r.height / 2 }; };

    function click(el) {
      if (el.tagName === "A" && el.target && el.target !== "_self") el.target = "_self"; // stay in this tab
      const p = point(el);
      const opts = { bubbles: true, cancelable: true, composed: true, view: window, button: 0, ...p };
      el.dispatchEvent(new PointerEvent("pointerover", { ...opts, pointerType: "mouse" }));
      el.dispatchEvent(new MouseEvent("mouseover", opts));
      el.dispatchEvent(new PointerEvent("pointerdown", { ...opts, pointerType: "mouse", isPrimary: true, buttons: 1 }));
      el.dispatchEvent(new MouseEvent("mousedown", { ...opts, buttons: 1 }));
      if (typeof el.focus === "function") el.focus({ preventScroll: true });
      el.dispatchEvent(new PointerEvent("pointerup", { ...opts, pointerType: "mouse", isPrimary: true }));
      el.dispatchEvent(new MouseEvent("mouseup", opts));
      el.dispatchEvent(new MouseEvent("click", { ...opts, detail: 1 }));
    }

    function setNative(el, v) {
      const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : el instanceof HTMLSelectElement ? HTMLSelectElement.prototype : HTMLInputElement.prototype;
      Object.getOwnPropertyDescriptor(proto, "value").set.call(el, v);
    }

    function key(el, k, opts = {}) {
      const code = k.length === 1 ? (/[a-z]/i.test(k) ? `Key${k.toUpperCase()}` : /\d/.test(k) ? `Digit${k}` : k === " " ? "Space" : "") : k;
      const init = { key: k, code, bubbles: true, cancelable: true, composed: true, ...opts };
      const down = el.dispatchEvent(new KeyboardEvent("keydown", init));
      if (k.length === 1 || k === "Enter") el.dispatchEvent(new KeyboardEvent("keypress", init));
      return { down, up: () => el.dispatchEvent(new KeyboardEvent("keyup", init)) };
    }

    async function type(el, text, enter) {
      if (el.tagName === "SELECT") return select(el, text);
      // a combobox wrapper: type into the field inside it
      if (!(el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement) && !el.isContentEditable) {
        const inner = el.querySelector?.("input, textarea, [contenteditable]");
        if (!inner) throw new Error("that element doesn't take text");
        el = inner;
      }
      click(el);
      await sleep(40);
      if (el.isContentEditable) {
        document.execCommand("selectAll");
        document.execCommand("insertText", false, text);
      } else if (["date", "time", "datetime-local", "month", "week", "range", "color"].includes(el.type)) {
        setNative(el, text);
        el.dispatchEvent(new Event("input", { bubbles: true }));
      } else {
        setNative(el, "");
        el.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "deleteContentBackward" }));
        // character by character, so autocompletes and React-controlled fields keep up
        const chunks = text.length > 40 ? [text] : [...text];
        let sofar = "";
        for (const ch of chunks) {
          const k = key(el, ch.length === 1 ? ch : "Unidentified");
          sofar += ch;
          setNative(el, sofar);
          el.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: ch }));
          k.up();
          await sleep(chunks.length > 1 ? 18 : 0);
        }
      }
      el.dispatchEvent(new Event("change", { bubbles: true }));
      if (enter) await pressEnter(el);
      return `typed ${JSON.stringify(text)}${enter ? " and pressed Enter" : ""}`;
    }

    async function pressEnter(el) {
      const k = key(el, "Enter");
      k.up();
      // synthetic keys don't submit forms by themselves: do what the browser would
      if (k.down && el.form && !(el instanceof HTMLTextAreaElement)) {
        await sleep(60);
        if (!unloading) el.form.requestSubmit ? el.form.requestSubmit() : el.form.submit();
      }
    }

    async function select(el, option) {
      if (el.tagName === "SELECT") {
        const want = String(option).toLowerCase().trim();
        const opts = [...el.options];
        const o = opts.find((x) => x.textContent.trim().toLowerCase() === want || x.value.toLowerCase() === want) || opts.find((x) => x.textContent.toLowerCase().includes(want));
        if (!o) throw new Error(`no option like ${JSON.stringify(option)}; options are: ${opts.slice(0, 20).map((x) => x.textContent.trim()).join(" | ")}`);
        el.focus();
        setNative(el, o.value);
        el.dispatchEvent(new Event("input", { bubbles: true }));
        el.dispatchEvent(new Event("change", { bubbles: true }));
        return `selected ${JSON.stringify(o.textContent.trim())}`;
      }
      click(el); // a custom dropdown: open it; the options show up in the next look
      return "opened the dropdown; pick an option from the next snapshot";
    }

    // does the page look like it's still loading? (a slow page, or results still coming in)
    const LOADERS = '[aria-busy="true"], [role="progressbar"], [class*="spinner" i], [class*="skeleton" i], [class*="loader" i], [class*="loading" i], [data-testid*="loading" i]';
    function loadingHint() {
      if (document.readyState === "loading") return "the page is still loading";
      const busy = [...document.querySelectorAll(LOADERS)].some((el) => { const r = el.getBoundingClientRect(); return r.width >= 8 && r.height >= 8 && r.bottom > 0 && r.top < innerHeight && getComputedStyle(el).visibility !== "hidden" && getComputedStyle(el).opacity !== "0"; });
      if (busy) return "a loading indicator is showing (results may still be coming in)";
      if ((document.body?.innerText || "").trim().length < 200) return "the page has almost no content yet";
      return "";
    }

    // the "wait" action: until the page has loaded and settled (no loading indicator, the DOM
    // quiet for a second), or up to secs
    async function waitReady(secs) {
      const t0 = Date.now(), end = t0 + secs * 1000;
      while (Date.now() < end && !unloading) {
        // no loading signs: give it a moment to settle (pages with animations never go fully quiet)
        if (document.readyState === "complete" && !loadingHint()) { await settle(800, Math.min(2500, Math.max(800, end - Date.now()))); if (!loadingHint()) break; }
        await sleep(400);
      }
      const took = Math.round((Date.now() - t0) / 1000);
      return loadingHint() ? `waited ${took}s; still loading (${loadingHint()})` : `waited ${took}s; the page is ready`;
    }

    // wait until the DOM stops changing (or give up after max)
    function settle(quiet = 350, max = 1800) {
      return new Promise((res) => {
        let t;
        const done = () => { obs.disconnect(); clearTimeout(t); clearTimeout(cap); res(); };
        const obs = new MutationObserver(() => { clearTimeout(t); t = setTimeout(done, quiet); });
        obs.observe(document.documentElement, { subtree: true, childList: true, characterData: true, attributes: true, attributeFilter: ["aria-expanded", "aria-selected", "aria-hidden", "hidden", "open", "disabled", "value"] });
        t = setTimeout(done, quiet);
        const cap = setTimeout(done, max);
      });
    }

    async function one(a) {
      switch (a.do) {
        case "click": { const el = get(a.id); const link = el.closest("a[href]"); if (link) stayOnSite(link.getAttribute("href")); await show(el); if (el.tagName === "OPTION" && el.parentElement?.tagName === "SELECT") return select(el.parentElement, el.textContent); click(el); return "clicked"; }
        case "type": { const el = get(a.id); await show(el); return type(el, String(a.text ?? ""), !!a.enter); }
        case "select": { const el = get(a.id); await show(el); return select(el, String(a.text ?? "")); }
        case "key": {
          const el = document.activeElement && document.activeElement !== document.body ? document.activeElement : document.body;
          if (a.text === "Enter") { await pressEnter(el); return "pressed Enter"; }
          key(el, String(a.text || "Escape")).up();
          return `pressed ${a.text}`;
        }
        case "read": {
          // the full text of an element and what it controls (an accordion's panel, a tab's
          // content), collapsed or not, without scrolling or opening anything
          const el = get(a.id);
          const own = clean(el.textContent, 4000);
          const panels = [];
          const ctl = el.getAttribute("aria-controls") || el.closest("[aria-controls]")?.getAttribute("aria-controls");
          if (ctl) for (const id of ctl.split(/\s+/)) panels.push(document.getElementById(id));
          panels.push(el.closest("details"));
          // a "More" / "Read more" button or a heading without a declared panel: the section around it
          for (let x = el, i = 0; x && x !== document.body && i < 5; x = x.parentElement, i++) panels.push(x.nextElementSibling, x.parentElement);
          let found = own;
          for (const p of panels) {
            const t = p && !ignore?.contains(p) ? clean(p.textContent, 4000) : "";
            if (t.length >= 80 && t.length > own.length * 2 && p.querySelectorAll("input, textarea, select").length < 2) { found = t; break; }
          }
          // about ingredients: the full list too, wherever the page keeps it
          if (/ingredient|what'?s in it|formula/i.test(`${own} ${found.slice(0, 300)}`)) {
            let ing = "";
            try { ing = ingredients(ignore); } catch {}
            if (ing && !found.includes(ing.slice(0, 60))) found = `${found}\nFull ingredient list: ${ing}`;
          }
          return found ? `text: ${found}` : "no text there";
        }
        case "scroll": {
          if (a.id) { get(a.id).scrollIntoView({ block: "center", behavior: "instant" }); return "scrolled to it"; }
          scrollBy({ top: (a.text === "up" ? -1 : 1) * innerHeight * 0.85, behavior: "instant" });
          return `scrolled ${a.text === "up" ? "up" : "down"}`;
        }
        case "go": {
          const u = new URL(String(a.text), location.href);
          if (!/^https?:$/.test(u.protocol)) throw new Error("only http(s) links");
          stayOnSite(u.href);
          markUnloading();
          location.assign(u.href);
          return `going to ${u.href}`;
        }
        case "back": markUnloading(); history.back(); return "went back";
        case "wait": return waitReady(Math.min(15, Math.max(1, Number(a.text) || 6)));
        default: throw new Error(`unknown action ${a.do}`);
      }
    }

    async function act(actions) {
      const results = [];
      const startUrl = location.href;
      for (const a of actions || []) {
        if (unloading) break;
        try {
          results.push(`${a.do}${a.id ? ` [${a.id}]` : ""}: ${await one(a)}`);
        } catch (e) {
          results.push(`${a.do}${a.id ? ` [${a.id}]` : ""}: FAILED, ${e.message}`);
          break;
        }
        await settle();
        if (unloading) { results.push("the page is loading a new page"); break; }
        if (location.href !== startUrl) { results.push(`the page changed to ${location.href}`); break; }
        await sleep(120);
      }
      if (unloading) return { results, url: location.href, navigating: true };
      return { results, url: location.href, navigating: false, snapshot: snapshot() };
    }

    // ---- what the visitor does by themselves (for memory) ------------------------------------
    // A click or change on the page → { type, group, value, item } when it says something about
    // them: a filter or sort, an option picked (shade, size), add to bag, compare, save, remove.
    // Only real input counts (isTrusted): the agent's own clicks are synthetic.
    const FILTER_ZONE = /filter|facet|refine|refinement|plp-?nav|sidebar|sort/i;
    const OPTION_ZONE = /swatch|variant|shade|colou?r|size|option|sku|scent|finish/i;
    const attrs = (a) => `${a.id || ""} ${typeof a.className === "string" ? a.className : ""} ${a.getAttribute?.("aria-label") || ""} ${a.getAttribute?.("data-at") || ""} ${a.getAttribute?.("data-testid") || ""} ${a.getAttribute?.("data-comp") || ""}`;
    function inZone(el, re) {
      for (let a = el, i = 0; a && a !== document.body && i < 12; a = a.parentElement, i++) if (re.test(attrs(a))) return true;
      return false;
    }
    // the facet or option group it belongs to: "Brand", "Price", "Shade"
    function groupOf(el) {
      for (let a = el.parentElement, i = 0; a && a !== document.body && i < 8; a = a.parentElement, i++) {
        const by = a.getAttribute("aria-labelledby");
        const lbl = a.getAttribute("aria-label") || (by && document.getElementById(by)?.textContent) || (a.tagName === "FIELDSET" && a.querySelector("legend")?.textContent);
        if (lbl && clean(lbl, 40)) return clean(lbl, 40);
        const head = a.querySelector(":scope > h2, :scope > h3, :scope > h4, :scope > legend, :scope > summary, :scope > button[aria-expanded], :scope > div > button[aria-expanded]");
        if (head && !head.contains(el) && clean(head.innerText, 40)) return clean(head.innerText, 40);
      }
      return "";
    }
    // productPage: a choice there is an option (shade, size); elsewhere it's a filter
    function interaction(e, { productPage = false } = {}) {
      if (!e.isTrusted) return null;
      const t = e.composedPath?.()[0] || e.target;
      if (!(t instanceof Element) || ignore?.contains(t)) return null;
      const el = t.closest('a, button, input, select, label, summary, [role="checkbox"], [role="radio"], [role="option"], [role="tab"], [role="switch"], [role="menuitemcheckbox"], [role="menuitemradio"], [aria-pressed], [aria-checked], [aria-selected]');
      if (!el) return null;
      const target = el.tagName === "LABEL" && el.control ? el.control : el;
      if (e.type === "change" && target.tagName !== "SELECT") return null; // checkboxes are seen as clicks
      if (e.type === "click" && target.tagName === "SELECT") return null; // selects as changes
      const name = target.tagName === "SELECT" ? clean(target.selectedOptions?.[0]?.textContent || "", 60) : nameOf(target) || nameOf(el);
      if (!name || name.length > 90) return null;
      const group = target.tagName === "SELECT" ? nameOf(target) || groupOf(target) : groupOf(target);
      // which product: on a product page the main buttons (near its title) are for that product
      // (left blank, the page's product is added); a tile's button is for the tile's product
      const h1 = productPage && document.querySelector("h1");
      // (whichever is closer going up: the page's title, or a link to another product = a tile)
      const otherProduct = (l) => { try { const u = new URL(l.href); return u.origin === location.origin && u.pathname !== location.pathname && /\/(product|products|p)\/|[-/]P\d{4,}/i.test(u.pathname); } catch { return false; } };
      const mainProduct = () => {
        for (let a = el.parentElement, i = 0; h1 && a && a !== document.body && i < 25; a = a.parentElement, i++) {
          if (a.contains(h1)) return true;
          if ([...a.querySelectorAll("a[href]")].some(otherProduct)) return false;
        }
        return false;
      };
      const item = () => {
        if (mainProduct()) return "";
        const ctx = contextOf(el, name).replace(/\b(buy it now|add to (bag|basket|cart)|qty|quantity|one-time purchase)\b|\b\d+\b/gi, "").replace(/\s+/g, " ").trim();
        return ctx.length >= 8 ? ctx.slice(0, 90) : ""; // just button words around it: nothing to name
      };
      if (/\badd(ed)? to (my )?(bag|basket|cart)\b|^buy (it )?now$/i.test(name)) return { type: "add_to_cart", value: name, item: item() };
      if (/\bcompare\b/i.test(name)) return { type: "compare", value: name, item: item() };
      if (/\b(love|loves|wish ?list|favou?rites?|save for later|heart)\b/i.test(name)) return { type: "save", value: name, item: item() };
      if (/^(remove|delete)\b/i.test(name)) return { type: "remove", value: name, item: item() };
      if (/\bsort\b/i.test(`${group} ${name}`) && (target.tagName === "SELECT" || /option|radio|menuitem/.test(roleOf(target)))) return { type: "sort", group, value: name };
      // a swatch that's a link to this same product with the variant in the address (?Color=…)
      if (productPage && el.tagName === "A") {
        try {
          const u = new URL(el.href, location.href);
          if (u.pathname === location.pathname && u.search) return { type: "option", group: group || [...u.searchParams.keys()][0] || "", value: name };
        } catch {}
      }
      const choice = /checkbox|radio|option|switch|tab|menuitem/.test(roleOf(target)) || target.hasAttribute("aria-pressed") || target.hasAttribute("aria-checked") || target.hasAttribute("aria-selected") || target.tagName === "SELECT";
      const checked = target.type === "checkbox" || target.type === "radio" ? target.checked : null;
      if (inZone(target, FILTER_ZONE) && (choice || el.tagName === "A")) return { type: "filter", group, value: name, ...(checked === false ? { off: true } : {}) };
      if (choice && (productPage || inZone(target, OPTION_ZONE))) return { type: "option", group, value: name };
      // elsewhere, only checkbox-like controls (tabs and carousel dots aren't filters)
      if (/checkbox|radio|switch|menuitemcheckbox/.test(roleOf(target)) || target.hasAttribute("aria-checked")) return { type: "filter", group, value: name, ...(checked === false ? { off: true } : {}) };
      return null;
    }

    return {
      snapshot: () => (unloading ? { navigating: true } : snapshot()),
      // the same view without renumbering the elements the agent is working with (background checks)
      peek: () => { if (unloading) return { navigating: true }; const keep = byId; try { return snapshot(); } finally { byId = keep; } },
      act,
      interaction,
      isUnloading: () => unloading,
    };
  }

  // ---- what this page is, for the browsing history (no model involved) ------------------------
  // A product's name, brand and price from the structured data sites publish for search
  // engines (JSON-LD, Open Graph), with URL patterns for search, cart and checkout pages.
  const SEARCH_PARAMS = ["q", "query", "keyword", "keywords", "searchTerm", "search", "k", "term", "text", "Ntt"];
  function describe() {
    const visit = { url: location.href, title: clean(document.title, 120), kind: "page", at: Date.now() };
    const h1 = clean(document.querySelector("h1")?.innerText || "", 100);
    const meta = (n) => document.querySelector(`meta[property="${n}"], meta[name="${n}"]`)?.content;
    const money = (price, cur) => price == null || price === "" ? undefined : `${!cur || cur === "USD" ? "$" : `${cur} `}${price}`;
    const nodes = [];
    const walk = (x) => { if (Array.isArray(x)) x.forEach(walk); else if (x && typeof x === "object") { nodes.push(x); if (x["@graph"]) walk(x["@graph"]); } };
    for (const s of document.querySelectorAll('script[type="application/ld+json"]')) { try { walk(JSON.parse(s.textContent)); } catch {} }
    const product = nodes.find((x) => [].concat(x["@type"] || []).some((t) => /^(Product|ProductGroup|IndividualProduct)$/i.test(t)));
    if (product) {
      visit.kind = "product";
      visit.name = clean(product.name, 100);
      const brand = typeof product.brand === "string" ? product.brand : product.brand?.name;
      if (brand) visit.brand = clean(brand, 60);
      const offer = [].concat(product.offers || product.hasVariant?.[0]?.offers || [])[0];
      const price = offer?.price ?? offer?.lowPrice ?? [].concat(offer?.offers || [])[0]?.price;
      visit.price = money(price, offer?.priceCurrency);
    } else if (/product/i.test(meta("og:type") || "")) {
      visit.kind = "product";
      visit.name = clean(meta("og:title") || h1, 100);
      visit.price = money(meta("product:price:amount") || meta("og:price:amount"), meta("product:price:currency"));
    }
    const u = new URL(location.href);
    const query = SEARCH_PARAMS.map((k) => u.searchParams.get(k)).find(Boolean);
    if (visit.kind === "page") {
      if (query || /\/(search|s)(\/|$)/i.test(u.pathname)) { visit.kind = "search"; if (query) visit.query = clean(query, 80); }
      else if (/\/(cart|basket|bag)(\/|$)/i.test(u.pathname)) visit.kind = "cart";
      else if (/checkout/i.test(u.pathname)) visit.kind = "checkout";
      else if (/\/(product|products|p|dp|item|pd|ip)\/|[-/]P\d{4,}/i.test(u.pathname) && h1) {
        visit.kind = "product";
        visit.name = h1;
        const priceEl = document.querySelector('[itemprop="price"], [data-testid*="price" i], [class*="price" i]');
        const m = priceEl?.textContent.match(/[$£€]\s?\d[\d,.]*/);
        if (m) visit.price = m[0].replace(/\s/, "");
      }
    }
    if (/\b(page not found|not found|404)\b/i.test(document.title)) { visit.kind = "page"; delete visit.name; delete visit.price; }
    // for the sales side: a crossed-out price, the category, the bag's subtotal
    if (visit.kind === "product") {
      const was = wasPrice(visit.price);
      if (was) visit.was = was;
      const ld = nodes.find((x) => [].concat(x["@type"] || []).includes("BreadcrumbList"));
      const crumbs = ld ? [].concat(ld.itemListElement || []).map((i) => clean(i.name || i.item?.name || "", 40))
        : [...document.querySelectorAll('nav[aria-label*="breadcrumb" i] li, [class*="breadcrumb" i] li, [data-at*="breadcrumb" i] a')].map((li) => clean(li.innerText, 40));
      const cat = crumbs.filter((c) => c && !/^home$/i.test(c) && c !== visit.name).slice(-2).join(" › ");
      if (cat) visit.category = cat;
    }
    if (visit.kind === "cart" || visit.kind === "checkout") {
      const text = (document.querySelector("main") || document.body).innerText;
      const m = text.match(/(?:merchandise\s+subtotal|subtotal|basket total|bag total|cart total|estimated total|order total)[^$\d]{0,40}\$\s?(\d[\d,]*\.?\d{0,2})/i);
      if (m) visit.subtotal = `$${m[1]}`;
    }
    if (!visit.name && h1 && visit.kind !== "search") visit.heading = h1;
    for (const k of Object.keys(visit)) if (visit[k] === undefined || visit[k] === "") delete visit[k];
    return visit;
  }

  // a crossed-out "was" price near the product's title: in <s>/<del>, or styled line-through
  function wasPrice(price) {
    const now = Number(String(price || "").replace(/[^\d.]/g, "")) || 0;
    const scope = document.querySelector("h1")?.closest("main, section, [class*='product' i]") || document.querySelector("main") || document.body;
    const cands = [...scope.querySelectorAll("s, del, strike, [class*='strike' i], [class*='was' i], [class*='original' i], [class*='compare' i], [data-at*='strike' i], [data-at*='original' i]")].slice(0, 40);
    let looked = 0;
    for (const el of scope.querySelectorAll("span, div, p")) {
      if (cands.length > 60 || ++looked > 4000) break;
      if (el.childElementCount === 0 && /\$\d/.test(el.textContent) && getComputedStyle(el).textDecorationLine.includes("line-through")) cands.push(el);
    }
    for (const el of cands) {
      const m = el.textContent.replace(/,/g, "").match(/\$\s?(\d+(?:\.\d{1,2})?)/);
      const v = m && Number(m[1]);
      if (v && (!now || v > now * 1.02) && v < (now || v) * 5) return `$${m[1]}`;
    }
    return null;
  }

  // ---- who is signed in, for the memory page (never sent to the model) ------------------------
  // A name from a greeting in the header or account menu ("Hi, Sam", "Welcome back, Sam"), an
  // email shown there, and on account / profile pages the name and email fields' values.
  //   account(ignore) → { name?, email?, from: { name?, email? } } | null
  //   loginEmail(form) → the email typed into a sign-in form (one with a password field), or ""
  const EMAIL = /[A-Z0-9._%+-]+@[A-Z0-9-]+(?:\.[A-Z0-9-]+)*\.[A-Z]{2,24}/i;
  const GREETING = /^(?:hi|hello|hey|howdy|welcome back|welcome|good (?:morning|afternoon|evening))\s*[,!:]?\s+([\p{L}][\p{L}'’.-]{1,24}(?: [\p{L}][\p{L}'’.-]{1,24})?)\s*[!.,]?$/iu;
  const GREETING_START = /^(?:hi|hello|hey|welcome back)\s*[,!:]?\s+([\p{L}][\p{L}'’-]{1,24})(?=[\s!.,]|$)/iu;
  const NOT_NAME =/^(there|guest|friend|friends|back|to|in|sign|log|shopper|everyone|all|you|beautiful|beauty|gorgeous|user|member|customer|again|stranger|my account|account)\b/i;
  const ACCOUNT_URL = /\/(account|accounts|my-?account|profile|personal-?info(rmation)?|my-?info|customer|user\/settings|settings\/profile|member)(\/|$|\?|#)/i;
  const ZONES = 'header, nav, [role="banner"], [role="navigation"], [class*="account" i], [id*="account" i], [class*="greeting" i], [class*="user-name" i], [class*="username" i], [class*="profile" i], [data-at*="account" i], [data-testid*="account" i]';
  const titleCase = (s) => (s === s.toUpperCase() ? s.toLowerCase().replace(/(^|[\s'’-])\p{L}/gu, (c) => c.toUpperCase()) : s);
  const looksEmail = (v) => EMAIL.test(v) && EMAIL.exec(v)[0].length === String(v).trim().length;

  // an element's text with a space between its parts ("Hi, Sam" + "1,250 pts", not "Sam1,250")
  function spaced(el) {
    const parts = [], w = document.createTreeWalker(el, NodeFilter.SHOW_TEXT);
    for (let n = w.nextNode(), i = 0; n && i < 40; n = w.nextNode(), i++) parts.push(n.nodeValue);
    return parts.join(" ");
  }
  function account(ignore) {
    const out = { from: {} };
    const inMine = (el) => ignore && (ignore === el || ignore.contains?.(el));
    // greetings and emails in the header and account menus
    let seen = 0;
    outer: for (const z of document.querySelectorAll(ZONES)) {
      if (inMine(z)) continue;
      for (const el of [z, ...z.querySelectorAll("a, button, span, p, div, strong, b, li, h1, h2, h3, h4")]) {
        if (++seen > 1500) break outer;
        if (el.childElementCount > 4) continue;
        const texts = [spaced(el), el.getAttribute("aria-label"), el.getAttribute("title")];
        for (const raw of texts) {
          const t = clean(raw, 80).replace(/\s*(my account|account|▾|▼|⌄)\s*$/i, "").trim();
          if (!t) continue;
          if (!out.name) {
            // "Hi, Sam" on its own, else a first name followed by more ("Hi, Sam 1,250 pts")
            const m = t.match(GREETING) || (t.length <= 50 && t.match(GREETING_START));
            if (m && !NOT_NAME.test(m[1])) { out.name = titleCase(m[1].replace(/[.’']+$/, "")); out.from.name = "greeting in the header"; }
          }
          if (!out.email && t.length < 80) {
            const m = t.match(EMAIL);
            if (m && t.length - m[0].length < 30) { out.email = m[0].toLowerCase(); out.from.email = "shown in the account menu"; }
          }
        }
        if (out.name && out.email) break outer;
      }
    }
    // account / profile pages: the name and email fields, else the page's text ("Name" over
    // "Taylor Smith", "Email: taylor@…"). A full name here beats the header's first name.
    if (ACCOUNT_URL.test(location.pathname + location.search)) {
      const val = (sel) => {
        for (const el of document.querySelectorAll(sel)) {
          if (inMine(el) || el.type === "password" || el.type === "hidden") continue;
          const v = clean(el.value, 80);
          if (v) return v;
        }
        return "";
      };
      let email = val('input[autocomplete~="email"], input[type="email"], input[name*="email" i], input[id*="email" i]');
      let full = val('input[autocomplete~="name"], input[name="fullName" i], input[name="full_name" i], input[name="name" i]');
      let first = val('input[autocomplete~="given-name"], input[name*="first" i][name*="name" i], input[id*="first" i][id*="name" i]');
      let last = val('input[autocomplete~="family-name"], input[name*="last" i][name*="name" i], input[id*="last" i][id*="name" i]');
      // the page's text, line by line, outside the header, footer and our own widget
      const main = document.querySelector('main, [role="main"]') || document.body;
      const lines = String(main.innerText || "").split("\n").map((l) => clean(l, 120)).filter(Boolean).slice(0, 1500);
      const LABEL = { email: /^(e-?mail|e-?mail address|email id)$/i, full: /^(full name|name|your name|account name)$/i, first: /^first name$/i, last: /^last name$/i };
      const valueAfter = (i) => { for (let j = i + 1; j < Math.min(lines.length, i + 3); j++) if (!/^(edit|change|update|add|manage)\b/i.test(lines[j])) return lines[j]; return ""; };
      for (let i = 0; i < lines.length; i++) {
        const l = lines[i], m = l.match(/^([^:]{2,20}):\s*(.+)$/);
        const [label, value] = m ? [m[1].trim(), m[2].trim()] : [l, null];
        for (const [k, re] of Object.entries(LABEL)) {
          if (!re.test(label)) continue;
          const v = value ?? valueAfter(i);
          if (k === "email" && !email && looksEmail(v)) email = v;
          if (k === "full" && !full && v) full = v;
          if (k === "first" && !first && v) first = v;
          if (k === "last" && !last && v) last = v;
        }
        if (!email && looksEmail(l)) email = l; // an email on a line of its own
      }
      if (looksEmail(email) && (!out.email || out.from.email !== "account page")) { out.email = email.toLowerCase(); out.from.email = "account page"; }
      const n = clean(full || [first, last].filter(Boolean).join(" "), 80);
      const okName = n && n.length <= 60 && !/\d|@|\b(edit|sign|log|account|profile|settings)\b/i.test(n) && n.split(" ").length <= 5;
      if (okName && (!out.name || n.split(" ").length > out.name.split(" ").length)) { out.name = titleCase(n); out.from.name = "account page"; }
    }
    return out.name || out.email ? out : null;
  }

  // The email typed to sign in, at the moment they go ahead: a form submitted, a Sign in /
  // Log in / Continue / Next button clicked, or Enter pressed in the email field. Only in a
  // sign-in context (a password field, or "sign in" / "log in" around it), so a newsletter
  // box doesn't count. Works for pop-ups and two-step sign-ins (email first, password next).
  //   loginEmail(el) → "taylor@…" | ""      el: the form, the button clicked or the field
  const SIGNIN = /\b(sign|log)[\s-]?in\b|\blogin\b|\bsign[\s-]?on\b/i;
  const GO = /\b(sign|log)[\s-]?in\b|\blogin\b|\bcontinue\b|\bnext\b|\bsubmit\b|\bproceed\b/i;
  function loginEmail(el) {
    if (!(el instanceof Element)) return "";
    const field = el.matches("input") ? el : null;
    const button = !field && !(el instanceof HTMLFormElement) ? el.closest('button, [role="button"], input[type="submit"], input[type="button"], a') : null;
    if (button && !(button.type === "submit" || GO.test(`${button.textContent} ${button.value || ""} ${button.getAttribute("aria-label") || ""}`))) return "";
    const from = el instanceof HTMLFormElement ? el : (field || button || el);
    const scope = from.closest("form") || from.closest('dialog, [role="dialog"], [aria-modal="true"]') || from.closest("section, main") || document.body;
    const signin = scope.querySelector('input[type="password"]') || SIGNIN.test(String(scope.textContent || "").slice(0, 4000)) || SIGNIN.test(`${location.pathname} ${document.title}`);
    if (!signin) return "";
    const fields = field ? [field] : [...scope.querySelectorAll('input[type="email"], input[autocomplete~="username"], input[autocomplete~="email"], input[name*="email" i], input[name*="user" i], input[type="text"], input:not([type])')];
    for (const f of fields) {
      const v = String(f.value || "").trim();
      if (looksEmail(v)) return v.toLowerCase();
    }
    return "";
  }


  // ---- a product's ingredients, from the page (for allergy checks) ---------------------------
  // An "Ingredients" heading, tab, button or accordion and the text it shows or controls (often
  // in the page even while collapsed), else a line that starts "Ingredients:".
  //   ingredients(ignore) → "Water, Glycerin, …" | ""
  const ING_HEAD = /^\s*(full\s+|key\s+)?ingredients?(\s+list)?\s*:?\s*$/i;
  const INCI = /\b(aqua|water|eau|glycerin|dimethicone|extract|oil|acid|sodium|alcohol|silica|mica|tocopherol|fragrance|parfum|butter|wax|glycol|phenoxyethanol|titanium dioxide|iron oxides?|citric|stearate|cetyl|caprylic|polymer|ci \d{5})\b/gi;
  // how much a text looks like an ingredient list ("Water, Glycerin, …"), and the list itself
  function asList(raw) {
    let t = clean(raw, 6000).replace(/^\s*(full\s+|key\s+)?ingredients?(\s+list)?\s*:?\s*/i, "");
    // drop a lead-in sentence: start where the comma-separated run begins
    const m = t.match(/(?:^|[.:!?]\s*|[a-z][A-Z])((?:[A-Z][^,.;:]{1,60},\s*){3,}[\s\S]*)$/);
    if (m && m[1].length < t.length) t = m[1];
    const commas = (t.match(/,/g) || []).length, inci = (t.match(INCI) || []).length;
    return { text: t.slice(0, 3000), score: commas >= 4 && inci >= 2 ? commas + 4 * inci : 0 };
  }
  function ingredients(ignore) {
    const mine = (el) => !!ignore && el instanceof Node && (ignore === el || ignore.contains(el));
    let best = { text: "", score: 0 };
    // the shown text and the full text (a collapsed accordion's list is only in the latter)
    const consider = (el) => {
      if (!el || mine(el)) return;
      for (const raw of new Set([el.innerText, el.textContent])) {
        if (!raw) continue;
        const c = asList(raw);
        if (!/[{}\\]|":/.test(c.text.slice(0, 200)) && c.score > best.score) best = c;
      }
    };
    const heads = [...document.querySelectorAll("h2, h3, h4, h5, h6, button, summary, [role='tab'], [role='button'], dt, strong, b, span, a, div, p, label")]
      .filter((el) => !mine(el) && el.childElementCount <= 3 && ING_HEAD.test(el.textContent || ""))
      .slice(0, 16);
    for (const h of heads) {
      const ctl = h.getAttribute("aria-controls") || h.closest("[aria-controls]")?.getAttribute("aria-controls");
      if (ctl) consider(document.getElementById(ctl));
      const tab = h.closest("[role='tab']");
      if (tab?.id) consider(document.querySelector(`[aria-labelledby~="${CSS.escape(tab.id)}"]`));
      for (const el of [h.closest("details"), h.nextElementSibling, h.parentElement?.nextElementSibling, h.parentElement?.parentElement?.nextElementSibling, h.parentElement]) consider(el);
    }
    // "Ingredients: Water, Glycerin, …" in one block of text
    const w = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    for (let n = w.nextNode(), i = 0; n && i < 20000; n = w.nextNode(), i++) {
      if (/ingredients?\s*:/i.test(n.nodeValue) && !mine(n.parentElement) && !/^(SCRIPT|STYLE|NOSCRIPT|TEMPLATE)$/.test(n.parentElement?.tagName)) consider({ textContent: n.parentElement.textContent.replace(/^[\s\S]*?ingredients?\s*:\s*/i, "") });
    }
    return best.text;
  }

  return { create, describe, account, loginEmail, ingredients };
})();
