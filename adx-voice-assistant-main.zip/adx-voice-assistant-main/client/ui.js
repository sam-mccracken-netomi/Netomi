/* Talk to Website: the widget UI (the orb, its hover dock, the chat panel, the talk
 * shortcut). The voice runs in the page (TalkVoice) or, in the Chrome extension, in its
 * offscreen document so the conversation outlives page loads; the page agent (TalkPage)
 * always runs here, where the page is.
 *
 *   Hold ⌥ Space (Alt+Space)  push-to-talk; release to hear the answer
 *   Hold the orb               push-to-talk with the mouse or a finger
 *   Click the orb              hands-free conversation; click again to end it
 *   Hover the orb              chat (the transcript), mute the mic, stop
 */
  if (window.__talkWidget) return window.__talkWidget.show();

  // ---- config ------------------------------------------------------------------------
  const script = document.currentScript;
  const given = { ...(script?.dataset || {}), ...(window.TalkWidgetConfig || {}) };
  const scriptOrigin = script?.src ? new URL(script.src) : null;
  const CONFIG = {
    server: given.server || (scriptOrigin ? `${scriptOrigin.protocol === "https:" ? "wss" : "ws"}://${scriptOrigin.host}` : "ws://localhost:5179"),
    shortcut: given.shortcut || "Alt+Space",
    name: given.name || "Assistant",
    accent: given.accent || "#4C4F62",
    mode: given.mode === "extension" ? "extension" : "page",
    idle: { ptt: Number(given.idleTimeoutSec ?? 60), handsFree: Number(given.handsFreeIdleSec ?? 120), muted: Number(given.mutedIdleSec ?? 300) },
  };
  const HOLD_MS = 220; // pointer held this long on the orb = push-to-talk
  const now = () => performance.now();
  const EXT = CONFIG.mode === "extension";

  // ---- this site's memory: what the visitor viewed (kept even while the voice is off) ----------
  // Everything is stored per site: in the extension under the site's key in extension
  // storage, on a page in the site's own localStorage. Nothing from one site is ever read
  // on another.
  const SITE = siteOf(location.hostname);
  function siteOf(host) {
    const parts = host.replace(/^www\d?\./, "").split(".");
    if (parts.length <= 2 || /^\d+$/.test(parts.at(-1))) return parts.join(".");
    const sld = parts.at(-2);
    return parts.slice(parts.at(-1).length === 2 && /^(co|com|org|net|gov|ac|edu|ne|or)$/.test(sld) ? -3 : -2).join(".");
  }
  const store = EXT
    ? {
        async get(k) { try { return (await chrome.storage.local.get(`ttw:${SITE}:${k}`))[`ttw:${SITE}:${k}`] ?? null; } catch { return null; } },
        async set(k, v) { try { await chrome.storage.local.set({ [`ttw:${SITE}:${k}`]: v }); } catch {} },
      }
    : {
        async get(k) { try { return JSON.parse(localStorage.getItem(`ttw:${k}`)); } catch { return null; } },
        async set(k, v) { try { localStorage.setItem(`ttw:${k}`, JSON.stringify(v)); } catch {} },
      };
  const VISITS_MAX = 50, VISITS_DAYS = 30;
  let visits = [];
  async function recordVisit() {
    const v = TalkPage.describe();
    const kept = ((await store.get("visits")) || []).filter((x) => x && Date.now() - x.at < VISITS_DAYS * 864e5);
    const prev = [...kept].reverse().find((x) => x.url.split(/[?#]/)[0] === v.url.split(/[?#]/)[0]);
    if (v.kind !== "product") for (const ev of filtersFromUrl(prev?.url)) await recordEvent(ev);
    const last = kept.at(-1);
    if (last && last.url === v.url) kept[kept.length - 1] = { ...last, ...v };
    else kept.push(v);
    visits = kept.slice(-VISITS_MAX);
    await store.set("visits", visits);
  }

  // ---- what they do on the site by themselves (also with the voice off) ---------------------
  // Filters, sort, options picked, add to bag, compare, save: kept with the history, and sent
  // to the relay's memory now and then, so what they're after is learned even when they
  // never talk to the assistant. (Extension only: the relay takes memory only from it.)
  const EVENTS_MAX = 80;
  const STRONG = new Set(["filter", "option", "add_to_cart", "save", "compare", "sort", "remove"]);
  let events = [];
  let lastEvent = null;
  async function recordEvent(ev) {
    const cur = TalkPage.describe();
    const e = { ...ev, at: Date.now(), url: location.href, page: cur.kind, ...(cur.kind === "product" ? { product: [cur.brand, cur.name].filter(Boolean).join(" "), price: cur.price } : {}) };
    // a label click and the input it toggles are one action
    if (lastEvent && lastEvent.type === e.type && lastEvent.value === e.value && e.at - lastEvent.at < 900) return;
    lastEvent = e;
    // one write, straight away: an add to bag often submits a form and the page goes
    events = [...events.filter((x) => x && Date.now() - x.at < VISITS_DAYS * 864e5), e].slice(-EVENTS_MAX);
    await store.set("events", events);
    syncSoon(e.type === "add_to_cart" ? 5000 : 30000);
  }
  function onInteract(e) {
    try {
      const ev = page.interaction(e, { productPage: visits.at(-1)?.kind === "product" && visits.at(-1)?.url === location.href });
      if (ev) recordEvent(ev);
    } catch {}
  }
  // filters and sort that show in the address (most stores: ?filter.v.price.lte=20,
  // ?ref=brand, ?sortBy=price): whatever's new compared with the last visit to this page
  const FILTER_PARAM = /filter|price|brand|refine|facet|^pl$|^ph$|^ref$|colou?r|size|skin|finish|undertone|shade|concern|formulation|coverage|benefit|sort|order/i;
  function paramName(k) {
    const n = k.replace(/^filters?[.[]/i, "").replace(/^(v|p|m)\./, "").replace(/^(custom|product_type)\./, "").replace(/[.\]_[]+/g, " ").trim();
    return n.replace(/\bgte\b|\bmin\b|^pl$/i, "(min)").replace(/\blte\b|\bmax\b|^ph$/i, "(max)").replace(/^ref$/i, "refinement").trim();
  }
  function filtersFromUrl(prevUrl) {
    const u = new URL(location.href);
    let before = new URLSearchParams();
    try { const p = new URL(prevUrl); if (p.pathname === u.pathname) before = p.searchParams; } catch {}
    const out = [];
    for (const [k, v] of u.searchParams) {
      if (!v || !FILTER_PARAM.test(k) || before.getAll(k).includes(v)) continue;
      out.push({ type: /sort|order/i.test(k) ? "sort" : "filter", group: paramName(k), value: decodeURIComponent(v).replace(/\+/g, " ").slice(0, 60) });
    }
    return out.slice(0, 6);
  }
  // what's new since the last sync goes to memory (at most every 40 s)
  let syncTimer = null;
  function syncSoon(ms) {
    if (!EXT || (syncTimer && ms > 5000)) return;
    clearTimeout(syncTimer);
    syncTimer = setTimeout(syncMemory, ms);
  }
  async function syncMemory() {
    syncTimer = null;
    const since = (await store.get("memorySyncAt")) || 0;
    if (Date.now() - since < 40000) return syncSoon(40000 - (Date.now() - since));
    const newVisits = visits.filter((v) => v.at > since), newEvents = events.filter((x) => x.at > since);
    if (!newEvents.some((x) => STRONG.has(x.type)) && newVisits.length < 4) return;
    await store.set("memorySyncAt", Date.now());
    voice.remember?.({ visits: newVisits, events: newEvents });
  }
  // ---- who's signed in (a name in "Hi, Sam", an email on the account page or typed to sign
  // in): kept with this site's memory for the settings page; the assistant isn't told
  async function noteAccount(found) {
    if (!EXT || !found) return;
    const prev = (await store.get("account")) || {};
    const next = { ...prev, from: { ...(prev.from || {}) } };
    for (const k of ["name", "email"]) {
      if (!found[k] || found[k] === prev[k]) continue;
      // the header's "Hi, Taylor" doesn't replace a full name already found ("Taylor Smith")
      if (k === "name" && prev.name && prev.name.toLowerCase().startsWith(`${found.name.toLowerCase()} `)) continue;
      next[k] = found[k]; next.from[k] = found.from?.[k] || "";
    }
    if (next.name === prev.name && next.email === prev.email) return;
    await store.set("account", next);
    voice.account?.({ name: next.name || "", email: next.email || "", from: next.from });
  }
  const checkAccount = () => { try { noteAccount(TalkPage.account(host)); } catch {} };
  // signing in: the email they typed, when they submit, click Sign in / Continue, or press Enter
  function onSignIn(e) {
    try {
      if (!e.isTrusted) return;
      if (e.type === "keydown" && (e.key !== "Enter" || !(e.target instanceof HTMLInputElement))) return;
      const t = e.composedPath?.()[0] || e.target;
      if (host.contains?.(t)) return;
      const email = TalkPage.loginEmail(t);
      if (email) noteAccount({ email, from: { email: "typed to sign in" } });
    } catch {}
  }
  // the site's own name ("Rare Beauty"), else its domain ("Sephora"): the brand the assistant speaks for
  const siteName = (document.querySelector('meta[property="og:site_name"], meta[name="application-name"]')?.content || "").trim().slice(0, 40)
    || SITE.split(".")[0].replace(/^./, (c) => c.toUpperCase());
  const pageInfo = () => {
    const info = { url: location.href, title: document.title, site: SITE, brand: siteName, visits: visits.slice(-20), events: events.slice(-20) };
    // on a product page, its ingredients (for allergy checks); not kept in the history
    if (visits.at(-1)?.kind === "product" && visits.at(-1)?.url === location.href) { try { info.ingredients = TalkPage.ingredients(host); } catch {} }
    return info;
  };
  const IS_MAC = /mac|iphone|ipad/i.test(navigator.userAgentData?.platform || navigator.platform || "");
  const SC = parseShortcut(CONFIG.shortcut);
  let swallowing = false; // between the shortcut's press and its key's release, the page sees none of that key
  let keyTalk = false;

  function parseShortcut(s) {
    const sc = { code: "Space", alt: false, ctrl: false, shift: false, meta: false };
    for (const raw of String(s).split("+").map((p) => p.trim()).filter(Boolean)) {
      const p = raw.toLowerCase();
      if (p === "alt" || p === "option" || p === "opt") sc.alt = true;
      else if (p === "ctrl" || p === "control") sc.ctrl = true;
      else if (p === "shift") sc.shift = true;
      else if (p === "meta" || p === "cmd" || p === "command") sc.meta = true;
      else if (/^[a-z]$/.test(p)) sc.code = `Key${p.toUpperCase()}`;
      else if (/^[0-9]$/.test(p)) sc.code = `Digit${p}`;
      else sc.code = raw.length > 1 ? raw[0].toUpperCase() + raw.slice(1) : raw;
    }
    return sc;
  }
  function shortcutLabel(html) {
    const keys = [];
    if (SC.ctrl) keys.push(IS_MAC ? "⌃" : "Ctrl");
    if (SC.alt) keys.push(IS_MAC ? "⌥" : "Alt");
    if (SC.shift) keys.push(IS_MAC ? "⇧" : "Shift");
    if (SC.meta) keys.push(IS_MAC ? "⌘" : "Win");
    keys.push(SC.code.replace(/^Key|^Digit/, ""));
    return html ? keys.map((k) => `<kbd>${k}</kbd>`).join("") : keys.join(IS_MAC ? " " : "+");
  }

  // ---- UI ------------------------------------------------------------------------------------
  const ORB = 52; // px
  const host = document.createElement("talk-to-website");
  for (const [k, v] of Object.entries({ all: "initial", position: "fixed", right: "22px", bottom: "22px", "z-index": "2147483647", width: `${ORB}px`, height: `${ORB}px`, display: "block" })) host.style.setProperty(k, v, "important");
  const root = host.attachShadow({ mode: "open" });
  const ICON = {
    chat: '<svg viewBox="0 0 16 16"><path d="M3 3.5h10a1 1 0 011 1v6a1 1 0 01-1 1H7l-3 2.5v-2.5H3a1 1 0 01-1-1v-6a1 1 0 011-1z"/></svg>',
    mic: '<svg viewBox="0 0 16 16"><rect x="5.75" y="1.75" width="4.5" height="8" rx="2.25"/><path d="M3.5 7.5a4.5 4.5 0 009 0M8 12v2.25"/><path class="slash" d="M2.5 2l11 12"/></svg>',
    stop: '<svg viewBox="0 0 16 16"><rect x="4" y="4" width="8" height="8" rx="1.5" class="fill"/></svg>',
    sound: '<svg viewBox="0 0 16 16"><path d="M2.5 6h2.5l3.5-3v10L5 10H2.5z"/><path class="on" d="M11 5.5a3.5 3.5 0 010 5M12.8 3.8a6 6 0 010 8.4"/><path class="off" d="M11 6l4 4M15 6l-4 4"/></svg>',
    clear: '<svg viewBox="0 0 16 16"><path d="M3 4.5h10M6.5 4.5V3h3v1.5M4.5 4.5l.6 8.5h5.8l.6-8.5"/></svg>',
    close: '<svg viewBox="0 0 16 16"><path d="M4 4l8 8M12 4l-8 8"/></svg>',
    flag: '<svg viewBox="0 0 16 16"><path d="M3.5 14V2.5M3.5 3h8l-1.75 2.75L11.5 8.5h-8"/></svg>',
    settings: '<svg viewBox="0 0 16 16"><path d="M2.5 4.5h7M12.5 4.5h1M2.5 11.5h1M6.5 11.5h7"/><circle cx="11" cy="4.5" r="1.5"/><circle cx="5" cy="11.5" r="1.5"/></svg>',
  };
  root.innerHTML = `<style>${css()}</style>
  <div class="hl" aria-hidden="true"></div>
  <div class="subs" aria-hidden="true"><span></span></div>
  <section class="kcard" role="dialog" aria-label="Information" aria-hidden="true">
    <div class="k-src"><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 2.5h7.5L13 5v8.5H3z"/><path d="M10.5 2.5V5H13M5.5 8h5M5.5 10.5h5"/></svg><span class="k-from"></span></div>
    <button class="k-x" type="button" aria-label="Close">${ICON.close}</button>
    <h3 class="k-title"></h3>
    <ul class="k-points"></ul>
    <a class="k-open" target="_blank" rel="noopener">Open page<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M6 3.5h6.5V10M12.5 3.5l-8 8"/></svg></a>
    <div class="k-timer"><i></i></div>
  </section>
  <div class="tw" data-state="idle" part="widget">
    <section class="panel" role="dialog" aria-label="Conversation with ${esc(CONFIG.name)}" aria-hidden="true">
      <header>
        <div class="who"><span class="live-dot"></span><b>${esc(CONFIG.name)}</b><span class="status" aria-live="polite"></span></div>
        <div class="acts">
          <button class="ic ext-only" data-act="settings" title="Edit prompts">${ICON.settings}</button>
          <button class="ic" data-act="voice" title="Mute voice" aria-pressed="false">${ICON.sound}</button>
          <button class="ic" data-act="report" title="Report a problem">${ICON.flag}</button>
          <button class="ic" data-act="forget" title="Start afresh">${ICON.clear}</button>
          <button class="ic" data-act="close" title="Close">${ICON.close}</button>
        </div>
      </header>
      <div class="log" role="log"></div>
      <div class="afresh" hidden><span>Start afresh? I'll forget our conversation, what you've viewed and what I've learned about you on ${esc(SITE)}.</span><span class="afresh-acts"><button class="kb-btn" type="button" data-act="forget-no">Cancel</button><button class="kb-btn danger" type="button" data-act="forget-yes">Start afresh</button></span></div>
      <div class="report" hidden>
        <label for="tw-report"><b>Report a problem</b><span>Say what went wrong. It goes to the team with this conversation's logs.</span></label>
        <input id="tw-reporter" type="text" maxlength="80" autocomplete="name" placeholder="Your name (optional; blank sends it anonymously)">
        <textarea id="tw-report" rows="3" maxlength="4000" placeholder="e.g. I asked for foundations and it kept saying it was looking, but nothing happened."></textarea>
        <span class="report-acts"><span class="report-status" aria-live="polite"></span><button class="kb-btn" type="button" data-act="report-no">Cancel</button><button class="kb-btn primary" type="button" data-act="report-send">Send report</button></span>
      </div>
      <div class="kb" hidden><span class="kb-text"></span><button class="kb-btn" type="button" data-act="learn"></button></div>
      <div class="kb offers" hidden><span class="kb-text"></span><button class="kb-btn" type="button" data-act="scan"></button></div>
      <footer><span>Hold ${shortcutLabel(true)} to talk</span><span class="sep">·</span><span>Click the orb to go hands-free</span></footer>
    </section>
    <div class="dock" role="toolbar" aria-label="${esc(CONFIG.name)} controls">
      <button class="ic" data-act="chat" title="Open chat" aria-pressed="false">${ICON.chat}</button>
      <button class="ic live-only" data-act="mic" title="Mute microphone" aria-pressed="false">${ICON.mic}</button>
      <button class="ic live-only stop" data-act="stop" title="Stop">${ICON.stop}</button>
    </div>
    <div class="toast" aria-live="assertive"></div>
    <div class="cap" aria-hidden="true"></div>
    <button class="orb" type="button" aria-label="Talk to ${esc(CONFIG.name)}"><span class="ring" aria-hidden="true"></span><canvas aria-hidden="true"></canvas></button>
  </div>`;
  const $ = (sel) => root.querySelector(sel);
  const kcard = $(".kcard");
  const tw = $(".tw"), orbEl = $(".orb"), panel = $(".panel"), logEl = $(".log"), toastEl = $(".toast"), statusEl = $(".status"), canvas = $("canvas"), hlEl = $(".hl");
  tw.style.setProperty("--accent", CONFIG.accent);
  tw.classList.toggle("ext", EXT);

  // ---- the voice, and the page agent it drives ---------------------------------------------
  const persist = { // the voice's own state in page mode (the extension keeps it per site in its offscreen document)
    get(k) { try { return JSON.parse(localStorage.getItem(`ttw:${k}`)); } catch { return null; } },
    set(k, v) { try { localStorage.setItem(`ttw:${k}`, JSON.stringify(v)); } catch {} },
  };
  function onVoice(type, data) {
    if (type === "messages") renderLog();
    else if (type === "message") { renderMessage(data.index); cardHeard(data.index); heard(data); }
    else if (type === "notice") toast(data.text, data.kind);
    else if (type === "page") onPageRequest(data);
    else if (type === "card") showCard(data);
    else if (type === "kb") renderKb(data);
    else if (type === "offers") renderOffers(data);
    else if (type === "forgotten") { visits = []; events = []; renderLog(); }
    else if (type === "report.open") reportBox(true);
    else if (type === "reported") onReported(data);
    render();
  }

  // ---- report a problem: the note goes to the relay with this conversation's logs ----------
  const reportEl = $(".report"), reportText = $(".report textarea"), reportStatus = $(".report-status"), reportSend = $('[data-act="report-send"]'), reportName = $("#tw-reporter");
  // typing here is for the box, not the site's own keyboard shortcuts
  for (const el of [reportText, reportName]) for (const ev of ["keydown", "keyup", "keypress"]) el.addEventListener(ev, (e) => { if (e.key !== "Escape") e.stopPropagation(); });
  reportText.addEventListener("keydown", (e) => { if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) { e.preventDefault(); sendReport(); } });
  function reportBox(show) {
    reportEl.hidden = !show;
    if (show) {
      $(".afresh").hidden = true; reportStatus.textContent = ""; reportSend.disabled = false; if (!open) setOpen(true); setTimeout(() => reportText.focus(), 60);
      // the reporter: what they typed last time, else the name they're signed in with here
      if (!reportName.value) Promise.all([store.get("reporter"), store.get("account")]).then(([r, a]) => { if (!reportName.value) reportName.value = r || a?.name || ""; }).catch(() => {});
    }
  }
  let reportTimer;
  function sendReport() {
    const note = reportText.value.trim();
    if (!note) { reportStatus.textContent = "Add a few words first."; reportText.focus(); return; }
    if (reportSend.disabled) return;
    reportSend.disabled = true;
    reportStatus.textContent = "Sending…";
    const msgs = voice.messages().map((m) => ({ role: m.role, text: m.text }));
    const reporter = reportName.value.replace(/\s+/g, " ").trim();
    store.set("reporter", reporter);
    voice.report({ reporter, note, site: SITE, page: pageInfo(), transcript: msgs });
    clearTimeout(reportTimer);
    reportTimer = setTimeout(() => onReported({ ok: false, error: "the relay didn't answer" }), 15000);
  }
  function onReported(r) {
    clearTimeout(reportTimer);
    reportSend.disabled = false;
    if (!r?.ok) { reportStatus.textContent = `Couldn't send it: ${r?.error || "unknown error"}`; return; }
    reportText.value = "";
    reportStatus.textContent = r.queued ? "Saved. It couldn't reach the team just now, so it'll be sent automatically." : r.sessions ? "Sent to the team, with this conversation's logs. Thank you." : "Sent (no conversation logs found for this site).";
    setTimeout(() => { if (!reportText.value) reportBox(false); }, 2600);
  }

  // start afresh on this site: the conversation ends and the transcript, the conversation to
  // resume and the browsing history are forgotten (the extension does it for every tab of the site)
  async function forget() {
    $(".afresh").hidden = true;
    if (EXT) return voice.forget();
    voice.forget();
    await store.set("visits", null);
    onVoice("forgotten");
  }
  const voice = EXT
    ? remoteVoice()
    : TalkVoice.create({ server: CONFIG.server, name: CONFIG.name, persist, onEvent: onVoice, idle: CONFIG.idle });
  const page = TalkPage.create({ ignore: host, highlight });

  async function onPageRequest({ id, op, args }) {
    try {
      const result = op === "snapshot" ? page.snapshot() : op === "peek" ? page.peek() : op === "act" ? await page.act(args?.actions) : null;
      if (!result) throw new Error(`unknown page request ${op}`);
      voice.respond(id, true, result);
    } catch (e) {
      voice.respond(id, false, String(e?.message || e));
    }
  }

  // In the extension, the voice lives in the offscreen document; this proxy talks to it
  // through the background worker and mirrors its state for drawing.
  function remoteVoice() {
    let port = null, gone = false, last = { view: "idle", level: 0 }, st = { session: "off" }, msgs = [];
    const post = (m) => { try { port?.postMessage(m); } catch {} };
    function connect() {
      try { port = chrome.runtime.connect({ name: "ui" }); } catch { gone = true; return; } // the extension was reloaded
      port.onMessage.addListener((m) => {
        if (m.type === "tick") last = m;
        else if (m.type === "status") { st = m.status; onVoice("state"); }
        else if (m.type === "messages") { msgs = m.messages; onVoice("messages"); }
        else if (m.type === "message") { msgs[m.index] = { role: m.role, text: m.text }; onVoice("message", m); }
        else if (m.type === "notice") onVoice("notice", m);
        else if (m.type === "page") onVoice("page", m.req);
        else if (m.type === "card") onVoice("card", m.card);
        else if (m.type === "kb") onVoice("kb", m.status);
        else if (m.type === "offers") onVoice("offers", m.status);
        else if (m.type === "forgotten") { msgs = []; onVoice("forgotten"); }
        else if (m.type === "report.open") onVoice("report.open");
        else if (m.type === "reported") onVoice("reported", m);
      });
      port.onDisconnect.addListener(() => { port = null; if (!gone) setTimeout(connect, 400); });
      post({ type: "hello", site: SITE, page: pageInfo(), name: CONFIG.name });
      post({ type: "kb.status" });
      post({ type: "offers.status" });
    }
    connect();
    const cmd = (name, ...args) => post({ type: "cmd", cmd: name, args });
    return {
      start: (o = {}) => cmd("start", { ...o, page: pageInfo() }),
      stop: () => cmd("stop"),
      pttDown: () => cmd("pttDown", pageInfo()),
      pttUp: () => cmd("pttUp"),
      toggle: () => cmd("toggle", pageInfo()),
      setMicMuted: (m) => cmd("setMicMuted", m),
      setVoiceMuted: (m) => cmd("setVoiceMuted", m),
      clear: () => cmd("clear"),
      forget: () => post({ type: "forget" }),
      report: (r) => post({ type: "report", ...r }),
      learn: () => post({ type: "kb.learn" }),
      scanOffers: () => post({ type: "offers.scan" }),
      remember: (evidence) => post({ type: "memory.learn", ...evidence }),
      account: (a) => post({ type: "memory.account", ...a }),
      settings: () => post({ type: "open.settings" }),
      respond: (id, ok, result) => post({ type: "page.response", id, ok, result }),
      pageReady: (page) => post({ type: "page.update", page }),
      tick: () => last,
      status: () => st,
      messages: () => msgs,
      shouldResume: () => false, // the offscreen document never went away
      reconnect() { if (port) post({ type: "hello", site: SITE, page: pageInfo(), name: CONFIG.name }); else connect(); },
      destroy() { gone = true; try { port?.disconnect(); } catch {} },
    };
  }

  // a soft ring around whatever the agent is about to touch
  let hlTimer;
  function highlight(el) {
    const r = el.getBoundingClientRect();
    if (el.ownerDocument !== document) return;
    Object.assign(hlEl.style, { left: `${r.left - 4}px`, top: `${r.top - 4}px`, width: `${r.width + 8}px`, height: `${r.height + 8}px` });
    hlEl.classList.remove("on");
    void hlEl.offsetWidth;
    hlEl.classList.add("on");
    clearTimeout(hlTimer);
    hlTimer = setTimeout(() => hlEl.classList.remove("on"), 1100);
  }

  // ---- the orb: click = hands-free on/off; press and hold = push-to-talk ---------------------
  let holdTimer = null, pointerTalk = false, pointerDownAt = 0;
  orbEl.addEventListener("pointerdown", (e) => {
    if (e.button !== 0) return;
    e.preventDefault();
    orbEl.setPointerCapture?.(e.pointerId);
    pointerDownAt = now();
    holdTimer = setTimeout(() => { holdTimer = null; pointerTalk = true; voice.pttDown(pageInfo()); }, HOLD_MS);
  });
  const pointerEnd = (click) => () => {
    if (!pointerDownAt) return;
    pointerDownAt = 0;
    if (holdTimer) { clearTimeout(holdTimer); holdTimer = null; if (click) voice.toggle(pageInfo()); }
    if (pointerTalk) { pointerTalk = false; voice.pttUp(); }
  };
  orbEl.addEventListener("pointerup", pointerEnd(true));
  orbEl.addEventListener("pointercancel", pointerEnd(false));
  orbEl.addEventListener("click", (e) => { if (e.detail === 0) voice.toggle(pageInfo()); }); // keyboard activation
  orbEl.addEventListener("contextmenu", (e) => e.preventDefault());

  // ---- keyboard: hold the shortcut anywhere on the page --------------------------------------
  const matches = (e) => e.code === SC.code && e.altKey === SC.alt && e.ctrlKey === SC.ctrl && e.shiftKey === SC.shift && e.metaKey === SC.meta;
  const MOD_KEYS = { Alt: "alt", Control: "ctrl", Shift: "shift", Meta: "meta" };

  function onKeyDown(e) {
    if (e.isComposing || !e.isTrusted) return; // never react to the agent's own synthetic keys
    if (swallowing && e.code === SC.code) { e.preventDefault(); e.stopImmediatePropagation(); return; }
    if (!matches(e)) return;
    e.preventDefault();
    e.stopImmediatePropagation();
    swallowing = true;
    if (!e.repeat && !keyTalk) { keyTalk = true; hideCard(); voice.pttDown(pageInfo()); }
  }
  function onKeyUp(e) {
    if (!e.isTrusted) return;
    const ours = swallowing && e.code === SC.code;
    if (ours) { swallowing = false; e.preventDefault(); e.stopImmediatePropagation(); }
    // letting go of either the key or one of its modifiers ends the turn
    if (keyTalk && (ours || SC[MOD_KEYS[e.key]])) { keyTalk = false; voice.pttUp(); }
  }
  function onBlur() { swallowing = false; if (keyTalk) { keyTalk = false; voice.pttUp(); } }

  // ---- hover (or keyboard focus) shows the dock: chat, mute mic, stop ------------------------
  let dockTimer, hovered = false;
  const setHover = (v) => { hovered = v; tw.classList.toggle("hover", v); };
  tw.addEventListener("pointerenter", (e) => { if (e.pointerType !== "touch") { clearTimeout(dockTimer); dockTimer = setTimeout(() => setHover(true), 60); } });
  tw.addEventListener("pointerleave", () => { clearTimeout(dockTimer); dockTimer = setTimeout(() => setHover(false), 350); });
  tw.addEventListener("focusin", () => { clearTimeout(dockTimer); setHover(true); });
  tw.addEventListener("focusout", (e) => { if (!tw.contains(e.relatedTarget)) setHover(false); });

  let open = false;
  function setOpen(v) {
    open = v;
    tw.classList.toggle("open", v);
    panel.setAttribute("aria-hidden", String(!v));
    if (v) logEl.scrollTop = logEl.scrollHeight;
    render();
  }
  tw.addEventListener("keydown", (e) => { if (e.key === "Escape" && open) { e.stopPropagation(); setOpen(false); orbEl.focus(); } });

  tw.addEventListener("click", (e) => {
    const act = e.target.closest("[data-act]")?.dataset.act;
    if (!act) return;
    const st = voice.status();
    if (act === "chat") setOpen(!open);
    else if (act === "close") setOpen(false);
    else if (act === "mic") voice.setMicMuted(!st.micMuted);
    else if (act === "stop") voice.stop();
    else if (act === "voice") voice.setVoiceMuted(!st.voiceMuted);
    else if (act === "forget" || act === "forget-no") $(".afresh").hidden = act === "forget-no" || !$(".afresh").hidden;
    else if (act === "forget-yes") forget();
    else if (act === "report") reportBox(!reportEl.hidden ? false : true);
    else if (act === "report-no") reportBox(false);
    else if (act === "report-send") sendReport();
    else if (act === "learn") voice.learn?.();
    else if (act === "scan") voice.scanOffers?.();
    else if (act === "settings") voice.settings?.();
    render();
  });

  // ---- transcript (assembled on the server; drawn here by index) -----------------------------
  const bubbles = [];
  function renderMessage(i) {
    const m = voice.messages()[i];
    if (!m) return;
    let el = bubbles[i];
    if (!el) {
      el = bubbles[i] = document.createElement("p");
      logEl.querySelector(".empty")?.remove();
      logEl.append(el);
    }
    el.className = `msg ${m.role}`;
    el.textContent = m.text;
    if (logEl.scrollHeight - logEl.scrollTop - logEl.clientHeight < 80) logEl.scrollTop = logEl.scrollHeight;
  }
  function renderLog() {
    logEl.textContent = "";
    bubbles.length = 0;
    const msgs = voice.messages();
    if (!msgs.length) logEl.innerHTML = `<div class="empty"><b>Ask me anything, or ask me to do something on this site.</b><span>Hold ${shortcutLabel(true)} while you speak, or click the orb for a hands-free conversation.</span></div>`;
    msgs.forEach((_, i) => renderMessage(i));
  }

  // ---- captions: what it says, as text, while it speaks (settings: off | bubble | subtitles) --
  // The words arrive faster than they're spoken, so they're revealed at speaking pace while
  // the voice plays (all at once when the voice is muted), and fade a moment after it stops.
  // Hidden while the chat panel is open (the transcript is right there).
  const CAP_CPS = 15; // characters per second, about the voice's pace
  const cap = { mode: "off", index: -1, text: "", shown: 0, quietAt: 0, on: false };
  const capEl = $(".cap"), subsEl = $(".subs"), subsText = $(".subs span");
  function heard(d) {
    if (d.captions) cap.mode = d.captions;
    const m = voice.messages()[d.index];
    if (!m) return;
    if (m.role === "user") return captionOff();
    if (d.index !== cap.index) Object.assign(cap, { index: d.index, shown: 0 });
    cap.text = m.text || "";
  }
  // like film subtitles: the words in phrases of up to `max` characters (a sentence, or a long
  // one split at a comma or a space), and the phrase being spoken is shown whole
  function phrases(text, max) {
    const out = [];
    for (const sentence of text.trim().split(/(?<=[.!?])\s+/)) {
      let rest = sentence;
      while (rest.length > max) {
        const head = rest.slice(0, max + 1);
        let at = head.lastIndexOf(", ");
        if (at < max * 0.45) at = head.lastIndexOf(" ");
        if (at <= 0) at = max;
        out.push(rest.slice(0, at + (rest[at] === "," ? 1 : 0)).trim());
        rest = rest.slice(at + 1).trim();
      }
      if (rest) out.push(rest);
    }
    return out;
  }
  function captionFrame(dt, view) {
    if (cap.mode === "off" || !cap.text || open) return captionOff();
    const speaking = view === "speaking";
    if (voice.status().voiceMuted) cap.shown = cap.text.length;
    else if (speaking) cap.shown = Math.min(cap.text.length, cap.shown + dt * CAP_CPS);
    if (speaking) cap.quietAt = now();
    if (cap.shown < 1 || now() - cap.quietAt > 1800) return captionOff();
    const sub = cap.mode === "subtitles";
    // the phrase the voice has reached (a phrase still arriving waits until it's complete or long)
    const list = phrases(cap.text, sub ? 84 : 150);
    let at = 0, line = list[0] || "";
    for (const ph of list) { if (at > cap.shown) break; line = ph; at += ph.length + 1; }
    const el = sub ? subsText : capEl;
    if (el.textContent !== line) el.textContent = line;
    (sub ? subsEl : capEl).classList.add("on");
    (sub ? capEl : subsEl).classList.remove("on");
    cap.on = true;
  }
  function captionOff() {
    if (!cap.on) return;
    cap.on = false;
    capEl.classList.remove("on");
    subsEl.classList.remove("on");
  }

  // problems only: a short note beside the orb
  let toastTimer;
  function toast(text, kind = "error") {
    toastEl.textContent = text;
    toastEl.className = `toast on ${kind}`;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toastEl.classList.remove("on"), 4500);
  }

  // Knowledge that didn't come from the page (the site's help and policy pages) shows on a
  // glass card mid-screen while the voice gives the gist. It leaves after a while, waits
  // while hovered, and closes with ✕ or Esc.
  const CARD_MS = 20000;
  let cardTimer, cardLeft = 0, cardStarted = 0, cardShownAt = 0, cardMsgs = 0;
  // card.update: more of a streaming answer for the card already on screen (if it was
  // closed meanwhile, it stays closed). card.placement: where the settings put it.
  // It also goes away when the visitor moves on: clicks the page, or says something.
  function showCard(card) {
    if (!card?.points?.length) return;
    if (card.update && !kcard.classList.contains("on")) return;
    if (card.placement) kcard.dataset.place = card.placement;
    kcard.querySelector(".k-from").textContent = card.kind === "offer" ? `Offer at ${siteName}` : `From ${siteName} help${card.source?.title ? ` · ${card.source.title}` : ""}`;
    kcard.querySelector(".k-title").textContent = card.title || card.source?.title || "";
    const ul = kcard.querySelector(".k-points");
    ul.textContent = "";
    for (const p of card.points.slice(0, 5)) { const li = document.createElement("li"); li.textContent = p; ul.append(li); }
    const open = kcard.querySelector(".k-open");
    open.hidden = !card.source?.url;
    if (card.source?.url) open.href = card.source.url;
    kcard.setAttribute("aria-label", card.title || "Information");
    if (card.update) return;
    kcard.setAttribute("aria-hidden", "false");
    kcard.classList.remove("on");
    void kcard.offsetWidth;
    kcard.classList.add("on");
    cardShownAt = now();
    cardMsgs = voice.messages().length;
    cardLeft = CARD_MS;
    runCardTimer();
  }
  // the visitor said something new (a go-ahead, another question, "no thanks"): they've moved on
  function cardHeard(index) {
    if (!kcard.classList.contains("on") || now() - cardShownAt < 1500 || index < cardMsgs) return;
    if (voice.messages()[index]?.role === "user") hideCard();
  }
  // a click anywhere but the card itself
  const onPageDown = (e) => { if (kcard.classList.contains("on") && !e.composedPath().includes(kcard)) hideCard(); };
  function runCardTimer() {
    clearTimeout(cardTimer);
    cardStarted = now();
    kcard.style.setProperty("--left", `${cardLeft}ms`);
    cardTimer = setTimeout(hideCard, cardLeft);
  }
  function hideCard() {
    clearTimeout(cardTimer);
    kcard.classList.remove("on");
    kcard.setAttribute("aria-hidden", "true");
  }
  kcard.querySelector(".k-x").addEventListener("click", hideCard);
  kcard.addEventListener("pointerenter", () => { if (!kcard.classList.contains("on")) return; clearTimeout(cardTimer); cardLeft = Math.max(3000, cardLeft - (now() - cardStarted)); kcard.classList.add("hold"); });
  kcard.addEventListener("pointerleave", () => { if (!kcard.classList.contains("on")) return; kcard.classList.remove("hold"); runCardTimer(); });
  const onCardKey = (e) => { if (e.key === "Escape" && kcard.classList.contains("on")) hideCard(); };

  // the site's knowledge base (extension only): what it knows, and a button to (re)learn it
  // the offers repository for this site (sales): what was found, and Scan
  function renderOffers(st) {
    const box = $(".offers");
    if (!EXT || !st) return;
    box.hidden = false;
    const text = box.querySelector(".kb-text"), btn = box.querySelector(".kb-btn");
    box.classList.toggle("busy", !!st.scanning);
    btn.hidden = !!st.scanning || !!st.offline;
    btn.textContent = st.updatedAt ? "Rescan" : "Scan";
    if (st.scanning) text.textContent = st.saving ? `Reading offers on ${st.found} pages…` : `Scanning offers… ${st.found} pages, ${st.checked} checked`;
    else if (st.offline) text.textContent = "Offers unavailable (is the relay running?)";
    else if (st.updatedAt) {
      const days = Math.floor((Date.now() - st.updatedAt) / 864e5);
      text.textContent = `${st.offers} offers · ${st.drops} price drops · ${days ? `${days}d ago` : "today"}${st.sales && !st.sales.enabled ? " · sales off" : ""}`;
    } else text.textContent = `Scan ${siteName}'s offers for sales tips`;
  }

  function renderKb(st) {
    const box = $(".kb:not(.offers)");
    if (!EXT || !st) return;
    box.hidden = false;
    const text = box.querySelector(".kb-text"), btn = box.querySelector(".kb-btn");
    box.classList.toggle("busy", !!st.learning);
    if (st.learning) {
      text.textContent = st.saving ? `Indexing ${st.found} help pages…` : `Learning help pages… ${st.found} found, ${st.checked} checked`;
      btn.hidden = true;
    } else if (st.offline) {
      text.textContent = "Knowledge base unavailable (is the relay running?)";
      btn.hidden = true;
    } else if (st.answers === "netomi") {
      text.textContent = "Answers from Netomi";
      btn.hidden = true;
    } else if (st.pages) {
      const days = Math.floor((Date.now() - st.updatedAt) / 864e5);
      text.textContent = `${st.answers === "both" ? "Netomi + " : "Knows "}${st.pages} help pages · ${days ? `${days}d ago` : "today"}`;
      btn.hidden = false;
      btn.textContent = "Refresh";
    } else {
      text.textContent = st.answers === "both" ? `Netomi · learn ${siteName}'s help pages for faster answers` : `Learn ${siteName}'s help pages for instant answers`;
      btn.hidden = false;
      btn.textContent = "Learn";
    }
  }

  // ---- state → view ---------------------------------------------------------------------
  const STATUS = {
    idle: "", connecting: "Connecting…", ready: "Ready", listening: "Listening…", thinking: "Thinking…",
    working: "Working on it…", speaking: "Speaking", muted: "Mic muted", error: "",
  };
  let preview = null; // { state, level }: shows a state with no session (screenshots, design QA)
  let shown = "idle";
  function render() {
    const st = voice.status();
    shown = preview ? preview.state : voice.tick().view;
    tw.dataset.state = shown;
    tw.classList.toggle("active", st.session !== "off" || (!!preview && preview.state !== "idle"));
    statusEl.textContent = (st.session === "off" && st.flash) || (shown === "working" && st.working) || STATUS[shown] || "";
    orbEl.setAttribute("aria-label", st.handsFree ? `End conversation with ${CONFIG.name}` : `Talk to ${CONFIG.name} (hold ${shortcutLabel()} or press and hold)`);
    orbEl.setAttribute("aria-pressed", String(!!st.handsFree));
    const mic = $('[data-act="mic"]');
    mic.setAttribute("aria-pressed", String(!!st.micMuted));
    mic.title = st.micMuted ? "Unmute microphone" : "Mute microphone";
    $('[data-act="chat"]').setAttribute("aria-pressed", String(open));
    $('[data-act="chat"]').title = open ? "Close chat" : "Open chat";
    $('[data-act="voice"]').setAttribute("aria-pressed", String(!!st.voiceMuted));
    $('[data-act="voice"]').title = st.voiceMuted ? "Unmute voice" : "Mute voice";
    tw.classList.toggle("mic-muted", !!st.micMuted);
    tw.classList.toggle("voice-muted", !!st.voiceMuted);
  }

  // ---- the orb: a WebGL fluid sphere driven by the real audio ------------------------------------
  // A disc shaded as a glass sphere, filled with domain-warped simplex noise. Loudness
  // swells it and ripples its rim; how fast the level moves (speech rhythm) speeds the
  // flow; each state has its own palette, blended smoothly. Mic while listening, the
  // agent's voice while speaking.
  const FRAG = `precision highp float;
varying vec2 vUv;
uniform float uTime, uLevel, uFlux, uPx, uRadius, uSat, uGlow, uBright;
uniform vec3 uA, uB, uC;
vec3 mod289(vec3 x){return x-floor(x*(1./289.))*289.;}
vec4 mod289(vec4 x){return x-floor(x*(1./289.))*289.;}
vec4 permute(vec4 x){return mod289(((x*34.)+1.)*x);}
vec4 tis(vec4 r){return 1.79284291400159-.85373472095314*r;}
float snoise(vec3 v){
  const vec2 C=vec2(1./6.,1./3.);const vec4 D=vec4(0.,.5,1.,2.);
  vec3 i=floor(v+dot(v,C.yyy));vec3 x0=v-i+dot(i,C.xxx);
  vec3 g=step(x0.yzx,x0.xyz);vec3 l=1.-g;vec3 i1=min(g.xyz,l.zxy);vec3 i2=max(g.xyz,l.zxy);
  vec3 x1=x0-i1+C.xxx;vec3 x2=x0-i2+C.yyy;vec3 x3=x0-D.yyy;
  i=mod289(i);
  vec4 p=permute(permute(permute(i.z+vec4(0.,i1.z,i2.z,1.))+i.y+vec4(0.,i1.y,i2.y,1.))+i.x+vec4(0.,i1.x,i2.x,1.));
  vec3 ns=.142857142857*D.wyz-D.xzx;
  vec4 j=p-49.*floor(p*ns.z*ns.z);vec4 x_=floor(j*ns.z);vec4 y_=floor(j-7.*x_);
  vec4 x=x_*ns.x+ns.yyyy;vec4 y=y_*ns.x+ns.yyyy;vec4 h=1.-abs(x)-abs(y);
  vec4 b0=vec4(x.xy,y.xy);vec4 b1=vec4(x.zw,y.zw);
  vec4 s0=floor(b0)*2.+1.;vec4 s1=floor(b1)*2.+1.;vec4 sh=-step(h,vec4(0.));
  vec4 a0=b0.xzyw+s0.xzyw*sh.xxyy;vec4 a1=b1.xzyw+s1.xzyw*sh.zzww;
  vec3 p0=vec3(a0.xy,h.x);vec3 p1=vec3(a0.zw,h.y);vec3 p2=vec3(a1.xy,h.z);vec3 p3=vec3(a1.zw,h.w);
  vec4 n=tis(vec4(dot(p0,p0),dot(p1,p1),dot(p2,p2),dot(p3,p3)));p0*=n.x;p1*=n.y;p2*=n.z;p3*=n.w;
  vec4 m=max(.6-vec4(dot(x0,x0),dot(x1,x1),dot(x2,x2),dot(x3,x3)),0.);m=m*m;
  return 42.*dot(m*m,vec4(dot(p0,x0),dot(p1,x1),dot(p2,x2),dot(p3,x3)));
}
void main(){
  vec2 p=vUv;
  float r=length(p);
  vec2 dir=p/max(r,1e-4);
  float t=uTime;
  // the rim: a soft, slow breathing at rest; broad swells (not spikes) with loudness
  float wob=snoise(vec3(dir*.8,t*.4))*(.012+uLevel*.04)+snoise(vec3(dir*1.6,t*.9+7.))*(uLevel*.018);
  float R=uRadius*(1.+uLevel*.12+wob);
  float d=r-R;
  float inside=1.-smoothstep(-uPx,uPx,d);
  // a glass sphere: depth from the disc, the liquid inside refracted toward the rim
  vec2 q=p/R;
  float z=sqrt(max(0.,1.-dot(q,q)));
  vec2 s=q*(.95-.3*z);
  vec2 w=vec2(snoise(vec3(s*.7,t*.18)),snoise(vec3(s*.7+4.3,t*.18)));
  float n1=snoise(vec3(s*.85+w*(.45+uFlux*.6),t*.24));
  float n2=snoise(vec3(s*1.1-w*.35+vec2(1.7,.3),t*.31+4.));
  vec3 col=mix(uA,uB,smoothstep(-.85,.8,n1));
  col=mix(col,uC,smoothstep(.05,.95,n2)*.7);
  vec3 nrm=normalize(vec3(q,z+1e-4));
  float light=clamp(dot(nrm,normalize(vec3(-.4,.55,.8))),0.,1.);
  col*=.82+.3*light;
  col+=uC*smoothstep(.9,0.,length(q-vec2(.12,-.42)))*.22;      // light pooling in the bottom of the glass
  col=mix(col,uA*.78,pow(1.-z,4.)*.6);                           // deeper edge: reads on white pages
  float hl=smoothstep(.42,0.,length((q-vec2(-.34,.4))*vec2(1.,1.35)));
  col+=hl*hl*.35;                                               // highlight
  col+=uC*uLevel*.3*smoothstep(1.,0.,length(q));              // core brightens when loud
  col=min(col*uBright,vec3(1.));
  float gray=dot(col,vec3(.299,.587,.114));
  col=mix(vec3(gray),col,uSat);
  float out_=1.-inside;
  float glow=exp(-max(d,0.)/(.045+uLevel*.12))*uGlow*out_*.6;
  vec3 gc=mix(uB,uC,.5)*mix(1.,gray*2.,1.-uSat);
  // a soft contact shadow under the orb (alpha only), so it sits on light pages
  float shadow=exp(-max(length(p-vec2(0.,-.07))-R*.9,0.)/.09)*.3*out_;
  float alpha=inside+glow+shadow*(1.-glow);
  gl_FragColor=vec4(col*inside+gc*glow,clamp(alpha,0.,1.));
}`;
  const VERT = "attribute vec2 a;varying vec2 vUv;void main(){vUv=a;gl_Position=vec4(a,0.,1.);}";
  const hex = (h) => [1, 3, 5].map((i) => parseInt(h.slice(i, i + 2), 16) / 255);
  // per state: palette (deep, body, highlight), saturation, glow, brightness, flow speed
  const LOOK = {
    idle: { c: ["#9aa3c9", "#c3c9e6", "#e3e8f7"], sat: 0.45, glow: 0, bright: 1, speed: 0.12 }, // stopped: pale, still, no glow
    ready: { c: ["#6b86f5", "#9fb6ff", "#b5f4ff"], sat: 1, glow: 0.4, bright: 1.04, speed: 0.5 },
    connecting: { c: ["#5c86f7", "#93b8ff", "#b0f2ff"], sat: 1, glow: 0.45, bright: 1.04, speed: 0.9 },
    listening: { c: ["#2f7bff", "#6fbaff", "#c6fbff"], sat: 1, glow: 0.9, bright: 1.1, speed: 0.85 },
    thinking: { c: ["#7a6cff", "#a99bff", "#8fe6ff"], sat: 1, glow: 0.55, bright: 1.05, speed: 1.9 },
    speaking: { c: ["#9a6dff", "#c9a4ff", "#ffb3e8"], sat: 1, glow: 0.7, bright: 1.08, speed: 0.75 },
    muted: { c: ["#9a9aa6", "#c4c4cc", "#e6e6ec"], sat: 0.1, glow: 0.08, bright: 1, speed: 0.2 },
    error: { c: ["#e2566a", "#ff8f9c", "#ffc9bd"], sat: 1, glow: 0.5, bright: 1.04, speed: 0.6 },
  };
  for (const k in LOOK) LOOK[k].c = LOOK[k].c.map(hex);

  const REDUCED = matchMedia("(prefers-reduced-motion: reduce)").matches;
  const orb = (() => {
    const px = Math.min(3, window.devicePixelRatio || 1);
    canvas.width = canvas.height = Math.round(ORB * 2 * px);
    const gl = canvas.getContext("webgl", { premultipliedAlpha: true, alpha: true, antialias: false, powerPreference: "low-power" });
    if (!gl) { tw.classList.add("nogl"); return null; }
    const sh = (type, src) => { const s = gl.createShader(type); gl.shaderSource(s, src); gl.compileShader(s); return s; };
    const prog = gl.createProgram();
    gl.attachShader(prog, sh(gl.VERTEX_SHADER, VERT));
    gl.attachShader(prog, sh(gl.FRAGMENT_SHADER, FRAG));
    gl.linkProgram(prog);
    if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) { tw.classList.add("nogl"); return null; }
    gl.useProgram(prog);
    gl.bindBuffer(gl.ARRAY_BUFFER, gl.createBuffer());
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, -1, 1, 1, 1]), gl.STATIC_DRAW);
    const a = gl.getAttribLocation(prog, "a");
    gl.enableVertexAttribArray(a);
    gl.vertexAttribPointer(a, 2, gl.FLOAT, false, 0, 0);
    const u = {};
    for (const n of ["uTime", "uLevel", "uFlux", "uPx", "uRadius", "uSat", "uGlow", "uBright", "uA", "uB", "uC"]) u[n] = gl.getUniformLocation(prog, n);
    gl.viewport(0, 0, canvas.width, canvas.height);
    gl.uniform1f(u.uPx, 2.4 / canvas.width);
    gl.uniform1f(u.uRadius, 0.46);
    canvas.addEventListener("webglcontextlost", (e) => { e.preventDefault(); tw.classList.add("nogl"); });
    return { gl, u };
  })();

  LOOK.working = { c: ["#4f7cff", "#8fb0ff", "#9cf5e6"].map(hex), sat: 1, glow: 0.5, bright: 1.05, speed: 1.4 };

  // the look eases toward the state's; the level comes from the audio
  const cur = { ...LOOK.idle, c: LOOK.idle.c.map((c) => c.slice()) };
  let level = 0, flux = 0, prevRaw = 0, clock = Math.random() * 100, lastFrame = now(), lastUi = 0;
  function frame() {
    if (destroyed) return;
    requestAnimationFrame(frame);
    const t = now();
    const dt = Math.min(0.1, (t - lastFrame) / 1000);
    const live = voice.status().session !== "off";
    // idle and unattended: 20 fps is plenty for a slow swirl
    if (!live && !hovered && !preview && dt < 0.05) return;
    lastFrame = t;
    const tk = voice.tick();
    if (t - lastUi > 150) { lastUi = t; render(); }
    else shown = preview ? preview.state : tk.view;
    captionFrame(dt, preview ? preview.state : tk.view);
    let raw = preview?.level != null ? preview.level * (0.75 + 0.25 * Math.sin(t / 90) * Math.sin(t / 233)) : tk.level;
    if (shown === "thinking" || shown === "working") raw = 0.12 + 0.08 * Math.sin(t / 260);
    if (shown === "connecting") raw = 0.1 + 0.06 * Math.sin(t / 200);
    level += (raw - level) * (raw > level ? 0.35 : 0.08);
    flux += (Math.min(1, Math.abs(raw - prevRaw) * 6) - flux) * 0.08;
    prevRaw = raw;
    const look = LOOK[shown] || LOOK.idle;
    const k = 1 - Math.exp(-dt * 5);
    for (let i = 0; i < 3; i++) for (let j = 0; j < 3; j++) cur.c[i][j] += (look.c[i][j] - cur.c[i][j]) * k;
    for (const f of ["sat", "glow", "bright", "speed"]) cur[f] += (look[f] - cur[f]) * k;
    clock += dt * (REDUCED ? 0.08 : cur.speed + flux * 2.2);
    const lv = REDUCED ? level * 0.3 : level;
    tw.style.setProperty("--lvl", lv.toFixed(3));
    if (!orb) return;
    const { gl, u } = orb;
    gl.uniform1f(u.uTime, clock);
    gl.uniform1f(u.uLevel, lv);
    gl.uniform1f(u.uFlux, flux);
    gl.uniform1f(u.uSat, cur.sat);
    gl.uniform1f(u.uGlow, cur.glow);
    gl.uniform1f(u.uBright, cur.bright);
    gl.uniform3fv(u.uA, cur.c[0]);
    gl.uniform3fv(u.uB, cur.c[1]);
    gl.uniform3fv(u.uC, cur.c[2]);
    gl.clearColor(0, 0, 0, 0);
    gl.clear(gl.COLOR_BUFFER_BIT);
    gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
  }
  // background tabs get no animation frames; keep the panel's status honest anyway
  const bgTimer = setInterval(() => { if (document.hidden) render(); }, 1000);

  // ---- mount -----------------------------------------------------------------------------
  let destroyed = false;
  const listeners = [
    [window, "keydown", onKeyDown, true],
    [window, "keyup", onKeyUp, true],
    [window, "blur", onBlur, false],
    [window, "keydown", onCardKey, false],
    [window, "pointerdown", onPageDown, true],
    [document, "click", onInteract, true],
    [document, "change", onInteract, true],
    [document, "submit", onSignIn, true],
    [document, "click", onSignIn, true],
    [document, "keydown", onSignIn, true],
    [document, "visibilitychange", () => document.hidden && onBlur(), false],
    // page mode: the connection drops with the page, the server keeps the conversation,
    // and the next page (with the widget on it) picks it up
    [window, "pagehide", () => { if (!EXT) voice.end({ keepConversation: true }); }, false],
    // back/forward cache: this very page is shown again, frozen state and all; announce it
    // as the current page again (the agent may have pressed back) and pick the voice up
    [window, "pageshow", (e) => {
      if (!e.persisted) return;
      lastUrl = location.href;
      if (EXT) voice.reconnect();
      else if (voice.shouldResume()) voice.start({ handsFree: voice.resumeHandsFree(), page: pageInfo() });
      recordVisit().then(() => voice.status().session !== "off" && voice.pageReady(pageInfo()));
    }, false],
  ];
  for (const [t, ev, fn, cap] of listeners) t.addEventListener(ev, fn, cap);
  (document.body || document.documentElement).appendChild(host);
  renderLog();
  render();
  requestAnimationFrame(frame);
  // this page goes into the history once it has settled (titles and product data often
  // arrive after the DOM); pages that change without loading (SPAs) are caught by the URL
  let lastUrl = location.href;
  const pageChanged = () => recordVisit().then(() => {
    syncSoon(30000);
    if (voice.status().session !== "off") voice.pageReady(pageInfo());
    checkAccount(); setTimeout(checkAccount, 3000); // headers often fill in the name late
  });
  (async () => {
    visits = ((await store.get("visits")) || []).slice(-VISITS_MAX);
    events = ((await store.get("events")) || []).slice(-EVENTS_MAX);
    await new Promise((r) => setTimeout(r, 900));
    await pageChanged();
    if (voice.shouldResume()) voice.start({ handsFree: voice.resumeHandsFree(), page: pageInfo() });
  })();
  const urlTimer = setInterval(() => {
    if (location.href === lastUrl) return;
    lastUrl = location.href;
    setTimeout(pageChanged, 1200);
  }, 1000);

  window.__talkWidget = {
    config: CONFIG,
    show() { host.style.setProperty("display", "block", "important"); },
    start: () => voice.start({ handsFree: true, page: pageInfo() }),
    stop: () => voice.stop(),
    toggle: () => voice.toggle(pageInfo()),
    muteMic: (m) => voice.setMicMuted(m),
    openChat: setOpen,
    forget, // start afresh on this site
    preview(state, lvl) { preview = state ? { state, level: lvl } : null; render(); },
    showCard, // e.g. __talkWidget.showCard({ title, points: [...], source: { title, url } })
    page, // the page agent, for debugging: __talkWidget.page.snapshot().text
    visit: () => TalkPage.describe(), // what the history records for this page (product, price, was, category…)
    outLevel: () => voice.outLevel?.() ?? 0, // the agent's voice level as played (tests)
    get state() { const st = voice.status(); return { view: voice.tick().view, session: st.session, handsFree: st.handsFree, ptt: st.ptt, micMuted: st.micMuted, working: st.working, messages: voice.messages().map(({ role, text }) => ({ role, text })) }; },
    destroy() {
      destroyed = true;
      voice.destroy();
      clearInterval(bgTimer);
      clearInterval(urlTimer);
      for (const [t, ev, fn, cap] of listeners) t.removeEventListener(ev, fn, cap);
      host.remove();
      delete window.__talkWidget;
    },
  };

  function esc(s) { return String(s).replace(/[&<>"']/g, (c) => `&#${c.charCodeAt(0)};`); }

  function css() {
    return `
:host { all: initial; }
* { box-sizing: border-box; }
.tw {
  --accent: #6B6D7C; --bg: rgba(28, 31, 42, 0.95); --line: rgba(255, 255, 255, 0.09);
  --fg: #f5f5f7; --muted: #a0a0ab; --size: ${ORB}px;
  position: relative; width: var(--size); height: var(--size);
  font: 13px/1.45 ui-sans-serif, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
  color: var(--fg); -webkit-font-smoothing: antialiased;
}

/* ---- the orb ---- */
.orb {
  all: unset; position: absolute; inset: 0; border-radius: 50%; cursor: pointer;
  touch-action: none; -webkit-tap-highlight-color: transparent; user-select: none;
  transition: transform .35s cubic-bezier(.2,.8,.2,1);
}
.orb:hover { transform: scale(1.06); }
/* stopped: a little smaller, asleep */
[data-state="idle"] .orb, [data-state="error"] .orb { transform: scale(.84); }
[data-state="idle"] .orb:hover { transform: scale(.9); }
/* listening: a soft glow that ripples out from behind the orb (no outline), so an open
   mic is clear without pulling the eye */
.ring { position: absolute; inset: 0; border-radius: 50%; pointer-events: none; z-index: -1; }
.ring::after { content: ""; position: absolute; inset: 0; border-radius: 50%; opacity: 0;
  background: radial-gradient(circle, rgba(79, 155, 255, .45) 45%, rgba(79, 155, 255, 0) 70%); }
[data-state="listening"] .ring::after { animation: tw-ripple 1.8s ease-out infinite; }
@keyframes tw-ripple { 0% { transform: scale(.95); opacity: .7; } 100% { transform: scale(1.55); opacity: 0; } }
.orb:active { transform: scale(.94); }
.orb:focus-visible { outline: 2px solid var(--accent); outline-offset: 4px; }
canvas { position: absolute; left: 50%; top: 50%; width: calc(var(--size) * 2); height: calc(var(--size) * 2); transform: translate(-50%, -50%); pointer-events: none; }
/* no WebGL: a CSS gradient orb that still breathes with the level */
.nogl canvas { display: none; }
.nogl .orb { box-shadow: 0 10px 28px rgba(8,10,30,.28); background: radial-gradient(circle at 32% 28%, #e4fbff 0%, #8fc4ff 40%, #5a74e8 100%); }
.nogl[data-state="speaking"] .orb { background: radial-gradient(circle at 32% 28%, #ffd3f1 0%, #c9a4ff 40%, #8a5cf0 100%); }
.nogl[data-state="muted"] .orb, .nogl[data-state="idle"] .orb { filter: saturate(.3) brightness(.8); }
.nogl[data-state="error"] .orb { background: radial-gradient(circle at 32% 28%, #ff9b86, #d4334b 45%, #3a0b12); }

/* ---- hover dock: chat, mute mic, stop ---- */
.dock {
  position: absolute; right: calc(var(--size) + 10px); top: 50%; display: flex; gap: 2px; padding: 4px;
  border-radius: 999px; background: var(--bg); border: 1px solid var(--line);
  box-shadow: 0 10px 30px rgba(0,0,0,.2); backdrop-filter: blur(16px) saturate(1.4); -webkit-backdrop-filter: blur(16px) saturate(1.4);
  opacity: 0; visibility: hidden; transform: translate(8px, -50%) scale(.96); transform-origin: right center;
  transition: opacity .18s ease, transform .25s cubic-bezier(.2,.8,.2,1), visibility 0s linear .25s;
}
.hover .dock { opacity: 1; visibility: visible; transform: translate(0, -50%); transition: opacity .18s ease, transform .25s cubic-bezier(.2,.8,.2,1), visibility 0s; }
.dock::after { content: ""; position: absolute; left: 100%; top: 0; bottom: 0; width: 12px; } /* hover bridge to the orb */
.dock .ic { width: 32px; height: 32px; border-radius: 999px; }
.live-only { display: none !important; }
.active .live-only { display: grid !important; }
.dock .stop:hover { color: #ff8a8a; background: rgba(255, 90, 90, .12); }
.mic-muted .dock [data-act="mic"] { color: #ffb86b; background: rgba(255, 184, 107, .12); }
.ic .slash { display: none; }
.mic-muted .ic .slash { display: inline; }

.toast {
  position: absolute; right: calc(var(--size) + 10px); top: 50%; transform: translate(6px, -50%);
  width: max-content; max-width: min(280px, calc(100vw - 100px)); padding: 8px 12px; border-radius: 12px;
  background: var(--bg); color: var(--fg); border: 1px solid var(--line); font-size: 12.5px; line-height: 1.4;
  box-shadow: 0 8px 24px rgba(0,0,0,.18); backdrop-filter: blur(14px); -webkit-backdrop-filter: blur(14px);
  opacity: 0; pointer-events: none; transition: opacity .25s ease, transform .25s ease;
}
.toast.on { opacity: 1; transform: translate(0, -50%); }
.hover .toast { opacity: 0; }

/* captions, as a bubble beside the orb */
.cap {
  position: absolute; right: calc(var(--size) + 12px); bottom: 4px; width: max-content; max-width: min(300px, calc(100vw - 100px));
  padding: 9px 13px; border-radius: 14px 14px 4px 14px; background: rgba(28,31,42,.92); color: #F3F5F6;
  font-size: 13.5px; line-height: 1.45; box-shadow: 0 8px 24px rgba(0,0,0,.2); backdrop-filter: blur(14px); -webkit-backdrop-filter: blur(14px);
  opacity: 0; transform: translateY(4px); pointer-events: none; transition: opacity .25s ease, transform .25s ease;
}
.cap.on { opacity: 1; transform: none; }
.open .cap, .hover .cap { opacity: 0; }

/* captions, as subtitles: bottom center of the screen, like a film */
.subs {
  position: fixed; left: 50%; bottom: 7vh; z-index: 1; width: min(820px, calc(100vw - 140px)); transform: translate(-50%, 6px);
  text-align: center; pointer-events: none; opacity: 0; transition: opacity .2s ease, transform .2s ease;
  font: 600 clamp(17px, 2.1vw, 23px)/1.45 ui-sans-serif, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
}
.subs span {
  display: inline; padding: 3px 10px; border-radius: 6px; color: #fff;
  /* translucent: the page shows through, blurred, and the shadow keeps the words legible on light pages */
  background: rgba(12,13,18,.42); -webkit-backdrop-filter: blur(8px) saturate(1.2); backdrop-filter: blur(8px) saturate(1.2);
  -webkit-box-decoration-break: clone; box-decoration-break: clone; text-shadow: 0 1px 3px rgba(0,0,0,.75), 0 0 1px rgba(0,0,0,.6);
}
.subs.on { opacity: 1; transform: translate(-50%, 0); }
@media (max-width: 640px) { .subs { width: calc(100vw - 32px); bottom: 96px; } }
.toast.error { color: #ffd2d2; }
.toast.info { color: #d8d8e0; }

/* ---- the chat panel ---- */
.panel {
  position: absolute; right: 0; bottom: calc(var(--size) + 14px);
  width: min(360px, calc(100vw - 32px)); max-height: min(460px, calc(100vh - 110px));
  display: flex; flex-direction: column; border-radius: 18px; overflow: hidden;
  background: var(--bg); border: 1px solid var(--line);
  box-shadow: 0 24px 60px rgba(0,0,0,.28), 0 4px 14px rgba(0,0,0,.18);
  backdrop-filter: blur(18px) saturate(1.4); -webkit-backdrop-filter: blur(18px) saturate(1.4);
  opacity: 0; visibility: hidden; transform: translateY(10px) scale(.97); transform-origin: bottom right;
  transition: opacity .2s ease, transform .3s cubic-bezier(.2,.8,.2,1), visibility 0s linear .3s;
}
.open .panel { opacity: 1; visibility: visible; transform: none; transition: opacity .2s ease, transform .3s cubic-bezier(.2,.8,.2,1), visibility 0s; }
header { display: flex; align-items: center; justify-content: space-between; gap: 8px; padding: 11px 10px 10px 14px; border-bottom: 1px solid var(--line); }
.who { display: flex; align-items: baseline; gap: 8px; min-width: 0; }
.who b { font-weight: 600; font-size: 13.5px; letter-spacing: -.01em; }
.status { color: var(--muted); font-size: 12px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.live-dot { width: 7px; height: 7px; border-radius: 50%; background: #55555f; align-self: center; flex: none; transition: background .2s ease; }
.active .live-dot { background: #3ddc84; box-shadow: 0 0 0 3px rgba(61,220,132,.18); }
.mic-muted .live-dot { background: #ffb86b; box-shadow: 0 0 0 3px rgba(255,184,107,.18); }
.acts { display: flex; gap: 2px; flex: none; }
.ic { all: unset; width: 28px; height: 28px; display: grid; place-items: center; border-radius: 8px; color: var(--muted); cursor: pointer; transition: background .15s ease, color .15s ease; }
.ic:hover { background: rgba(255,255,255,.08); color: var(--fg); }
.ic:focus-visible { outline: 2px solid var(--accent); outline-offset: -2px; }
.ic svg { width: 15px; height: 15px; fill: none; stroke: currentColor; stroke-width: 1.4; stroke-linecap: round; stroke-linejoin: round; }
.ic svg .fill { fill: currentColor; stroke: none; }
.ic[aria-pressed="true"] { color: var(--fg); background: rgba(255,255,255,.08); }
.ic .off { display: none; }
.voice-muted .ic .on { display: none; }
.voice-muted .ic .off { display: inline; }
.log { flex: 1; overflow-y: auto; padding: 12px 14px; display: flex; flex-direction: column; gap: 8px; overscroll-behavior: contain; scrollbar-width: thin; scrollbar-color: rgba(255,255,255,.15) transparent; min-height: 120px; }
.msg { margin: 0; max-width: 85%; padding: 7px 11px; border-radius: 14px; white-space: pre-wrap; word-wrap: break-word; }
.msg.agent { align-self: flex-start; background: rgba(255,255,255,.06); border-bottom-left-radius: 5px; }
.msg.user { align-self: flex-end; background: #4C4F62; color: #fff; border-bottom-right-radius: 5px; }
.empty { margin: auto 0; display: flex; flex-direction: column; gap: 4px; color: var(--muted); padding: 8px 2px; }
.empty b { color: var(--fg); font-weight: 600; }
.kb.offers { border-top: 0; padding-top: 0; }
.kb { display: flex; align-items: center; justify-content: space-between; gap: 8px; padding: 8px 14px; border-top: 1px solid var(--line); font-size: 11.5px; color: var(--muted); }
.kb[hidden] { display: none; }
.ext-only { display: none; }
.ext .ext-only { display: grid; }
.kb.busy .kb-text { background: linear-gradient(90deg, var(--muted) 30%, var(--fg) 50%, var(--muted) 70%); background-size: 200% 100%; -webkit-background-clip: text; background-clip: text; color: transparent; animation: tw-shimmer 1.6s linear infinite; }
@keyframes tw-shimmer { to { background-position: -200% 0; } }
.kb-btn { all: unset; cursor: pointer; font-weight: 600; color: var(--fg); padding: 3px 9px; border-radius: 7px; background: rgba(255,255,255,.08); border: 1px solid rgba(255,255,255,.1); }
.kb-btn:hover { background: rgba(255,255,255,.14); }
.kb-btn:focus-visible { outline: 2px solid var(--accent); outline-offset: 1px; }
.kb-btn[hidden] { display: none; }
.afresh { display: flex; flex-direction: column; gap: 8px; padding: 10px 14px; border-top: 1px solid var(--line); font-size: 12px; color: var(--fg); }
.afresh[hidden] { display: none; }
.report { display: flex; flex-direction: column; gap: 8px; padding: 10px 14px; border-top: 1px solid var(--line); font-size: 12px; color: var(--fg); }
.report[hidden] { display: none; }
.report label { display: flex; flex-direction: column; gap: 2px; }
.report label span { color: var(--muted); }
.report input#tw-reporter { all: unset; box-sizing: border-box; width: 100%; padding: 6px 9px; border-radius: 8px; font: 12.5px/1.45 ui-sans-serif, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; color: var(--fg); background: rgba(255,255,255,.06); border: 1px solid rgba(255,255,255,.12); }
.report input#tw-reporter::placeholder { color: var(--muted); }
.report textarea { all: unset; box-sizing: border-box; width: 100%; min-height: 64px; max-height: 160px; overflow: auto; white-space: pre-wrap; padding: 7px 9px; border-radius: 8px; font: 12.5px/1.45 ui-sans-serif, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; color: var(--fg); background: rgba(255,255,255,.06); border: 1px solid rgba(255,255,255,.12); }
.report textarea:focus { border-color: var(--accent); }
.report textarea::placeholder { color: var(--muted); opacity: .8; }
.report-acts { display: flex; align-items: center; justify-content: flex-end; gap: 6px; }
.report-status { margin-right: auto; color: var(--muted); }
.kb-btn.primary { background: rgba(255,255,255,.16); border-color: rgba(255,255,255,.22); }
.kb-btn[disabled] { opacity: .5; cursor: default; }
.afresh-acts { display: flex; justify-content: flex-end; gap: 6px; }
.kb-btn.danger { background: rgba(229,72,77,.22); border-color: rgba(229,72,77,.4); }
.kb-btn.danger:hover { background: rgba(229,72,77,.32); }
footer { display: flex; align-items: center; gap: 6px; padding: 9px 14px; border-top: 1px solid var(--line); color: var(--muted); font-size: 11.5px; flex-wrap: wrap; }
.sep { opacity: .5; }
kbd { font: 500 10.5px/1 ui-sans-serif, -apple-system, system-ui, sans-serif; color: var(--fg); padding: 2px 5px; border-radius: 5px; margin: 0 1px; background: rgba(255,255,255,.08); border: 1px solid rgba(255,255,255,.1); border-bottom-width: 2px; }

/* ---- the knowledge card: frosted glass, mid-screen ---- */
.kcard {
  position: fixed; left: 50%; top: 50%; z-index: 2; width: min(440px, calc(100vw - 32px)); max-height: min(70vh, 520px); overflow: auto;
  padding: 18px 20px 16px; border-radius: 20px; color: #1C1F2A;
  font: 14px/1.5 ui-sans-serif, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif; -webkit-font-smoothing: antialiased;
  /* nearly solid: a see-through card let whatever was behind it (the site's own pop-ups,
     their ✕) show through, as if there were a second window */
  background: linear-gradient(160deg, rgba(255,255,255,.97), rgba(249,250,250,.95));
  backdrop-filter: blur(24px) saturate(1.4); -webkit-backdrop-filter: blur(24px) saturate(1.4);
  border: 1px solid rgba(28,31,42,.08);
  box-shadow: 0 30px 80px rgba(24, 24, 48, .18), 0 6px 20px rgba(24, 24, 48, .08), inset 0 1px 0 rgba(255,255,255,.9);
  opacity: 0; visibility: hidden; pointer-events: none; transform: translate(-50%, calc(-50% + 12px)) scale(.97); filter: blur(4px);
  transition: opacity .3s ease, transform .4s cubic-bezier(.2,.8,.2,1), filter .3s ease, visibility 0s linear .4s;
}
.kcard.on { opacity: 1; visibility: visible; pointer-events: auto; transform: translate(-50%, -50%); filter: none; transition: opacity .3s ease, transform .4s cubic-bezier(.2,.8,.2,1), filter .3s ease, visibility 0s; }
/* other placements (settings page): above the orb, top right, bottom center */
.kcard[data-place="above-orb"] { left: auto; top: auto; right: 22px; bottom: 88px; width: min(380px, calc(100vw - 32px)); max-height: min(60vh, 460px); transform-origin: bottom right; transform: translateY(12px) scale(.97); }
.kcard[data-place="top-right"] { left: auto; right: 22px; top: 22px; width: min(380px, calc(100vw - 32px)); max-height: min(60vh, 460px); transform-origin: top right; transform: translateY(-12px) scale(.97); }
.kcard[data-place="bottom-center"] { top: auto; bottom: 28px; width: min(560px, calc(100vw - 32px)); max-height: min(45vh, 360px); transform: translate(-50%, 12px) scale(.97); }
.kcard.on[data-place="above-orb"], .kcard.on[data-place="top-right"] { transform: none; }
.kcard.on[data-place="bottom-center"] { transform: translate(-50%, 0); }
.k-src { display: flex; align-items: center; gap: 6px; font-size: 11.5px; font-weight: 500; letter-spacing: .01em; color: #5d5d6e; padding-right: 28px; }
.k-src svg { width: 13px; height: 13px; flex: none; fill: none; stroke: currentColor; stroke-width: 1.3; stroke-linejoin: round; }
.k-x { all: unset; position: absolute; top: 10px; right: 10px; width: 28px; height: 28px; display: grid; place-items: center; border-radius: 9px; color: #6b6b7a; cursor: pointer; }
.k-x:hover { background: rgba(0,0,0,.06); color: #1c1c22; }
.k-x:focus-visible { outline: 2px solid var(--accent, #4C4F62); outline-offset: -2px; }
.k-x svg { width: 14px; height: 14px; fill: none; stroke: currentColor; stroke-width: 1.5; stroke-linecap: round; }
.k-title { margin: 8px 0 8px; font-size: 16.5px; line-height: 1.3; font-weight: 650; letter-spacing: -.015em; }
.k-points { margin: 0; padding: 0; list-style: none; display: grid; gap: 7px; }
.k-points li { position: relative; padding-left: 16px; color: #2b2b35; }
.k-points li::before { content: ""; position: absolute; left: 2px; top: .62em; width: 6px; height: 6px; border-radius: 50%; background: linear-gradient(135deg, #AFBAC0, #4C4F62); }
.k-open { display: inline-flex; align-items: center; gap: 4px; margin-top: 12px; font-size: 12.5px; font-weight: 600; color: #2C2E3D; text-decoration: none; }
.k-open:hover { text-decoration: underline; }
.k-open svg { width: 12px; height: 12px; fill: none; stroke: currentColor; stroke-width: 1.6; stroke-linecap: round; }
.k-timer { position: absolute; left: 20px; right: 20px; bottom: 7px; height: 2px; border-radius: 2px; overflow: hidden; background: rgba(0,0,0,.05); }
.k-timer i { display: block; height: 100%; background: linear-gradient(90deg, #AFBAC0, #4C4F62); transform-origin: left; }
.kcard.on .k-timer i { animation: tw-countdown var(--left, 20000ms) linear forwards; }
.kcard.hold .k-timer i { animation-play-state: paused; }
@keyframes tw-countdown { from { transform: scaleX(1); } to { transform: scaleX(0); } }

/* the ring around what the agent is touching (fixed to the viewport, outside the widget box) */
.hl { position: fixed; pointer-events: none; border-radius: 10px; opacity: 0; z-index: 1;
  box-shadow: 0 0 0 2px var(--accent, #4C4F62), 0 0 0 6px color-mix(in srgb, var(--accent, #4C4F62) 22%, transparent), 0 6px 24px color-mix(in srgb, var(--accent, #4C4F62) 30%, transparent);
  transition: opacity .5s ease; }
.hl.on { opacity: 1; transition: opacity .12s ease; }

@media (prefers-reduced-motion: reduce) {
  .orb, .panel, .dock, .toast { transition: none; }
  [data-state="listening"] .ring::after { animation: none; }
  .kcard { transition: none; filter: none; }
}`;
  }
