/* Talk to Website: the voice engine.
 *
 * Mic → 24 kHz PCM16 in 50 ms chunks → relay server → GPT-Live, and the agent's voice
 * back through a jitter buffer. Runs inside the page (script tag, bookmarklet) or in the
 * Chrome extension's offscreen document, where it outlives page loads in the tab.
 *
 * GPT-Live is full duplex and judges end-of-turn from silence, so push-to-talk is real
 * mic audio while held and silence otherwise. The conversation (transcript, the task in
 * progress) lives on the server under a conversation id; reconnecting with the same id
 * within ~45 s carries on where it was (a page load in script-tag mode).
 *
 * TalkVoice.create({ server, name, persist, onEvent }) → controls; events:
 *   state    nothing in particular changed shape; re-read tick()/status()
 *   messages the full transcript, [{ role, text }]
 *   message  { index, role, text } (one bubble added or extended)
 *   notice   { text, kind: "error" | "info", code? }
 *   page     { id, op, args } a request from the agent for the page (snapshot, act)
 *   card     { title, points, source: { title, url } } knowledge from beyond the page, to show
 */
const TalkVoice = (() => {
  "use strict";
  const RATE = 24000;
  const CHUNK = 1200; // 50 ms
  const PREROLL = 5; // chunks kept from just before a press: catches the first syllable
  const TAIL_MS = 450; // keep sending after release: people let go on their last word
  const THINKING_MAX_MS = 7000;
  const RESUME_MS = 40000; // a conversation left this recently is picked up again
  // Barge-in. GPT-Live stops itself when talked over, but only ~1.2 s later (measured), so
  // the client doesn't wait: it cuts playback at once and then gates out the rest of the
  // interrupted sentence until the model actually goes quiet; its reply plays normally.
  const BARGE_SPEECH_MS = 150; // hands-free: this much of your voice over the agent cuts it off
  const GATE_QUIET_MS = 450; // the model is quiet this long: the interrupted sentence is over (longer than a pause between sentences)
  const GATE_FALSE_ALARM_MS = 500; // you went quiet and the model kept talking: it wasn't speech
  const GATE_MAX_AFTER_RELEASE_MS = 1500; // push-to-talk: the model ignored the press; let it go on
  const SILENCE = new ArrayBuffer(CHUNK * 2);
  const now = () => performance.now();

  // ---- audio -------------------------------------------------------------------------
  // Float32 at the context rate → Int16 at 24 kHz, in fixed chunks (linear interpolation;
  // usually a pass-through, since the context itself runs at 24 kHz where allowed)
  class Pcm16Chunker {
    constructor(inRate, size) { this.step = inRate / 24000; this.pos = 0; this.prev = 0; this.size = size; this.buf = new Int16Array(size); this.fill = 0; }
    push(input, emit) {
      const n = input.length;
      let t = this.pos;
      while (t < n - 1) {
        const i = Math.floor(t), f = t - i;
        const a = i < 0 ? this.prev : input[i];
        let v = a + (input[i + 1] - a) * f;
        v = v > 1 ? 1 : v < -1 ? -1 : v;
        this.buf[this.fill++] = v < 0 ? v * 0x8000 : v * 0x7fff;
        if (this.fill === this.size) { emit(this.buf.buffer); this.buf = new Int16Array(this.size); this.fill = 0; }
        t += this.step;
      }
      this.pos = t - n;
      this.prev = input[n - 1];
    }
  }

  // The agent's voice: Int16 24 kHz in, Float32 at the context rate out. A jitter buffer
  // that waits for 80 ms before (re)starting, and keeps latency down by dropping silent
  // chunks when it runs more than 400 ms behind (and anything past 1.5 s).
  class PcmRing {
    constructor(outRate) {
      this.step = 24000 / outRate; this.size = 24000 * 4; this.ring = new Float32Array(this.size);
      this.w = 0; this.r = 0; this.playing = false;
    }
    push(int16) {
      let sum = 0;
      for (let i = 0; i < int16.length; i++) sum += int16[i] * int16[i];
      const silent = Math.sqrt(sum / (int16.length || 1)) < 120;
      const backlog = this.w - this.r;
      if (silent && backlog > 24000 * 0.4) return;
      for (let i = 0; i < int16.length; i++) this.ring[(this.w + i) % this.size] = int16[i] / 32768;
      this.w += int16.length;
      if (this.w - this.r > 24000 * 1.5) this.r = this.w - 24000 * 0.4;
    }
    flush() { this.r = this.w; this.playing = false; }
    render(out) {
      for (let k = 0; k < out.length; k++) {
        const avail = this.w - this.r;
        if (!this.playing && avail >= 24000 * 0.08) this.playing = true;
        if (!this.playing || avail < 2) { this.playing = false; out[k] = 0; continue; }
        const i = Math.floor(this.r), f = this.r - i;
        const a = this.ring[i % this.size], b = this.ring[(i + 1) % this.size];
        out[k] = a + (b - a) * f;
        this.r += this.step;
      }
    }
  }

  const WORKLET_SRC = `${Pcm16Chunker}\n${PcmRing}
class TwMic extends AudioWorkletProcessor {
  constructor() { super(); this.c = new Pcm16Chunker(sampleRate, ${CHUNK}); }
  process(inputs) { const ch = inputs[0] && inputs[0][0]; if (ch) this.c.push(ch, (b) => this.port.postMessage(b, [b])); return true; }
}
class TwPlayer extends AudioWorkletProcessor {
  constructor() { super(); this.p = new PcmRing(sampleRate); this.port.onmessage = (e) => (e.data === "flush" ? this.p.flush() : this.p.push(new Int16Array(e.data))); }
  process(_i, outputs) { this.p.render(outputs[0][0]); return true; }
}
registerProcessor("tw-mic", TwMic);
registerProcessor("tw-player", TwPlayer);`;

  async function openAudio({ onChunk }) {
    if (!navigator.mediaDevices?.getUserMedia) throw Object.assign(new Error("insecure"), { name: "InsecureContext" });
    const stream = await navigator.mediaDevices.getUserMedia({
      audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true, channelCount: 1 },
    });
    let ctx, src;
    try {
      ctx = new AudioContext({ sampleRate: RATE, latencyHint: "interactive" });
      src = ctx.createMediaStreamSource(stream);
    } catch {
      // some browsers refuse a mic source at a rate other than the device's
      try { ctx?.close(); } catch {}
      ctx = new AudioContext({ latencyHint: "interactive" });
      src = ctx.createMediaStreamSource(stream);
    }
    if (ctx.state === "suspended") await ctx.resume().catch(() => {});

    const micAnalyser = Object.assign(ctx.createAnalyser(), { fftSize: 512, smoothingTimeConstant: 0.5 });
    const outAnalyser = Object.assign(ctx.createAnalyser(), { fftSize: 512, smoothingTimeConstant: 0.5 });
    const outGain = ctx.createGain();
    const sink = ctx.createGain(); // the mic node needs a path to the output to keep running
    sink.gain.value = 0;
    src.connect(micAnalyser);
    outAnalyser.connect(outGain).connect(ctx.destination);
    sink.connect(ctx.destination);

    let play, flush, nodes = [];
    try {
      const url = URL.createObjectURL(new Blob([WORKLET_SRC], { type: "text/javascript" }));
      await ctx.audioWorklet.addModule(url);
      URL.revokeObjectURL(url);
      const mic = new AudioWorkletNode(ctx, "tw-mic");
      const player = new AudioWorkletNode(ctx, "tw-player");
      mic.port.onmessage = (e) => onChunk(e.data);
      src.connect(mic).connect(sink);
      player.connect(outAnalyser);
      play = (buf) => player.port.postMessage(buf, [buf]);
      flush = () => player.port.postMessage("flush");
      nodes = [mic, player];
    } catch {
      // no worklet (CSP blocks blob: modules, or no audioWorklet): one ScriptProcessor
      // takes the mic in and plays the agent out
      const chunker = new Pcm16Chunker(ctx.sampleRate, CHUNK);
      const ring = new PcmRing(ctx.sampleRate);
      const sp = ctx.createScriptProcessor(1024, 1, 1);
      sp.onaudioprocess = (e) => {
        chunker.push(e.inputBuffer.getChannelData(0), onChunk);
        ring.render(e.outputBuffer.getChannelData(0));
      };
      src.connect(sp).connect(outAnalyser);
      play = (buf) => ring.push(new Int16Array(buf));
      flush = () => ring.flush();
      nodes = [sp];
    }

    return {
      ctx, micAnalyser, outAnalyser,
      play, flush,
      setMuted: (m) => outGain.gain.setTargetAtTime(m ? 0 : 1, ctx.currentTime, 0.02),
      async close() {
        stream.getTracks().forEach((t) => t.stop());
        nodes.forEach((n) => { try { n.disconnect(); } catch {} });
        await ctx.close().catch(() => {});
      },
    };
  }
  // ---- connection to the relay ------------------------------------------------------------
  function openLink({ url, start, onAudio, onMessage, onClose }) {
    const ws = new WebSocket(`${url.replace(/\/$/, "")}/live`);
    ws.binaryType = "arraybuffer";
    const pending = [];
    let opened = false, done = false;
    ws.onopen = () => {
      opened = true;
      ws.send(JSON.stringify(start));
      for (const b of pending.splice(0)) ws.send(b);
    };
    ws.onmessage = (m) => {
      if (typeof m.data !== "string") return onAudio(m.data);
      try { onMessage(JSON.parse(m.data)); } catch {}
    };
    ws.onclose = (e) => { if (!done) { done = true; onClose({ opened, code: e.code }); } };
    const send = (data) => {
      if (ws.readyState === 1) ws.send(data);
      else if (ws.readyState === 0 && pending.length < 600) pending.push(typeof data === "string" ? data : data.slice(0));
    };
    return {
      send,
      json: (msg) => send(JSON.stringify(msg)),
      close() { done = true; try { ws.close(1000); } catch {} },
    };
  }

  const uid = () => (crypto.randomUUID ? crypto.randomUUID() : `${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`);

  function micError(e) {
    if (e?.name === "InsecureContext") return { text: "Voice needs a secure (https) page.", code: "insecure" };
    if (e?.name === "NotAllowedError" || e?.name === "SecurityError") return { text: "Microphone access is blocked.", code: "mic-permission" };
    if (e?.name === "NotFoundError") return { text: "No microphone found.", code: "no-mic" };
    return { text: `Couldn't start the microphone${e?.message ? ` (${e.message})` : ""}.`, code: "mic" };
  }

  function create({ server, name, persist, onEvent, idle = {} }) {
    const IDLE = { ptt: 60, handsFree: 120, muted: 300, ...idle }; // seconds of quiet before hanging up
    const emit = (type, data) => { try { onEvent(type, data); } catch (e) { console.error("[talk]", e); } };
    const S = {
      session: "off", // off | connecting | live
      seq: 0, // increments per session; stale callbacks check it
      audio: null, link: null,
      handsFree: false, ptt: false, tailUntil: 0, preroll: [],
      micMuted: false, voiceMuted: !!persist.get("voiceMuted"),
      awaitingSince: 0, // released, waiting for the reply ("thinking")
      agentAudioAt: 0, // last audible agent chunk
      lastActivity: 0,
      working: null, // the agent is operating the page: { note }
      gate: null, // after a barge-in: { at, quietMs, source } agent audio is dropped until the model goes quiet
      vad: { speechMs: 0, lastSpeechAt: 0, floor: 0.004, peak: 0, calmUntil: 0 }, // a light voice detector on the (echo-cancelled) mic
      flash: null, // { text, kind, until }
      page: null, // { url, title } of the page the agent works on
    };
    let messages = persist.get("messages") || [];
    let conv = persist.get("conv"); // { id, at, handsFree }: the conversation to resume

    function saveConv() { persist.set("conv", conv); }
    // while live: keep the conversation resumable, and remember when we last talked here
    const keepConvFresh = setInterval(() => {
      if (S.session === "off") return;
      persist.set("lastAt", Date.now());
      if (conv) { conv.at = Date.now(); saveConv(); }
    }, 2000);

    function notice(text, kind = "error", code) {
      S.flash = { text, kind, until: now() + 4500 };
      emit("notice", { text, kind, code });
      emit("state");
    }

    // greet: started by a click (not by talking), so the assistant may open the conversation
    async function start({ handsFree = false, page, greet = false } = {}) {
      if (page) S.page = page;
      if (S.session !== "off") { if (handsFree) { S.handsFree = true; S.lastActivity = now(); emit("state"); } return; }
      const seq = ++S.seq;
      const resume = conv && Date.now() - conv.at < RESUME_MS;
      if (!resume) conv = { id: uid(), at: Date.now(), handsFree };
      conv.handsFree = handsFree;
      saveConv();
      persist.set("lastConv", conv.id); // kept after it ends, for a problem report
      Object.assign(S, { session: "connecting", handsFree, lastActivity: now(), flash: null });
      emit("state");
      // the relay and GPT-Live connect while the mic comes up; mic audio queues meanwhile
      S.link = openLink({
        url: server,
        start: { type: "start", conversationId: conv.id, name, page: S.page, history: messages.slice(-16), greet: greet && !resume, lastAt: persist.get("lastAt") || null },
        onAudio: (buf) => seq === S.seq && onAgentAudio(buf),
        onMessage: (msg) => seq === S.seq && onServer(msg),
        onClose: ({ opened }) => {
          if (seq !== S.seq) return;
          end({ keepConversation: true });
          if (!opened) notice(`Can't reach the voice server at ${server}. Is it running?`);
        },
      });
      let audio;
      try {
        audio = await openAudio({ onChunk: (buf) => seq === S.seq && onMicChunk(buf) });
      } catch (e) {
        if (seq !== S.seq) return;
        stop();
        const err = micError(e);
        return notice(err.text, "error", err.code);
      }
      if (seq !== S.seq) return void audio.close(); // ended while the mic prompt was up
      S.audio = audio;
      audio.setMuted(S.voiceMuted);
      if (audio.ctx.state === "suspended") resumeOnGesture(audio.ctx);
    }

    // a page that has just loaded can't start audio until the visitor interacts with it
    // (script-tag mode only; the extension's offscreen document has no such limit)
    function resumeOnGesture(ctx) {
      notice("Click anywhere or press a key to continue the conversation.", "info");
      const go = () => { ctx.resume(); for (const ev of ["pointerdown", "keydown"]) removeEventListener(ev, go, true); };
      for (const ev of ["pointerdown", "keydown"]) addEventListener(ev, go, { capture: true, passive: true });
    }

    // keepConversation: the connection dropped (a page load): the server holds the
    // conversation for a while and the next page picks it up
    function end({ keepConversation = false } = {}) {
      if (S.session === "off") return;
      if (keepConversation && conv) { conv.at = Date.now(); saveConv(); }
      S.seq++;
      if (!keepConversation) S.link?.json({ type: "stop" });
      S.link?.close();
      S.audio?.close();
      Object.assign(S, { session: "off", audio: null, link: null, handsFree: false, ptt: false, awaitingSince: 0, agentAudioAt: 0, preroll: [], micMuted: false, working: null, gate: null });
      if (!keepConversation) { conv = null; saveConv(); }
      emit("state");
    }
    const stop = () => end();

    function onServer(msg) {
      switch (msg.type) {
        case "status":
          if (msg.state === "live") { S.session = "live"; emit("state"); }
          else if (msg.state === "closed" || msg.state === "error") { stop(); if (msg.message) notice(msg.message, msg.state === "closed" ? "info" : "error"); }
          else if (msg.state === "warning") console.warn("[talk]", msg.message);
          return;
        case "history":
          messages = (msg.messages || []).map(({ role, text }) => ({ role, text }));
          persist.set("messages", messages);
          return emit("messages", messages);
        case "message":
          messages[msg.index] = { role: msg.role, text: msg.text };
          messages.length = Math.max(messages.length, msg.index + 1);
          S.lastActivity = now();
          persist.set("messages", messages);
          return emit("message", { index: msg.index, role: msg.role, text: msg.text, captions: msg.captions });
        case "agent":
          S.working = msg.state === "working" ? { note: msg.note || "" } : null;
          S.lastActivity = now();
          if (!S.working) S.awaitingSince = now(); // the reply is on its way
          return emit("state");
        case "card": // knowledge from outside the page, to show on screen
          return emit("card", msg.card);
        case "report.open": // the visitor asked to report a problem: the widget opens its box
          return emit("report.open");
        case "page.request":
          S.lastActivity = now();
          return emit("page", { id: msg.id, op: msg.op, args: msg.args });
      }
    }

    function onMicChunk(buf) {
      if (S.micMuted) return void S.link?.send(SILENCE);
      if (S.handsFree) detectBargeIn(buf);
      if (S.ptt || S.handsFree || now() < S.tailUntil) return void S.link?.send(buf);
      S.preroll.push(buf);
      if (S.preroll.length > PREROLL) S.preroll.shift();
      S.link?.send(SILENCE); // the model hears the gap and knows the turn is over
    }

    function onAgentAudio(buf) {
      const v = new Int16Array(buf);
      let sum = 0;
      for (let i = 0; i < v.length; i += 4) sum += v[i] * v[i];
      const loud = Math.sqrt(sum / (v.length / 4 || 1)) > 300;
      if (S.gate && !gatePasses(loud, v.length / 24)) return; // the interrupted sentence: dropped
      if (loud) {
        S.agentAudioAt = now();
        S.awaitingSince = 0;
        S.lastActivity = now();
      }
      S.audio?.play(buf);
    }

    // Interrupted: stop the voice now and drop the rest of the interrupted sentence.
    function bargeIn(source) {
      S.audio?.flush();
      S.agentAudioAt = 0;
      S.gate = { at: now(), quietMs: 0, source };
      emit("state");
    }

    // While gated: let audio through again once the model has gone quiet (its next words are
    // the reply), or if it never stopped (a false alarm, or a press with nothing said).
    function gatePasses(loud, ms) {
      const g = S.gate;
      if (S.ptt) { g.quietMs = 0; return false; } // still holding the key: nothing plays
      if (!loud) { g.quietMs += ms; if (g.quietMs >= GATE_QUIET_MS) S.gate = null; return false; }
      g.quietMs = 0;
      const t = now();
      const falseAlarm = g.source === "voice" && t - S.vad.lastSpeechAt > GATE_FALSE_ALARM_MS;
      const ignoredPress = g.source === "key" && g.releasedAt && t - g.releasedAt > GATE_MAX_AFTER_RELEASE_MS;
      if (falseAlarm) {
        // probably the agent's own voice leaking from the speakers: learn that level, and
        // don't react again for a moment
        S.vad.floor = Math.max(S.vad.floor, S.vad.peak / 2.5);
        S.vad.calmUntil = t + 2000;
      }
      if (falseAlarm || ignoredPress) { S.gate = null; return true; }
      return false;
    }

    // Hands-free: is the visitor talking over the agent? The mic is echo-cancelled, so the
    // agent's own voice mostly doesn't reach it; what leaks through sets a floor to beat.
    function detectBargeIn(buf) {
      const v = new Int16Array(buf);
      let sum = 0;
      for (let i = 0; i < v.length; i++) sum += v[i] * v[i];
      const rms = Math.sqrt(sum / (v.length || 1)) / 32768;
      const d = S.vad, t = now();
      const agentTalking = t - S.agentAudioAt < 300 && !S.gate;
      const speech = rms > Math.max(0.02, d.floor * 3);
      if (speech) { d.speechMs += 50; d.lastSpeechAt = t; d.peak = Math.max(d.peak * 0.9, rms); }
      else { d.speechMs = 0; d.floor += (Math.min(rms, 0.05) - d.floor) * (agentTalking ? 0.05 : 0.02); } // leak + room noise
      if (agentTalking && t > d.calmUntil && d.speechMs >= BARGE_SPEECH_MS) { d.speechMs = 0; bargeIn("voice"); }
    }

    function pttDown(page) {
      if (S.ptt) return;
      if (page) S.page = page;
      if (S.micMuted) return notice("Your mic is muted. Hover the orb to unmute.", "info");
      const talking = now() - S.agentAudioAt < 600;
      Object.assign(S, { ptt: true, awaitingSince: 0, lastActivity: now() });
      if (talking) bargeIn("key"); // stop the voice now, and drop the rest of that sentence
      else S.audio?.flush();
      S.agentAudioAt = 0;
      if (S.session === "off") start({ handsFree: false });
      else { S.link?.json({ type: "turn" }); for (const b of S.preroll.splice(0)) S.link?.send(b); }
      emit("state");
    }

    function pttUp() {
      if (!S.ptt) return;
      if (S.gate) S.gate.releasedAt = now();
      Object.assign(S, { ptt: false, tailUntil: now() + TAIL_MS, awaitingSince: S.handsFree ? 0 : now(), lastActivity: now() });
      emit("state");
    }

    function toggle(page) {
      if (S.handsFree) return stop();
      if (S.session !== "off") { S.handsFree = true; S.lastActivity = now(); return emit("state"); }
      start({ handsFree: true, page, greet: true });
    }

    function setMicMuted(m) {
      if (S.session === "off") return;
      Object.assign(S, { micMuted: !!m, preroll: [], lastActivity: now() });
      if (m) Object.assign(S, { ptt: false, tailUntil: 0 });
      emit("state");
    }

    function setVoiceMuted(m) {
      S.voiceMuted = !!m;
      persist.set("voiceMuted", S.voiceMuted);
      S.audio?.setMuted(S.voiceMuted);
      emit("state");
    }

    function clear() {
      messages = [];
      persist.set("messages", messages);
      S.link?.json({ type: "clear" });
      emit("messages", messages);
    }

    // start afresh: end the conversation and forget it (transcript, the conversation to
    // resume, when we last talked), so the next one starts as a first visit
    function forget() {
      stop();
      messages = [];
      conv = null;
      for (const k of ["messages", "conv", "lastAt"]) persist.set(k, null);
      emit("messages", messages);
    }

    // a problem report (script-tag mode; the extension sends it from its worker): the note and
    // transcript go to the relay, which adds this conversation's logs
    async function report({ reporter, note, site, page, transcript } = {}) {
      const base = String(server).replace(/^ws/i, "http").replace(/\/live\/?$/, "").replace(/\/$/, "");
      try {
        const r = await fetch(`${base}/reports`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ reporter, note, site, page, transcript: transcript || messages, conversationId: conv?.id || persist.get("lastConv") || "" }) });
        const j = await r.json().catch(() => ({}));
        emit("reported", r.ok ? j : { ok: false, error: j.error || `relay said ${r.status}` });
      } catch (e) {
        emit("reported", { ok: false, error: `can't reach the relay (${e.message})` });
      }
    }

    // the page the agent works on: a new page is ready, or the current one is going away
    function pageReady(page) { S.page = page; S.link?.json({ type: "page.ready", page }); }
    function pageGone() { S.link?.json({ type: "page.gone" }); }
    function respond(id, ok, result) { S.link?.json({ type: "page.response", id, ok, result }); }

    function view() {
      const t = now();
      if (S.session === "off") return S.flash && t < S.flash.until && S.flash.kind === "error" ? "error" : "idle";
      if (t - S.agentAudioAt < 450) return "speaking";
      if (S.micMuted) return "muted";
      if (S.ptt) return "listening";
      if (S.working) return "working";
      if (S.awaitingSince && t - S.awaitingSince < THINKING_MAX_MS) return "thinking";
      if (S.handsFree) return "listening";
      if (S.session === "connecting") return "connecting";
      return "ready";
    }

    const td = new Float32Array(512);
    function level(v) {
      const an = v === "listening" ? S.audio?.micAnalyser : v === "speaking" ? S.audio?.outAnalyser : null;
      if (!an) return 0;
      an.getFloatTimeDomainData(td);
      let sum = 0;
      for (let i = 0; i < td.length; i++) sum += td[i] * td[i];
      const db = 20 * Math.log10(Math.sqrt(sum / td.length) + 1e-7);
      return Math.min(1, Math.max(0, (db + 52) / 36));
    }

    // what the UI draws, once per frame
    function tick() { const v = view(); return { view: v, level: level(v) }; }
    const outLevel = () => level("speaking"); // what's actually coming out of the speakers (tests)

    function status() {
      return {
        session: S.session, handsFree: S.handsFree, ptt: S.ptt, micMuted: S.micMuted, voiceMuted: S.voiceMuted,
        working: S.working?.note ?? null, flash: S.flash && now() < S.flash.until ? S.flash.text : "",
      };
    }

    // quiet for too long: hang up (the model bills by the second)
    const idleTimer = setInterval(() => {
      if (S.session === "off" || S.ptt || S.working) return;
      const quiet = (now() - Math.max(S.lastActivity, S.agentAudioAt)) / 1000;
      if (S.micMuted ? quiet > IDLE.muted : S.handsFree ? quiet > IDLE.handsFree : quiet > IDLE.ptt) {
        stop();
        if (S.handsFree || S.micMuted) notice("Ended the conversation after a quiet spell.", "info");
      }
    }, 1000);

    return {
      start, stop, end, pttDown, pttUp, toggle, setMicMuted, setVoiceMuted, clear, forget, report,
      pageReady, pageGone, respond, tick, status, view, outLevel,
      messages: () => messages,
      // a conversation was live when the last page unloaded: pick it up again
      shouldResume: () => !!conv && Date.now() - conv.at < RESUME_MS,
      resumeHandsFree: () => !!conv?.handsFree,
      destroy() {
        if (conv && S.session !== "off") { conv.at = Date.now(); saveConv(); }
        clearInterval(idleTimer); clearInterval(keepConvFresh); end({ keepConversation: true });
      },
    };
  }

  return { create };
})();
