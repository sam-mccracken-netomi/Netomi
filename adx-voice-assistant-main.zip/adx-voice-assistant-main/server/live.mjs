// One visitor's GPT-Live session, relayed by the server (the browser never sees the key).
//
//   widget mic ──PCM16 24 kHz──► server ──session.input_audio.append──► GPT-Live
//   widget spk ◄─PCM16 24 kHz─── server ◄─session.output_audio.delta─── GPT-Live
//
// GPT-Live is full duplex: it hears a continuous input stream and decides itself when the
// visitor has finished (silence) and when it is being interrupted. Push-to-talk therefore
// needs nothing special here: the widget sends real audio while the key is held and
// silence otherwise. Output audio is continuous too (silent frames between replies).
//
// Website tasks: the instructions tell the model to delegate them. A delegation carries
// no text (just an id), so the conversation works out the request from the transcript,
// runs the browser agent, and answers with session.commentary.append (delegation_id set);
// the model says the result in its own words. Commentary without an id is spoken too,
// which is how long tasks give a progress note.

import { EventEmitter } from "node:events";

const LIVE_URL = "wss://api.openai.com/v1/live/sessions";
// audio that arrives before session.started (the visitor talks while we connect) is held,
// then sent in one go; beyond this it is dropped from the front
const MAX_EARLY_BYTES = 24000 * 2 * 20; // 20 s

export class LiveSession extends EventEmitter {
  constructor({ apiKey, instructions, voice, log }) {
    super();
    this.apiKey = apiKey;
    this.instructions = instructions;
    this.voice = voice;
    this.log = log || (() => {});
    this.ws = null;
    this.started = false;
    this.closed = false;
    this.early = [];
    this.earlyBytes = 0;
  }

  connect() {
    const ws = (this.ws = new WebSocket(LIVE_URL, { headers: { Authorization: `Bearer ${this.apiKey}` } }));
    ws.addEventListener("open", () => {
      this.log("client", { type: "session.start" });
      ws.send(JSON.stringify({
        type: "session.start",
        session: {
          model: "gpt-live-1",
          instructions: this.instructions,
          audio: { format: { type: "audio/pcm", rate: 24000 }, output: { voice: this.voice } },
        },
      }));
    });
    ws.addEventListener("message", (m) => {
      let e;
      try { e = JSON.parse(m.data); } catch { return; }
      this.onEvent(e);
    });
    ws.addEventListener("close", (e) => {
      this.log("upstream_closed", { code: e.code, reason: e.reason });
      // moderated: the voice service stopped a reply on a sensitive topic and closed the
      // session (the conversation reopens one rather than ending)
      if (!this.closed) this.emit("status", { state: "closed", moderated: this.moderated, message: this.started ? "The voice session ended." : "Couldn't start a voice session." });
      this.closed = true;
    });
    ws.addEventListener("error", () => {
      if (!this.closed) this.emit("status", { state: "error", message: "Lost the connection to the voice service." });
    });
  }

  pushAudio(pcm) {
    if (this.closed) return;
    if (!this.started) {
      this.early.push(Buffer.from(pcm));
      this.earlyBytes += pcm.byteLength;
      while (this.earlyBytes > MAX_EARLY_BYTES) this.earlyBytes -= this.early.shift().byteLength;
      return;
    }
    this.send({ type: "session.input_audio.append", audio: Buffer.from(pcm).toString("base64") });
  }

  send(event) {
    if (this.ws?.readyState === 1) this.ws.send(JSON.stringify(event));
  }

  commentary(content, delegationId = null) {
    this.log("commentary", { delegation_id: delegationId, content });
    this.send({ type: "session.commentary.append", delegation_id: delegationId, content });
  }

  // background for the model, not to be said as such (used for superseded delegations)
  thinking(content, delegationId = null) {
    this.log("thinking", { delegation_id: delegationId, content });
    this.send({ type: "session.thinking.append", delegation_id: delegationId, content });
  }

  close() {
    if (this.closed) return;
    this.closed = true;
    try {
      this.send({ type: "session.close" });
      setTimeout(() => this.ws?.close(), 1500);
    } catch {}
  }

  onEvent(e) {
    switch (e.type) {
      case "session.started": {
        this.started = true;
        this.log("session.started", { id: e.session?.id });
        this.emit("status", { state: "live" });
        // flush what the visitor said while we were connecting, in ~200 ms appends
        const all = Buffer.concat(this.early.splice(0));
        this.earlyBytes = 0;
        const step = 24000 * 2 * 0.2;
        for (let i = 0; i < all.length; i += step) this.send({ type: "session.input_audio.append", audio: all.subarray(i, i + step).toString("base64") });
        if (all.length) this.log("early_audio", { seconds: +(all.length / 48000).toFixed(2) });
        return;
      }
      case "session.output_audio.delta":
        if (e.delta) this.emit("audio", Buffer.from(e.delta, "base64"));
        return;
      case "session.output_transcript.delta":
        this.log("agent_words", { delta: e.delta, start_ms: e.start_ms });
        this.emit("transcript", { role: "agent", delta: e.delta, start_ms: e.start_ms });
        return;
      case "session.input_transcript.delta":
        this.log("user_words", { delta: e.delta, start_ms: e.start_ms });
        this.emit("transcript", { role: "user", delta: e.delta, start_ms: e.start_ms });
        return;
      case "session.delegation.created":
        // the model hands the turn to the app (website tasks); every delegation must be
        // answered with commentary carrying its id, or the turn hangs
        this.log("delegation", { id: e.delegation?.id, offset_ms: e.offset_ms });
        this.emit("delegation", { id: e.delegation?.id ?? null, offset_ms: e.offset_ms });
        return;
      case "error":
        this.log("error", e.error);
        if (e.error?.code === "content_filter") { this.moderated = true; return; }
        this.emit("status", { state: "warning", message: e.error?.message || "Voice service error" });
        return;
      case "session.closed":
        this.log("session.closed", { reason: e.reason, usage: e.usage });
        if (e.reason === "content") this.moderated = true;
        return;
      case "session.usage.updated":
        return;
      default:
        this.log("event", { type: e.type });
    }
  }
}
