// Problem reports: the visitor (you, testing) says what went wrong, and the relay bundles it
// with that conversation's logs, so the session can be looked at later.
//  - the conversation is found by its id, or else as the most recent one on the site (the
//    widget forgets the id when a conversation ends); every log file it spans is taken
//    (a conversation that reconnected is split across several)
//  - with it: the relay's own log lines from that time, the settings that shape behaviour
//    (no Netomi IDs), the transcript the widget showed, and a readable timeline
// Sent to the issue tracker (REPORTS_URL in .env) as { reporter, issue, logs }: the reporter's
// name ("anonymous" if none), what went wrong, and the logs (the readable timeline, then the
// raw logs as JSON). Kept locally only if sending fails, then retried (retry(), every few
// minutes). Without REPORTS_URL, saved under logs/reports/ as before:
//   <id>.json  everything, for tools      <id>.txt  the note, transcript and timeline, for people
//   await reports.create({ site, conversationId, reporter, note, transcript, page, userAgent })
//     → { id, sessions, conversationId, sent, queued?, error? }
//   reports.list() → [{ id, at, site, note, sessions }]      reports.path(id, ext) → file | null
import { existsSync, mkdirSync, readdirSync, readFileSync, writeFileSync, openSync, readSync, closeSync, unlinkSync } from "node:fs";
import { join } from "node:path";

const WINDOW_MS = 6 * 3600e3; // the most recent conversation on the site, within this

export function createReports({ logs, getSettings, url = process.env.REPORTS_URL || "", log = () => {} }) {
  const DIR = join(logs, "reports");
  const ID = /^[0-9TZ-]+-[a-z0-9.-]+$/i;

  // a session log's first line (its "start"), without reading the whole file
  function head(file) {
    const fd = openSync(file, "r");
    try {
      const buf = Buffer.alloc(16384);
      const n = readSync(fd, buf, 0, buf.length, 0);
      return JSON.parse(buf.subarray(0, n).toString("utf8").split("\n")[0]);
    } catch { return null; } finally { closeSync(fd); }
  }
  const startedAt = (name) => {
    const m = name.match(/^session-(\d{4}-\d\d-\d\d)T(\d\d)-(\d\d)-(\d\d)-(\d{3})Z/);
    return m ? Date.parse(`${m[1]}T${m[2]}:${m[3]}:${m[4]}.${m[5]}Z`) : 0;
  };
  const siteOfStart = (s) => {
    const v = String(s?.page?.site || "");
    if (v) return v.replace(/^www\./, "");
    try { return new URL(s?.page?.url).hostname.replace(/^www\./, ""); } catch { return ""; }
  };

  // the conversation's log files, oldest first
  function sessionsFor(site, conversationId) {
    const names = readdirSync(logs).filter((f) => /^session-.*\.jsonl$/.test(f)).sort().reverse().slice(0, 400);
    const now = Date.now();
    const heads = names.map((name) => ({ name, at: startedAt(name), start: head(join(logs, name)) })).filter((x) => x.start);
    let id = conversationId && heads.some((x) => x.start.id === conversationId) ? conversationId : null;
    if (!id) id = heads.find((x) => now - x.at < WINDOW_MS && site && siteOfStart(x.start) === site)?.start.id || null;
    if (!id) return { id: null, files: [] };
    return { id, files: heads.filter((x) => x.start.id === id).reverse() };
  }

  const readJsonl = (file) => {
    try { return readFileSync(file, "utf8").split("\n").filter(Boolean).map((l) => { try { return JSON.parse(l); } catch { return null; } }).filter(Boolean); } catch { return []; }
  };

  // what people read: speech joined into lines, and the events that explain what happened
  const SHOW = new Set(["delegation_request", "missed_handoff", "task", "step", "holding", "handoff_wait", "task_done", "task_waiting", "task_resume", "help_answer", "card", "agent_error", "recover_error", "resume_error", "error", "look_failed", "moderated", "upstream_closed", "detach", "attach", "conversation_end", "visitor_left", "report", "greeting", "sales_pitch", "page"]);
  function timeline(events) {
    const out = [];
    let who = null, text = "", at = 0;
    const flush = () => { if (text.trim()) out.push(`${fmt(at)}  ${who === "agent" ? "VOICE  " : "VISITOR"}  ${text.trim()}`); text = ""; who = null; };
    for (const e of events) {
      if (e.kind === "agent_words" || e.kind === "user_words") {
        const w = e.kind === "agent_words" ? "agent" : "user";
        if (w !== who) { flush(); who = w; at = e.t; }
        text += e.delta || "";
        continue;
      }
      if (!SHOW.has(e.kind)) continue;
      flush();
      out.push(`${fmt(e.t)}    -- ${e.kind} ${describe(e)}`.trimEnd());
    }
    flush();
    return out;
  }
  const fmt = (t) => `${Number(t || 0).toFixed(1)}s`.padStart(7);
  function describe(e) {
    const ms = e.ms != null ? ` (${e.ms} ms${e.hedged ? ", hedged" : ""})` : "";
    switch (e.kind) {
      case "step": return `#${e.n} ${e.tool}${ms}: ${e.args?.why || e.args?.say || ""} @ ${e.url || ""}`;
      case "task_done": return `${e.status}${ms}: ${e.say || ""}`;
      case "task": case "delegation_request": return JSON.stringify(e.request || "");
      case "missed_handoff": return `${JSON.stringify(e.request)} (the voice said: ${JSON.stringify(e.said)})`;
      case "page": return e.url || "";
      case "error": case "agent_error": case "recover_error": case "resume_error": return e.error?.message || e.error || e.message || JSON.stringify(e).slice(0, 200);
      case "upstream_closed": return `code ${e.code} ${e.reason || ""}`;
      case "help_answer": return `${JSON.stringify(e.question)}${ms} ${e.answered ? "answered" : "no answer"}`;
      case "holding": case "handoff_wait": return `${e.after_ms ?? e.ms} ms`;
      case "report": return JSON.stringify(e.note || "");
      default: return "";
    }
  }

  async function create({ site = "", conversationId = "", reporter = "", note = "", transcript = [], page = null, userAgent = "" }) {
    site = String(site).replace(/^www\./, "").slice(0, 120);
    note = String(note || "").trim().slice(0, 4000);
    reporter = String(reporter || "").replace(/\s+/g, " ").trim().slice(0, 80);
    const at = new Date();
    const id = `${at.toISOString().replace(/[:.]/g, "-")}-${site.replace(/[^a-z0-9.-]/gi, "_") || "unknown"}`;
    const found = sessionsFor(site, String(conversationId || ""));
    const sessions = found.files.map((f) => ({ file: f.name, startedAt: new Date(f.at).toISOString(), events: readJsonl(join(logs, f.name)) }));
    // the relay's own lines from the conversation's time (Netomi, knowledge, offers, errors)
    const from = found.files[0]?.at || Date.now() - 3600e3;
    const server = readJsonl(join(logs, "server.jsonl")).filter((e) => { const t = Date.parse(e.at); return t >= from - 60e3 && t <= Date.now(); }).slice(-2000);
    const s = getSettings();
    const settings = { knowledge: { mode: s.knowledge?.mode, local: s.knowledge?.local }, sales: s.sales, memory: s.memory, ui: s.ui };
    const shown = (Array.isArray(transcript) ? transcript : []).slice(-200).map((m) => ({ role: m?.role === "user" ? "user" : "agent", text: String(m?.text || "").slice(0, 2000) }));
    const report = { id, at: at.toISOString(), site, reporter: reporter || "anonymous", note, page, userAgent: String(userAgent).slice(0, 300), conversationId: found.id, settings, transcript: shown, sessions, server };
    const txt = [
      `Problem report ${id}`,
      `Reporter: ${report.reporter}`,
      `When:  ${at.toString()}`,
      `Site:  ${site}${page?.url ? `   page: ${page.url}` : ""}`,
      `Conversation: ${found.id || "(none found)"}   log files: ${sessions.map((x) => x.file).join(", ") || "none"}`,
      "", "What went wrong (as reported):", note || "(no description)", "",
      "Transcript (as the chat panel showed it):",
      ...(shown.length ? shown.map((m) => `  ${m.role === "user" ? "you  " : "voice"}: ${m.text}`) : ["  (empty)"]),
      ...sessions.flatMap((x) => ["", `Timeline: ${x.file} (started ${x.startedAt})`, ...timeline(x.events)]),
      "", `Relay log lines in this period: ${server.length} (in the .json)`,
    ].join("\n");
    const out = { id, sessions: sessions.length, conversationId: found.id };
    if (url) {
      const r = await deliver(report, txt);
      if (r.ok) { log("report_sent", { id, status: r.status }); return { ...out, sent: true }; }
      log("report_send_failed", { id, error: r.error });
      save(report, txt, { pending: true, error: r.error });
      return { ...out, sent: false, queued: true, error: r.error };
    }
    save(report, txt);
    return { ...out, sent: false };
  }
  function save(report, txt, extra = {}) {
    mkdirSync(DIR, { recursive: true });
    writeFileSync(join(DIR, `${report.id}.json`), JSON.stringify({ ...report, ...extra }, null, 1));
    writeFileSync(join(DIR, `${report.id}.txt`), txt + "\n");
  }

  // to the issue tracker: { reporter, issue, logs }
  async function deliver(report, txt) {
    const { sessions, server, ...rest } = report;
    const logs = `${txt}\n\n===== Raw logs (JSON) =====\n${JSON.stringify({ ...rest, sessions, server })}`;
    try {
      const r = await fetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ reporter: report.reporter || "anonymous", issue: report.note || "(no description)", logs }), signal: AbortSignal.timeout(30000) });
      if (!r.ok) return { ok: false, status: r.status, error: `the tracker said ${r.status}` };
      return { ok: true, status: r.status };
    } catch (e) {
      return { ok: false, error: e.name === "TimeoutError" ? "the tracker didn't answer" : "couldn't reach the tracker" };
    }
  }
  // reports that couldn't be sent: try again (and drop the local copy once sent)
  let retrying = false;
  async function retry() {
    if (!url || retrying || !existsSync(DIR)) return;
    retrying = true;
    try {
      for (const f of readdirSync(DIR).filter((x) => x.endsWith(".json"))) {
        let r;
        try { r = JSON.parse(readFileSync(join(DIR, f), "utf8")); } catch { continue; }
        if (!r.pending) continue;
        const txtFile = join(DIR, f.replace(/\.json$/, ".txt"));
        const { pending, error, ...report } = r;
        const d = await deliver(report, existsSync(txtFile) ? readFileSync(txtFile, "utf8").trimEnd() : `Problem report ${report.id}`);
        if (d.ok) { try { unlinkSync(join(DIR, f)); unlinkSync(txtFile); } catch {} log("report_sent", { id: report.id, retried: true }); }
        else { r.error = d.error; writeFileSync(join(DIR, f), JSON.stringify(r, null, 1)); }
      }
    } finally { retrying = false; }
  }

  function list() {
    if (!existsSync(DIR)) return [];
    return readdirSync(DIR).filter((f) => f.endsWith(".json")).sort().reverse().slice(0, 100).map((f) => {
      try {
        const r = JSON.parse(readFileSync(join(DIR, f), "utf8"));
        return { id: r.id, at: r.at, site: r.site, reporter: r.reporter, note: r.note.slice(0, 300), sessions: r.sessions.length, pending: !!r.pending, error: r.error };
      } catch { return null; }
    }).filter(Boolean);
  }

  const path = (id, ext = "json") => {
    if (!ID.test(String(id)) || !["json", "txt"].includes(ext)) return null;
    const f = join(DIR, `${id}.${ext}`);
    return existsSync(f) ? f : null;
  };

  return { create, list, path, retry, dir: DIR, sendsTo: url ? new URL(url).host : "" };
}
