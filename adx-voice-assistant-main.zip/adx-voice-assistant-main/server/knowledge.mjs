// A small local knowledge base per site (help and policy pages: returns, shipping,
// rewards…), so the agent can answer "can I return this?" from a product page without
// going to the returns page. Stand-in for the Netomi knowledge API, which will plug in
// behind the same two calls:
//
//   knowledge.search(site, query, k) → [{ id, title, section, url, text, score }]
//   knowledge.ingest(site, pages)    → { pages, chunks }   pages: [{ url, title, sections: [{ heading, text }] }]
//
// No vector database: a site's help centre is ~1-2k passages, which fit in memory and are
// searched in a few milliseconds. Each passage has an embedding (text-embedding-3-small,
// 512 dimensions) and the search is hybrid: meaning (cosine) + exact words (BM25), so both
// "can I send back an opened lipstick" and "Rouge rewards" find the right passage.
// Stored as data/knowledge/<site>.json (embeddings as base64 float32).

import { readFileSync, writeFileSync, existsSync, mkdirSync, statSync } from "node:fs";
import { join } from "node:path";
import { DATA } from "./env.mjs";

const DIR = join(DATA(), "knowledge");
const MODEL = "text-embedding-3-small";
const DIMS = 512;
const CHUNK = 900; // characters per passage
const OVERLAP = 150;
const STOP = new Set("a an and are as at be by can do does for from has have how i if in is it its me my no not of on or our so that the their them then there these this to us was we what when where which who why will with you your".split(" "));

const tokens = (s) => String(s).toLowerCase().normalize("NFKD").replace(/[^\p{L}\p{N}\s]/gu, " ").split(/\s+/).filter((w) => w.length > 1 && !STOP.has(w));
const siteFile = (site) => join(DIR, `${String(site).replace(/[^a-z0-9.-]/gi, "_")}.json`);

export function createKnowledge({ apiKey, log = () => {} }) {
  const loaded = new Map(); // site → index (reloaded when the file changes)
  const queryCache = new Map(); // query text → embedding

  async function embed(texts) {
    const out = [];
    for (let i = 0; i < texts.length; i += 96) {
      const r = await fetch("https://api.openai.com/v1/embeddings", {
        method: "POST",
        headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
        body: JSON.stringify({ model: MODEL, dimensions: DIMS, input: texts.slice(i, i + 96) }),
      });
      const j = await r.json();
      if (!r.ok) throw new Error(`embeddings: ${j.error?.message || r.status}`);
      for (const d of j.data) out.push(normalize(Float32Array.from(d.embedding)));
    }
    return out;
  }

  function load(site) {
    const file = siteFile(site);
    if (!existsSync(file)) return null;
    const mtime = statSync(file).mtimeMs;
    const cached = loaded.get(site);
    if (cached?.mtime === mtime) return cached;
    const raw = JSON.parse(readFileSync(file, "utf8"));
    const vec = (b64) => { const b = Buffer.from(b64, "base64"); return new Float32Array(b.buffer.slice(b.byteOffset, b.byteOffset + b.byteLength)); };
    const chunks = raw.chunks.map(({ emb, ...c }) => ({ ...c, vec: vec(emb), toks: tokens(`${c.title} ${c.section} ${c.text}`) }));
    // BM25 statistics
    const df = new Map();
    for (const c of chunks) for (const t of new Set(c.toks)) df.set(t, (df.get(t) || 0) + 1);
    const avg = chunks.reduce((s, c) => s + c.toks.length, 0) / (chunks.length || 1);
    const index = { site, mtime, updatedAt: raw.updatedAt, pages: raw.pages, chunks, df, avg };
    loaded.set(site, index);
    return index;
  }

  async function search(site, query, k = 5) {
    const idx = load(site);
    if (!idx || !query?.trim()) return [];
    const t0 = Date.now();
    let qv = queryCache.get(query);
    if (!qv) {
      try { [qv] = await embed([query]); queryCache.set(query, qv); if (queryCache.size > 500) queryCache.delete(queryCache.keys().next().value); }
      catch (e) { log("knowledge_embed_failed", { error: e.message }); } // keywords alone still work
    }
    const qt = tokens(query);
    const N = idx.chunks.length;
    const scored = idx.chunks.map((c) => {
      let bm = 0;
      const tf = new Map();
      for (const t of c.toks) tf.set(t, (tf.get(t) || 0) + 1);
      for (const t of qt) {
        const f = tf.get(t);
        if (!f) continue;
        const idf = Math.log(1 + (N - idx.df.get(t) + 0.5) / (idx.df.get(t) + 0.5));
        bm += idf * (f * 2.2) / (f + 1.2 * (0.25 + 0.75 * c.toks.length / idx.avg));
      }
      return { c, cos: qv ? dot(qv, c.vec) : 0, bm };
    });
    const maxBm = Math.max(1e-9, ...scored.map((s) => s.bm));
    for (const s of scored) s.score = (qv ? 0.7 * s.cos : 0) + (qv ? 0.3 : 1) * (s.bm / maxBm);
    scored.sort((a, b) => b.score - a.score);
    const out = [], perUrl = new Map();
    for (const s of scored) {
      if (out.length >= k) break;
      if (qv && s.cos < 0.25 && s.bm / maxBm < 0.5) break; // nothing relevant left
      const n = perUrl.get(s.c.url) || 0;
      if (n >= 2) continue; // a spread of pages beats five chunks of one
      perUrl.set(s.c.url, n + 1);
      out.push({ id: s.c.id, title: s.c.title, section: s.c.section, url: s.c.url, text: s.c.text, score: +s.score.toFixed(3) });
    }
    log("knowledge_search", { site, query, ms: Date.now() - t0, hits: out.map((h) => `${h.title} › ${h.section} (${h.score})`) });
    return out;
  }

  async function ingest(site, pages) {
    const chunks = [];
    const seen = new Set();
    for (const p of pages || []) {
      for (const sec of p.sections || []) {
        const text = String(sec.text || "").replace(/\s+/g, " ").trim();
        if (text.length < 40) continue;
        for (let i = 0; i < text.length; i += CHUNK - OVERLAP) {
          let piece = text.slice(i, i + CHUNK);
          if (i > 0) piece = piece.replace(/^\S*\s/, ""); // start on a word
          const key = piece.slice(0, 200);
          if (seen.has(key)) continue; // the same block repeated across pages
          seen.add(key);
          chunks.push({ id: `k${chunks.length + 1}`, url: p.url, title: clean(p.title, 120), section: clean(sec.heading || p.title, 120), text: piece });
          if (i + CHUNK >= text.length) break;
        }
      }
    }
    if (!chunks.length) throw new Error("no text to learn from");
    const t0 = Date.now();
    const vecs = await embed(chunks.map((c) => `${c.title} › ${c.section}\n${c.text}`));
    chunks.forEach((c, i) => (c.emb = Buffer.from(vecs[i].buffer).toString("base64")));
    mkdirSync(DIR, { recursive: true });
    const data = { site, updatedAt: Date.now(), model: MODEL, dims: DIMS, pages: (pages || []).map((p) => ({ url: p.url, title: clean(p.title, 120) })), chunks };
    writeFileSync(siteFile(site), JSON.stringify(data));
    log("knowledge_ingest", { site, pages: data.pages.length, chunks: chunks.length, embed_ms: Date.now() - t0 });
    return { pages: data.pages.length, chunks: chunks.length };
  }

  function status(site) {
    const idx = load(site);
    return idx ? { site, pages: idx.pages.length, chunks: idx.chunks.length, updatedAt: idx.updatedAt } : { site, pages: 0, chunks: 0 };
  }

  return { search, ingest, status, has: (site) => !!load(site), embed };
}

function normalize(v) {
  let n = 0;
  for (let i = 0; i < v.length; i++) n += v[i] * v[i];
  n = Math.sqrt(n) || 1;
  for (let i = 0; i < v.length; i++) v[i] /= n;
  return v;
}
function dot(a, b) {
  let s = 0;
  for (let i = 0; i < a.length; i++) s += a[i] * b[i];
  return s;
}
const clean = (s, max) => String(s || "").replace(/\s+/g, " ").trim().slice(0, max);
