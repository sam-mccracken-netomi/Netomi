// What we've learned about the visitor on a site: their preferences and traits, the way a
// good sales associate remembers a regular ("oily skin, shade 220 Beige, likes fragrance-free,
// usually spends under $40 on skincare").
//
// Each memory is one fact with where it came from:
//   stated    the visitor said it about themselves ("I have oily skin"): used openly
//   inferred  from what they asked or did (a price filter, the products they keep viewing):
//             used quietly, with a confidence that grows only with repeated signals
// The planner model reads new evidence (the visitor's words, what they browsed) against the
// current memory and returns only what changes; nothing is written when nothing durable was
// learned. A stated fact is never overwritten by a guess. Sensitive traits are never kept.
//
// Kept per site (no leakage between sites), in data/memory/<site>.json; Start afresh and
// the settings page clear it.
//
//   memory.learn(site, { said, visits, events })   said: [{ role, text }], visits: pages browsed,
//                    events: what they did by themselves (filters, options picked, add to bag…)
//   memory.summary(site) → text for prompts · memory.facts(site) · remove · forget · sites
//   memory.setAccount(site, { name, email, from }) · who's signed in, for the settings page only
//
// With Adobe RT-CDP on (rtcdp.mjs; settings: memory.rtcdp): the signed-in email is the key.
//   pull(site)  the profile's facts into this site's memory (newer wins, a guess never replaces
//               what they said, facts removed here stay removed); other sites' facts come too,
//               marked with their site. At most every 5 minutes unless forced.
//   push(site)  this site's facts back to the profile with the other sites' kept, a few seconds
//               after anything changes (learning, the account, a removal)

import { readFileSync, writeFileSync, existsSync, mkdirSync, readdirSync, unlinkSync } from "node:fs";
import { join } from "node:path";
import { DATA } from "./env.mjs";
import { nextStep } from "./openai.mjs";
import { prompt } from "./prompts.mjs";
import { fieldOf } from "./rtcdp.mjs";

const DIR = () => join(DATA(), "memory");
const fileOf = (site) => join(DIR(), `${String(site).replace(/[^a-z0-9.-]/gi, "_")}.json`);
const MAX_FACTS = 40;
const MIN_CONFIDENCE = 0.35; // weaker guesses aren't used or shown as known

const UPDATE = {
  name: "update_memory",
  description: "Record what changed in what we know about the visitor. Leave both lists empty when nothing durable was learned.",
  parameters: {
    type: "object",
    properties: {
      facts: {
        type: "array",
        description: "New or changed facts (one per key; a key already known replaces it)",
        items: {
          type: "object",
          properties: {
            key: { type: "string", description: "snake_case, e.g. skin_type, skin_concerns, foundation_shade, undertone, hair_type, clothing_size, shoe_size, preferred_brands, avoids, values, scent_preferences, finish_preference, budget_skincare, shopping_for" },
            label: { type: "string", description: "Short human label, e.g. 'Skin type', 'Foundation shade', 'Budget for skincare'" },
            value: { type: "string", description: "Short value, e.g. 'Oily', '220 Beige (Estée Lauder Double Wear)', 'Under $40'" },
            kind: { type: "string", enum: ["stated", "inferred"] },
            confidence: { type: "number", description: "0-1. Stated: 0.9+. Inferred from one signal: 0.4-0.6; from repeated or strong signals (an explicit price filter): up to 0.8" },
            evidence: { type: "string", description: "The signal, briefly: 'said: \"I have really oily skin\"', 'price filter $0-$40 on moisturizers', 'viewed 4 fragrance-free cleansers'" },
          },
          required: ["key", "label", "value", "kind", "confidence", "evidence"],
        },
      },
      remove: { type: "array", items: { type: "string" }, description: "Keys that turned out wrong or that the visitor asked to forget" },
    },
    required: ["facts", "remove"],
  },
};

// one action, as a line for the model
export function describeEvent(x) {
  // an item named: a product tile's button; none on a product page: that product itself
  const where = x.item && x.product ? ` (a tile on the page of ${x.product})` : x.product ? ` on ${x.product}${x.price ? ` (${x.price})` : ""}` : x.page && x.page !== "page" ? ` on a ${x.page} page` : "";
  const what = {
    filter: `${x.off ? "cleared" : "applied"} filter ${x.group ? `${x.group}: ` : ""}${x.value}`,
    sort: `sorted by ${x.value}`,
    option: `picked ${x.group ? `${x.group}: ` : "option "}${x.value}`,
    add_to_cart: `added to bag${x.item ? `: ${x.item}` : ""}`,
    compare: `compare${x.item ? `: ${x.item}` : ""}`,
    save: `saved / loved${x.item ? `: ${x.item}` : ""}`,
    remove: `removed${x.item ? `: ${x.item}` : ""}`,
  }[x.type] || `${x.type}: ${x.value}`;
  return `${what}${where} · ${String(x.url || "").slice(0, 160)}`;
}

// a profile in plain words: "Taylor Blake (taylor@…). They've told us their skin type is oily, …"
const SURE = (c) => (c >= 0.75 ? "very likely" : c >= 0.55 ? "probably" : "possibly");
function list(items) { return items.length <= 1 ? items.join("") : `${items.slice(0, -1).join(", ")} and ${items.at(-1)}`; }
function phrase(f) {
  const label = String(f.label || f.key).replace(/_/g, " ");
  const l = label.charAt(0).toLowerCase() + label.slice(1);
  // "Oily" → "oily", "Natural, wispy" → "natural, wispy"; brands, shades and names keep their capitals
  const v = !/brand|shade|name|product|label|line/i.test(`${f.key} ${label}`) && /^[A-Z][a-z]+(?:[ ,/-]+[a-z]+)*$/.test(f.value) ? f.value.toLowerCase() : f.value;
  return `${l} ${/s$/.test(l) && !/(ss|us)$/.test(l) ? "are" : "is"} ${v}`;
}
export function narrate(p, site = "") {
  const out = [];
  const who = p.name || "This shopper";
  out.push(`${who}${p.email ? ` (${p.email})` : ""}.`);
  if (p.address?.zip || p.address?.city) out.push(`Their customer record has their home in ${[p.address.city, [p.address.state, p.address.zip].filter(Boolean).join(" ")].filter(Boolean).join(", ")}.`);
  const bySite = new Map();
  for (const f of p.facts || []) { const s = f.site || site || "an unknown site"; if (!bySite.has(s)) bySite.set(s, []); bySite.get(s).push(f); }
  const sites = [...bySite.keys()].sort((a, b) => (b === site) - (a === site));
  for (const s of sites) {
    const fs = bySite.get(s);
    const stated = fs.filter((f) => f.kind === "stated"), inferred = fs.filter((f) => f.kind !== "stated").sort((a, b) => b.confidence - a.confidence);
    const where = sites.length > 1 || s !== site ? `On ${s}, ` : "";
    if (stated.length) out.push(`${where}${where ? "they" : "They"}'ve told us their ${list(stated.map(phrase))}.`);
    if (inferred.length) out.push(`${stated.length || !where ? "" : where}From what they did${stated.length || !where ? "" : ""}, we think their ${list(inferred.map((f) => `${phrase(f)} (${SURE(f.confidence)})`))}.`.replace(/^From/, stated.length || !where ? "From" : "from"));
  }
  if (!(p.facts || []).length) out.push("Nothing about their preferences is on the profile yet.");
  if (p.updatedAt) out.push(`Last updated ${new Date(p.updatedAt).toLocaleString("en-US", { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" })}${p.lastSite ? ` from ${p.lastSite}` : ""}.`);
  return out.join(" ");
}

export const ALLERGY_TALK = /\ballerg|\breact(ion|s)?\b|\bsensitiv|\bbreak(s)? me out|\birritat|\brash\b|\bhives\b|\bintoleran/i;

export function createMemory({ apiKey, model, effort, log = () => {}, cdp = null, cdpOn = () => false }) {
  const queues = new Map(); // site → promise chain (one update at a time per site)
  const pushTimers = new Map();

  const load = (site) => { try { return existsSync(fileOf(site)) ? JSON.parse(readFileSync(fileOf(site), "utf8")) : null; } catch { return null; } };
  const blank = (site) => ({ site, facts: [], lastVisitAt: 0, updatedAt: 0 });
  function save(site, m) {
    mkdirSync(DIR(), { recursive: true });
    writeFileSync(fileOf(site), JSON.stringify(m, null, 2));
  }

  const facts = (site) => (load(site)?.facts || []).filter((f) => f.confidence >= MIN_CONFIDENCE);

  // for prompts: what we know, stated first, with how sure we are
  function summary(site) {
    const fs = facts(site);
    const home = load(site)?.profile?.address;
    const where = home?.zip ? `- Home zip code: ${home.zip}${home.city ? ` (${[home.city, home.state].filter(Boolean).join(", ")})` : ""} (from their customer profile)` : "";
    if (!fs.length && !where) return "";
    const line = (f) => `- ${f.label}: ${f.value}${f.kind === "inferred" ? ` (inferred, ${Math.round(f.confidence * 100)}% sure: ${f.evidence})` : " (they said so)"}`;
    const stated = fs.filter((f) => f.kind === "stated"), inferred = fs.filter((f) => f.kind === "inferred").sort((a, b) => b.confidence - a.confidence);
    return [
      "What we know about this visitor on this site:",
      ...(where ? [where] : []),
      ...stated.map(line), ...inferred.map(line),
      "",
      prompt("memoryUse"),
    ].join("\n");
  }

  // new evidence → the model's changes → saved. Returns the facts that changed.
  function learn(site, { said = [], visits = [], events = [], page = null }) {
    const run = async () => {
      const m = load(site) || blank(site);
      const newVisits = visits.filter((v) => v?.at > (m.lastVisitAt || 0));
      const newEvents = events.filter((x) => x?.at > (m.lastEventAt || 0) && x.type);
      const words = said.filter((t) => t?.text?.trim());
      if (!words.some((t) => t.role === "user" && t.text.split(/\s+/).length >= 3) && newVisits.length < 3 && !newEvents.length) return [];
      const known = m.facts.length ? m.facts.map((f) => `- ${f.key} = ${f.value} [${f.kind}, ${f.confidence}] (${f.evidence})`).join("\n") : "(nothing yet)";
      const input = [
        `Site: ${site}. Today: ${new Date().toISOString().slice(0, 10)}.`,
        "", "What we already know:", known,
      ];
      if (words.length) input.push("", "The conversation since the last update (Visitor = them, Assistant = us):", ...words.map((t) => `${t.role === "user" ? "Visitor" : "Assistant"}: ${t.text}`));
      // "I'm allergic to this": what "this" can be on the product they're looking at
      if (page?.ingredients && words.some((t) => t.role === "user" && ALLERGY_TALK.test(t.text))) input.push("", `The product page they're on: ${page.title || page.url}`, `Its ingredients: ${String(page.ingredients).slice(0, 3000)}`);
      if (newVisits.length) {
        input.push("", "What they browsed since (oldest first; URLs show searches and filters):");
        for (const v of newVisits.slice(-25)) input.push(`- ${v.kind}: ${[v.brand, v.name || v.query || v.heading || v.title].filter(Boolean).join(" ")}${v.category ? ` [${v.category}]` : ""}${v.price ? ` ${v.price}` : ""} · ${v.url}`);
      }
      if (newEvents.length) {
        input.push("", "What they did on the site by themselves (oldest first; their own clicks, not ours):");
        for (const x of newEvents.slice(-40)) input.push(`- ${describeEvent(x)}`);
      }
      const t0 = Date.now();
      const call = await nextStep({ apiKey, model, effort, instructions: prompt("memoryLearn"), tools: [UPDATE], input: [{ role: "user", content: input.join("\n") }], timeoutMs: 45000 });
      const changed = [];
      const now = Date.now();
      for (const key of call.args.remove || []) {
        const i = m.facts.findIndex((f) => f.key === key);
        if (i >= 0) { changed.push({ ...m.facts[i], removed: true }); m.facts.splice(i, 1); (m.removed ||= {})[key] = now; }
      }
      for (const f of call.args.facts || []) {
        if (!f?.key || !f.value) continue;
        const key = String(f.key).toLowerCase().replace(/[^a-z0-9_]/g, "_").slice(0, 40);
        const kind = f.kind === "stated" ? "stated" : "inferred";
        const fact = {
          key, label: String(f.label || key).slice(0, 40), value: String(f.value).slice(0, 120), kind,
          confidence: Math.max(0, Math.min(kind === "stated" ? 1 : 0.85, Number(f.confidence) || 0.5)),
          evidence: String(f.evidence || "").slice(0, 160), updatedAt: now, site,
        };
        const i = m.facts.findIndex((x) => x.key === key);
        if (i >= 0) {
          // a guess never overwrites what they told us
          if (m.facts[i].kind === "stated" && kind === "inferred") continue;
          m.facts[i] = { ...m.facts[i], ...fact, createdAt: m.facts[i].createdAt || now };
        } else m.facts.push({ ...fact, createdAt: now });
        changed.push(fact);
      }
      if (m.facts.length > MAX_FACTS) m.facts = m.facts.sort((a, b) => (b.kind === "stated") - (a.kind === "stated") || b.confidence - a.confidence).slice(0, MAX_FACTS);
      m.lastVisitAt = Math.max(m.lastVisitAt || 0, ...visits.map((v) => v?.at || 0));
      m.lastEventAt = Math.max(m.lastEventAt || 0, ...events.map((x) => x?.at || 0));
      if (changed.length || newVisits.length || newEvents.length) { m.updatedAt = now; save(site, m); }
      if (changed.length) pushSoon(site);
      log("memory_update", { site, ms: Date.now() - t0, changed: changed.map((f) => `${f.removed ? "-" : ""}${f.key}=${f.value} [${f.kind} ${f.confidence ?? ""}]`) });
      return changed;
    };
    const next = (queues.get(site) || Promise.resolve()).then(run, run).catch((e) => { log("memory_failed", { site, error: e.message }); return []; });
    queues.set(site, next);
    return next;
  }

  // who's signed in on the site (name / email the extension found on its pages): shown on the
  // settings page with the facts, never put in a prompt
  function setAccount(site, { name = "", email = "", from = {} } = {}) {
    const m = load(site) || blank(site);
    const prev = m.account || {};
    const acc = { name: String(name || prev.name || "").slice(0, 60), email: String(email || prev.email || "").slice(0, 120).toLowerCase(), from: { name: String(from.name || prev.from?.name || "").slice(0, 80), email: String(from.email || prev.from?.email || "").slice(0, 80) }, seenAt: Date.now() };
    if (!acc.name && !acc.email) return list(site);
    const emailChanged = acc.email && acc.email !== prev.email;
    m.account = acc;
    m.updatedAt = Date.now();
    save(site, m);
    if (emailChanged) pull(site, { force: true }).then(() => pushSoon(site, 1000));
    else if (acc.name !== prev.name) pushSoon(site);
    return list(site);
  }

  // a fact set by hand (the settings page): stated, replaces what was there
  function setFact(site, { key, label, value }) {
    const m = load(site) || blank(site);
    const now = Date.now();
    const fact = { key, label: label || key, value: String(value).slice(0, 120), kind: "stated", confidence: 0.95, evidence: "set on the settings page", updatedAt: now, site };
    const i = m.facts.findIndex((f) => f.key === key);
    if (i >= 0) m.facts[i] = { ...m.facts[i], ...fact }; else m.facts.push({ ...fact, createdAt: now });
    if (m.removed) delete m.removed[key];
    m.updatedAt = now;
    save(site, m);
    return list(site);
  }

  // products we've already told them don't fit (an allergy, a preference): not again for a while
  function warnedRecently(site, product, ms = 12 * 3600e3) { return Date.now() - (load(site)?.warned?.[product] || 0) < ms; }
  function markWarned(site, product) {
    const m = load(site) || blank(site);
    const now = Date.now();
    m.warned = Object.fromEntries(Object.entries({ ...(m.warned || {}), [product]: now }).filter(([, t]) => now - t < 7 * 864e5));
    save(site, m);
  }

  function remove(site, key) {
    const m = load(site);
    if (m && key === "account") { delete m.account; m.updatedAt = Date.now(); save(site, m); }
    else if (m) { m.facts = m.facts.filter((f) => f.key !== key); (m.removed ||= {})[key] = Date.now(); m.updatedAt = Date.now(); save(site, m); pushSoon(site); }
    return list(site);
  }
  function forget(site) { try { unlinkSync(fileOf(site)); } catch {} }
  function sites() {
    if (!existsSync(DIR())) return [];
    return readdirSync(DIR()).filter((f) => f.endsWith(".json")).map((f) => { const m = load(f.slice(0, -5)); return { site: f.slice(0, -5), facts: (m?.facts?.length || 0) + (m?.account ? 1 : 0), updatedAt: m?.updatedAt || 0 }; });
  }
  function forgetAll() { for (const s of sites()) forget(s.site); }
  const list = (site) => {
    const m = load(site) || blank(site);
    return { site, updatedAt: m.updatedAt, facts: m.facts, account: m.account || null, address: m.profile?.address || null, rtcdp: { on: cdpOn(), ...(m.rtcdp || {}) } };
  };

  // ---- Adobe RT-CDP ---------------------------------------------------------------------------
  const pulling = new Map(); // site → promise
  function pull(site, { force = false } = {}) {
    if (!cdpOn() || !cdp) return Promise.resolve([]);
    const m0 = load(site);
    const email = m0?.account?.email;
    if (!email) return Promise.resolve([]);
    if (!force && Date.now() - (m0.rtcdp?.pulledAt || 0) < 20000) return Promise.resolve([]);
    if (pulling.has(site)) return pulling.get(site);
    const run = async () => {
      const t0 = Date.now();
      let p;
      try { p = await cdp.profile(email); } catch (e) {
        const m = load(site) || blank(site);
        m.rtcdp = { ...(m.rtcdp || {}), error: e.message.slice(0, 200), errorAt: Date.now() };
        save(site, m);
        log("rtcdp_pull_failed", { site, error: e.message });
        return [];
      }
      const m = load(site) || blank(site);
      const changed = [];
      if (p.found) {
        for (const rf of p.facts || []) {
          if (!rf?.key || !rf.value) continue;
          const at = Date.parse(rf.updatedAt) || 0;
          const from = rf.site || site;
          if ((m.removed?.[rf.key] || 0) >= at && from === site) continue; // removed here after it was written
          const f = { key: rf.key, label: rf.label || rf.key, value: rf.value, kind: rf.kind === "stated" ? "stated" : "inferred", confidence: Number(rf.confidence) || 0.5,
            evidence: from === site ? rf.evidence || "" : `on ${from}: ${rf.evidence || ""}`.trim(), updatedAt: at || Date.now(), site: from, from: "rtcdp" };
          const i = m.facts.findIndex((x) => x.key === f.key);
          if (i < 0) { m.facts.push(f); changed.push(f); continue; }
          const cur = m.facts[i];
          if (from !== site && (cur.site || site) === site) continue; // this site's own fact wins over another site's
          if (at <= (cur.updatedAt || 0) || cur.value === f.value) continue;
          if (cur.kind === "stated" && f.kind === "inferred") continue;
          m.facts[i] = { ...cur, ...f };
          changed.push(f);
        }
        // the home address (from the customer record): replaces what we had, even when removed
        const was = m.profile?.address?.zip || "", now = p.address?.zip || "";
        m.profile = { address: p.address || null, at: Date.now() };
        if (was !== now) changed.push({ key: "home_zip", label: "Home zip code", value: now ? [now, p.address.city].filter(Boolean).join(", ") : "(removed)", kind: "stated", site, from: "rtcdp" });
        if (p.name && m.account && (!m.account.name || p.name.split(" ").length > m.account.name.split(" ").length)) { m.account.name = p.name; m.account.from = { ...(m.account.from || {}), name: "Adobe RT-CDP profile" }; }
      }
      m.rtcdp = { ...(m.rtcdp || {}), pulledAt: Date.now(), found: !!p.found, error: null };
      if (changed.length) m.updatedAt = Date.now();
      save(site, m);
      // no profile yet, or it lacks something we know here (learned before the sync was on,
      // or a write that failed): write it
      const remote = new Map((p.facts || []).filter((f) => (f.site || site) === site).map((f) => [f.key, f.value]));
      // (or a fact's own field isn't on the profile yet: Adobe takes a while to accept a new field)
      const fieldMissing = p.found && m.facts.some((f) => (f.site || site) === site && f.confidence >= MIN_CONFIDENCE && !p.typed?.[fieldOf(f.key)]);
      const behind = m.facts.some((f) => (f.site || site) === site && remote.get(f.key) !== f.value) || (!p.found && m.account?.name)
        || (fieldMissing && Date.now() - (m.rtcdp?.pushedAt || 0) > 2 * 60e3);
      if (behind) pushSoon(site, 1000);
      log("rtcdp_pull", { site, ms: Date.now() - t0, found: !!p.found, changed: changed.map((f) => `${f.key}=${f.value}${f.site !== site ? ` (${f.site})` : ""}`) });
      return changed;
    };
    const job = (queues.get(site) || Promise.resolve()).then(run, run).finally(() => pulling.delete(site));
    pulling.set(site, job);
    return job;
  }
  // the profile as it is in RT-CDP right now, for the settings page, with a readable summary
  async function remote(site) {
    const m = load(site);
    const email = m?.account?.email;
    if (!cdp || !cdpOn()) return { on: false };
    if (!email) return { on: true, email: null };
    await pull(site, { force: true });
    const p = await cdp.profile(email);
    const cur = load(site) || blank(site);
    cur.rtcdp = { ...(cur.rtcdp || {}), pulledAt: cur.rtcdp?.pulledAt, checkedAt: Date.now(), found: !!p.found };
    save(site, cur);
    if (!p.found) return { on: true, email, found: false, text: `There's no profile for ${email} in Adobe Real-Time CDP yet. It's created the next time something is learned about them.` };
    return { on: true, email, found: true, sandbox: process.env.AEP_SANDBOX_NAME || "", name: p.name, profileEmail: p.email, facts: p.facts, typed: p.typed, address: p.address, lastSite: p.lastSite, updatedAt: p.updatedAt, text: narrate(p, site) };
  }
  function pushSoon(site, ms = 4000) {
    if (!cdpOn() || !cdp || !load(site)?.account?.email) return;
    clearTimeout(pushTimers.get(site));
    pushTimers.set(site, setTimeout(() => { pushTimers.delete(site); push(site); }, ms));
  }
  async function push(site) {
    const m = load(site);
    const email = m?.account?.email;
    if (!cdpOn() || !cdp || !email) return { ok: false, skipped: true };
    const t0 = Date.now();
    try {
      // the other sites' facts as they are on the profile, so they aren't lost
      const p = await cdp.profile(email).catch(() => ({ found: false }));
      const mine = m.facts.filter((f) => (f.site || site) === site).map((f) => ({ ...f, site }));
      const others = (p.facts || []).filter((f) => f.site && f.site !== site);
      const r = await cdp.save(email, { name: m.account.name || p.name || "", facts: [...others, ...mine], site });
      // fields added just now: Profile drops their values until it knows them (minutes), so write again
      if (r.added?.length) for (const min of [5, 15, 30]) setTimeout(() => push(site), min * 60e3).unref?.();
      else if (r.retryLater) pushSoon(site, 3 * 60e3);
      const cur = load(site) || m;
      cur.rtcdp = { ...(cur.rtcdp || {}), ...(r.ok ? { pushedAt: Date.now(), error: null } : { error: `write failed (${r.status})`, errorAt: Date.now() }) };
      save(site, cur);
      log(r.ok ? "rtcdp_push" : "rtcdp_push_failed", { site, ms: Date.now() - t0, facts: mine.length, others: others.length, ...(r.ok ? {} : { status: r.status, error: String(r.error).slice(0, 300) }) });
      return r;
    } catch (e) {
      log("rtcdp_push_failed", { site, error: e.message });
      return { ok: false, error: e.message };
    }
  }

  return { learn, summary, facts, list, remove, forget, forgetAll, sites, setAccount, pull, push, remote, setFact, warnedRecently, markWarned };
}
