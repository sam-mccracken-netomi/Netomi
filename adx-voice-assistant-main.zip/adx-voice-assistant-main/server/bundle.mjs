// The widget is three plain scripts with no build tooling: the voice engine, the page
// agent and the UI. This joins them into the single file a <script> tag, a bookmarklet or
// the extension loads. The extension's offscreen document loads voice.js on its own.
import { readFileSync } from "node:fs";
import { join } from "node:path";
import { ROOT } from "./env.mjs";

const PARTS = ["voice.js", "page-agent.js", "ui.js"];

export function bundle() {
  const src = PARTS.map((f) => readFileSync(join(ROOT, "client", f), "utf8"));
  return `/*! Talk to Website widget, built from client/${PARTS.join(", client/")} */\n(() => {\n"use strict";\n${src.join("\n")}\n})();\n`;
}
