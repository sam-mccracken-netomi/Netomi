// One call to the OpenAI Responses API with function tools: the planner's next step.
// (The newer reasoning models only take function tools through /v1/responses.)

const URL_ = "https://api.openai.com/v1/responses";

export async function nextStep({ apiKey, model, effort, instructions, input, tools, timeoutMs = 30000, hedgeMs = 7000 }) {
  const body = {
    model,
    instructions,
    input,
    tools: tools.map((t) => ({ type: "function", strict: false, ...t })),
    tool_choice: "required",
    parallel_tool_calls: false,
    store: false,
  };
  if (effort) body.reasoning = { effort };
  // one request; resolves { ok, out } or { ok: false, err, fatal }
  const once = async (ctl) => {
    const t0 = Date.now();
    try {
      const r = await fetch(URL_, { method: "POST", signal: ctl.signal, headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" }, body: JSON.stringify(body) });
      const j = await r.json().catch(() => ({}));
      if (r.ok) {
        const call = (j.output || []).find((o) => o.type === "function_call");
        let args = {};
        try { args = JSON.parse(call?.arguments || "{}"); } catch {}
        return { ok: true, out: { name: call?.name || null, args, ms: Date.now() - t0, usage: j.usage } };
      }
      return { ok: false, err: new Error(`${r.status} ${j.error?.message || r.statusText}`), fatal: r.status < 500 && r.status !== 429 };
    } catch (e) {
      return { ok: false, err: e.name === "AbortError" ? new Error("planner timed out") : e };
    }
  };
  let lastErr;
  for (let attempt = 0; attempt < 3; attempt++) {
    const t0 = Date.now();
    // a step usually takes 2–4 s; one that hasn't answered in hedgeMs gets a second, identical
    // request alongside it, and whichever answers first is used (the occasional 20 s step)
    const ctls = [new AbortController()];
    const timer = setTimeout(() => ctls.forEach((c) => c.abort()), timeoutMs);
    const r = await new Promise((resolve) => {
      let pending = 1, hedge = null;
      const settle = (res) => {
        pending--;
        if (res.ok || res.fatal || pending === 0) { clearTimeout(hedge); resolve(res); }
      };
      once(ctls[0]).then(settle);
      hedge = setTimeout(() => { const c = new AbortController(); ctls.push(c); pending++; once(c).then((res) => { if (res.ok) res.out.hedged = true; settle(res); }); }, hedgeMs);
    });
    clearTimeout(timer);
    ctls.forEach((c) => c.abort()); // the slower one isn't needed
    if (r.ok) { r.out.ms = Date.now() - t0; return r.out; }
    lastErr = r.err;
    if (r.fatal) break; // a bad request won't get better
    await new Promise((res) => setTimeout(res, 600 * (attempt + 1)));
  }
  throw lastErr;
}
