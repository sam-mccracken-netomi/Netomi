// One conversation: the GPT-Live session, the transcript, the browser agent and the
// page it operates. It outlives the widget's connection: when a page load drops the
// socket (script-tag mode), the conversation waits GRACE_MS for the next page to
// reconnect with the same id and carries on, mid-task included.
//
// Widget ⇄ server messages beyond audio (see index.mjs for the rest):
//   ← {"type":"message","index","role","text"}       a transcript bubble added or extended
//   ← {"type":"history","messages":[...]}             the whole transcript (on attach)
//   ← {"type":"agent","state":"working"|"idle","note"} the agent is operating the page
//   ← {"type":"page.request","id","op":"snapshot"|"act","args"}
//   → {"type":"page.response","id","ok","result"}
//   → {"type":"page.ready","page"} / {"type":"page.gone"}   (the extension, per page load)
//   → {"type":"turn"} (a push-to-talk press) {"type":"clear"} {"type":"stop"}

import { randomUUID } from "node:crypto";
import { LiveSession } from "./live.mjs";
import { BrowserAgent, helpCard, siteOf } from "./browser-agent.mjs";
import { vetter } from "./links.mjs";
import { instructions, greeting, nudge, brandOf } from "./persona.mjs";
import { prompt } from "./prompts.mjs";
import { nextStep } from "./openai.mjs";
import { knowledgeFor, getSettings } from "./settings.mjs";
import { Sales, LEVELS, WAITS } from "./sales.mjs";

const GRACE_MS = 45000;
const SILENCE = Buffer.alloc(2400); // 50 ms of 24 kHz PCM16
const RECENT_TURNS = 10;
const NUDGE_EVERY_MS = 3 * 60000; // at most one unprompted suggestion this often

class PageGone extends Error {
  constructor(msg) { super(msg); this.navigated = true; }
}

export class Conversation {
  // greet: opened by a click, so the voice speaks first (a greeting, or a welcome back);
  // lastAt: when the visitor last talked with us on this site
  constructor({ id, name, page, history, greet, lastAt, apiKey, voice, planner, log, onEnd, maxMinutes, knowledge, netomi, offers, memory }) {
    this.id = id;
    this.log = log;
    this.onEnd = onEnd;
    this.knowledge = knowledge; // the site's local knowledge base (knowledge.mjs)
    this.netomi = netomi; // Netomi's answers (netomi.mjs), when the settings turn it on for this site
    this.netomiConversation = randomUUID(); // one Netomi conversation per ours, so follow-ups have context
    this.client = null;
    this.ended = false;
    this.messages = (history || []).filter((m) => m?.text).slice(-16).map(({ role, text }) => ({ role, text }));
    this.current = { user: null, agent: null };
    this.breakUser = false;
    this.userWords = []; // { start, text, at }: for working out what a delegation was about
    this.agentSegs = []; // { start, end }: when the voice spoke
    this.lastUserWordAt = 0;
    this.page = page || null;
    this.pageEpoch = 0;
    this.pageUp = false;
    this.pending = new Map();
    this.rpcSeq = 0;
    this.waiters = [];
    this.task = null;
    this.lastSpokenProgress = 0;
    this.lastAgentWordAt = 0;
    this.lastDelegationAt = 0; // when the voice's words last arrived (they come ~real time, a little ahead of the audio)
    this.site = page?.site || null;
    this.visits = Array.isArray(page?.visits) ? page.visits : []; // this site's browsing history, newest last
    this.events = Array.isArray(page?.events) ? page.events : []; // what they did by themselves (filters, options, add to bag…)
    this.startedAt = Date.now();
    this.lastNudge = { at: 0, url: null };
    this.sales = new Sales({ offers, site: this.site, log }); // offers and price drops, when sales is on
    this.lastProactiveAt = 0; // a nudge or a pitch: never two close together
    this.lastTaskEndAt = 0;
    // what we know about the visitor (memory.mjs): learned in the background from what they
    // say and browse, used by the voice and the planner, and to preselect product options
    this.memory = memory;
    this.memoryFrom = this.messages.length; // transcript learned up to here
    this.lastBrowseLearn = 0;
    this.preselected = new Set();
    this.fitChecked = new Set(); // product pages already checked against their allergies and preferences
    this.plannerSetup = { apiKey, model: planner.model, effort: planner.effort };
    const known = this.memoryOn() ? memory.summary(this.site) : "";
    if (this.memoryOn()) this.learnBrowsing(true);
    // the shopper's Adobe RT-CDP profile (if it's on and we know their email): anything new
    // is passed to the voice as background
    this.syncProfile();

    this.voiceSetup = { apiKey, name, voice };
    this.recoveries = 0;
    // Proactive and Assertive sales: the best offer for this page goes into the greeting itself,
    // looked up while the voice connects (it waits at most a moment for it)
    const greetOffer = greet ? this.greetingOffer() : null;
    this.openLive(instructions({ name, page, history, memory: known }), async () => {
      if (!greet || this.greeted) return;
      this.greeted = true;
      const offer = await Promise.race([greetOffer, sleep(900).then(() => null)]).catch(() => null);
      let text = greeting({ site: this.site, page: this.page, visits: this.visits, history: this.messages, lastAt });
      if (offer) { text += `\n${offer.text}`; this.lastProactiveAt = Date.now(); if (offer.card) this.showCard(offer.card); }
      this.log("greeting", { returning: this.messages.length > 0, offer: !!offer });
      this.live.commentary(text, null);
    });

    this.agent = new BrowserAgent({
      apiKey, model: planner.model, effort: planner.effort, fast: planner.fast, log,
      page: {
        snapshot: () => this.rpc("snapshot", {}, 12000),
        act: (actions) => this.rpc("act", { actions }, 60000),
        epoch: () => this.pageEpoch,
        waitForPage: (ms, after) => this.waitForPage(ms, after),
      },
      onProgress: (note, { elapsed }) => this.progress(note, elapsed),
    });
    this.cap = setTimeout(() => {
      this.send({ type: "status", state: "closed", message: `Conversations end after ${maxMinutes} minutes. Talk again to start a new one.` });
      this.end("time cap");
    }, maxMinutes * 60000);
    const bot = knowledgeFor(this.site).netomi;
    if (bot) { this.netomi?.warm(bot); this.netomi?.prefetch(bot, brandOf(this.page)); } // the token before the first question; the common answers ahead
    this.live.connect();
  }

  // the GPT-Live session; onLive runs once it's up
  openLive(text, onLive) {
    const { apiKey, voice } = this.voiceSetup;
    const live = (this.live = new LiveSession({ apiKey, instructions: text, voice, log: this.log }));
    live.on("status", (s) => {
      if (live !== this.live) return; // an earlier session, replaced
      if (s.state === "closed" && s.moderated && !this.ended) return this.recover();
      this.send({ type: "status", ...s });
      if (s.state === "closed") this.end("upstream closed");
      if (s.state === "live") onLive?.();
    });
    live.on("audio", (buf) => live === this.live && this.client?.readyState === 1 && this.client.send(buf, { binary: true }));
    live.on("transcript", (t) => live === this.live && this.onTranscript(t.role, t.delta || "", t.start_ms));
    live.on("delegation", (d) => live === this.live && this.onDelegation(d).catch((e) => this.log("delegation_error", { error: e.message })));
  }

  // The voice service's own moderation stopped a reply (self-harm, violence, sexual content…)
  // and closed the session. Rather than going silent: drop that request (the planner must not
  // act on it), open a new session without the flagged turn (it would be flagged again), and
  // say the safe response from the prompts ("safety"). The visitor's mic and the widget stay
  // connected throughout.
  recover() {
    this.recoveries++;
    this.log("moderated", { recoveries: this.recoveries });
    if (this.recoveries > 3) { this.send({ type: "status", state: "closed", message: "The voice session ended." }); return this.end("moderated"); }
    if (this.task) { this.task.aborted = true; this.task = null; this.send({ type: "agent", state: "idle" }); }
    // the flagged exchange: from their last words on
    const last = this.messages.findLastIndex((m) => m.role === "user");
    const kept = last >= 0 ? this.messages.slice(0, last) : this.messages;
    this.current = { user: null, agent: null };
    this.userWords = [];
    this.agentSegs = [];
    const { name } = this.voiceSetup;
    const known = this.memoryOn() ? this.memory.summary(this.site) : "";
    this.openLive(instructions({ name, page: this.page, history: kept, memory: known }), () => {
      this.live.commentary(prompt("safety", { brand: brandOf(this.page) }), null);
    });
    this.live.connect();
  }

  // ---- the widget's connection ------------------------------------------------------------
  attach(ws, page) {
    if (this.client && this.client !== ws) try { this.client.close(1000, "replaced"); } catch {}
    this.client = ws;
    clearTimeout(this.grace);
    clearInterval(this.silence);
    this.log("attach", { page });
    if (this.live.started) this.send({ type: "status", state: "live", resumed: true });
    this.send({ type: "history", messages: this.messages });
    if (this.task) this.send({ type: "agent", state: "working", note: this.task.note || "" });
    if (page) this.pageReady(page);
  }

  detach(ws) {
    if (this.client !== ws || this.ended) return;
    this.client = null;
    this.pageGone("disconnected");
    this.log("detach", { grace_ms: GRACE_MS });
    // keep the model's input flowing while nobody is connected
    this.silence = setInterval(() => this.live.pushAudio(SILENCE), 50);
    this.grace = setTimeout(() => this.end("nobody came back"), GRACE_MS);
  }

  send(msg) {
    if (this.client?.readyState === 1) this.client.send(JSON.stringify(msg));
  }

  fromClient(data, isBinary) {
    if (isBinary) return this.live.pushAudio(data);
    let msg;
    try { msg = JSON.parse(String(data)); } catch { return; }
    switch (msg.type) {
      case "turn": this.breakUser = true; return;
      case "clear": this.messages = []; this.current = { user: null, agent: null }; return;
      case "stop": return this.end("stopped");
      case "page.ready": return this.pageReady(msg.page);
      case "page.gone": return this.pageGone("navigating");
      case "page.response": {
        const p = this.pending.get(msg.id);
        if (!p) return;
        this.pending.delete(msg.id);
        clearTimeout(p.timer);
        return msg.ok ? p.resolve(msg.result) : p.reject(new Error(String(msg.result || "page error")));
      }
    }
  }

  end(reason) {
    if (this.ended) return;
    this.ended = true;
    this.log("conversation_end", { reason });
    clearTimeout(this.grace);
    clearTimeout(this.cap);
    clearTimeout(this.salesTimer);
    clearInterval(this.silence);
    if (this.task) this.task.aborted = true;
    this.learnNow(); // what they said since the last update
    this.pageGone("ended");
    this.live.close();
    this.onEnd(this);
  }

  // ---- the page the agent operates ------------------------------------------------------------
  pageReady(page) {
    this.page = page || this.page;
    if (Array.isArray(page?.visits)) this.visits = page.visits;
    if (Array.isArray(page?.events)) this.events = page.events;
    this.pageEpoch++;
    this.pageUp = true;
    this.log("page_ready", { epoch: this.pageEpoch, url: this.page?.url, visits: this.visits.length });
    for (const w of this.waiters.splice(0)) w();
    this.learnBrowsing();
    this.syncProfile();
    this.checkFit().catch((e) => this.log("fit_error", { error: e.message }));
    // a task that was waiting for this page carries on (nothing else proactive meanwhile)
    if (/^https?:/.test(this.page?.url || "") && this.resumeParked()) return;
    // one proactive thing per page at most: preselecting options from their preferences,
    // else an offer, else the compare nudge
    this.maybePreselect()
      .then((done) => done || this.maybeSales())
      .then((done) => { if (!done) this.maybeNudge(); })
      .catch((e) => this.log("proactive_error", { error: e.message }));
  }

  // ---- memory ---------------------------------------------------------------------------------
  memoryOn() { return !!this.memory && !!this.site && getSettings().memory.enabled; }

  // after the visitor speaks, once they've paused: what they said goes to memory
  scheduleMemory() {
    clearTimeout(this.memoryTimer);
    this.memoryTimer = setTimeout(() => this.learnNow(), 6000);
  }
  learnNow() {
    clearTimeout(this.memoryTimer);
    if (!this.memoryOn() || this.messages.length <= this.memoryFrom) return;
    const said = this.messages.slice(Math.max(0, this.memoryFrom - 1)).map(({ role, text }) => ({ role, text })); // with the turn before, for context
    this.memoryFrom = this.messages.length;
    const page = { url: this.page?.url, title: this.page?.title, ingredients: this.page?.ingredients };
    this.memory.learn(this.site, { said, visits: this.visits, events: this.events, page }).then((changed) => { if (changed.length) this.log("memory", { changed: changed.map((f) => `${f.removed ? "-" : ""}${f.label}: ${f.value} (${f.kind})`) }); });
  }
  // what they browsed (searches, filters, products), every couple of minutes at most
  learnBrowsing(force = false) {
    if (!this.memoryOn() || (!force && Date.now() - this.lastBrowseLearn < 120000)) return;
    this.lastBrowseLearn = Date.now();
    this.memory.learn(this.site, { said: [], visits: this.visits, events: this.events });
  }

  // the shopper's Adobe RT-CDP profile, on each page load (at most every 20 s): anything new
  // (a zip code changed in Adobe, a preference from another site) goes to the voice as background
  syncProfile() {
    if (!this.memoryOn() || !this.memory.pull) return;
    this.memory.pull(this.site).then((changed) => {
      if (!changed?.length || this.ended) return;
      this.log("rtcdp_pull", { changed: changed.map((f) => `${f.label}: ${f.value}`) });
      if (this.live?.started) this.live.thinking(prompt("memorySynced", { known: this.memory.summary(this.site) }), null);
    }).catch(() => {});
  }

  // A product page (opened by them or by the agent) and we know something a product can
  // contradict (an allergy, an ingredient they avoid, a finish, coverage, values…): the page and
  // its ingredients are checked by a model; if something clearly doesn't fit, the voice mentions
  // it once, politely, after whatever it's saying, and offers an alternative.
  async checkFit() {
    if (!this.memoryOn()) return;
    const path = (u) => String(u || "").split(/[?#]/)[0].replace(/\/$/, "");
    const cur = this.visits.filter((v) => sameUrl(v.url, this.page?.url)).at(-1);
    if (!cur || cur.kind !== "product") return;
    const key = path(cur.url);
    if (this.fitChecked.has(key) || this.memory.warnedRecently?.(this.site, key)) return;
    const prefs = this.memory.facts(this.site).filter((f) => FIT_KEYS.test(f.key) && (f.kind === "stated" || f.confidence >= 0.7));
    if (!prefs.length) return;
    this.fitChecked.add(key);
    const allergic = prefs.some((f) => /allerg|avoid|ingredient/.test(f.key));
    const product = [cur.brand, cur.name].filter(Boolean).join(" ") || this.page?.title || "this product";
    const here = () => !this.ended && path(this.page?.url) === key;
    // the page as the agent sees it (read only: nothing moves), and its ingredients
    let pageText = "";
    try { pageText = String((await this.rpc("peek", {}, 12000))?.text || "").replace(/\nElements:[\s\S]*?\n\nPage text:/, "\nPage text:"); } catch {}
    let ingredients = String(this.page?.ingredients || "").trim(), source = "page";
    if (allergic && ingredients.length < 25 && !/ingredients?/i.test(pageText)) {
      // not on the page anywhere: the agent looks (reading, not scrolling), once nothing else runs
      if (!(await this.waitIdle(60000)) || !here() || !this.live.started) return this.log("fit_check", { product, skipped: "no ingredients on the page" });
      const task = { delegationId: null, request: "(checking ingredients)", aborted: false, note: "", startedAt: Date.now(), auto: true };
      this.task = task;
      let out = null;
      try {
        out = await this.agent.run(prompt("allergyIngredients"), { label: "(checking the ingredients)", recent: this.recent(), visits: this.visits, events: this.events, brand: brandOf(this.page), isAborted: () => task.aborted || !here() });
      } catch (e) { this.log("fit_error", { error: e.message }); }
      if (this.task === task) { this.task = null; this.send({ type: "agent", state: "idle" }); }
      if (out?.status === "done" && String(out.say || "").length >= 25) { ingredients = String(out.say); source = "agent"; }
    }
    if (!here()) return;
    const t0 = Date.now();
    const known = prefs.map((f) => `- ${f.label}: ${f.value} (${f.kind === "stated" ? "they said so" : `inferred, ${Math.round(f.confidence * 100)}%`})`).join("\n");
    const call = await nextStep({
      ...this.plannerSetup, instructions: prompt("fitCheck"), tools: [FIT_TOOL], timeoutMs: 30000,
      input: [{ role: "user", content: `What we know about the shopper:\n${known}\n\nProduct: ${product}\n${ingredients ? `Ingredients: ${ingredients.slice(0, 4000)}\n` : ""}\nThe product page:\n${pageText.slice(0, 6000)}` }],
    });
    const issues = (call.args?.issues || []).filter((x) => x?.preference && x?.detail);
    this.log("fit_check", { product, prefs: prefs.map((f) => f.key), source, ms: Date.now() - t0, issues });
    if (!issues.length) return;
    // allergies first, at most two things (don't overdo it), as plain clauses
    const clause = (t) => String(t).trim().replace(/[.!]+$/, "").replace(/^[A-Z](?=[a-z])/, (c) => c.toLowerCase());
    const said = [...issues].sort((a, b) => (b.kind === "allergy") - (a.kind === "allergy")).slice(0, 2).map((x) => `${clause(x.detail)}, and ${clause(x.preference)}${x.kind === "allergy" ? " (an allergy: say it plainly)" : ""}`).join("; also ");
    // said when nobody's talking (not over the greeting, an answer or them), and only counted as
    // told if they didn't talk over it; then once more at the next quiet moment
    const deadline = Date.now() + 120000; // no quiet moment within 2 minutes: checked again next time
    for (let attempt = 0; attempt < 2; ) {
      if (Date.now() > deadline || !(await this.waitIdle(90000)) || !here()) return;
      await new Promise((r) => setTimeout(r, 2500)); // a task that just finished hands its answer over first
      if (!(await this.bothQuiet(Math.max(0, deadline - Date.now()))) || !here()) return;
      if (this.task) continue; // the agent started on something meanwhile: after it
      attempt++;
      this.lastProactiveAt = Date.now();
      const sentAt = Date.now();
      this.log("fit_warning", { product, issues, attempt });
      this.live.commentary(prompt("fitWarning", { product, issues: said }), null);
      await new Promise((r) => setTimeout(r, 4500));
      if (this.lastUserWordAt < sentAt) { this.memory.markWarned?.(this.site, key); return; }
      this.log("fit_warning_interrupted", { product });
    }
  }
  // until neither the voice nor the visitor has spoken for a moment (true), or maxMs (false)
  async bothQuiet(maxMs, quietMs = 1800) {
    const t0 = Date.now();
    while (!this.ended && Date.now() - t0 < maxMs) {
      if (Date.now() - this.lastAgentWordAt > quietMs && Date.now() - (this.lastUserWordAt || 0) > quietMs) return true;
      await new Promise((r) => setTimeout(r, 150));
    }
    return false;
  }
  // until no task is running (true), or the wait is over / the conversation ended (false)
  async waitIdle(maxMs) {
    const t0 = Date.now();
    while (this.task && !this.ended && Date.now() - t0 < maxMs) await new Promise((r) => setTimeout(r, 400));
    return !this.task && !this.ended;
  }

  // The visitor opened a product by themselves and we know their shade, size or similar:
  // the agent selects the matching option (if there's a clear one) and the voice says so.
  async maybePreselect() {
    const { enabled, preselect } = getSettings().memory;
    if (!enabled || !preselect || !this.memory || !this.live.started || this.task) return false;
    const cur = this.visits.filter((v) => sameUrl(v.url, this.page?.url)).at(-1);
    if (!cur || cur.kind !== "product" || this.preselected.has(cur.url.split(/[?#]/)[0])) return false;
    const prefs = this.memory.facts(this.site).filter((f) => (f.kind === "stated" || f.confidence >= 0.7) && /shade|tone|colou?r|size|fit|scent|finish|coverage|skin_type|hair_type|concern/.test(f.key));
    if (!prefs.length || Date.now() - this.lastUserWordAt < 3000) return false;
    this.preselected.add(cur.url.split(/[?#]/)[0]);
    // picking a shade often changes the address (?Color=…): only another product ends this
    const path = (u) => String(u || "").split(/[?#]/)[0].replace(/\/$/, "");
    const product = path(cur.url);
    const task = { delegationId: null, request: "(preselect options)", aborted: false, note: "", startedAt: Date.now(), auto: true };
    this.task = task;
    this.log("preselect", { url: cur.url, prefs: prefs.map((f) => `${f.label}: ${f.value}`) });
    let out = null;
    try {
      out = await this.agent.run(prompt("memoryPreselect"), {
        label: "(preselected options from their preferences)", recent: this.recent(), visits: this.visits, events: this.events, memory: this.memory.summary(this.site), brand: brandOf(this.page),
        isAborted: () => task.aborted || this.ended || path(this.page?.url) !== product,
      });
    } catch (e) {
      this.log("preselect_error", { error: e.message });
    }
    if (this.task === task) { this.task = null; this.send({ type: "agent", state: "idle" }); }
    const say = String(out?.say || "").trim();
    if (!out || task.aborted || this.ended || out.status !== "done" || !say) return false;
    this.lastProactiveAt = Date.now();
    this.live.commentary(prompt("handoffDone", { say, brand: brandOf(this.page) }), null);
    return true;
  }

  // the info card, where the settings place it
  showCard(card) {
    // an offer card's link: the site's own page only (links.mjs)
    if (card?.kind === "offer") {
      const site = siteOf(this.page?.url || "");
      const url = card.source?.url;
      card = vetter(site, url && siteOf(url) === site ? [url] : []).card(card).card;
    }
    this.send({ type: "card", card: { ...card, placement: getSettings().ui.cardPlacement } });
  }

  // the bag's subtotal, last seen on the cart page
  subtotal() {
    const v = this.visits.filter((x) => x.subtotal).at(-1);
    return v ? Number(String(v.subtotal).replace(/[^\d.]/g, "")) || null : null;
  }

  // The visitor, by themselves, opened a product, a search, the bag or checkout: if sales is
  // on and an offer fits well enough for the level, the voice brings it up. The same quiet
  // rules as the compare nudge: not while the agent works or just after, not right after
  // the visitor spoke.
  // the greeting's offer (Proactive and Assertive), or null
  async greetingOffer() {
    const { enabled, level } = getSettings().sales;
    if (!enabled) return null;
    const interests = this.memoryOn() ? this.memory.facts(this.site).filter((f) => f.confidence >= 0.5).map((f) => `${f.label}: ${f.value}`).slice(0, 6) : [];
    return this.sales.greetingOffer({ page: this.page, visits: this.visits, level, subtotal: this.subtotal(), interests });
  }

  async maybeSales() {
    const { enabled, level } = getSettings().sales;
    if (!enabled) return false;
    const now = Date.now();
    // the higher levels hold back less (sales.mjs LEVELS[level].waits)
    const W = LEVELS[level]?.waits || WAITS;
    const wait = !this.live.started ? "voice not started" : this.task ? "agent working" : now - this.startedAt < W.start ? "conversation just started"
      : now - this.lastTaskEndAt < W.afterTask ? "agent just finished" : now - this.lastUserWordAt < W.afterSpoke ? "visitor just spoke" : now - this.lastProactiveAt < W.afterProactive ? "just suggested something" : null;
    if (wait) {
      this.log("sales_wait", { url: this.page?.url, wait });
      // still on this page in a while, and things are quiet: try again (at most twice per page),
      // so a pitch isn't only for the moment a page loads (the home page they linger on)
      const epoch = this.pageEpoch;
      if (wait !== "voice not started" && (this.salesRetry?.epoch !== epoch || this.salesRetry.n < 2)) {
        this.salesRetry = { epoch, n: this.salesRetry?.epoch === epoch ? this.salesRetry.n + 1 : 1 };
        clearTimeout(this.salesTimer);
        this.salesTimer = setTimeout(() => { if (!this.ended && this.pageEpoch === epoch && this.pageUp) this.maybeSales().catch(() => {}); }, 15000);
      }
      return false;
    }
    // context beyond the page: what we remember they like
    const interests = this.memoryOn() ? this.memory.facts(this.site).filter((f) => f.confidence >= 0.5).map((f) => `${f.label}: ${f.value}`).slice(0, 6) : [];
    const pitch = await this.sales.moment({ page: this.page, visits: this.visits, level, messages: this.messages, subtotal: this.subtotal(), interests });
    if (!pitch || this.task || this.ended || Date.now() - this.lastUserWordAt < 4000) return false;
    this.lastProactiveAt = Date.now();
    if (pitch.card) this.showCard(pitch.card);
    this.live.commentary(pitch.text, null);
    return true;
  }

  // The visitor opened another product by themselves mid-conversation, having viewed
  // others: offer (once in a while) to compare or help. Never while the agent is working
  // or just after it navigated, never right after the visitor spoke, never twice per page.
  maybeNudge() {
    const now = Date.now();
    const cur = this.visits.filter((v) => v.url === this.page?.url).at(-1);
    if (!cur || cur.kind !== "product" || !this.live.started || this.task) return;
    if (now - this.startedAt < 15000 || now - this.lastTaskEndAt < 20000 || now - this.lastUserWordAt < 8000) return;
    if (now - this.lastNudge.at < NUDGE_EVERY_MS || this.lastNudge.url === cur.url || now - this.lastProactiveAt < 45000) return;
    if (!this.visits.some((v) => v.kind === "product" && v.url !== cur.url)) return;
    this.lastNudge = { at: now, url: cur.url };
    this.lastProactiveAt = now;
    this.log("nudge", { url: cur.url });
    this.live.commentary(nudge({ page: this.page, visits: this.visits }), null);
  }

  pageGone(why) {
    this.pageUp = false;
    for (const [id, p] of this.pending) { clearTimeout(p.timer); p.reject(new PageGone(why)); this.pending.delete(id); }
  }

  rpc(op, args, timeoutMs) {
    if (!this.client || !this.pageUp) return Promise.reject(new PageGone("no page connected"));
    const id = ++this.rpcSeq;
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => { this.pending.delete(id); reject(new Error(`the page didn't answer (${op})`)); }, timeoutMs);
      this.pending.set(id, { resolve, reject, timer });
      this.send({ type: "page.request", id, op, args });
    });
  }

  // resolves true once a page is connected (a newer one than `after`, if given)
  waitForPage(ms, after) {
    const ok = () => this.pageUp && this.client && (after === undefined || this.pageEpoch > after);
    if (ok()) return Promise.resolve(true);
    return new Promise((resolve) => {
      const timer = setTimeout(() => resolve(false), ms);
      const check = () => { if (ok()) { clearTimeout(timer); resolve(true); } else this.waiters.push(check); };
      this.waiters.push(check);
    });
  }

  // ---- transcript ---------------------------------------------------------------------------
  // Words arrive per role with start_ms on the session's timeline; the visitor's arrive
  // ~1 s late, often after the reply has begun, so a delta joins its role's current bubble
  // when it continues it in time, even if the other role's bubble came after.
  onTranscript(role, delta, startMs) {
    if (!delta) return;
    if (role === "user") {
      this.userWords.push({ start: startMs ?? Infinity, text: delta });
      if (this.userWords.length > 400) this.userWords.splice(0, 100);
      this.lastUserWordAt = Date.now();
      this.scheduleMemory();
    } else if (role === "agent") {
      this.lastAgentWordAt = Date.now();
      // the watchdog for a promise without a handoff: checked once the voice's line is over
      clearTimeout(this.missedTimer);
      this.missedTimer = setTimeout(() => this.checkMissedHandoff(), MISSED_MS);
    }
    if (role !== "user" && startMs != null) {
      const seg = this.agentSegs.at(-1);
      if (seg && startMs - seg.end < 1500) seg.end = startMs + 200;
      else this.agentSegs.push({ start: startMs, end: startMs + 200 });
      if (this.agentSegs.length > 100) this.agentSegs.shift();
    }
    let m = this.current[role];
    const continues = m && (startMs == null || m.lastMs == null || startMs - m.lastMs < 2500);
    if (role === "user" && this.breakUser) { this.breakUser = false; if (m && m.text.trim()) m = null; }
    if (!m || !continues) {
      m = { role, text: "" };
      this.messages.push(m);
      this.current[role] = m;
    }
    m.text = (m.text + delta).replace(/^\s+/, "");
    if (startMs != null) m.lastMs = startMs;
    this.send({ type: "message", index: this.messages.indexOf(m), role, text: m.text, ...(role === "agent" ? { captions: getSettings().ui.captions } : {}) });
  }

  recent() {
    return this.messages.slice(-RECENT_TURNS).map(({ role, text }) => ({ role, text }));
  }

  // What the visitor asked: the words since the voice last finished speaking before the
  // delegation (it carries only an id). Their transcript lags the audio, so wait for the
  // last words to land first.
  async requestFor(offsetMs) {
    const t0 = Date.now();
    while (Date.now() - t0 < 1800 && Date.now() - this.lastUserWordAt < 700) await sleep(50);
    const D = offsetMs ?? Infinity;
    const before = this.agentSegs.filter((s) => s.end <= D - 300).at(-1)?.end ?? -Infinity;
    const text = this.userWords.filter((w) => w.start > before && w.start <= D + 800).map((w) => w.text).join("").trim();
    return text || [...this.messages].reverse().find((m) => m.role === "user")?.text || "";
  }

  // ---- website tasks -----------------------------------------------------------------------
  async onDelegation({ id, offset_ms }) {
    this.lastDelegationAt = Date.now();
    clearTimeout(this.missedTimer);
    this.live.thinking(prompt("delegated"), null); // don't run ahead with a guess while it works
    const request = await this.requestFor(offset_ms);
    const prev = this.task;
    if (prev) {
      prev.aborted = true;
      if (!prev.auto) this.live.thinking("The visitor's newer request replaces the earlier one, which was dropped.", prev.delegationId);
    }
    this.parked = null; // a new request: whatever was waiting for a slow page is dropped
    // "report this session": the widget opens its report box; the visitor types what went wrong
    if (REPORT.test(request)) {
      this.log("report_open", { request });
      this.send({ type: "report.open" });
      this.live.commentary(prompt("reportOpen"), id);
      return;
    }
    const task = { delegationId: id, request, aborted: false, note: "", startedAt: Date.now() };
    this.task = task;
    this.log("delegation_request", { id, offset_ms, request });
    await this.work(task);
  }

  // runs the agent on a task and hands its answer to the voice (earlier: steps already taken)
  async work(task, earlier = []) {
    const { request } = task;
    this.send({ type: "agent", state: "working", note: "" });
    // an answer that isn't ready soon gets one short holding line, so the acknowledgement
    // isn't followed by a long silence; fast answers follow the acknowledgement directly
    // (said when the agent starts on the page or the help center, or at HOLD_MS at the latest:
    // an answer from the knowledge base is ready by ~3 s and needs none)
    if (!task.auto && !task.recovered) task.holdTimer = setTimeout(() => this.hold(task), HOLD_MS);
    let out;
    try {
      // the knowledge search runs alongside the agent's first look at the page
      const use = knowledgeFor(this.site);
      const kb = use.local && this.knowledge && this.site && this.knowledge.has(this.site) ? this.knowledge.search(this.site, request, 5) : Promise.resolve([]);
      const { enabled, level } = getSettings().sales;
      const sales = enabled ? this.sales.plannerBlock({ request, page: this.page, visits: this.visits, level, subtotal: this.subtotal() }) : Promise.resolve(null);
      const memory = this.memoryOn() ? this.memory.summary(this.site) : "";
      out = await this.agent.run(request, { recent: this.recent(), visits: this.visits, events: this.events, knowledge: kb, help: this.helpFor(request, use.netomi), sales, memory, brand: brandOf(this.page), earlier, isAborted: () => task.aborted || this.ended });
    } catch (e) {
      this.log("agent_error", { error: e.message });
      out = { status: "cannot", say: "Something went wrong while I was working on the page." };
    }
    clearTimeout(task.holdTimer);
    if (!out || task.aborted || this.ended) return;
    // don't talk over the voice: hand the answer over once it's finished its line
    // a holding line just sent: let it be said first (the voice takes ~1.5 s to start), so the
    // answer comes after it with a beat rather than in the same breath
    const t0 = Date.now();
    if (task.held) while (this.lastAgentWordAt < task.held && Date.now() - t0 < 2500) await sleep(80);
    const waited = Date.now() - t0 + await this.whenQuiet();
    if (task.aborted || this.ended) return;
    if (waited) this.log("handoff_wait", { ms: waited });
    this.task = null;
    this.lastTaskEndAt = Date.now();
    this.send({ type: "agent", state: "idle" });
    // a page that's slow to load: say so, and carry on when it arrives (see pageReady)
    if (out.status === "waiting") this.parked = { request, steps: out.steps || [], at: Date.now(), tries: (task.tries || 0) + 1 };
    // what came from the knowledge base (not the page) also shows on screen, as a card
    if (out.card) { this.log("card", { card: out.card }); this.showCard(out.card); }
    if (out.help && !out.help.answer.done) this.streamCard(out.help);
    const framed = prompt({ done: "handoffDone", need_info: "handoffNeedInfo", cannot: "handoffCannot" }[out.status] || "handoffDone", { say: out.say, brand: brandOf(this.page) });
    this.live.commentary(out.card ? `${framed} ${prompt("handoffCard")}` : framed, task.delegationId);
  }

  // the slow page arrived: pick the task up where it left off (within 3 minutes, at most
  // twice, and only if the visitor hasn't asked for something else meanwhile)
  resumeParked() {
    const p = this.parked;
    if (!p || this.task || this.ended) return false;
    this.parked = null;
    if (Date.now() - p.at > 3 * 60000 || p.tries > 2) return false;
    this.log("task_resume", { request: p.request, after_ms: Date.now() - p.at });
    const task = { delegationId: null, request: p.request, aborted: false, note: "", startedAt: Date.now(), auto: true, tries: p.tries };
    this.task = task;
    this.work(task, [...p.steps, { why: "Waited for the page to load", actions: [], results: ["the page has loaded now; carry on with the request from here"] }])
      .catch((e) => this.log("resume_error", { error: e.message }));
    return true;
  }

  // Netomi, for the agent: a question that looks like it's for the help center is sent at
  // once, so Netomi works while the planner takes its first step; when the planner then asks
  // the help center, it gets that answer already on its way
  helpFor(request, bot) {
    if (!this.netomi || !bot) return null;
    const likely = looksLikeHelpQuestion(request);
    // a follow-up ("what about sale items?") leans on the conversation: never from the cache
    const ask = (q, standalone) => this.netomi.ask(q, bot, { conversationId: this.netomiConversation, useCache: standalone });
    let early = likely ? ask(request, !FOLLOW_UP.test(request) && request.split(/\s+/).length >= 4) : null;
    if (early) this.log("netomi_early", { request });
    return {
      likely,
      ask: (question) => {
        if (early) { const a = early; early = null; return a; }
        return ask(question, true);
      },
    };
  }

  // the rest of a help-center answer, as it streams in, on the card already on screen
  streamCard({ answer, title }) {
    let timer = null;
    const push = () => { timer = null; this.showCard({ ...helpCard(answer, title), update: true }); };
    const off = answer.onUpdate(() => {
      if (answer.done) { off(); clearTimeout(timer); return push(); }
      timer ||= setTimeout(push, 400);
    });
  }

  // the voice has said nothing for a moment (its words arrive a little ahead of the audio);
  // resolves with how long it waited, at most 3 s
  async whenQuiet(quietMs = 1000, maxMs = 3000) {
    const t0 = Date.now();
    while (Date.now() - this.lastAgentWordAt < quietMs && Date.now() - t0 < maxMs) await sleep(80);
    return Date.now() - t0;
  }

  // the holding line: once per task, only while the voice is quiet (if it's still talking,
  // it isn't a silence to fill)
  hold(task, tries = 0) {
    if (this.task !== task || task.aborted || this.ended || task.held) return;
    if (Date.now() - this.lastAgentWordAt < 1200 || Date.now() - this.lastUserWordAt < 1200) {
      if (tries < 3) task.holdTimer = setTimeout(() => this.hold(task, tries + 1), 700);
      return;
    }
    task.held = Date.now();
    this.lastSpokenProgress = Date.now();
    this.log("holding", { after_ms: Date.now() - task.startedAt });
    this.live.commentary(prompt("holding", { request: task.request }), null);
  }

  // The voice said it would do something ("I'll pick a few for you") but never handed it to
  // the app, so nothing would happen. A moment after its line ends with no handoff since the
  // visitor spoke, the app takes the request itself and answers through the voice.
  checkMissedHandoff() {
    if (this.ended || this.task || !this.live.started) return;
    const now = Date.now();
    if (now - this.lastAgentWordAt < MISSED_MS - 100) return;           // still talking
    if (this.lastUserWordAt > this.lastAgentWordAt) return;              // they spoke again: the voice will handle it
    if (this.lastDelegationAt > this.lastUserWordAt - 8000) return;      // this turn was handed over
    if (now - this.lastUserWordAt > 30000) return;
    const i = this.messages.findLastIndex((m) => m.role === "user");
    const said = this.messages.slice(i + 1).filter((m) => m.role === "agent").map((m) => m.text).join(" ");
    const request = this.messages[i]?.text?.trim();
    if (i < 0 || !request || !PROMISE.test(said) || SMALL_TALK.test(request)) return;
    if (this.lastProactiveAt > this.lastUserWordAt) return; // a pitch or nudge of its own, not an answer
    this.log("missed_handoff", { request, said: said.slice(0, 200) });
    this.lastDelegationAt = now;
    const task = { delegationId: null, request, aborted: false, note: "", startedAt: now, recovered: true };
    this.parked = null;
    this.task = task;
    this.work(task).catch((e) => this.log("recover_error", { error: e.message }));
  }

  progress(note, elapsed) {
    if (this.task) this.task.note = note;
    // the agent is on the page now (or asking the help center): the holding line, if the
    // answer has taken a moment already
    const t = this.task;
    if (t && !t.held && !t.auto && !t.recovered) { clearTimeout(t.holdTimer); t.holdTimer = setTimeout(() => this.hold(t), Math.max(0, 2000 - elapsed)); }
    this.send({ type: "agent", state: "working", note });
    // long page tasks get one short spoken update, so the silence doesn't feel stuck. Not for
    // answers on their way from the help center (an extra line just before the answer is
    // noise: the orb and panel already show it's checking), and once per task at most
    if (/help center/i.test(note) || this.task?.spokeProgress) return;
    if (elapsed > 12000 && Date.now() - this.lastSpokenProgress > 8000) {
      if (this.task) this.task.spokeProgress = true;
      this.lastSpokenProgress = Date.now();
      this.live.commentary(prompt("progress", { note }), null);
    }
  }
}

const HOLD_MS = 5000; // the latest the holding line comes, after the request is worked out
const REPORT = /\b(report|flag) (this |the |a |an |that )?(session|conversation|chat|bug|glitch)\b|\b(report|flag) (this|that|it)[\s.!]*$|\b(file|send|make|raise|submit) (a |an )?(bug|session) report\b|\breport (a |an )?(problem|issue) with (you|this assistant|the assistant|the voice|this session)\b/i;
const SMALL_TALK = /^(hi|hello|hey|thanks|thank you|thx|bye|goodbye|see you|how are you|good (morning|afternoon|evening)|nice|cool|great|awesome|perfect|never ?mind)\b[^?]{0,25}$/i;
const MISSED_MS = 2500; // after the voice's last word, with no handoff: the watchdog acts
// the voice saying it will do or look up something (it should have handed it over)
const PROMISE = /\b(i'?ll|i will|let me|lemme|i'?m (going to|gonna|just|on it|checking|looking|pulling|searching|finding|getting|picking|grabbing)|one (sec|second|moment)|hang on|just a (sec|second|moment)|give me a (sec|second|moment)|on it|pulling (those|them|that|some|a few)|checking (that|on|now)|looking (that up|into (it|that)))\b/i;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
// what a product can contradict: allergies, ingredients they avoid, finish, coverage, values…
const FIT_KEYS = /allerg|avoid|ingredient|finish|coverage|vegan|cruelty|value|fragrance|scent|skin_type|formula|texture|gluten|alcohol|silicone|paraben|sulfate/;
const FIT_TOOL = {
  name: "fit_check",
  description: "What, if anything, about this product clearly conflicts with what we know about the shopper.",
  parameters: {
    type: "object",
    properties: {
      issues: {
        type: "array", description: "Empty if nothing clearly conflicts",
        items: { type: "object", properties: {
          preference: { type: "string", description: "What we know, as said to them, e.g. \"you mentioned you're allergic to charcoal\", \"you prefer a matte finish\"" },
          detail: { type: "string", description: "What the product has, e.g. \"it lists Charcoal Powder\", \"it has a dewy finish\"" },
          kind: { type: "string", enum: ["allergy", "preference"] },
        }, required: ["preference", "detail", "kind"] },
      },
    },
    required: ["issues"],
  },
};
const sameUrl = (a, b) => !!a && !!b && String(a).split(/[?#]/)[0].replace(/\/$/, "") === String(b).split(/[?#]/)[0].replace(/\/$/, "");

// Is this request probably a question for the help center? Only a guess, to get Netomi going
// early; the planner decides whether to use it. Wrong guesses cost one unused Netomi call.
const POLICY = /\b(return|refund|exchange|ship|shipping|deliver|delivery|track|order status|my order|reward|points|beauty insider|loyalty|member|gift card|pay|payment|afterpay|klarna|paypal|price (match|adjust)|promo|coupon|discount code|store hours|pick ?up|same[- ]day|cancel|subscription|warranty|policy|policies|privacy|account|password|customer service|contact|sample|birthday|international|tax|damaged|missing)\b/i;
const ACTION = /^(please\s+|can you\s+|could you\s+|i want to\s+|i'd like to\s+|let's\s+)?(add|search|find|show|open|go|take|click|select|pick|choose|buy|book|compare|scroll|sort|filter|put|remove|check ?out|navigate|sign|log|look for|get me)\b/i;
const QUESTION = /\?\s*$|^(what|how|when|where|why|which|who|can|could|do|does|did|is|are|will|would|should|may)\b/i;
const ON_SCREEN = /\b(this|these|that one|it)\b/i;
const FOLLOW_UP = /^(and|also|but|so|what about|how about|same|then)\b/i;
function looksLikeHelpQuestion(request) {
  const r = String(request).trim();
  if (POLICY.test(r)) return !ACTION.test(r) || /\b(policy|how|when|can i|do you)\b/i.test(r);
  return QUESTION.test(r) && !ACTION.test(r) && !ON_SCREEN.test(r) && r.split(/\s+/).length >= 4;
}
