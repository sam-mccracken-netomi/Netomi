// Talk to Website: the relay server.
//  - GET /widget.js  the drop-in widget (load it from any page with a <script> tag)
//  - GET /           a test page with the widget, a bookmarklet and setup notes
//  - GET/PUT /prompts  the prompts, editable from the extension's settings page (also at /settings)
//  - GET/PUT /config  settings: where knowledge answers come from (local, Netomi, both) and
//                    the Netomi bot; POST /config/netomi-test asks the bot a test question
//  - /offers/<site>/{ingest,status,list,remove}  the offers repository (sales.mjs uses it;
//                    the extension's Scan offers collects the pages)
//  - /memory[/<site>[/learn|account|remove|forget]]  what we've learned about the visitor (memory.mjs);
//                    the extension and this machine only
//  - /sitemap/<site>/{status,ingest}  the site's own pages from its sitemaps (sitemap.mjs),
//                    collected by the extension; only these and the knowledge base's links
//                    are ever given to the visitor (links.mjs)
//  - /knowledge/<site>/{ingest,status,search}  the local knowledge base (help pages the
//                    extension crawled in the visitor's own browser; see knowledge.mjs)
//  - /reports      problem reports: POST /reports (the widget's "Report a problem": the note,
//                    with that conversation's logs, saved under logs/reports/); GET /reports,
//                    /reports/<id>.json|.txt for the settings page (the extension and this machine only)
//  - WS  /live       conversations: GPT-Live voice relayed both ways, plus the browser
//                    agent operating the page through the widget
//
// Widget → server on /live:
//   {"type":"start","conversationId","name","page":{"url","title"},"history":[...]}  first
//   binary: PCM16 mono 24 kHz mic audio (silence while not talking)
//   + the conversation messages in conversation.mjs
// Server → widget: binary agent audio, {"type":"status","state":"live"|"warning"|"error"|"closed"},
//   and the conversation messages.
// A start with the id of a conversation that's still alive (its page just reloaded)
// reattaches to it. The OpenAI key stays here: GPT-Live doesn't take browser tokens.

import http from "node:http";
import { readFileSync, existsSync, mkdirSync, appendFileSync } from "node:fs";
import { join } from "node:path";
import { WebSocketServer } from "ws";
import { loadEnv, ROOT } from "./env.mjs";
import { Conversation } from "./conversation.mjs";
import { sitemap } from "./sitemap.mjs";
import { bundle } from "./bundle.mjs";
import { createKnowledge } from "./knowledge.mjs";
import { listPrompts, savePrompts } from "./prompts.mjs";
import { createNetomi } from "./netomi.mjs";
import { createOffers } from "./offers.mjs";
import { createReports } from "./reports.mjs";
import { createMemory } from "./memory.mjs";
import { createRtcdp } from "./rtcdp.mjs";
import { getSettings, saveSettings, knowledgeFor } from "./settings.mjs";

loadEnv();
const PORT = Number(process.env.PORT || 5179);
const HOST = process.env.HOST || "127.0.0.1";
const LOGS = process.env.LOG_DIR || join(ROOT, "logs");
const NAME = process.env.ASSISTANT_NAME || "Assistant";
const VOICE = process.env.VOICE || "marin";
const PLANNER = {
  model: process.env.PLANNER_MODEL || "gpt-6.1-sol", effort: process.env.PLANNER_EFFORT || "low",
  // answering from the knowledge base: a faster model that stays grounded (gpt-4.1 didn't)
  fast: { model: process.env.PLANNER_FAST_MODEL || "gpt-6-luna", effort: process.env.PLANNER_FAST_EFFORT || "low" },
};
// spend guards: anything that can reach this server can open sessions on the key
const MAX_SESSIONS = Number(process.env.MAX_SESSIONS || 5);
const MAX_SESSION_MIN = Number(process.env.MAX_SESSION_MIN || 20);
const ALLOWED = (process.env.ALLOWED_ORIGINS || "*").split(",").map((s) => s.trim()).filter(Boolean);
mkdirSync(LOGS, { recursive: true });
const serverLog = (kind, data = {}) => appendFileSync(join(LOGS, "server.jsonl"), JSON.stringify({ at: new Date().toISOString(), kind, ...data }) + "\n");
const knowledge = createKnowledge({ apiKey: process.env.OPENAI_API_KEY, log: serverLog });
const netomi = createNetomi({ embed: knowledge.embed, log: serverLog });
// Adobe RT-CDP as the memory's long-term home (when .env has its credentials and IDs, and
// the setting is on): pulled when the signed-in email is known, pushed after changes
const rtcdp = createRtcdp({ log: serverLog });
const memory = createMemory({ apiKey: process.env.OPENAI_API_KEY, model: PLANNER.model, effort: PLANNER.effort, log: serverLog, cdp: rtcdp, cdpOn: () => rtcdp.configured() && getSettings().memory.enabled && getSettings().memory.rtcdp });
const offers = createOffers({ apiKey: process.env.OPENAI_API_KEY, model: PLANNER.model, effort: PLANNER.effort, embed: knowledge.embed, log: serverLog });
// problem reports go to the issue tracker (REPORTS_URL); ones that couldn't be sent are retried
const reports = createReports({ logs: LOGS, getSettings, log: serverLog });
setTimeout(() => reports.retry(), 15000).unref?.();
setInterval(() => reports.retry(), 5 * 60e3).unref?.();
const warmNetomi = () => { const k = getSettings().knowledge; if (k.mode !== "local") netomi.warm(k.netomi); };
warmNetomi();

function json(res, code, body) {
  res.writeHead(code, { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "Content-Type", "Access-Control-Allow-Methods": "GET, POST, PUT, OPTIONS" });
  res.end(JSON.stringify(body));
}
function readBody(req, max = 20 << 20) {
  return new Promise((resolve, reject) => {
    let size = 0;
    const parts = [];
    req.on("data", (d) => { size += d.length; if (size > max) { reject(new Error("too large")); req.destroy(); } else parts.push(d); });
    req.on("end", () => { try { resolve(JSON.parse(Buffer.concat(parts).toString("utf8") || "{}")); } catch (e) { reject(e); } });
    req.on("error", reject);
  });
}

// Only the extension (or this machine) may change the prompts: a website's page could
// otherwise rewrite what the assistant is told.
const trusted = (origin) => !origin || /^chrome-extension:\/\//.test(origin) || /^https?:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/.test(origin);
async function promptsRoute(req, res) {
  if (req.method === "OPTIONS") return json(res, 204, {});
  if (req.method === "GET") return json(res, 200, listPrompts());
  if (req.method !== "PUT") return json(res, 405, { error: "GET or PUT" });
  if (!trusted(req.headers.origin)) return json(res, 403, { error: "prompts can only be changed from the extension" });
  try {
    const list = savePrompts((await readBody(req, 1 << 20)).edits);
    console.log(`prompts saved (${list.filter((p) => p.edited).length} edited)`);
    return json(res, 200, list);
  } catch (e) {
    return json(res, 400, { error: e.message });
  }
}

// GET /config: the settings; PUT /config: save them (the extension or this machine only);
// POST /config/netomi-test { question, netomi? }: ask the bot (the form's values, unsaved)
async function configRoute(req, res, url) {
  if (req.method === "OPTIONS") return json(res, 204, {});
  if (req.method === "GET" && url.pathname === "/config") return json(res, 200, { ...getSettings(), available: { rtcdp: rtcdp.configured() } });
  if (!trusted(req.headers.origin)) return json(res, 403, { error: "settings can only be changed from the extension" });
  try {
    const body = await readBody(req, 1 << 16);
    if (req.method === "PUT" && url.pathname === "/config") {
      const s = saveSettings(body);
      console.log(`settings saved (knowledge: ${s.knowledge.mode})`);
      warmNetomi();
      return json(res, 200, s);
    }
    if (req.method === "POST" && url.pathname === "/config/netomi-test") {
      const bot = { ...getSettings().knowledge.netomi, ...(body.netomi || {}) };
      if (!bot.botId || !bot.refId) return json(res, 400, { error: "Enter the bot ID and bot ref ID first." });
      const t0 = Date.now();
      await netomi.token(bot).catch((e) => { throw Object.assign(e, { tokenFailed: true }); });
      const tokenMs = Date.now() - t0;
      const a = netomi.ask(String(body.question || "What is your return policy?").slice(0, 300), bot, { useCache: false });
      await a.partial();
      const spokenMs = Date.now() - a.startedAt;
      await a.finished;
      return json(res, 200, { tokenMs, firstMs: a.firstAt ? a.firstAt - a.startedAt : null, spokenMs, totalMs: Date.now() - a.startedAt, answered: a.answered(), text: a.text, link: a.link, error: a.error });
    }
    return json(res, 404, { error: "unknown settings action" });
  } catch (e) {
    return json(res, 400, { error: e.message });
  }
}

// /offers: every site's offers status; /offers/<site>/{status,list,ingest,remove}
async function offersRoute(req, res, url) {
  const [, , site, action] = url.pathname.split("/");
  if (req.method === "OPTIONS") return json(res, 204, {});
  try {
    if (!site) return json(res, 200, offers.sites());
    if (action === "status") return json(res, 200, { ...offers.status(site), sales: getSettings().sales });
    if (action === "list") return json(res, 200, offers.list(site));
    if (req.method !== "POST") return json(res, 405, { error: "POST" });
    if (!trusted(req.headers.origin)) return json(res, 403, { error: "offers can only be changed from the extension" });
    const body = await readBody(req);
    if (action === "ingest") {
      console.log(`reading ${site}'s offers: ${body.pages?.length || 0} pages…`);
      const r = await offers.ingest(site, body.pages);
      console.log(`${site}: ${r.offers} offers, ${r.drops} price drops`);
      return json(res, 200, r);
    }
    if (action === "remove") return json(res, 200, offers.remove(site, String(body.id || "")));
    return json(res, 404, { error: "unknown offers action" });
  } catch (e) {
    return json(res, 400, { error: e.message });
  }
}

// /memory: sites with memories; /memory/<site>: its facts; POST /memory/<site>/{learn,remove,forget},
// POST /memory/forget-all. Personal: only the extension and this machine may read it, so
// no website can fetch it from the relay.
async function memoryRoute(req, res, url) {
  const [, , site, action] = url.pathname.split("/");
  if (req.method === "OPTIONS") return json(res, 204, {});
  if (!trusted(req.headers.origin)) return json(res, 403, { error: "memory is only available to the extension" });
  try {
    if (req.method === "GET" && action === "rtcdp") return json(res, 200, await memory.remote(site));
    if (req.method === "GET") return json(res, 200, site ? memory.list(site) : memory.sites());
    if (req.method !== "POST") return json(res, 405, { error: "GET or POST" });
    const body = await readBody(req, 1 << 16).catch(() => ({}));
    if (site === "forget-all") { memory.forgetAll(); return json(res, 200, []); }
    if (action === "learn") {
      // browsing and actions the extension saw, voice on or off
      if (!getSettings().memory.enabled) return json(res, 200, { changed: [], off: true });
      const changed = await memory.learn(site, { visits: Array.isArray(body.visits) ? body.visits.slice(-50) : [], events: Array.isArray(body.events) ? body.events.slice(-80) : [] });
      return json(res, 200, { changed });
    }
    if (action === "account") {
      // who's signed in on the site; kept for the settings page, not used in prompts
      if (!getSettings().memory.enabled) return json(res, 200, { off: true });
      return json(res, 200, memory.setAccount(site, { name: typeof body.name === "string" ? body.name : "", email: typeof body.email === "string" ? body.email : "", from: body.from && typeof body.from === "object" ? body.from : {} }));
    }
    if (action === "address") {
      // TEMPORARY (demo): change the home address in Adobe's customer records, as a CRM would
      const email = memory.list(site).account?.email;
      if (!rtcdp.configured() || !rtcdp.crmConfigured()) return json(res, 400, { error: "RT-CDP customer records aren't set up" });
      if (!email) return json(res, 400, { error: "we don't know this visitor's email yet" });
      const clean = (v) => String(v || "").trim().slice(0, 60);
      if (!/^[A-Za-z0-9 -]{3,10}$/.test(clean(body.zip))) return json(res, 400, { error: "enter a zip code" });
      const r = await rtcdp.saveAddress(email, { zip: clean(body.zip), city: clean(body.city), state: clean(body.state) });
      serverLog("rtcdp_address", { site, ok: r.ok, status: r.status });
      return json(res, r.ok ? 200 : 502, r.ok ? { ok: true } : { error: `Adobe said ${r.status}` });
    }
    if (action === "allergies") {
      // TEMPORARY (demo): change or clear their allergies, here and in Adobe right away
      if (!memory.list(site).account?.email) return json(res, 400, { error: "we don't know this visitor's email yet" });
      const value = String(body.value || "").replace(/\s+/g, " ").trim().slice(0, 120);
      if (value) memory.setFact(site, { key: "allergies", label: "Allergies", value });
      else memory.remove(site, "allergies");
      const r = await memory.push(site);
      serverLog("allergies_set", { site, cleared: !value, ok: !!r?.ok });
      return json(res, r?.ok ? 200 : 502, r?.ok ? { ok: true } : { error: r?.error || "couldn't write to Adobe" });
    }
    if (action === "remove") return json(res, 200, memory.remove(site, String(body.key || "")));
    if (action === "forget") { memory.forget(site); return json(res, 200, memory.list(site)); }
    return json(res, 404, { error: "unknown memory action" });
  } catch (e) {
    return json(res, 400, { error: e.message });
  }
}

// /sitemap/<site>/status, POST /sitemap/<site>/ingest { urls } (the extension only)
async function sitemapRoute(req, res, url) {
  const [, , site, action] = url.pathname.split("/");
  if (req.method === "OPTIONS") return json(res, 204, {});
  try {
    if (!site) return json(res, 400, { error: "site" });
    if (action === "status") return json(res, 200, sitemap.status(site));
    if (action === "ingest" && req.method === "POST") {
      if (!trusted(req.headers.origin)) return json(res, 403, { error: "the sitemap can only be changed from the extension" });
      const body = await readBody(req, 16 << 20);
      const r = sitemap.ingest(site, Array.isArray(body.urls) ? body.urls : [], Array.isArray(body.nav) ? body.nav : [], !!body.search);
      console.log(`${site}: ${r.urls} pages from its sitemap, ${r.nav} menu links`);
      return json(res, 200, r);
    }
    return json(res, 404, { error: "unknown sitemap action" });
  } catch (e) {
    return json(res, 400, { error: e.message });
  }
}

async function knowledgeRoute(req, res, url) {
  const [, , site, action] = url.pathname.split("/"); // /knowledge/<site>/<action>
  if (req.method === "OPTIONS") return json(res, 204, {});
  try {
    if (action === "status") {
      const use = knowledgeFor(site); // which source answers here, for the chat panel
      return json(res, 200, { ...knowledge.status(site), answers: use.netomi ? (use.local ? "both" : "netomi") : "local" });
    }
    if (action === "search") return json(res, 200, await knowledge.search(site, url.searchParams.get("q") || "", Number(url.searchParams.get("k") || 5)));
    if (action === "ingest" && req.method === "POST") {
      const body = await readBody(req);
      console.log(`learning ${site}: ${body.pages?.length || 0} pages…`);
      const r = await knowledge.ingest(site, body.pages);
      console.log(`learned ${site}: ${r.pages} pages, ${r.chunks} passages`);
      return json(res, 200, r);
    }
    return json(res, 404, { error: "unknown knowledge action" });
  } catch (e) {
    return json(res, 400, { error: e.message });
  }
}

// a report can come from any allowed page (the widget in script-tag mode), but only the
// extension and this machine can read them back: they hold what the visitor said and did
async function reportsRoute(req, res, url) {
  if (req.method === "OPTIONS") return json(res, 204, {});
  try {
    if (req.method === "POST" && url.pathname === "/reports") {
      if (!originOk(req.headers.origin || "") && !trusted(req.headers.origin)) return json(res, 403, { error: "not allowed" });
      const body = await readBody(req, 2 << 20);
      const r = await reports.create({ ...body, userAgent: req.headers["user-agent"] });
      const conv = r.conversationId && conversations.get(r.conversationId);
      if (conv && !conv.ended) conv.log("report", { id: r.id, note: String(body.note || "").slice(0, 300) });
      serverLog("report", { id: r.id, site: body.site, sessions: r.sessions, sent: r.sent, queued: !!r.queued });
      console.log(`problem report ${r.id}: ${r.sessions} log file(s) → ${r.sent ? `sent to ${reports.sendsTo}` : r.queued ? `couldn't send (${r.error}); kept and retried` : `${join(reports.dir, r.id)}.txt`}`);
      return json(res, 200, { ok: true, ...r });
    }
    if (!trusted(req.headers.origin)) return json(res, 403, { error: "reports are only available to the extension" });
    if (req.method === "GET" && url.pathname === "/reports") return json(res, 200, { reports: reports.list(), dir: reports.dir, sendsTo: reports.sendsTo });
    const m = url.pathname.match(/^\/reports\/([^/]+)\.(json|txt)$/);
    const file = m && reports.path(decodeURIComponent(m[1]), m[2]);
    if (req.method === "GET" && file) {
      // the .txt opens in a tab to read; the .json downloads
      res.writeHead(200, { "Content-Type": m[2] === "json" ? "application/json" : "text/plain; charset=utf-8", "Content-Disposition": `${m[2] === "json" ? "attachment" : "inline"}; filename="report-${m[1]}.${m[2]}"`, "Cache-Control": "no-store" });
      return res.end(readFileSync(file));
    }
    return json(res, 404, { error: "no such report" });
  } catch (e) {
    return json(res, 400, { error: e.message });
  }
}

const server = http.createServer((req, res) => {
  const url = new URL(req.url, "http://localhost");
  if (url.pathname === "/health") {
    res.writeHead(200, { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" });
    return res.end(JSON.stringify({ ok: true, conversations: conversations.size, max: MAX_SESSIONS, planner: PLANNER.model }));
  }
  if (url.pathname.startsWith("/knowledge/")) return void knowledgeRoute(req, res, url);
  if (url.pathname.startsWith("/sitemap/")) return void sitemapRoute(req, res, url);
  if (url.pathname === "/offers" || url.pathname.startsWith("/offers/")) return void offersRoute(req, res, url);
  if (url.pathname === "/memory" || url.pathname.startsWith("/memory/")) return void memoryRoute(req, res, url);
  if (url.pathname === "/prompts") return void promptsRoute(req, res);
  if (url.pathname === "/reports" || url.pathname.startsWith("/reports/")) return void reportsRoute(req, res, url);
  if (url.pathname === "/config" || url.pathname.startsWith("/config/")) return void configRoute(req, res, url);
  // the prompts editor, also reachable without the extension (the Mac app's menu opens it)
  const page = { "/settings": ["options.html", "text/html; charset=utf-8"], "/options.js": ["options.js", "text/javascript; charset=utf-8"] }[url.pathname];
  if (page) {
    res.writeHead(200, { "Content-Type": page[1], "Cache-Control": "no-store" });
    return res.end(readFileSync(join(ROOT, "extension", page[0])));
  }
  if (url.pathname === "/widget.js") {
    res.writeHead(200, { "Content-Type": "text/javascript; charset=utf-8", "Cache-Control": "no-store", "Access-Control-Allow-Origin": "*", "Cross-Origin-Resource-Policy": "cross-origin" });
    return res.end(bundle());
  }
  if (url.pathname === "/") {
    const file = join(ROOT, "public", "index.html");
    if (existsSync(file)) {
      res.writeHead(200, { "Content-Type": "text/html; charset=utf-8", "Cache-Control": "no-store" });
      return res.end(readFileSync(file));
    }
  }
  res.writeHead(404);
  res.end("Not found");
});

const originOk = (origin) => ALLOWED.includes("*") || ALLOWED.includes(origin);
const conversations = new Map();
let n = 0;

const wss = new WebSocketServer({ server, path: "/live", maxPayload: 4 << 20 });
wss.on("connection", (ws, req) => {
  const origin = req.headers.origin || "";
  const say = (msg) => ws.readyState === 1 && ws.send(JSON.stringify(msg));
  if (!originOk(origin)) {
    console.log(`refused a connection from ${origin || "(no origin)"}: not in ALLOWED_ORIGINS`);
    say({ type: "status", state: "error", message: "This site isn't allowed to use the voice server." });
    return ws.close(1008, "origin");
  }
  let conv = null;
  const early = []; // audio that beat the start message
  ws.on("message", (data, isBinary) => {
    if (conv) return conv.fromClient(data, isBinary);
    if (isBinary) return void early.push(data);
    let msg;
    try { msg = JSON.parse(String(data)); } catch { return; }
    if (msg.type !== "start") return;
    const id = String(msg.conversationId || "").slice(0, 80) || `c${Date.now()}`;
    const page = msg.page ? { url: String(msg.page.url || ""), title: String(msg.page.title || ""), site: String(msg.page.site || "").slice(0, 120), brand: String(msg.page.brand || "").replace(/[^\p{L}\p{N} .&'-]/gu, "").slice(0, 60), visits: Array.isArray(msg.page.visits) ? msg.page.visits.slice(-30) : [] } : null;
    conv = conversations.get(id);
    if (conv && !conv.ended) {
      console.log(`[${id.slice(0, 8)}] reattached from ${page?.url || origin}`);
    } else {
      if (conversations.size >= MAX_SESSIONS) {
        say({ type: "status", state: "error", message: "The assistant is busy right now. Try again in a minute." });
        return ws.close(1013, "busy");
      }
      const logFile = join(LOGS, `session-${new Date().toISOString().replace(/[:.]/g, "-")}-${++n}.jsonl`);
      const t0 = Date.now();
      const log = (kind, data = {}) => appendFileSync(logFile, JSON.stringify({ t: +((Date.now() - t0) / 1000).toFixed(3), kind, ...data }) + "\n");
      const name = String(msg.name || "").replace(/[^\p{L}\p{N} .'-]/gu, "").trim().slice(0, 40) || NAME;
      const history = Array.isArray(msg.history) ? msg.history.slice(-40) : [];
      const greet = !!msg.greet, lastAt = Number(msg.lastAt) || null;
      log("start", { id, origin, name, page: { ...page, visits: page?.visits?.length }, history_turns: history.length, greet, planner: PLANNER });
      conv = new Conversation({
        id, name, page, history, greet, lastAt, log, knowledge, netomi, offers, memory, apiKey: process.env.OPENAI_API_KEY, voice: VOICE, planner: PLANNER, maxMinutes: MAX_SESSION_MIN,
        onEnd: (c) => { if (conversations.get(c.id) === c) conversations.delete(c.id); console.log(`[${c.id.slice(0, 8)}] ended (${conversations.size} live)`); },
      });
      conversations.set(id, conv);
      console.log(`[${id.slice(0, 8)}] started from ${page?.url || origin} (${conversations.size} live); log: ${logFile}`);
    }
    conv.attach(ws, page);
    for (const a of early.splice(0)) conv.fromClient(a, true);
  });
  ws.on("close", () => conv?.detach(ws));
});

// run by the Mac app: exit when the app is gone (quit, force-quit or crash), so the server
// never lingers in the background holding the port
const PARENT = Number(process.env.PARENT_PID || 0);
if (PARENT) setInterval(() => { try { process.kill(PARENT, 0); } catch { process.exit(0); } }, 2000).unref();

server.listen(PORT, HOST, () => {
  console.log(`Talk to Website relay on http://localhost:${PORT}`);
  console.log(`  test page:  http://localhost:${PORT}/`);
  console.log(`  widget:     <script src="http://localhost:${PORT}/widget.js"></script>`);
  console.log(`  planner:    ${PLANNER.model} (${PLANNER.effort})   origins: ${ALLOWED.join(", ")}`);
});
