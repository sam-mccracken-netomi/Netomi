// Adobe Real-Time CDP: a shopper's profile as long-term memory.
//
// Who: the identity the extension found (the email on the site's account page) in the
// AEP_IDENTITY_NAMESPACE namespace (Email), SHA-256 hashed when AEP_IDENTITY_HASHED=true.
// Read: the Profile Access API returns the merged profile (AEP_MERGE_POLICY_ID).
// Write: one XDM record streamed to our HTTP API inlet → the "Talk to Website Profiles"
// dataset (Profile-enabled). There's no "create profile" call: the first record makes it.
// Updates reach the profile within seconds to minutes, so the local memory stays the live
// copy during a session.
//
// Fields (scripts/rtcdp-setup.mjs creates them), under _<tenant>.talkToWebsite:
//   typed, for segments: skinType, skinConcerns, foundationShade, undertone, coverage,
//     finish, preferredBrands, avoids, scentPreferences, hairType, budget
//   facts[]: every memory fact { key, label, value, kind, confidence, evidence, site,
//     updatedAt }: new kinds of attribute ("coverage", "lash_style"…) need no schema change
//   lastSite, updatedAt
// plus person.name and personalEmail.address (the identity).
//
//   const cdp = createRtcdp()        cdp.configured() → bool (credentials and IDs in .env)
//   await cdp.profile(email) → { found, name, facts, typed, raw } (found: false if none)
//   await cdp.save(email, { name, facts, site }) → { ok, status, error? }
//   await cdp.saveAddress(email, { zip, city, state })   the customer record (scripts/rtcdp-zip.mjs)
//   profile(…).address → { zip, city, state } | null, from the customer record
import { createHash } from "node:crypto";

const IMS = "https://ims-na1.adobelogin.com/ims/token/v3";
const PLATFORM = "https://platform.adobe.io";
const XED_FULL = "application/vnd.adobe.xed-full+json;version=1";

// memory keys that also get a typed field (anything else lives only in facts[])
export const TYPED = {
  skin_type: "skinType", skin_concerns: "skinConcerns", foundation_shade: "foundationShade", undertone: "undertone",
  coverage: "coverage", finish_preference: "finish", preferred_brands: "preferredBrands", avoids: "avoids",
  scent_preferences: "scentPreferences", hair_type: "hairType", budget: "budget", allergies: "allergies",
};

// a memory key's field in Adobe: the names above, else camelCase ("coverage_preference" →
// coveragePreference). New ones are added to the field group when first written.
const RESERVED = new Set(["facts", "lastSite", "updatedAt"]);
export function fieldOf(key) {
  if (TYPED[key]) return TYPED[key];
  const words = String(key).toLowerCase().replace(/[^a-z0-9]+/g, " ").trim().split(" ").filter(Boolean);
  let f = words.map((w, i) => (i ? w[0].toUpperCase() + w.slice(1) : w)).join("");
  if (/^[0-9]/.test(f)) f = `attr${f[0].toUpperCase()}${f.slice(1)}`; // field names start with a letter
  f = f.slice(0, 40);
  if (!f) return "";
  if (RESERVED.has(f)) f += "Value";
  return f;
}
const MAX_FIELDS = 120; // a ceiling on fields added automatically

export function createRtcdp({ env = process.env, log = () => {} } = {}) {
  const E = (k) => String(env[k] || "").trim();
  const tenant = () => E("AEP_TENANT_ID").replace(/^_/, "");
  let tok = null; // { value, until }

  const configured = () => ["AEP_CLIENT_ID", "AEP_CLIENT_SECRET", "AEP_SCOPES", "AEP_IMS_ORG", "AEP_SANDBOX_NAME", "AEP_TENANT_ID", "AEP_SCHEMA_ID", "AEP_DATASET_ID", "AEP_STREAMING_CONNECTION_ID", "AEP_DATAFLOW_ID"].every((k) => E(k));

  async function token() {
    if (tok && Date.now() < tok.until) return tok.value;
    const r = await fetch(IMS, { method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" }, body: new URLSearchParams({ grant_type: "client_credentials", client_id: E("AEP_CLIENT_ID"), client_secret: E("AEP_CLIENT_SECRET"), scope: E("AEP_SCOPES") }), signal: AbortSignal.timeout(15000) });
    const j = await r.json().catch(() => ({}));
    if (!r.ok || !j.access_token) throw new Error(`Adobe sign-in failed: ${j.error_description || j.error || r.status}`);
    tok = { value: j.access_token, until: Date.now() + Math.max(60, (j.expires_in || 86400) - 600) * 1000 }; // 24 h, renewed 10 min early
    return tok.value;
  }
  async function headers(extra = {}) {
    return { Authorization: `Bearer ${await token()}`, "x-api-key": E("AEP_CLIENT_ID"), "x-gw-ims-org-id": E("AEP_IMS_ORG"), "x-sandbox-name": E("AEP_SANDBOX_NAME"), ...extra };
  }
  // any Platform call → { ok, status, body }
  async function api(method, path, { body, accept, contentType = "application/json", timeoutMs = 60000 } = {}) {
    const r = await fetch(path.startsWith("http") ? path : `${PLATFORM}${path}`, {
      method, headers: await headers({ ...(accept ? { Accept: accept } : {}), ...(body !== undefined ? { "Content-Type": contentType } : {}) }),
      body: body === undefined ? undefined : typeof body === "string" ? body : JSON.stringify(body), signal: AbortSignal.timeout(timeoutMs),
    });
    const text = await r.text();
    let j; try { j = text ? JSON.parse(text) : null; } catch { j = text; }
    return { ok: r.ok, status: r.status, body: j };
  }

  const identity = (email) => {
    const v = String(email || "").trim().toLowerCase();
    return E("AEP_IDENTITY_HASHED") === "true" ? createHash("sha256").update(v).digest("hex") : v;
  };
  const ns = () => E("AEP_IDENTITY_NAMESPACE") || "Email";

  // the merged profile for this email, as memory facts
  async function profile(email) {
    const q = new URLSearchParams({ "schema.name": "_xdm.context.profile", entityId: identity(email), entityIdNS: ns() });
    if (E("AEP_MERGE_POLICY_ID")) q.set("mergePolicyId", E("AEP_MERGE_POLICY_ID"));
    const r = await api("GET", `/data/core/ups/access/entities?${q}`);
    if (r.status === 404 || (r.ok && !Object.keys(r.body || {}).length)) return { found: false };
    if (!r.ok) throw new Error(`profile lookup failed: ${r.status} ${JSON.stringify(r.body).slice(0, 300)}`);
    const ent = Object.values(r.body)[0]?.entity || {};
    const mine = ent[`_${tenant()}`]?.talkToWebsite || {};
    const n = ent.person?.name || {};
    const typed = Object.fromEntries(Object.entries(mine).filter(([k, v]) => !RESERVED.has(k) && typeof v === "string" && v));
    const a = ent.homeAddress || {};
    const address = a.postalCode || a.city ? { zip: a.postalCode || "", city: a.city || "", state: a.stateProvince || "" } : null;
    return { found: true, name: n.fullName || [n.firstName, n.lastName].filter(Boolean).join(" "), email: ent.personalEmail?.address || "", facts: Array.isArray(mine.facts) ? mine.facts : [], typed, address, lastSite: mine.lastSite, updatedAt: mine.updatedAt, raw: ent };
  }

  // one record to a dataset through its dataflow (a record replaces that dataset's previous
  // record for the same person; the profile merges records from different datasets)
  async function stream(entity, { datasetId, flowId, source }) {
    const schemaRef = { id: E("AEP_SCHEMA_ID"), contentType: XED_FULL };
    const msg = { header: { schemaRef, imsOrgId: E("AEP_IMS_ORG"), datasetId, flowId, source: { name: source } }, body: { xdmMeta: { schemaRef }, xdmEntity: entity } };
    const r = await fetch(`https://dcs.adobedc.net/collection/${E("AEP_STREAMING_CONNECTION_ID")}?syncValidation=true`, {
      method: "POST", headers: await headers({ "Content-Type": "application/json", "x-adobe-flow-id": flowId }), body: JSON.stringify(msg), signal: AbortSignal.timeout(20000),
    });
    const text = await r.text();
    if (!r.ok) { log("rtcdp_save_failed", { status: r.status, error: text.slice(0, 300) }); return { ok: false, status: r.status, error: text.slice(0, 4000) }; }
    return { ok: true, status: r.status };
  }

  // the customer record (stands in for a CRM): the home address. The assistant only reads it.
  const crmConfigured = () => !!(E("AEP_CRM_DATASET_ID") && E("AEP_CRM_DATAFLOW_ID"));
  function saveAddress(email, { zip = "", city = "", state = "" } = {}) {
    if (!crmConfigured()) throw new Error("the customer records dataset isn't set up: run node scripts/rtcdp-setup.mjs");
    const homeAddress = Object.fromEntries(Object.entries({ postalCode: String(zip).trim(), city: String(city).trim(), stateProvince: String(state).trim() }).filter(([, v]) => v));
    return stream({ personalEmail: { address: identity(email) }, homeAddress }, { datasetId: E("AEP_CRM_DATASET_ID"), flowId: E("AEP_CRM_DATAFLOW_ID"), source: "Customer records" });
  }

  // the whole record each time (facts from every site, so other sites' facts must be passed in)
  // the field group's current fields (cached), and adding the ones a write needs
  const FG_TITLE = "Talk to Website Preferences";
  let fg = null; // { id, fields: Set, at }
  const recent = new Map(); // field → when we added it (validation may lag for a few minutes)
  async function fieldGroup(force = false) {
    if (fg && !force && Date.now() - fg.at < 10 * 60e3) return fg;
    const XED = "application/vnd.adobe.xed+json";
    let id = fg?.id;
    if (!id) {
      const l = await api("GET", `/data/foundation/schemaregistry/tenant/fieldgroups?property=title==${encodeURIComponent(FG_TITLE)}`, { accept: "application/vnd.adobe.xed-id+json" });
      id = l.body?.results?.[0]?.["$id"];
      if (!id) throw new Error("the Talk to Website field group isn't there: run node scripts/rtcdp-setup.mjs");
    }
    const r = await api("GET", `/data/foundation/schemaregistry/tenant/fieldgroups/${encodeURIComponent(id)}`, { accept: XED });
    if (!r.ok) throw new Error(`reading the field group: ${r.status}`);
    const props = r.body.definitions?.talkToWebsite?.properties?.[`_${tenant()}`]?.properties?.talkToWebsite?.properties || {};
    fg = { id, fields: new Set(Object.keys(props)), at: Date.now() };
    return fg;
  }
  async function ensureFields(facts) {
    const want = new Map();
    for (const f of facts) { const field = fieldOf(f.key); if (field && !want.has(field)) want.set(field, f); }
    let g = await fieldGroup();
    let missing = [...want.keys()].filter((k) => !g.fields.has(k));
    if (!missing.length) return [];
    g = await fieldGroup(true); // someone may have added them meanwhile
    missing = [...want.keys()].filter((k) => !g.fields.has(k)).slice(0, Math.max(0, MAX_FIELDS - g.fields.size));
    if (!missing.length) return [];
    const ops = missing.map((field) => {
      const f = want.get(field);
      return { op: "add", path: `/definitions/talkToWebsite/properties/_${tenant()}/properties/talkToWebsite/properties/${field}`, value: { type: "string", title: String(f.label || f.key).slice(0, 60), description: `Learned by the Talk to Website assistant (memory key "${f.key}")` } };
    });
    const r = await api("PATCH", `/data/foundation/schemaregistry/tenant/fieldgroups/${encodeURIComponent(g.id)}`, { accept: "application/vnd.adobe.xed+json", body: ops });
    if (!r.ok) { log("rtcdp_fields_failed", { fields: missing, status: r.status, error: JSON.stringify(r.body).slice(0, 300) }); return []; }
    for (const k of missing) { g.fields.add(k); recent.set(k, Date.now()); }
    log("rtcdp_fields_added", { fields: missing });
    return missing;
  }

  async function save(email, { name = "", facts = [], site = "" } = {}) {
    const now = new Date().toISOString();
    const parts = String(name || "").trim().split(/\s+/).filter(Boolean);
    const mine = { facts: facts.slice(0, 200).map((f) => ({
      key: String(f.key).slice(0, 60), label: String(f.label || f.key).slice(0, 60), value: String(f.value).slice(0, 200),
      kind: f.kind === "stated" ? "stated" : "inferred", confidence: Number(f.confidence) || 0, evidence: String(f.evidence || "").slice(0, 200),
      site: String(f.site || site || ""), updatedAt: new Date(f.updatedAt || Date.now()).toISOString(),
    })), lastSite: site, updatedAt: now };
    // every fact also in a field of its own (added to the field group if it's new), from every
    // site's facts, this site's last so its values win
    let added = [];
    try { added = await ensureFields(facts); } catch (e) { log("rtcdp_fields_failed", { error: e.message }); }
    const known = fg?.fields || new Set(Object.values(TYPED));
    const ordered = [...facts.filter((f) => (f.site || site) !== site), ...facts.filter((f) => (f.site || site) === site)];
    for (const f of ordered) { const field = fieldOf(f.key); if (field && known.has(field)) mine[field] = String(f.value).slice(0, 200); }
    const entity = {
      personalEmail: { address: identity(email) },
      ...(parts.length ? { person: { name: { fullName: parts.join(" "), firstName: parts[0], ...(parts.length > 1 ? { lastName: parts.slice(1).join(" ") } : {}) } } } : {}),
      [`_${tenant()}`]: { talkToWebsite: mine },
    };
    const r = await stream(entity, { datasetId: E("AEP_DATASET_ID"), flowId: E("AEP_DATAFLOW_ID"), source: "Talk to Website" });
    if (r.ok || r.status !== 400) return { ...r, added };
    // a field added a moment ago may not validate yet: write without the newest ones, try again later
    const fresh = [...recent].filter(([, t]) => Date.now() - t < 15 * 60e3).map(([k]) => k);
    if (!fresh.some((k) => k in mine)) return { ...r, added };
    for (const k of fresh) delete mine[k];
    const r2 = await stream(entity, { datasetId: E("AEP_DATASET_ID"), flowId: E("AEP_DATAFLOW_ID"), source: "Talk to Website" });
    log("rtcdp_fields_pending", { fields: fresh, ok: r2.ok });
    return { ...r2, added, retryLater: r2.ok };
  }

  return { configured, crmConfigured, token, api, profile, save, saveAddress, tenant };
}
