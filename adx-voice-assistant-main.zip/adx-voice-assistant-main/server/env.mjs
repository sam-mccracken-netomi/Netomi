// Loads .env (KEY=value lines) and, if OPENAI_ENV_FILE names another env file, the
// OpenAI key from there. Values are never printed.
import { readFileSync, existsSync } from "node:fs";
import { resolve, dirname } from "node:path";
import { homedir } from "node:os";
import { fileURLToPath } from "node:url";

export const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), "..");
// where prompts and knowledge bases are kept: the project's data/ in development, a
// writable folder (Application Support) when running inside the Mac app
export const DATA = () => process.env.DATA_DIR || resolve(ROOT, "data");

function parse(path) {
  const out = {};
  if (!existsSync(path)) return out;
  for (const line of readFileSync(path, "utf8").split(/\r?\n/)) {
    const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*$/);
    if (m) out[m[1]] = m[2].replace(/^(['"])(.*)\1$/, "$2");
  }
  return out;
}

const expand = (p) => resolve(ROOT, p.replace(/^~(?=\/|$)/, homedir()));

export function loadEnv() {
  for (const [k, v] of Object.entries(parse(resolve(ROOT, ".env")))) if (process.env[k] === undefined) process.env[k] = v;
  if (!process.env.OPENAI_API_KEY && process.env.OPENAI_ENV_FILE) {
    const other = parse(expand(process.env.OPENAI_ENV_FILE));
    if (other.OPENAI_API_KEY) process.env.OPENAI_API_KEY = other.OPENAI_API_KEY;
  }
  if (!process.env.OPENAI_API_KEY) {
    throw new Error("No OPENAI_API_KEY: set it in .env, or point OPENAI_ENV_FILE at an env file that has it.");
  }
}
