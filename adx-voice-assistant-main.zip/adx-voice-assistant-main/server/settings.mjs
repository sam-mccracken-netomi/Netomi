// Settings saved from the settings page (data/settings.json): where knowledge answers come
// from, the Netomi bot, sales, memory and the card's placement. Read on every use, so a
// change applies right away.
//
//   knowledge.mode    "local"  the site's own help pages, learned with Learn (knowledge.mjs)
//                     "netomi" Netomi's knowledge answers (netomi.mjs)
//                     "both"   the local passages when they cover it, else Netomi
//   knowledge.netomi  { botId, refId, sites, authUrl, proxyUrl }
//                     sites: the sites this bot answers for ("sephora.com, …"); empty = all
//   sales             { enabled, level }: offers and sales moments (sales.mjs); level 1 light,
//                     2 balanced, 3 proactive, 4 assertive
//   memory            { enabled, preselect, rtcdp }: what we learn about the visitor (memory.mjs), and
//                     whether product options are preselected from it
//   ui                { cardPlacement, captions }: captions: off | bubble | subtitles (the
//                     spoken words as text); cardPlacement: where the info card shows: center | above-orb |
//                     top-right | bottom-center

import { readFileSync, writeFileSync, existsSync, mkdirSync, statSync } from "node:fs";
import { join } from "node:path";
import { DATA } from "./env.mjs";

const FILE = join(DATA(), "settings.json");
const MODES = ["local", "netomi", "both"];
export const PLACEMENTS = ["center", "above-orb", "top-right", "bottom-center"];
// what it says, as text, while it speaks: nothing, a small bubble beside the orb, or subtitles
export const CAPTIONS = ["off", "bubble", "subtitles"];
const uiOf = (u = {}) => ({
  cardPlacement: PLACEMENTS.includes(u.cardPlacement) ? u.cardPlacement : "center",
  captions: CAPTIONS.includes(u.captions) ? u.captions : "bubble",
});
export const NETOMI_DEFAULTS = {
  authUrl: "https://auth-us.netomi.com/v1/auth/generate-token",
  proxyUrl: "https://streamproxy-us.netomi.com/api/proxy",
};

let cache = { mtime: -1, value: {} };
function stored() {
  if (!existsSync(FILE)) return {};
  const mtime = statSync(FILE).mtimeMs;
  if (mtime !== cache.mtime) {
    try { cache = { mtime, value: JSON.parse(readFileSync(FILE, "utf8")) || {} }; } catch { cache = { mtime, value: {} }; }
  }
  return cache.value;
}

export function getSettings() {
  const k = stored().knowledge || {};
  const n = k.netomi || {};
  const sl = stored().sales || {};
  const mem = stored().memory || {};
  return {
    sales: { enabled: !!sl.enabled, level: levelOf(sl.level) },
    memory: { enabled: mem.enabled !== false, preselect: mem.preselect !== false, rtcdp: mem.rtcdp !== false },
    ui: uiOf(stored().ui),
    knowledge: {
      mode: MODES.includes(k.mode) ? k.mode : "local",
      netomi: {
        botId: n.botId || "", refId: n.refId || "", sites: n.sites || "",
        authUrl: n.authUrl || NETOMI_DEFAULTS.authUrl, proxyUrl: n.proxyUrl || NETOMI_DEFAULTS.proxyUrl,
      },
    },
  };
}

const clean = (v, max = 300) => String(v ?? "").trim().slice(0, max);
const httpsUrl = (v, fallback) => { const s = clean(v, 500); return /^https:\/\/[^\s]+$/.test(s) ? s : fallback; };

const levelOf = (v) => Math.min(4, Math.max(1, Math.round(Number(v) || 2)));

// a partial update: sections left out keep their saved values
export function saveSettings(input = {}) {
  const cur = getSettings();
  const k = input.knowledge || cur.knowledge;
  const n = k.netomi || {};
  const sl = input.sales || cur.sales;
  const mem = input.memory || cur.memory;
  const ui = { ...cur.ui, ...(input.ui || {}) }; // one choice at a time keeps the others
  const value = {
    sales: { enabled: !!sl.enabled, level: levelOf(sl.level) },
    memory: { enabled: mem.enabled !== false, preselect: mem.preselect !== false, rtcdp: mem.rtcdp !== false },
    ui: uiOf(ui),
    knowledge: {
      mode: MODES.includes(k.mode) ? k.mode : "local",
      netomi: {
        botId: clean(n.botId, 80), refId: clean(n.refId, 80),
        sites: clean(n.sites).toLowerCase().split(/[\s,]+/).map((s) => s.replace(/^https?:\/\//, "").replace(/^www\./, "").replace(/\/.*$/, "")).filter(Boolean).join(", "),
        authUrl: httpsUrl(n.authUrl, NETOMI_DEFAULTS.authUrl), proxyUrl: httpsUrl(n.proxyUrl, NETOMI_DEFAULTS.proxyUrl),
      },
    },
  };
  mkdirSync(DATA(), { recursive: true });
  writeFileSync(FILE, JSON.stringify(value, null, 2));
  return getSettings();
}

// what answers questions on this site: { local, netomi } (netomi: the bot's config, or null).
// A site the bot isn't set up for keeps its local knowledge base, whatever the mode.
export function knowledgeFor(site) {
  const { mode, netomi } = getSettings().knowledge;
  const sites = netomi.sites.split(/[\s,]+/).filter(Boolean);
  const netomiOn = mode !== "local" && !!netomi.botId && !!netomi.refId && (!sites.length || sites.includes(site));
  return { local: mode !== "netomi" || !netomiOn, netomi: netomiOn ? netomi : null };
}
