// The offers repository: what a site is running right now (sitewide discounts, gifts with
// purchase, spend thresholds, codes, loyalty perks, products on sale), parsed from its
// offer and sale pages and kept per site, for the sales side of the assistant (sales.mjs).
//
// The extension collects the pages in the visitor's own browser (Scan offers in the chat
// panel), as Learn does for help pages; here each page is read by the planner model into
// structured offers, and products shown with a crossed-out price become price drops.
//
//   offers.ingest(site, pages)  pages: [{ url, title, banners: [..], text, products: [{ name, url, price, was }] }]
//   offers.status(site) · offers.list(site) · offers.remove(site, id)
//   offers.relevant(site, ctx)  → scored offers and price drops for a moment (see below)
//
// Stored as data/offers/<site>.json. Expired offers are kept but never used.

import { readFileSync, writeFileSync, existsSync, mkdirSync, statSync, readdirSync } from "node:fs";
import { join } from "node:path";
import { createHash } from "node:crypto";
import { DATA } from "./env.mjs";
import { nextStep } from "./openai.mjs";

const DIR = () => join(DATA(), "offers");
const siteFile = (site) => join(DIR(), `${String(site).replace(/[^a-z0-9.-]/gi, "_")}.json`);
const KINDS = ["sitewide_discount", "category_discount", "brand_discount", "product_sale", "gift_with_purchase", "free_shipping", "spend_threshold", "loyalty", "bundle", "samples", "other"];
const MAX_DROPS = 400;

const EXTRACT = {
  name: "save_offers",
  description: "Save the offers this page states.",
  parameters: {
    type: "object",
    properties: {
      offers: {
        type: "array",
        items: {
          type: "object",
          properties: {
            title: { type: "string", description: "Short, specific, as a shopper would say it: 'Free Olaplex No.3 trial size with a $35 purchase', '20% off Sephora Collection'" },
            kind: { type: "string", enum: KINDS },
            summary: { type: "string", description: "One sentence with the terms exactly as stated (what you get, what you must do)" },
            code: { type: ["string", "null"], description: "Promo code, if the page gives one" },
            min_spend: { type: ["number", "null"], description: "Minimum purchase in dollars, if any" },
            discount: { type: ["string", "null"], description: "e.g. '20% off', '$10 off', 'free gift', 'free shipping'" },
            who: { type: ["string", "null"], description: "Who can get it, if limited: 'Beauty Insider members', 'Rouge members', 'online only', 'in the app'" },
            brands: { type: "array", items: { type: "string" } },
            categories: { type: "array", items: { type: "string" }, description: "e.g. 'haircare', 'fragrance', 'lipstick'" },
            products: { type: "array", items: { type: "string" } },
            excludes: { type: ["string", "null"] },
            ends: { type: ["string", "null"], description: "End date as YYYY-MM-DD, only if the page states one" },
          },
          required: ["title", "kind", "summary"],
        },
      },
    },
    required: ["offers"],
  },
};

const INSTRUCTIONS = `You read a page from an online store and list the offers it states that are running now: discounts, sales, promo codes, gifts or samples with purchase, free shipping, spend-more-save-more thresholds, loyalty perks and rewards, bundles and value sets with savings.

Rules:
- Only offers the page itself states. Never add terms, dates, codes or amounts from general knowledge.
- One entry per distinct offer. Merge repeats of the same offer.
- Skip things that aren't a saving or perk: new arrivals, bestsellers, "shop now", editorial content, store events without a perk.
- Skip offers the page says have ended.
- Keep the conditions (minimum spend, membership, online only, exclusions): they decide when the offer can be mentioned.
- Call save_offers once, with an empty list if there are none.`;

const norm = (s) => String(s || "").toLowerCase().replace(/[^a-z0-9$%]+/g, " ").trim();
const idOf = (o) => createHash("sha1").update(o.code ? `code:${norm(o.code)}` : `t:${norm(o.title)}`).digest("hex").slice(0, 10);
const moneyOf = (s) => { const m = String(s ?? "").replace(/,/g, "").match(/\d+(?:\.\d+)?/); return m ? Number(m[0]) : null; };
const today = () => new Date().toISOString().slice(0, 10);
export const live = (o) => !o.ends || o.ends >= today();

export function createOffers({ apiKey, model, effort, embed = null, log = () => {} }) {
  const cache = new Map(); // site → { mtime, data, vecs }

  function load(site) {
    const file = siteFile(site);
    if (!existsSync(file)) return null;
    const mtime = statSync(file).mtimeMs;
    const c = cache.get(site);
    if (c?.mtime === mtime) return c;
    const data = JSON.parse(readFileSync(file, "utf8"));
    const vec = (b64) => { if (!b64) return null; const b = Buffer.from(b64, "base64"); return new Float32Array(b.buffer.slice(b.byteOffset, b.byteOffset + b.byteLength)); };
    const entry = { mtime, data, vecs: new Map([...data.offers, ...data.drops].map((x) => [x.id, vec(x.emb)])) };
    cache.set(site, entry);
    return entry;
  }

  function save(site, data) {
    mkdirSync(DIR(), { recursive: true });
    writeFileSync(siteFile(site), JSON.stringify(data));
  }

  async function vectors(texts) {
    if (!embed || !texts.length) return texts.map(() => null);
    try { return await embed(texts); } catch (e) { log("offers_embed_failed", { error: e.message }); return texts.map(() => null); }
  }
  const b64 = (v) => (v ? Buffer.from(v.buffer).toString("base64") : null);
  const offerText = (o) => [o.title, o.summary, o.brands?.join(", "), o.categories?.join(", "), o.products?.join(", ")].filter(Boolean).join(". ");

  // one page → its offers, read by the model
  async function extract(page) {
    const body = [`URL: ${page.url}`, `Title: ${page.title || ""}`, `Today: ${today()}`];
    if (page.banners?.length) body.push("", "Banners and promo strips on the page:", ...page.banners.map((b) => `- ${b}`));
    body.push("", "Page text:", String(page.text || "").slice(0, 14000));
    const call = await nextStep({ apiKey, model, effort, instructions: INSTRUCTIONS, tools: [EXTRACT], input: [{ role: "user", content: body.join("\n") }], timeoutMs: 60000 });
    return (call.args.offers || []).filter((o) => o?.title && o?.summary).map((o) => ({
      title: String(o.title).slice(0, 140), kind: KINDS.includes(o.kind) ? o.kind : "other", summary: String(o.summary).slice(0, 400),
      code: o.code ? String(o.code).slice(0, 40) : null, min_spend: o.min_spend != null ? moneyOf(o.min_spend) : null,
      discount: o.discount ? String(o.discount).slice(0, 60) : null, who: o.who ? String(o.who).slice(0, 80) : null,
      brands: (o.brands || []).map(String).slice(0, 12), categories: (o.categories || []).map(String).slice(0, 12), products: (o.products || []).map(String).slice(0, 12),
      excludes: o.excludes ? String(o.excludes).slice(0, 200) : null, ends: /^\d{4}-\d{2}-\d{2}$/.test(o.ends || "") ? o.ends : null,
      url: page.url,
    }));
  }

  async function ingest(site, pages) {
    if (!Array.isArray(pages) || !pages.length) throw new Error("no pages");
    const t0 = Date.now();
    const found = [];
    let failed = 0;
    for (let i = 0; i < pages.length; i += 3) {
      const got = await Promise.all(pages.slice(i, i + 3).map((p) => extract(p).catch((e) => { failed++; log("offers_extract_failed", { url: p.url, error: e.message }); return []; })));
      found.push(...got.flat());
    }
    // the same offer from several pages: keep one, the most detailed
    const byId = new Map();
    for (const o of found) {
      const id = idOf(o);
      const prev = byId.get(id);
      if (!prev || o.summary.length > prev.summary.length) byId.set(id, { id, ...o, seenAt: Date.now() });
    }
    // products shown with a crossed-out price
    const drops = new Map();
    for (const p of pages) for (const x of p.products || []) {
      const price = moneyOf(x.price), was = moneyOf(x.was);
      if (!x.name || !x.url || !price || !was || was <= price * 1.02) continue;
      drops.set(x.url, { id: createHash("sha1").update(x.url).digest("hex").slice(0, 10), name: String(x.name).slice(0, 140), url: x.url, price, was, pct: Math.round((1 - price / was) * 100), seenAt: Date.now() });
    }
    let offers = [...byId.values()];
    const dropList = [...drops.values()].sort((a, b) => b.pct - a.pct).slice(0, MAX_DROPS);
    const vecs = await vectors([...offers.map(offerText), ...dropList.map((d) => d.name)]);
    offers.forEach((o, i) => { o.emb = b64(vecs[i]); o.vec = vecs[i]; });
    // the same offer worded differently on two pages: keep the more detailed one
    const dot = (a, b) => { let s = 0; for (let i = 0; i < a.length; i++) s += a[i] * b[i]; return s; };
    const kept = [];
    for (const o of [...offers].sort((a, b) => b.summary.length - a.summary.length)) {
      const twin = o.vec && kept.find((k) => k.vec && k.kind === o.kind && (k.code || null) === (o.code || null) && (k.min_spend || null) === (o.min_spend || null) && dot(k.vec, o.vec) >= 0.86);
      if (!twin) kept.push(o);
    }
    offers = kept.map(({ vec, ...o }) => o);
    dropList.forEach((d, i) => { d.emb = b64(vecs[offers.length + i]); });
    const data = { site, updatedAt: Date.now(), pages: pages.map((p) => ({ url: p.url, title: p.title })), offers, drops: dropList };
    save(site, data);
    log("offers_ingested", { site, pages: pages.length, offers: offers.length, drops: dropList.length, failed, ms: Date.now() - t0 });
    return { pages: pages.length, offers: offers.length, drops: dropList.length, failed };
  }

  function status(site) {
    const d = load(site)?.data;
    return d ? { site, offers: d.offers.filter(live).length, drops: d.drops.length, updatedAt: d.updatedAt } : { site, offers: 0, drops: 0 };
  }

  const strip = ({ emb, ...x }) => x;
  function list(site) {
    const d = load(site)?.data;
    return d ? { site, updatedAt: d.updatedAt, pages: d.pages, offers: d.offers.map((o) => ({ ...strip(o), live: live(o) })), drops: d.drops.map(strip) } : { site, offers: [], drops: [], pages: [] };
  }
  function sites() {
    if (!existsSync(DIR())) return [];
    return readdirSync(DIR()).filter((f) => f.endsWith(".json")).map((f) => status(f.slice(0, -5)));
  }
  function remove(site, id) {
    const d = load(site)?.data;
    if (!d) return list(site);
    d.offers = d.offers.filter((o) => o.id !== id);
    d.drops = d.drops.filter((o) => o.id !== id);
    save(site, d);
    return list(site);
  }

  // ---- what fits a moment ----------------------------------------------------------------------
  // ctx: { text: what they're looking at or asking ("Dior Lip Glow, lipstick"), brand,
  //        subtotal: their bag's subtotal if known, url: the current product, all: true for
  //        "what deals are on?" }
  // → [{ type: "offer"|"drop", item, score 0-1, why }], best first
  const queryVecs = new Map();
  async function relevant(site, ctx = {}) {
    const entry = load(site);
    if (!entry) return [];
    const { data, vecs } = entry;
    let qv = null;
    // on a store that sells its own brand (e.l.f. on elfcosmetics.com), the brand says nothing
    // about which offer fits: leave it out of the match
    const letters = (s) => String(s || "").toLowerCase().replace(/[^a-z0-9]/g, "");
    const houseBrand = ctx.brand && ctx.house && letters(ctx.house.split(".")[0]).includes(letters(ctx.brand).slice(0, 12));
    const q = String(houseBrand ? String(ctx.text || "").split(ctx.brand).join(" ") : ctx.text || "").replace(/^[\s,.]+/, "").trim();
    if (q) {
      qv = queryVecs.get(q);
      if (!qv) { [qv] = await vectors([q]); if (qv) { queryVecs.set(q, qv); if (queryVecs.size > 300) queryVecs.delete(queryVecs.keys().next().value); } }
    }
    const sim = (id) => { const v = vecs.get(id); if (!qv || !v) return 0; let s = 0; for (let i = 0; i < v.length; i++) s += v[i] * qv[i]; return s; };
    const brand = houseBrand ? "" : norm(ctx.brand);
    const out = [];
    for (const o of data.offers) {
      if (!live(o)) continue;
      const s = sim(o.id);
      let score = Math.min(1, Math.max(0, (s - 0.2) / 0.45)); // ~0.2 unrelated … ~0.65 the same thing
      const why = [];
      const general = !o.brands.length && !o.categories.length && !o.products.length;
      if (brand && o.brands.some((b) => norm(b) === brand || norm(b).includes(brand) || brand.includes(norm(b)))) { score = Math.max(score, 0.9); why.push(`for ${ctx.brand}`); }
      // ctx.general: how well a sitewide offer fits this moment (default: a fair fit)
      if (general) { score = Math.max(score, ctx.general ?? 0.55); why.push(ctx.general >= 0.75 ? "it's running sitewide right now" : "sitewide"); }
      if (o.min_spend && ctx.subtotal != null) {
        const gap = Math.round((o.min_spend - ctx.subtotal) * 100) / 100;
        if (gap <= 0) { score = Math.max(score, 0.8); why.push(`their bag ($${ctx.subtotal}) already qualifies`); }
        else if (gap <= Math.max(25, o.min_spend * 0.6)) { score = Math.max(score, 0.85); why.push(`they're $${gap.toFixed(2)} away (bag $${ctx.subtotal} of $${o.min_spend})`); }
        else score *= 0.6;
      } else if (o.min_spend && ctx.price) {
        // no bag total known: this product alone, toward the minimum
        const gap = Math.round((o.min_spend - ctx.price) * 100) / 100;
        if (gap <= 0) { score = Math.max(score, 0.78); why.push(`this item ($${ctx.price}) alone meets the $${o.min_spend} minimum`); }
        else if (gap <= Math.max(25, o.min_spend * 0.75)) { score = Math.max(score, 0.74); why.push(`this item ($${ctx.price}) gets them part of the way to the $${o.min_spend} minimum ($${gap.toFixed(2)} more)`); }
      }
      // only for some people (students, teachers, military…): not something to bring up unasked
      if (!ctx.all && /\b(student|graduate|teacher|educator|military|veteran|first responder|nurse|healthcare|medical|employee|staff)s?\b/i.test(`${o.who || ""} ${o.title}`)) score *= 0.55;
      if (ctx.all) score = Math.max(score, 0.5);
      out.push({ type: "offer", item: strip(o), score: +score.toFixed(3), why: why.join("; ") });
    }
    for (const d of data.drops) {
      if (ctx.url && d.url.split("?")[0] === String(ctx.url).split("?")[0]) { out.push({ type: "drop", item: strip(d), score: 0.8, why: "this product is on sale" }); continue; }
      const s = sim(d.id);
      if (s < 0.5) continue;
      out.push({ type: "drop", item: strip(d), score: +Math.min(0.85, (s - 0.2) / 0.45).toFixed(3), why: "a similar product on sale" });
    }
    return out.sort((a, b) => b.score - a.score);
  }

  return { ingest, status, list, sites, remove, relevant, has: (site) => !!load(site) };
}
