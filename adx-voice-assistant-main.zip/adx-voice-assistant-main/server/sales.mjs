// The sales side of the assistant: at the right moments, bring up an offer or a price drop
// that genuinely fits what the visitor is doing, the way a good sales associate would, and
// never more often than the chosen level allows.
//
// Two ways in:
//  - while working a request (the planner): the offers that fit the request and page are in
//    its prompt, with how far to go (plannerBlock); e.g. after adding to the bag it can say
//    "you're $8 away from the free gift"
//  - while the visitor browses by themselves (moment): the home page, a category or any other
//    page, a product, a search, the bag or checkout; the best fitting offer, if it clears the
//    level's bar, is offered by the voice (and shown on a card). What fits is judged from
//    the page and what they've been after lately (recent browsing, remembered preferences):
//    on the home page, what's running sitewide right now, or what matches their interests
//
// The level (settings page, 1-4) sets which moments count, how good a fit must be, how
// often, and the tone. A "no thanks" backs it off.

import { prompt } from "./prompts.mjs";
import { describeVisit } from "./persona.mjs";

// waits: how long to hold back after the conversation starts, the agent finishes, the visitor
// speaks, or something else proactive was said (the higher levels don't hold back as long).
// greet: the best offer goes into the opening greeting itself.
export const WAITS = { start: 15000, afterTask: 25000, afterSpoke: 8000, afterProactive: 60000 };
export const LEVELS = {
  1: { name: "Light", moments: ["cart", "checkout", "price_drop"], minScore: 0.84, gapMs: 15 * 60000, max: 1, card: false,
    style: "Light touch. Mention an offer only when it saves them money on what they're already buying (they qualify, are close to a threshold, or a code applies). One short sentence, no pushing." },
  2: { name: "Balanced", moments: ["home", "product", "cart", "checkout", "price_drop"], minScore: 0.74, gapMs: 5 * 60000, max: 2, card: true,
    style: "Helpful sales associate. Mention an offer when it clearly fits what they're looking at or buying. One short sentence, framed as a tip." },
  3: { name: "Proactive", moments: ["home", "browse", "product", "search", "compare", "cart", "checkout", "price_drop"], minScore: 0.66, gapMs: 3 * 60000, max: 3, card: true,
    waits: { start: 15000, afterTask: 20000, afterSpoke: 8000, afterProactive: 60000 },
    style: "Helpful, proactive sales associate. Bring up an offer or price drop when it fits what they're doing, or a threshold they're near. One short, friendly sentence, then back to what they were doing." },
  4: { name: "Assertive", moments: ["home", "browse", "product", "search", "compare", "cart", "checkout", "price_drop"], minScore: 0.58, gapMs: 2 * 60000, max: 5, card: true, greet: true,
    waits: { start: 0, afterTask: 15000, afterSpoke: 6000, afterProactive: 45000 },
    style: "Confident sales associate. Point out savings that fit, suggest reaching a threshold when they're close, mention real end dates when there are any. One offer at a time, one short sentence; never pushy and never twice about the same thing." },
};

const DECLINE = /\b(no thanks|no thank you|not interested|don'?t (need|want) (it|that|any)|stop (telling|pitching|offering)|no (more )?(deals|offers)|i'?m good|nah)\b/i;

export class Sales {
  constructor({ offers, site, log }) {
    Object.assign(this, { offers, site, log });
    this.pitched = new Set(); // offer/drop ids already mentioned in this conversation
    this.count = 0;
    this.lastAt = 0;
    this.lastMsgIndex = -1;
    this.mutedUntil = 0;
  }

  // a "no thanks" after the last pitch: quiet for the rest of the conversation (levels 1-2)
  // or for 10 minutes (3-4)
  checkDecline(messages, level) {
    if (this.lastMsgIndex < 0) return;
    const after = messages.slice(this.lastMsgIndex).filter((m) => m.role === "user").map((m) => m.text).join(" ");
    if (DECLINE.test(after)) {
      this.mutedUntil = level <= 2 ? Infinity : Date.now() + 10 * 60000;
      this.lastMsgIndex = -1;
      this.log("sales_declined", { level });
    }
  }

  // the visitor, by themselves, is on a page (home, category, product, search, bag, checkout…)
  // interests: what we remember they like (memory facts' values), for context
  // → { text for the voice, card } or null
  async moment({ page, visits, level, messages, subtotal, interests = [] }) {
    const L = LEVELS[level];
    if (!L) return null;
    this.checkDecline(messages, level);
    const now = Date.now();
    const skip = (reason, moment) => { this.log("sales_skip", { url: page?.url, moment, reason }); return null; };
    if (now < this.mutedUntil) return skip("they said no thanks");
    if (this.count >= L.max) return skip(`already ${this.count} this conversation`);
    if (now - this.lastAt < L.gapMs) return skip("too soon after the last one");
    const p = await this.pick({ page, visits, level, subtotal, interests });
    if (p.skip) { this.log("sales_skip", { url: page?.url, moment: p.kind, reason: p.skip, best: p.best ? { title: p.best.item.title || p.best.item.name, score: p.best.score } : undefined }); return null; }
    this.mark(p, messages, level);
    return {
      text: prompt("salesPitch", { moment: momentText(p.kind, p.cur, p.lately), offer: offerText(p.best), why: p.best.why || "it fits what they're looking at", style: L.style }),
      card: L.card && needsCard(p.best) ? cardOf(p.best) : null,
    };
  }

  // Assertive: the offer that fits best, woven into the greeting itself, so it
  // doesn't wait for a later moment → { text to add to the greeting, card } or null
  async greetingOffer({ page, visits, level, subtotal, interests = [] }) {
    const L = LEVELS[level];
    if (!L?.greet || Date.now() < this.mutedUntil || this.count >= L.max) return null;
    const p = await this.pick({ page, visits, level, subtotal, interests, any: true });
    if (p.skip) { this.log("sales_skip", { url: page?.url, moment: "greeting", reason: p.skip }); return null; }
    this.mark({ ...p, kind: `greeting (${p.kind})` }, [], level);
    return {
      text: prompt("salesGreeting", { offer: offerText(p.best), why: p.best.why || "it fits what they're looking at", style: L.style }),
      card: null, // spoken only: no pop-up on arrival
    };
  }

  // what fits this page now → { kind, cur, lately, best } or { skip: reason, kind, best }
  // any: any page counts (the greeting), not only this level's moments
  async pick({ page, visits, level, subtotal, interests = [], any = false }) {
    const L = LEVELS[level];
    let cur = visits.filter((v) => sameUrl(v.url, page?.url)).at(-1);
    if (!cur && any && page?.url) cur = { kind: "page", url: page.url, title: page.title, at: Date.now() };
    if (!cur) return { skip: "page not in the history yet" };

    // the moment, and what it's about
    let kind = cur.kind === "page" ? (isHome(cur.url) ? "home" : "browse") : cur.kind;
    const lately = interestOf(cur, visits, interests);
    const drop = priceDropSince(cur, visits);
    if (drop) kind = "price_drop";
    else if (kind === "product" && similarViewed(cur, visits) >= 2) kind = L.moments.includes("compare") ? "compare" : "product";
    if (!any && !L.moments.includes(kind)) return { skip: "not a moment at this level", kind };
    // someone signing in, getting help, returning or tracking an order isn't shopping
    if ((kind === "browse" || any) && SERVICE.test(new URL(cur.url).pathname)) return { skip: "a service page (account, help, returns…)", kind };

    let best = null;
    if (drop) {
      best = { type: "personal_drop", item: { id: `seen:${cur.url}`, name: cur.name, url: cur.url, price: drop.now, was: drop.before }, score: 0.95, why: `the price dropped from $${drop.before} to $${drop.now} since they last looked` };
    } else {
      const here = kind === "home" ? "" : [cur.brand, cur.name || cur.query || cur.heading || cur.title, cur.category].filter(Boolean).join(", ");
      const ctx = {
        // the page first; what they've been after lately as context (all of it on the home page)
        text: [here, lately].filter(Boolean).join(". ") || page?.title, brand: cur.brand, house: this.site,
        // what's running sitewide: the headline on the home page (or in a greeting), a fair fit elsewhere
        general: kind === "home" || any ? 0.78 : kind === "browse" ? 0.66 : undefined,
        url: kind === "product" || kind === "compare" ? cur.url : null, subtotal: subtotal ?? cur.subtotal ?? null, price: kind === "product" || kind === "compare" ? money(cur.price) : null,
      };
      if (kind === "checkout" || kind === "cart") ctx.text = `${ctx.text || ""} checkout bag promo code gift with purchase free shipping`;
      const ranked = this.offers?.has(this.site) ? (await this.offers.relevant(this.site, ctx)).filter((r) => !this.pitched.has(r.item.id)) : [];
      // at checkout, codes and thresholds matter most; elsewhere, what fits
      best = ranked.find((r) => kind !== "checkout" || r.item.code || r.item.min_spend) || null;
    }
    if (!best || best.score < L.minScore) return { skip: "nothing fits well enough", kind, best };
    return { kind, cur, lately, best };
  }

  mark({ kind, best }, messages, level) {
    this.pitched.add(best.item.id);
    this.count++;
    this.lastAt = Date.now();
    this.lastMsgIndex = messages.length;
    this.log("sales_pitch", { moment: kind, level, type: best.type, title: best.item.title || best.item.name, score: best.score, why: best.why });
  }

  // for the planner: the offers that fit this request and page, and how far to go
  async plannerBlock({ request, page, visits, level, subtotal }) {
    const L = LEVELS[level];
    if (!L || !this.offers?.has(this.site)) return null;
    const cur = visits.filter((v) => v.url === page?.url).at(-1) || {};
    const asking = /\b(deal|deals|offer|offers|sale|sales|discount|promo|coupon|code|gift with|free gift|save|saving|cheaper|price drop|rewards?)\b/i.test(request);
    // unasked, an offer in the planner's answer competes with the proactive pitches: only at
    // Proactive and Assertive, within the same spacing, and never as a pop-up
    if (!asking && (level < 3 || Date.now() < this.mutedUntil || Date.now() - this.lastAt < L.gapMs || this.count >= L.max)) return null;
    const ctx = { text: [request, cur.brand, cur.name, cur.category].filter(Boolean).join(". "), brand: cur.brand, house: this.site, url: cur.kind === "product" ? cur.url : null, subtotal: subtotal ?? cur.subtotal ?? null, price: cur.kind === "product" ? money(cur.price) : null, all: asking };
    const ranked = (await this.offers.relevant(this.site, ctx)).filter((r) => r.score >= (asking ? 0.3 : L.minScore - 0.15)).slice(0, asking ? 10 : 5);
    if (!ranked.length) return null;
    const items = ranked.map((r, i) => ({ ref: `O${i + 1}`, ...r }));
    const date = new Date(this.offers.status(this.site).updatedAt || Date.now()).toLocaleDateString("en-US", { month: "short", day: "numeric" });
    const lines = items.map((r) => `[${r.ref}] ${offerText(r)}${r.why ? ` (fits: ${r.why})` : ""}`);
    return {
      items,
      asked: asking,
      text: [`Offers running on this site (scanned ${date}; only these are real, never invent others):`, ...lines, "", prompt("salesPlanner", { style: L.style, already: [...this.pitched].length ? "Some offers were already mentioned in this conversation; don't repeat them unless asked." : "" })].join("\n"),
      used: (ids) => { for (const r of items) if (ids.includes(r.ref)) { this.pitched.add(r.item.id); this.lastAt = Date.now(); } },
    };
  }
}

// proactive offers are spoken; a card only when there's something to read and keep (a code)
const needsCard = (r) => !!r.item?.code;

// a product they viewed earlier at a higher price
function priceDropSince(cur, visits) {
  if (cur.kind !== "product" || !cur.price) return null;
  const now = money(cur.price);
  const earlier = visits.filter((v) => v.url.split("?")[0] === cur.url.split("?")[0] && v.at < cur.at - 60000 && v.price).map((v) => money(v.price)).filter(Boolean);
  const before = Math.max(0, ...earlier);
  return now && before > now * 1.02 ? { before, now } : null;
}
const sameUrl = (a, b) => !!a && !!b && String(a).split(/[?#]/)[0].replace(/\/$/, "") === String(b).split(/[?#]/)[0].replace(/\/$/, "");
const money = (s) => { const m = String(s || "").replace(/,/g, "").match(/\d+(?:\.\d+)?/); return m ? Number(m[0]) : null; };
const SERVICE = /\/(account|my-?account|login|log-?in|sign-?in|sign-?up|register|password|help|faq|support|contact|customer-?service|returns?|refund|track|order-?status|orders|privacy|terms|polic(y|ies)|legal|careers|accessibility|cookie)/i;
// the home page: the site's root (or /home, /index…)
const isHome = (u) => { try { return /^\/((home|index)(\.html?)?)?\/?$/i.test(new URL(u).pathname); } catch { return false; } };
// what they've been after lately: recent searches, categories, brands and products (not this
// page), and what we remember they like
function interestOf(cur, visits, interests) {
  const seen = new Set(), out = [];
  const add = (x) => { const k = String(x || "").trim(); if (k && k.length < 80 && !seen.has(k.toLowerCase())) { seen.add(k.toLowerCase()); out.push(k); } };
  for (const v of visits.filter((v) => v !== cur && v.url !== cur.url).slice(-8).reverse()) {
    if (v.kind === "search") add(v.query);
    else if (v.kind === "product") { add(v.category); add([v.brand, v.name].filter(Boolean).join(" ")); }
    else if (v.kind === "page" && !isHome(v.url)) add(v.heading || v.category);
  }
  for (const i of interests) add(i);
  return out.slice(0, 8).join(", ");
}
const similarViewed = (cur, visits) => visits.filter((v) => v.kind === "product" && v.url !== cur.url && ((cur.category && v.category === cur.category) || (cur.brand && v.brand === cur.brand))).length;

function momentText(kind, cur, lately) {
  const also = lately ? ` Lately they've been looking at: ${lately}.` : "";
  return ({
    home: "They're on the home page.",
    browse: `They're browsing ${describeVisit(cur)}.`,
    product: `They're looking at ${describeVisit(cur)}.`,
    compare: `They're looking at ${describeVisit(cur)}, after viewing similar products.`,
    search: `They're browsing ${describeVisit(cur)}.`,
    cart: `They're looking at their bag${cur.subtotal ? ` (subtotal ${cur.subtotal})` : ""}.`,
    checkout: `They're at checkout${cur.subtotal ? ` (subtotal ${cur.subtotal})` : ""}.`,
    price_drop: `They came back to ${describeVisit(cur)}.`,
  }[kind] || `They're on ${describeVisit(cur)}.`) + also;
}

export function offerText(r) {
  const x = r.item;
  if (r.type === "drop" || r.type === "personal_drop") return `${x.name}: now $${x.price}, was $${x.was}${x.pct ? ` (${x.pct}% off)` : ""}`;
  const same = (a, b) => String(a).toLowerCase().replace(/[^a-z0-9$%]/g, "") === String(b).toLowerCase().replace(/[^a-z0-9$%]/g, "");
  return [x.title, same(x.summary, x.title) ? "" : x.summary, x.code ? `code ${x.code}` : "", x.min_spend ? `minimum $${x.min_spend}` : "", x.who ? `for ${x.who}` : "", x.excludes ? `excludes ${x.excludes}` : "", x.ends ? `ends ${x.ends}` : ""].filter(Boolean).join(" · ");
}

// the glass card for an offer
export function cardOf(r) {
  const x = r.item;
  if (r.type === "drop" || r.type === "personal_drop") {
    return { kind: "offer", title: `Price drop: ${x.name}`.slice(0, 90), points: [`Now $${x.price}, was $${x.was}${x.pct ? ` (${x.pct}% off)` : ""}`, r.why && r.type === "personal_drop" ? "Lower than when you last looked" : ""].filter(Boolean), source: { title: "", url: x.url } };
  }
  const points = [x.summary, x.code ? `Use code ${x.code}` : "", r.why && /away|qualifies/.test(r.why) ? r.why.replace(/^they're/, "You're").replace(/^their bag/, "Your bag") : "", x.who ? `For ${x.who}` : "", x.ends ? `Ends ${new Date(`${x.ends}T12:00:00`).toLocaleDateString("en-US", { month: "short", day: "numeric" })}` : ""].filter(Boolean);
  return { kind: "offer", title: x.title, points: points.slice(0, 4), source: { title: "", url: x.url || "" } };
}
