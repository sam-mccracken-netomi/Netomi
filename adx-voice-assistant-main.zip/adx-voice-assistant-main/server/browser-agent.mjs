// The browser agent: operates the website for the visitor, one step at a time, like a
// person would. Each step it sees the request, the recent conversation, what it has done
// so far and a fresh snapshot of the page, and either acts (one or more actions in order,
// e.g. fill a form and submit it) or replies (done, needs the visitor's input, or can't).
//
// Each step is a stateless planner call built from scratch, so old page snapshots never
// pile up in the context. The page is reached through `page` (an RPC to the widget):
//   page.snapshot() → { url, title, text } | { navigating: true }
//   page.act(actions) → { results, url, navigating, snapshot? }
//   page.epoch() / page.waitForPage(ms, afterEpoch): a new page has loaded and connected

import { nextStep } from "./openai.mjs";
import { describeVisit } from "./persona.mjs";
import { prompt } from "./prompts.mjs";
import { sentences, complete } from "./netomi.mjs";
import { cardOf } from "./sales.mjs";
import { describeEvent } from "./memory.mjs";
import { sitemap } from "./sitemap.mjs";
import { vetter } from "./links.mjs";

const MAX_STEPS = 18; // waits for slow pages count as steps
const MAX_MEMORY = 6; // earlier tasks remembered in this conversation

// the planner's instructions live in prompts.mjs (editable from the extension)
// (plus where answers may come from: a prompt of its own, so it holds even when the
// planner's instructions are edited)
// domain: the site's registrable domain ({domain} in the prompts), e.g. sephora.com
export const instructions = (brand = "this site", domain = "this site") => `${prompt("planner", { brand, domain })}\n\n${prompt("grounding", { brand, domain })}`;

// the registrable domain, roughly: www.sephora.com and m.sephora.com are both sephora.com
export function siteOf(url) {
  let host;
  try { host = new URL(url).hostname; } catch { return ""; }
  const parts = host.replace(/^www\d?\./, "").split(".");
  if (parts.length <= 2 || /^\d+$/.test(parts.at(-1))) return parts.join(".");
  const sld = parts.at(-2);
  return parts.slice(parts.at(-1).length === 2 && /^(co|com|org|net|gov|ac|edu|ne|or)$/.test(sld) ? -3 : -2).join(".");
}

export const TOOLS = [
  {
    name: "act",
    description: "Perform actions on the page, in order.",
    parameters: {
      type: "object",
      properties: {
        why: { type: "string", description: "A few words on what this step does, e.g. 'Searching for red lipstick'" },
        actions: {
          type: "array",
          items: {
            type: "object",
            properties: {
              do: { type: "string", enum: ["click", "type", "select", "key", "read", "scroll", "go", "back", "wait"], description: "click [id]; type text into [id] (enter: press Enter after); select an option by its text in [id]; key: press a key (text: Enter, Escape, Tab, ArrowDown); read: the full text of [id] and the panel it controls (an accordion, a tab, a details or ingredients section), collapsed or not, without scrolling or opening it, so the visitor's view doesn't move; scroll: text up|down, or id to bring into view; go: open a URL on this site (same domain only) in text; back: browser back; wait: the page is still loading or results are still coming in, text = seconds (up to 15); returns as soon as the page is ready" },
              id: { type: "integer" },
              text: { type: "string" },
              enter: { type: "boolean" },
            },
            required: ["do"],
          },
        },
      },
      required: ["why", "actions"],
    },
  },
  {
    name: "reply",
    description: "Finish this turn: report the result, ask the visitor for what's missing, or say what's blocking.",
    parameters: {
      type: "object",
      properties: {
        status: { type: "string", enum: ["done", "need_info", "cannot"] },
        say: { type: "string", description: "What the voice says. For a list of results, name at most two products: the first two in the list, in page order (not three; you can say there are more)." },
        sources: { type: "array", items: { type: "string" }, description: "Ids of the knowledge passages (K1, K2…) and offers (O1, O2…) the answer relies on or mentions, if any" },
        card: {
          type: "object",
          description: "Only when sources are used: what to show on screen",
          properties: { title: { type: "string" }, points: { type: "array", items: { type: "string" } } },
          required: ["title", "points"],
        },
      },
      required: ["status", "say"],
    },
  },
];

// offered when Netomi answers this site's questions (settings: Netomi or both)
export const HELP_TOOL = {
  name: "ask_help_center",
  description: "Ask the help center (the brand's knowledge base) a question about its policies and services. Its answer goes straight to the visitor.",
  parameters: {
    type: "object",
    properties: {
      question: { type: "string", description: "The visitor's question, complete on its own (resolve 'it', 'that' from the conversation)" },
      title: { type: "string", description: "A short title for the on-screen card, e.g. 'Returning opened makeup'" },
    },
    required: ["question", "title"],
  },
};

// a help-center answer as the voice's script (the gist) and the on-screen card (all of it)
const noUrls = (text) => String(text).replace(/\s*\(?https?:\/\/\S+\)?/g, "");
const speakable = (a) => sentences(noUrls(complete(a.text, a.done))).slice(0, 3).join(" ").slice(0, 420);
export const helpCard = (a, title) => ({
  title, points: sentences(noUrls(complete(a.text, a.done))).slice(0, 4).map((s) => s.slice(0, 220)),
  source: { title: "", url: a.link || "" },
});

const ago = (at) => {
  const m = Math.round((Date.now() - (at || Date.now())) / 60000);
  return m < 1 ? "just now" : m < 60 ? `${m} min ago` : m < 48 * 60 ? `${Math.round(m / 60)} h ago` : `${Math.round(m / 1440)} days ago`;
};

export class BrowserAgent {
  // fast: a quicker model for a first step that's likely just answering from the
  // knowledge base (measured: ~2.5 s vs ~5 s, equally grounded); page work stays on `model`
  constructor({ apiKey, model, effort, fast, page, log, onProgress }) {
    Object.assign(this, { apiKey, model, effort, fast, page, log: log || (() => {}), onProgress: onProgress || (() => {}) });
    this.memory = [];
  }

  // isAborted: the visitor asked for something else meanwhile; stop between steps
  // visits: what the visitor viewed on this site, newest last (for "the earlier product")
  // knowledge: a promise of passages from the site's knowledge base, searched in parallel
  // help: when Netomi answers this site's questions, { ask(question) → a streaming answer
  // (netomi.mjs), likely: it was already asked, so this is probably a policy question }
  // sales: when sales is on, a promise of { items, text, used(refs) } (sales.mjs plannerBlock)
  // memory: what we know about the visitor (memory.mjs summary)
  // label: what to remember this task as, when the request is an instruction of ours
  // earlier: steps already taken, when resuming a task that waited for a slow page
  async run(request, { recent = [], visits = [], events = [], knowledge = Promise.resolve([]), help = null, sales = Promise.resolve(null), memory = "", brand, label, earlier = [], isAborted = () => false } = {}) {
    const steps = [...earlier];
    const task = label || request;
    const t0 = Date.now();
    this.log("task", { request });
    const kb = Promise.race([knowledge.catch(() => []), new Promise((r) => setTimeout(() => r([]), 3000))]);
    const offers = Promise.race([sales.catch(() => null), new Promise((r) => setTimeout(() => r(null), 3000))]);
    let [snap, passages, salesBlock] = await Promise.all([this.look(), kb, offers]);
    passages = (passages || []).map((p, i) => ({ ...p, ref: `K${i + 1}` }));
    if (!snap) return this.waiting(task, steps);
    // the site this task stays on: no "go" to, or click that lands on, another domain
    const home = siteOf(snap.url);
    const offSite = (u) => { const s = siteOf(u); return !!(home && s && s !== home); };
    const BLOCKED = `Blocked: off-site URL. Reply that you only see this site (${home}) and offer to help with the need here.`;
    // links it may give: the site's own pages and what the knowledge base says (links.mjs)
    const sitePages = home ? sitemap.match(home, request) : [];
    const guide = home ? sitemap.guide(home, request) : "";
    const startUrl = snap.url;
    const vet = vetter(home, [...passages.flatMap((p) => [p.url, p.text]), ...visits.map((v) => v.url), ...sitePages,
      ...(salesBlock?.items || []).map((r) => r.item?.url).filter((u) => u && siteOf(u) === home)]);
    let asked = false;
    for (let n = 1; n <= MAX_STEPS; n++) {
      if (isAborted()) return null;
      const quick = n === 1 && this.fast && (passages[0]?.score >= 0.45 || !!help?.likely);
      vet.addPage(snap);
      const call = await nextStep({
        apiKey: this.apiKey, model: quick ? this.fast.model : this.model, effort: quick ? this.fast.effort : this.effort,
        instructions: instructions(brand, siteOf(snap.url) || "this site"), tools: help && !asked ? [...TOOLS, HELP_TOOL] : TOOLS,
        input: [{ role: "user", content: this.prompt(request, recent, steps, snap, visits, passages, help && !asked, salesBlock, memory, events, sitePages, guide) }],
      });
      if (isAborted()) return null;
      this.log("step", { n, ms: call.ms, ...(call.hedged ? { hedged: true } : {}), model: quick ? this.fast.model : this.model, tool: call.name, args: call.args, url: snap.url, tokens: call.usage?.input_tokens });
      if (call.name === "reply") {
        const used = passages.filter((p) => (call.args.sources || []).includes(p.ref));
        let card = used.length && call.args.card?.points?.length ? { title: String(call.args.card.title || used[0].title), points: call.args.card.points.slice(0, 5).map(String), source: { title: used[0].title, url: used[0].url } } : null;
        // an offer it mentioned: on the card too (when there's no help-page card)
        const offerRefs = (call.args.sources || []).filter((x) => /^O\d+$/.test(x));
        if (salesBlock && offerRefs.length) {
          salesBlock.used(offerRefs);
          const first = salesBlock.items.find((r) => r.ref === offerRefs[0]);
          // a card when they asked about deals, or there's a code to read; otherwise just said
          if (!card && first && (salesBlock.asked || first.item?.code)) card = cardOf(first);
          this.log("offers_used", { refs: offerRefs, titles: salesBlock.items.filter((r) => offerRefs.includes(r.ref)).map((r) => r.item.title || r.item.name) });
        }
        // where this task ended up, for the next time someone asks the same (sitemap.mjs guide)
        if ((call.args.status || "done") === "done" && steps.length > earlier.length && snap.url !== startUrl && !label) sitemap.learnRoute(home, request, snap.url);
        return this.finish(task, vet, { status: call.args.status || "done", say: String(call.args.say || ""), sources: used.map((p) => p.url), card }, Date.now() - t0);
      }
      if (call.name === "ask_help_center" && help) {
        // the answer goes to the voice once its first sentences are in; the card gets the rest
        asked = true;
        const question = String(call.args.question || request);
        this.onProgress("Checking our help center", { elapsed: Date.now() - t0 });
        const answer = help.ask(question);
        const slow = setTimeout(() => this.onProgress("Still checking our help center", { elapsed: Date.now() - t0 }), Math.max(0, 10000 - (Date.now() - t0)));
        await answer.partial();
        clearTimeout(slow);
        if (isAborted()) return null;
        this.log("help_answer", { question, ms: Date.now() - answer.startedAt, done: answer.done, cached: answer.fromCache, answered: answer.answered(), text: answer.text.slice(0, 300) });
        if (answer.answered()) {
          vet.add(answer.link); for (const u of [answer.text, ...(answer.sources || []).map((x) => x.text)]) vet.addText(u);
          const title = String(call.args.title || question).slice(0, 80);
          return this.finish(task, vet, { status: "done", say: speakable(answer), card: helpCard(answer, title), help: { answer, title } }, Date.now() - t0);
        }
        steps.push({ why: `Asked the help center: ${JSON.stringify(question)}`, actions: [], results: [answer.error ? `it failed (${answer.error})` : "it had no answer"] });
        continue;
      }
      const actions = Array.isArray(call.args.actions) ? call.args.actions : [];
      if (call.name !== "act" || !actions.length) { steps.push({ why: "(invalid step, no actions)", actions: [], results: [] }); continue; }
      const away = actions.find((a) => { try { return a?.do === "go" && offSite(new URL(String(a.text || ""), snap.url).href); } catch { return false; } });
      if (away) {
        this.log("blocked", { url: away.text, home });
        steps.push({ why: call.args.why, actions, results: [`go: ${BLOCKED}`] });
        continue;
      }
      this.onProgress(call.args.why || "Working on it", { elapsed: Date.now() - t0 });
      const epoch = this.page.epoch();
      let res;
      try {
        res = (await this.page.act(actions)) || { results: ["the page navigated away"], navigating: true };
      } catch (e) {
        // the page went away mid-action: a click that loaded a new page
        res = e.navigated ? { results: ["the page navigated away"], navigating: true } : { results: [`FAILED: ${e.message}`] };
      }
      steps.push({ why: call.args.why, actions, results: res.results || [] });
      this.log("acted", { results: res.results, url: res.url, navigating: !!res.navigating });
      snap = res.snapshot && !res.navigating ? res.snapshot : await this.look(epoch, !!res.navigating);
      if (!snap) return this.waiting(task, steps);
      // a click that took the page to another site (a script, a redirect): go back
      if (offSite(snap.url)) {
        this.log("blocked", { url: snap.url, home });
        steps.at(-1).results.push(BLOCKED);
        const e2 = this.page.epoch();
        await this.page.act([{ do: "back" }]).catch(() => {});
        snap = await this.look(e2, true);
        if (!snap) return this.finish(task, vet, { status: "cannot", say: `That link left ${home}, and I can only help here on our site.` });
      }
    }
    return this.finish(task, vet, { status: "cannot", say: "That took more steps than I expected, so I stopped. Tell me how you'd like to continue." });
  }

  // a fresh snapshot; if the page is loading, wait for the next one to connect
  // waits up to ~45 s for a slow page, saying so after the first 12
  async look(epoch = this.page.epoch(), navigating = false) {
    const t0 = Date.now();
    let told = false;
    for (let i = 0; i < 6 && Date.now() - t0 < 45000; i++) {
      if (navigating || i > 0) {
        let ok = await this.page.waitForPage(12000, navigating ? epoch : undefined);
        if (!ok) {
          if (!told) { told = true; this.onProgress("The page is still loading", { elapsed: 8000 }); }
          ok = await this.page.waitForPage(Math.max(1000, 45000 - (Date.now() - t0)), navigating ? epoch : undefined);
        }
        if (!ok) return null;
        navigating = false;
      }
      try {
        const s = await this.page.snapshot();
        if (s && !s.navigating) return s;
        epoch = this.page.epoch();
        navigating = true;
      } catch (e) {
        this.log("look_failed", { error: e.message });
        if (!e.navigated) await new Promise((r) => setTimeout(r, 1000));
        epoch = this.page.epoch();
        navigating = !!e.navigated;
      }
    }
    return null;
  }

  prompt(request, recent, steps, snap, visits = [], passages = [], helpCenter = false, salesBlock = null, memory = "", events = [], sitePages = [], guide = "") {
    const date = new Date().toLocaleDateString("en-US", { weekday: "long", year: "numeric", month: "long", day: "numeric" });
    const out = [`Today is ${date}.`, "", `The visitor's request: ${JSON.stringify(request)}`];
    if (recent.length) {
      out.push("", "Recent conversation (oldest first):");
      for (const m of recent) out.push(`${m.role === "user" ? "Visitor" : "Voice assistant"}: ${m.text}`);
    }
    if (memory) out.push("", memory);
    const viewed = visits.filter((v) => v.kind !== "page" || v.heading).slice(-15);
    if (viewed.length) {
      out.push("", "Pages the visitor viewed on this site (oldest first; use these URLs to take them back to something):");
      for (const v of viewed) out.push(`- ${ago(v.at)}: ${v.kind} · ${describeVisit(v)} · ${v.url}`);
    }
    if (guide) out.push("", guide);
    if (sitePages.length) {
      out.push("", "Pages on this site that may fit the request (from its sitemap; real pages you can open with go):");
      for (const u of sitePages) out.push(`- ${u}`);
    }
    const did = events.slice(-12);
    if (did.length) {
      out.push("", "What the visitor did by themselves recently (oldest first; their clicks, not yours):");
      for (const x of did) out.push(`- ${ago(x.at)}: ${describeEvent(x)}`);
    }
    if (passages.length) {
      out.push("", "Knowledge base for this site (from its help and policy pages, not the current screen):");
      for (const p of passages) out.push(`[${p.ref}] ${p.title} › ${p.section}: ${p.text} (${p.url})`);
    }
    if (helpCenter) {
      out.push("", passages.length
        ? "Help center: for a question about the brand, its policies and services, or anything not about a product, that the knowledge passages above don't answer, call ask_help_center rather than looking on the site or answering yourself. If the passages answer it, reply from them."
        : "Help center: for a question about the brand, its policies and services (returns, shipping, rewards, payments, orders, stores…), or anything not about a product, call ask_help_center rather than looking on the site or answering yourself.");
      out.push("Questions about the product or page on screen are answered from the page, and website tasks are done on the page, not with the help center.");
    }
    if (salesBlock) out.push("", salesBlock.text);
    if (this.memory.length) {
      out.push("", "Earlier tasks in this conversation:");
      for (const m of this.memory) out.push(`- ${JSON.stringify(m.request)} → ${m.status}: ${m.say}`);
    }
    if (steps.length) {
      out.push("", "What you've done so far for this request:");
      steps.forEach((s, i) => {
        const acts = s.actions.map((a) => `${a.do}${a.id ? ` [${a.id}]` : ""}${a.text != null ? ` ${JSON.stringify(a.text)}` : ""}${a.enter ? " +Enter" : ""}`).join(", ");
        out.push(`${i + 1}. ${s.why}: ${acts || "(nothing)"} → ${s.results.join("; ") || "ok"}`);
      });
    }
    out.push("", "The page now:", snap.text);
    return out.join("\n");
  }

  // a page that's slow to load: not a failure. The conversation keeps the task and resumes it
  // (with the steps so far) when the page arrives
  waiting(task, steps) {
    this.log("task_waiting", { request: task, steps: steps.length });
    return { status: "waiting", say: "The page is taking a while to load. I'll carry on as soon as it's ready.", steps: steps.slice(-8) };
  }

  finish(request, vet, outcome, ms) {
    // only links from the site or the knowledge base reach the visitor
    if (vet) {
      const said = vet.text(outcome.say), shown = vet.card(outcome.card);
      const removed = [...said.removed, ...shown.removed];
      if (removed.length) this.log("links_removed", { removed });
      outcome = { ...outcome, say: said.text, card: shown.card };
    }
    const { help, ...logged } = outcome;
    this.log("task_done", { ...logged, ms });
    this.memory.push({ request, status: outcome.status, say: outcome.say });
    if (this.memory.length > MAX_MEMORY) this.memory.shift();
    return outcome;
  }
}
