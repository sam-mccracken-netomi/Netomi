// The site's own map of pages: the URLs a site publishes in its sitemaps (robots.txt →
// sitemap.xml), collected by the extension through the visitor's own tab (big retailers block
// crawlers) and kept here, per site.
//  - the planner gets the pages that match a request ("Pages on this site"), so it opens
//    real pages instead of guessing paths
//  - links.mjs uses it to tell a real page of the site from a made-up one
//   sitemap.ingest(site, urls) → { urls }      sitemap.status(site) → { urls, updatedAt }
//   sitemap.has(site, url) → bool              sitemap.match(site, query, k) → [url]
// And a guide to the site, so common requests don't need the page worked out each time:
//  - its menus (header, navigation, footer: label → URL), read once from a page of the site
//  - routes: where earlier tasks ended up ("find a store" → /stores), learned as it works
//   sitemap.guide(site, request) → text for the planner, or ""
//   sitemap.learnRoute(site, request, url)
import { existsSync, mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { DATA } from "./env.mjs";
import { siteOf } from "./browser-agent.mjs";

const DIR = join(DATA(), "sitemaps"); // Application Support inside the Mac app
const MAX = 60000;
const file = (site) => join(DIR, `${String(site).replace(/[^a-z0-9.-]/gi, "_")}.json`);

// a page's identity: host without www/m, path without the trailing slash; no query or hash
export function keyOf(url) {
  try {
    const u = new URL(url);
    return `${u.hostname.replace(/^(www\d?|m)\./, "")}${decodeURIComponent(u.pathname).replace(/\/+$/, "").toLowerCase()}`;
  } catch { return ""; }
}

const STOP = new Set("a an and the of for to in on at by with from my me our your you i we is are be it this that what where how can could do does show find take open go get page pages site please want need some any about".split(" "));
const words = (s) => String(s).toLowerCase().split(/[^a-z0-9]+/).filter((w) => w.length > 1 && !STOP.has(w));
const stem = (w) => w.replace(/(ies)$/, "y").replace(/(es|s)$/, "");

const save = (site, d) => {
  mkdirSync(DIR, { recursive: true });
  writeFileSync(file(site), JSON.stringify({ site, updatedAt: d.updatedAt, urls: d.urls, nav: d.nav, routes: d.routes, search: d.search }));
  loaded.delete(site);
};
const overlap = (a, b) => { const A = new Set(words(a).map(stem)), B = words(b).map(stem); return B.length ? B.filter((w) => A.has(w)).length / Math.max(A.size, 1) : 0; };

const loaded = new Map(); // site → { urls, keys:Set, updatedAt }
function load(site) {
  if (loaded.has(site)) return loaded.get(site);
  let d = { urls: [], updatedAt: 0 };
  try { if (existsSync(file(site))) d = JSON.parse(readFileSync(file(site), "utf8")); } catch {}
  const nav = d.nav || [], routes = d.routes || [];
  const entry = { urls: d.urls || [], nav, routes, search: !!d.search, keys: new Set([...(d.urls || []), ...nav.map((n) => n.url), ...routes.map((r) => r.url)].map(keyOf)), updatedAt: d.updatedAt || 0 };
  loaded.set(site, entry);
  return entry;
}

export const sitemap = {
  ingest(site, urls, nav = [], search = false) {
    const seen = new Set(), out = [];
    for (const raw of urls || []) {
      const u = String(raw || "").trim();
      if (!/^https?:\/\//i.test(u) || siteOf(u) !== site) continue; // the site's own pages only
      const k = keyOf(u);
      if (!k || seen.has(k)) continue;
      seen.add(k);
      out.push(u.split("#")[0]);
      if (out.length >= MAX) break;
    }
    // the menus: the site's own links with a readable label, one per URL
    const menu = [], seenNav = new Set();
    for (const n of nav || []) {
      const label = String(n?.label || "").replace(/\s+/g, " ").trim().slice(0, 60), url = String(n?.url || "");
      if (!label || !/^https?:\/\//i.test(url) || siteOf(url) !== site) continue;
      const k = keyOf(url);
      if (!k || seenNav.has(k)) continue;
      seenNav.add(k);
      menu.push({ label, url: url.split("#")[0], where: ["header", "footer", "menu"].includes(n.where) ? n.where : "menu" });
      if (menu.length >= 200) break;
    }
    const old = load(site);
    save(site, { updatedAt: Date.now(), urls: out.length ? out : old.urls, nav: menu.length ? menu : old.nav, routes: old.routes, search: !!search || old.search });
    return { urls: out.length || old.urls.length, nav: menu.length || old.nav.length };
  },
  status(site) {
    const d = load(site);
    return { urls: d.urls.length, nav: d.nav.length, routes: d.routes.length, updatedAt: d.updatedAt || null };
  },
  // where a task that worked ended up, for the next similar request (a page it went to, not
  // a search result or a product it happened to open)
  learnRoute(site, request, url) {
    if (!site || !url || siteOf(url) !== site) return;
    let u;
    try { u = new URL(url); } catch { return; }
    if (u.search && /[?&](q|query|keyword|search|s|term|text)=/i.test(u.search)) return;
    const d = load(site);
    const k = keyOf(url), req = String(request).slice(0, 120);
    const routes = d.routes.filter((r) => !(keyOf(r.url) === k && overlap(r.request, req) > 0.6));
    routes.push({ request: req, url: url.split("#")[0], at: Date.now() });
    save(site, { ...d, routes: routes.slice(-120) });
  },
  // what the planner is told about the site before it looks at the page
  guide(site, request) {
    const d = load(site);
    if (!d.nav.length && !d.routes.length) return "";
    const out = [];
    const routes = d.routes.map((r) => ({ r, s: overlap(r.request, request) })).filter((x) => x.s >= 0.5).sort((a, b) => b.s - a.s || b.r.at - a.r.at).slice(0, 3);
    if (routes.length) {
      out.push("Earlier, similar requests on this site ended on these pages (go straight there if it's the same need):");
      for (const { r } of routes) out.push(`- ${JSON.stringify(r.request)} → ${r.url}`);
    }
    if (d.nav.length) {
      const hits = d.nav.map((n) => ({ n, s: overlap(request, `${n.label} ${n.url}`) })).filter((x) => x.s > 0).sort((a, b) => b.s - a.s).slice(0, 8);
      const header = d.nav.filter((n) => n.where === "header").slice(0, 24);
      const shown = new Set();
      const line = (n) => { shown.add(n.url); return `- ${n.label} → ${n.url}`; };
      if (hits.length) { out.push("Site menu links that match the request:"); for (const { n } of hits) out.push(line(n)); }
      const rest = header.filter((n) => !shown.has(n.url));
      if (rest.length) out.push(`Main menu: ${rest.map((n) => `${n.label} (${n.url.replace(/^https?:\/\/[^/]+/, "") || "/"})`).join(" · ")}`);
    }
    if (d.search) out.push("The site has a search box (in the header).");
    return out.length ? ["Site guide (learned from this site's menus; use it to go straight to a page instead of hunting for links):", ...out].join("\n") : "";
  },
  has(site, url) { return load(site).keys.has(keyOf(url)); },
  // the site's pages whose path says what the request asks for: categories and help pages
  // over deep product pages, when they match as well
  match(site, query, k = 6) {
    const d = load(site);
    const want = [...new Set(words(query).map(stem))];
    if (!d.urls.length || !want.length) return [];
    const scored = [];
    for (const u of d.urls) {
      let path;
      try { path = new URL(u).pathname; } catch { continue; }
      const segs = words(path.replace(/[-_]/g, " ")).map(stem);
      if (!segs.length) continue;
      const hit = want.filter((w) => segs.includes(w)).length;
      if (!hit) continue;
      const depth = path.split("/").filter(Boolean).length;
      scored.push({ u, s: hit / want.length - depth * 0.03 - segs.length * 0.01 });
    }
    return scored.sort((a, b) => b.s - a.s).slice(0, k).map((x) => x.u);
  },
};
