// What the voice (GPT-Live) is told. It talks; the app operates the website. Anything that
// needs the site is delegated, and the result comes back as commentary to say. The wording
// lives in prompts.mjs (editable from the extension); this file adds the context.

import { prompt } from "./prompts.mjs";

const MAX_HISTORY = 16; // turns carried over from an earlier conversation
const MAX_TURN_CHARS = 600;

// the brand the assistant speaks for: the site's own name ("Sephora"), else its domain
export const brandOf = (page) => page?.brand || (page?.site || hostOf(page?.url)).split(".")[0].replace(/^./, (c) => c.toUpperCase());

// memory: what we know about the visitor (memory.mjs summary), if anything
export function instructions({ name, page, history, memory = "" }) {
  const lines = [prompt("voice", { name, brand: brandOf(page) })];
  if (memory) lines.push("", memory);
  if (page?.title || page?.url) {
    lines.push("", `The visitor is on: ${clean(page.title, 160) || "(untitled page)"}${page.url ? ` (${clean(page.url, 300)})` : ""}.`);
  }
  const turns = (Array.isArray(history) ? history : [])
    .filter((t) => (t?.role === "user" || t?.role === "agent") && typeof t.text === "string" && t.text.trim())
    .slice(-MAX_HISTORY);
  if (turns.length) {
    lines.push("", "Your earlier conversation with this visitor on this site (it may have just been interrupted by a page load, or been a while ago). Carry on naturally; don't mention reconnecting:");
    for (const t of turns) lines.push(`${t.role === "user" ? "Visitor" : "You"}: ${clean(t.text, MAX_TURN_CHARS)}`);
  }
  return lines.join("\n");
}

// ---- being proactive ------------------------------------------------------------------------

// The opening line when the visitor starts a conversation by clicking the orb. A first
// conversation on this site gets a short greeting fitted to the site and what they're
// looking at; a returning visitor gets a nudge about where they left off instead.
export function greeting({ site, page, visits, history, lastAt }) {
  const recent = (history || []).filter((m) => m?.text).slice(-6);
  const lines = [
    prompt("greetingOpen"),
    `Website: ${brandOf(page)} (${site || hostOf(page?.url)}). ${describeNow(page, visits)}`,
  ];
  const viewed = viewedBefore(page, visits, 5);
  if (viewed.length) lines.push(`Earlier on this site they viewed: ${viewed.join("; ")}.`);
  if (recent.length) {
    lines.push(
      `They talked with you here before (${ago(lastAt)}). The end of that conversation:`,
      ...recent.map((m) => `${m.role === "user" ? "Visitor" : "You"}: ${clean(m.text, 220)}`),
      prompt("greetingReturning"),
    );
  } else {
    lines.push(prompt("greetingFirst"));
  }
  lines.push(prompt("greetingClose"));
  return lines.join("\n");
}

// A suggestion when, mid-conversation, the visitor opens another product after viewing
// others (not when the app itself navigated). The voice may also stay quiet.
export function nudge({ page, visits }) {
  const viewed = viewedBefore(page, visits, 4, "product");
  return [
    `The visitor just opened a product page by themselves. ${describeNow(page, visits)}`,
    `Products they viewed before this: ${viewed.join("; ")}.`,
    prompt("nudge"),
  ].join("\n");
}

export const describeVisit = (v) => {
  const what = v.kind === "product" ? [v.brand, v.name].filter(Boolean).join(" ") + (v.price ? ` (${v.price})` : "")
    : v.kind === "search" ? `a search for "${v.query || clean(v.title, 60)}"`
    : v.kind === "cart" ? "their cart" : v.kind === "checkout" ? "checkout" : clean(v.heading || v.title, 80);
  return clean(what, 140);
};

function describeNow(page, visits) {
  const cur = (visits || []).filter((v) => v.url === page?.url).at(-1);
  if (cur) return `Right now they're on ${cur.kind === "product" ? "the product page for " : ""}${describeVisit(cur)}.`;
  return page?.title ? `Right now they're on "${clean(page.title, 100)}".` : "";
}

function viewedBefore(page, visits, n, kind) {
  const seen = new Set();
  return (visits || []).filter((v) => v.url !== page?.url && (!kind || v.kind === kind))
    .reverse().filter((v) => { const k = describeVisit(v); if (seen.has(k)) return false; seen.add(k); return true; })
    .slice(0, n).reverse().map(describeVisit);
}

function ago(at) {
  if (!at) return "some time ago";
  const m = Math.round((Date.now() - at) / 60000);
  return m < 2 ? "a moment ago" : m < 60 ? `${m} minutes ago` : m < 48 * 60 ? `${Math.round(m / 60)} hours ago` : `${Math.round(m / 1440)} days ago`;
}

const hostOf = (u) => { try { return new URL(u).hostname.replace(/^www\./, ""); } catch { return "this website"; } };

const clean = (s, max) => String(s || "").replace(/\s+/g, " ").trim().slice(0, max);
