// Links the assistant may give: only ones that come from the site or from the knowledge base.
//  - the site's own pages: in its sitemap, on a page the planner saw, or a page the visitor
//    viewed (with no sitemap yet, any page of the site; the site's home is always fine)
//  - anything a knowledge passage or a Netomi help-center answer contains, even on another domain
// Everything else (a link the model made up, another website) is taken out before it's said
// or shown: a full off-site link is dropped, a bare domain ("amazon.com") becomes its name.
import { siteOf } from "./browser-agent.mjs";
import { sitemap, keyOf } from "./sitemap.mjs";

const URL_RE = /\bhttps?:\/\/[^\s<>"'()\[\]{}]+|\bwww\.[a-z0-9-]+(?:\.[a-z0-9-]+)+[^\s<>"'()\[\]{}]*|\b(?:[a-z0-9-]+\.)+(?:com|net|org|io|co|us|uk|ca|in|au|de|fr|info|biz|shop|store|app|ai|me|tv)\b(?:\/[^\s<>"'()\[\]{}]*)?/gi;
const TRAIL = /[.,;:!?…]+$/;

export function urlsIn(text) {
  return [...String(text || "").matchAll(URL_RE)].map((m) => m[0].replace(TRAIL, ""));
}
const abs = (u) => (/^https?:\/\//i.test(u) ? u : `https://${u}`);

// known: URLs that came from the knowledge base, a help-center answer, the page or the
// visitor's own browsing, for this task
export function vetter(site, known = []) {
  const keys = new Set();
  const add = (u) => { const k = keyOf(abs(u)); if (k) keys.add(k); };
  for (const u of known) { if (u) { add(u); for (const x of urlsIn(u)) add(x); } }
  const hasMap = sitemap.status(site).urls > 0;
  const ok = (u) => {
    const url = abs(u);
    const k = keyOf(url);
    if (!k) return false;
    if (keys.has(k)) return true;
    if (siteOf(url) !== site) return false;
    let path = "/";
    try { path = new URL(url).pathname; } catch {}
    return path.replace(/\/+$/, "") === "" || !hasMap || sitemap.has(site, url);
  };
  return {
    add,
    addText(t) { for (const x of urlsIn(t)) add(x); },
    // the site's own links on a page the planner saw (shown as "→ /path" in the snapshot)
    addPage(snap) {
      for (const m of String(snap?.text || "").matchAll(/→ (\S+)/g)) {
        try { const u = new URL(m[1], snap.url).href; if (siteOf(u) === site) add(u); } catch {}
      }
      if (snap?.url && siteOf(snap.url) === site) add(snap.url);
    },
    ok,
    // text with only the links it may keep: a bare domain becomes its name ("amazon.com" →
    // "Amazon"); a sentence built around a link it may not give is dropped
    text(s) {
      const removed = [];
      const one = (sentence) => {
        let drop = false;
        const out = sentence.replace(URL_RE, (m) => {
          const u = m.replace(TRAIL, ""), tail = m.slice(u.length);
          if (ok(u)) return m;
          removed.push(u);
          if (/^https?:|^www\./i.test(u) || u.includes("/")) { drop = true; return tail; }
          const name = u.split(".").slice(-2, -1)[0] || u;
          return name.charAt(0).toUpperCase() + name.slice(1) + tail;
        });
        return drop ? "" : out;
      };
      // sentences end at . ! ? followed by a space, so "zz.com/a.b" stays whole
      const parts = String(s ?? "").split(/(?<=[.!?])\s+/);
      let out = parts.map(one).filter((x) => x.trim()).join(" ").replace(/ {2,}/g, " ").trim();
      if (!out && removed.length) out = "I don't have a link for that, but I can find it here on our site.";
      return { text: out, removed };
    },
    card(card) {
      if (!card) return { card, removed: [] };
      const removed = [];
      const clean = (s) => { const r = this.text(s); removed.push(...r.removed); return r.text; };
      const c = { ...card, title: clean(card.title || ""), points: (card.points || []).map(clean).filter(Boolean) };
      if (card.source) {
        c.source = { ...card.source };
        if (c.source.url && !ok(c.source.url)) { removed.push(c.source.url); c.source.url = ""; }
      }
      if (card.url && !ok(card.url)) { removed.push(card.url); c.url = ""; }
      return { card: c, removed };
    },
  };
}
