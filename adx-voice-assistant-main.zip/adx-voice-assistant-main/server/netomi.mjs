// Netomi's knowledge answers, through its Stream Proxy. The token call, request body and
// NDJSON parsing are taken from streamproxy-chat/streamProxyChat.mjs (the Salesforce V2
// Copilot's rules); the bot comes from the settings page instead of env vars.
//
// Netomi is slow (measured: token ~1 s, first words 4.5-7.5 s, whole answer 11-13 s), so:
//  - the token is cached (in memory and on disk; it lasts 30 days) and fetched ahead of time
//  - the question goes out the moment the visitor asks (conversation.mjs), alongside the
//    planner's first step, not after it
//  - the answer streams: whoever waits can take it once its first whole sentences are in
//    (partial(), ~1-2 s after the first words), and the card fills in the rest as it arrives
//  - answers are cached for a day, matched by meaning, so a repeated question is instant
//
//   const netomi = createNetomi({ embed, log })
//   const a = netomi.ask(question, bot, { conversationId })   bot: settings' knowledge.netomi
//   a.text · a.done · a.answered() · await a.partial(ms) · await a.finished · a.onUpdate(fn)

import { randomUUID } from "node:crypto";
import { readFileSync, writeFileSync, existsSync, mkdirSync, chmodSync } from "node:fs";
import { join } from "node:path";
import { DATA } from "./env.mjs";

const MULTI_SOURCE = "ai.msg.domain.responses.core.MultiSource";
const CARD = "ai.msg.domain.responses.core.Card";
const TOKEN_DAYS = 29; // the token is asked for 30 days
const CACHE_HOURS = 24;
const CACHE_MATCH = 0.93; // cosine similarity for "the same question"
// a question's words that matter, in order: no filler, no brand name, no punctuation
const FILLER = new Set("what whats is are was the a an your yours you do does did can could would will i im me my please tell about us we our there any have has offer offers provide get it its to of hi hey hello so just know want like id".split(" "));
function gist(q, bot) {
  const brands = String(bot?.sites || "").toLowerCase().split(/[\s,]+/).map((s) => s.split(".")[0]).filter(Boolean);
  const words = q.toLowerCase().replace(/[\u2019']s\b/g, "").replace(/[\u2019']/g, "").replace(/[^a-z0-9 ]+/g, " ").split(/\s+/)
    .filter((w) => w && !FILLER.has(w) && !brands.includes(w));
  return words.length >= 1 ? words.join(" ") : "";
}
// asked ahead of time (prefetch): [the visitor's way, the planner's way]
const COMMON = [
  ["What is your return policy?", "What is {brand}'s return policy?"],
  ["How long does shipping take?", "How long does {brand} shipping take?"],
  ["Do you offer free shipping?", "Does {brand} offer free shipping?"],
  ["How do I track my order?", "How do I track my {brand} order?"],
  ["Can I cancel or change my order?", "Can I cancel or change my {brand} order?"],
  ["What payment methods do you accept?", "What payment methods does {brand} accept?"],
  ["How does your rewards program work?", "How does the {brand} rewards program work?"],
  ["Do you do price adjustments?", "Does {brand} offer price adjustments?"],
  ["Can I buy online and pick up in store?", "Can I buy online and pick up in store at {brand}?"],
  ["How do gift cards work?", "How do {brand} gift cards work?"],
];
const CACHE_MAX = 300;
// Netomi's way of saying it has nothing on this
const NO_ANSWER = /\b(not able to help|unable to help|can'?t help with that|don'?t have (that|any) information)\b/i;

const tokenFile = () => join(DATA(), "netomi-tokens.json");
const cacheFile = () => join(DATA(), "netomi-cache.json");
const readJson = (f, fallback) => { try { return existsSync(f) ? JSON.parse(readFileSync(f, "utf8")) : fallback; } catch { return fallback; } };
const botKey = (bot) => `${bot.authUrl}|${bot.botId}|${bot.refId}`;

// the bot's HTML answer as plain text, for speaking and the card: links keep their label,
// the numbered source links and emoji go
export function htmlToText(html) {
  return String(html)
    .replace(/<a[^>]*class=['"]source-link-number['"][^>]*>.*?<\/a>/gi, "")
    .replace(/<br\s*\/?>/gi, "\n")
    .replace(/<\/(p|div|li|h\d)>/gi, "\n")
    .replace(/<li[^>]*>/gi, "• ")
    .replace(/<[^>]+>/g, "")
    .replace(/&nbsp;/g, " ").replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&#39;/g, "'")
    .replace(/[\p{Extended_Pictographic}\u{FE0F}\u{200D}]/gu, "")
    .replace(/[ \t]+/g, " ")
    .replace(/ *\n */g, "\n")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

// the part of a streaming answer that's whole sentences (all of it once it's done)
export const complete = (text, done) => (done ? String(text) : String(text).match(/^[\s\S]*[.!?](?=\s|$)/)?.[0] || "");

export const sentences = (text) => String(text).split(/(?<=[.!?])\s+|\n+/).map((s) => s.replace(/^[•*-]\s*/, "").trim()).filter((s) => s.length > 2);

async function* readNdjson(response) {
  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split("\n");
    buffer = lines.pop() ?? "";
    for (const line of lines) {
      if (!line.trim()) continue;
      try { yield JSON.parse(line); } catch {} // malformed lines are skipped, as in agenty
    }
  }
  if (buffer.trim()) { try { yield JSON.parse(buffer); } catch {} }
}

function body(query, conversationId) {
  return JSON.stringify({
    conversationId,
    ownerType: "BOT",
    messagePayload: { text: query, label: query, messageId: randomUUID(), timestamp: Date.now() },
    userDetails: { emailId: "", userId: "" },
    additionalAttributes: {
      CUSTOM_ATTRIBUTES: [
        { type: "TEXT", name: "ORIGIN", value: "STREAM_PROXY", scope: "LIFE_TIME" },
        { type: "TEXT", name: "conversation_id", value: conversationId, scope: "LIFE_TIME" },
      ],
    },
  });
}

export function createNetomi({ embed = null, log = () => {} } = {}) {
  const tokens = new Map(Object.entries(readJson(tokenFile(), {}))); // botKey → { token, at }
  const pendingTokens = new Map();
  let cache = readJson(cacheFile(), []); // [{ bot, q, vec (base64), text, link, at }]

  function saveTokens() {
    try {
      mkdirSync(DATA(), { recursive: true });
      writeFileSync(tokenFile(), JSON.stringify(Object.fromEntries(tokens)));
      chmodSync(tokenFile(), 0o600);
    } catch {}
  }

  async function token(bot, refresh = false) {
    const key = botKey(bot);
    const t = tokens.get(key);
    if (!refresh && t && Date.now() - t.at < TOKEN_DAYS * 864e5) return t.token;
    if (!refresh && pendingTokens.has(key)) return pendingTokens.get(key);
    const p = (async () => {
      const t0 = Date.now();
      const res = await fetch(bot.authUrl, {
        method: "POST",
        headers: { "x-channel": "NETOMI_WEB_WIDGET", "x-virtual-agent-id": bot.botId, "x-channel-ref-id": bot.refId, "Content-Type": "application/json", "expires-in": "30d" },
        body: "{}",
      });
      const json = await res.json().catch(() => ({}));
      const tok = json?.payload?.token;
      if (!res.ok || !tok) throw new Error(`Netomi token failed (HTTP ${res.status}): ${json?.message || json?.error || "check the bot ID and bot ref ID"}`);
      tokens.set(key, { token: tok, at: Date.now() });
      saveTokens();
      log("netomi_token", { ms: Date.now() - t0 });
      return tok;
    })().finally(() => pendingTokens.delete(key));
    pendingTokens.set(key, p);
    return p;
  }

  // ---- the answer cache: the same question (by meaning) on the same bot within a day ------
  const vecOf = (b64) => { const b = Buffer.from(b64, "base64"); return new Float32Array(b.buffer.slice(b.byteOffset, b.byteOffset + b.byteLength)); };
  const dot = (a, b) => { let s = 0; for (let i = 0; i < a.length; i++) s += a[i] * b[i]; return s; };
  async function vector(q) {
    if (!embed) return null;
    try { return (await embed([q]))[0]; } catch { return null; }
  }
  async function cached(q, bot) {
    const key = botKey(bot);
    cache = cache.filter((c) => Date.now() - c.at < CACHE_HOURS * 3600e3);
    const norm = q.trim().toLowerCase();
    const exact = cache.find((c) => c.bot === key && c.q.toLowerCase() === norm);
    if (exact) return exact;
    // the same words that matter ("tell me about return policy" = "What is Sephora's return
    // policy?"), safer than lowering the meaning threshold: "return policy for sale items"
    // is close in meaning (0.87) but a different question
    const words = gist(q, bot);
    const same = words && cache.find((c) => c.bot === key && gist(c.q, bot) === words);
    if (same) return same;
    const v = await vector(q);
    if (!v) return null;
    let best = null, score = 0;
    for (const c of cache) {
      if (c.bot !== key || !c.vec) continue;
      const s = dot(v, vecOf(c.vec));
      if (s > score) { score = s; best = c; }
    }
    return score >= CACHE_MATCH ? best : null;
  }
  async function remember(q, bot, answer) {
    const v = await vector(q);
    cache = cache.filter((c) => !(c.bot === botKey(bot) && c.q.toLowerCase() === q.trim().toLowerCase()));
    cache.push({ bot: botKey(bot), q: q.trim(), vec: v ? Buffer.from(v.buffer).toString("base64") : null, text: answer.text, link: answer.link, at: Date.now() });
    if (cache.length > CACHE_MAX) cache = cache.slice(-CACHE_MAX);
    try { mkdirSync(DATA(), { recursive: true }); writeFileSync(cacheFile(), JSON.stringify(cache)); } catch {}
  }

  // ---- one question, streaming ---------------------------------------------------------------
  // useCache: false for a question that may lean on the conversation ("what about sale items?")
  function ask(question, bot, { conversationId = randomUUID(), useCache = true } = {}) {
    const listeners = new Set();
    const a = {
      question, html: "", text: "", link: null, sources: [], intent: null,
      done: false, error: null, fromCache: false, startedAt: Date.now(), firstAt: 0,
      onUpdate(fn) { listeners.add(fn); return () => listeners.delete(fn); },
      // an answer we can use (as far as we can tell so far)
      answered() { return !!a.text && !NO_ANSWER.test(a.text.slice(0, 160)) && (!a.done || !a.error); },
      // wait until the first sentences are in (or it's done, or ms passed)
      partial(ms = 25000) {
        // a sentence or two in (enough to give the gist), or a "can't help" that's clear from its first words
        const ready = () => a.done || NO_ANSWER.test(a.text.slice(0, 160)) || complete(a.text).length >= 90;
        return new Promise((resolve) => {
          if (ready()) return resolve(a);
          const timer = setTimeout(() => { off(); resolve(a); }, ms);
          const off = a.onUpdate(() => { if (ready()) { clearTimeout(timer); off(); resolve(a); } });
        });
      },
    };
    const update = () => { for (const f of [...listeners]) { try { f(a); } catch {} } };

    a.finished = (async () => {
      const hit = useCache ? await cached(question, bot) : null;
      if (hit) {
        Object.assign(a, { text: hit.text, link: hit.link, fromCache: true, firstAt: Date.now(), intent: "cached" });
        log("netomi_cache_hit", { question, matched: hit.q });
        return;
      }
      const send = async (tok) => fetch(bot.proxyUrl, {
        method: "POST",
        headers: { "x-channel": "CHAT", "x-integration": "NETOMI_WEB_WIDGET", "x-virtual-agent-id": bot.botId, "x-channel-ref-id": bot.refId, "x-auth-token": tok, "Content-Type": "application/json" },
        body: body(question, conversationId),
      });
      let res = await send(await token(bot));
      if (res.status === 401) res = await send(await token(bot, true)); // the same retry as agenty
      if (!res.ok) throw new Error(`Netomi answer failed: HTTP ${res.status} ${(await res.text()).slice(0, 200)}`);
      for await (const chunk of readNdjson(res)) {
        for (const at of chunk.attachments ?? []) {
          const att = at.attachment ?? {};
          if (at.type === MULTI_SOURCE) a.sources.push(...(att.multipleSourceDetails ?? []));
          else if (at.type === CARD) a.html += `${att.title ? `<p>${att.title}</p>` : ""}${att.text ?? ""}`;
          else a.html += att.text ?? "";
        }
        a.intent = chunk.customPayload?.icInfo?.intent ?? a.intent;
        // hold back a half-received tag (`<a href="…`)
        const safe = a.html.lastIndexOf("<") > a.html.lastIndexOf(">") ? a.html.slice(0, a.html.lastIndexOf("<")) : a.html;
        const text = htmlToText(safe);
        if (text !== a.text) {
          if (!a.firstAt && text) a.firstAt = Date.now();
          a.text = text;
          a.link ||= (safe.match(/<a\s[^>]*href="(https?:[^"]+)"/i) || [])[1] || null;
          update();
        }
      }
      a.text = htmlToText(a.html);
      a.link ||= (a.html.match(/<a\s[^>]*href="(https?:[^"]+)"/i) || [])[1] || a.sources.map((s) => s.text).find((s) => /^https?:/.test(s || "")) || null;
      if (a.answered()) remember(question, bot, a);
    })()
      .catch((e) => { a.error = e.message; log("netomi_error", { question, error: e.message }); })
      .finally(() => {
        a.done = true;
        log("netomi_answer", { question, ms: Date.now() - a.startedAt, first_ms: a.firstAt ? a.firstAt - a.startedAt : null, cached: a.fromCache, answered: a.answered(), intent: a.intent, chars: a.text.length, error: a.error });
        update();
      });
    return a;
  }

  // fetch the token ahead of the first question (on start, and when the settings change)
  function warm(bot) {
    if (bot?.botId && bot?.refId) token(bot).catch((e) => log("netomi_token_failed", { error: e.message }));
  }

  // The questions visitors ask most, answered ahead of time (once a day per bot, two at a
  // time, in the background), so the first time someone asks, the answer comes from the
  // cache in about a second instead of Netomi's ~7. Phrased both ways they arrive: the
  // visitor's words ("what's your return policy?") and the planner's ("What is Sephora's…").
  const prefetched = new Map(); // bot → when
  function prefetch(bot, brand = "") {
    if (!bot?.botId || !bot?.refId || !embed) return;
    const key = botKey(bot);
    if (Date.now() - (prefetched.get(key) || 0) < CACHE_HOURS * 3600e3) return;
    prefetched.set(key, Date.now());
    const qs = COMMON.flatMap(([you, theirs]) => [you, brand ? theirs.replace("{brand}", brand) : null]).filter(Boolean);
    const t0 = Date.now();
    let asked = 0;
    const next = async () => {
      while (qs.length) {
        const q = qs.shift();
        if (await cached(q, bot)) continue;
        asked++;
        await ask(q, bot, { useCache: false }).finished;
      }
    };
    Promise.all([next(), next()]).then(() => log("netomi_prefetch", { bot: bot.botId, asked, ms: Date.now() - t0 })).catch(() => {});
  }

  return { ask, warm, token, prefetch };
}
