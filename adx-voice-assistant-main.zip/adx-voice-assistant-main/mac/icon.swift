// Draws the app icon (the orb on a soft rounded square) as a 1024 px PNG.
//   swiftc mac/icon.swift -o icon && ./icon out.png
import AppKit

let size: CGFloat = 1024
let image = NSImage(size: NSSize(width: size, height: size))
image.lockFocus()
let ctx = NSGraphicsContext.current!.cgContext
let rgb = CGColorSpaceCreateDeviceRGB()
func color(_ hex: UInt32, _ a: CGFloat = 1) -> CGColor {
    CGColor(red: CGFloat((hex >> 16) & 255) / 255, green: CGFloat((hex >> 8) & 255) / 255, blue: CGFloat(hex & 255) / 255, alpha: a)
}
// the tile: macOS icon grid (824 px squircle-ish rounded square, centred), with a soft shadow
let tile = CGRect(x: 100, y: 100, width: 824, height: 824)
let path = CGPath(roundedRect: tile, cornerWidth: 185, cornerHeight: 185, transform: nil)
ctx.saveGState()
ctx.setShadow(offset: CGSize(width: 0, height: -14), blur: 40, color: color(0x1c1c3a, 0.28))
ctx.addPath(path)
ctx.setFillColor(color(0xffffff))
ctx.fillPath()
ctx.restoreGState()
ctx.saveGState()
ctx.addPath(path)
ctx.clip()
let bg = CGGradient(colorsSpace: rgb, colors: [color(0xffffff), color(0xeceaff)] as CFArray, locations: [0, 1])!
ctx.drawLinearGradient(bg, start: CGPoint(x: 0, y: 924), end: CGPoint(x: 0, y: 100), options: [])
ctx.restoreGState()
// the orb: a glow behind, the sphere, a highlight
let c = CGPoint(x: 512, y: 512), r: CGFloat = 255
let glow = CGGradient(colorsSpace: rgb, colors: [color(0x6e8cff, 0.45), color(0x6e8cff, 0)] as CFArray, locations: [0.55, 1])!
ctx.drawRadialGradient(glow, startCenter: c, startRadius: 0, endCenter: c, endRadius: r * 1.45, options: [])
ctx.saveGState()
ctx.addEllipse(in: CGRect(x: c.x - r, y: c.y - r, width: 2 * r, height: 2 * r))
ctx.clip()
let body = CGGradient(colorsSpace: rgb, colors: [color(0xe8fcff), color(0x8fc4ff), color(0x6f7ef0), color(0x6e56ff)] as CFArray, locations: [0, 0.38, 0.72, 1])!
ctx.drawRadialGradient(body, startCenter: CGPoint(x: c.x - 80, y: c.y + 95), startRadius: 0, endCenter: c, endRadius: r * 1.05, options: [.drawsAfterEndLocation])
let tint = CGGradient(colorsSpace: rgb, colors: [color(0xff9be3, 0.55), color(0xff9be3, 0)] as CFArray, locations: [0, 1])!
ctx.drawRadialGradient(tint, startCenter: CGPoint(x: c.x + 110, y: c.y - 120), startRadius: 0, endCenter: CGPoint(x: c.x + 110, y: c.y - 120), endRadius: r * 0.9, options: [])
let hl = CGGradient(colorsSpace: rgb, colors: [color(0xffffff, 0.85), color(0xffffff, 0)] as CFArray, locations: [0, 1])!
ctx.drawRadialGradient(hl, startCenter: CGPoint(x: c.x - 90, y: c.y + 120), startRadius: 0, endCenter: CGPoint(x: c.x - 90, y: c.y + 120), endRadius: r * 0.5, options: [])
ctx.restoreGState()
image.unlockFocus()
let rep = NSBitmapImageRep(data: image.tiffRepresentation!)!
try! rep.representation(using: .png, properties: [:])!.write(to: URL(fileURLWithPath: CommandLine.arguments[1]))
