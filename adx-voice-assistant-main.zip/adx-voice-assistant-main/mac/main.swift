// Talk to Website for macOS: a menu-bar app that runs the relay server (with the Node
// runtime bundled inside the app) and helps install the Chrome extension.
//
//   Contents/Resources/node          the Node runtime
//   Contents/Resources/app/          server/, client/, extension/, node_modules/, .env (the key)
//   Contents/Resources/seed/         knowledge bases copied in on first launch
//   ~/Library/Application Support/Talk to Website/
//       data/        prompts and knowledge bases (DATA_DIR)
//       logs/        conversation logs and server.log (LOG_DIR)
//       Chrome Extension/   the extension, for Chrome's "Load unpacked"

import AppKit

let PORT = 5179

final class AppDelegate: NSObject, NSApplicationDelegate {
    private var statusItem: NSStatusItem!
    private let statusLine = NSMenuItem(title: "Starting…", action: nil, keyEquivalent: "")
    private var toggleItem: NSMenuItem!
    private var server: Process?
    private var stopping = false
    private var restarts = 0
    private let fm = FileManager.default
    private lazy var resources = Bundle.main.resourceURL!
    private lazy var support: URL = {
        let url = fm.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0].appendingPathComponent("Talk to Website")
        try? fm.createDirectory(at: url, withIntermediateDirectories: true)
        return url
    }()
    private var extensionFolder: URL { support.appendingPathComponent("Chrome Extension") }
    private var logsFolder: URL { support.appendingPathComponent("logs") }

    func applicationDidFinishLaunching(_ notification: Notification) {
        statusItem = NSStatusBar.system.statusItem(withLength: NSStatusItem.squareLength)
        if let image = NSImage(systemSymbolName: "waveform.circle", accessibilityDescription: "Talk to Website") {
            image.isTemplate = true
            statusItem.button?.image = image
        } else {
            statusItem.button?.title = "◉"
        }
        buildMenu()
        prepareSupportFolder()
        startServer()
        if !UserDefaults.standard.bool(forKey: "welcomed") {
            UserDefaults.standard.set(true, forKey: "welcomed")
            DispatchQueue.main.asyncAfter(deadline: .now() + 1) { self.installExtension(nil) }
        }
    }

    func applicationWillTerminate(_ notification: Notification) {
        stopping = true
        server?.terminate()
    }

    // MARK: menu

    private func buildMenu() {
        let menu = NSMenu()
        statusLine.isEnabled = false
        menu.addItem(statusLine)
        menu.addItem(.separator())
        toggleItem = NSMenuItem(title: "Stop Server", action: #selector(toggleServer(_:)), keyEquivalent: "")
        menu.addItem(toggleItem)
        menu.addItem(NSMenuItem(title: "Install Chrome Extension…", action: #selector(installExtension(_:)), keyEquivalent: ""))
        menu.addItem(NSMenuItem(title: "Settings…", action: #selector(editPrompts(_:)), keyEquivalent: ","))
        menu.addItem(NSMenuItem(title: "Open Logs", action: #selector(openLogs(_:)), keyEquivalent: ""))
        menu.addItem(.separator())
        menu.addItem(NSMenuItem(title: "How to Use…", action: #selector(howTo(_:)), keyEquivalent: ""))
        menu.addItem(NSMenuItem(title: "Quit Talk to Website", action: #selector(quit(_:)), keyEquivalent: "q"))
        for item in menu.items where item.action != nil { item.target = self }
        statusItem.menu = menu
    }

    private func setStatus(_ text: String, running: Bool) {
        statusLine.title = text
        toggleItem.title = running ? "Stop Server" : "Start Server"
    }

    // MARK: files

    // The extension is refreshed on every launch (so an updated app brings an updated
    // extension: reload it in Chrome); knowledge bases are only seeded when missing.
    private func prepareSupportFolder() {
        try? fm.removeItem(at: extensionFolder)
        try? fm.copyItem(at: resources.appendingPathComponent("app/extension"), to: extensionFolder)
        let knowledge = support.appendingPathComponent("data/knowledge")
        try? fm.createDirectory(at: knowledge, withIntermediateDirectories: true)
        try? fm.createDirectory(at: logsFolder, withIntermediateDirectories: true)
        let seed = resources.appendingPathComponent("seed/knowledge")
        for file in (try? fm.contentsOfDirectory(at: seed, includingPropertiesForKeys: nil)) ?? [] {
            let target = knowledge.appendingPathComponent(file.lastPathComponent)
            if !fm.fileExists(atPath: target.path) { try? fm.copyItem(at: file, to: target) }
        }
    }

    // MARK: the server

    private func startServer() {
        stopping = false
        // a relay already answering on the port (e.g. `npm start` from the project) is used as is
        health { up in
            if up { self.setStatus("Running · localhost:\(PORT) (already running)", running: false); return }
            self.launchServer()
        }
    }

    private func launchServer() {
        let process = Process()
        process.executableURL = resources.appendingPathComponent("node")
        process.arguments = [resources.appendingPathComponent("app/server/index.mjs").path]
        var env = ProcessInfo.processInfo.environment
        env["DATA_DIR"] = support.appendingPathComponent("data").path
        env["LOG_DIR"] = logsFolder.path
        env["PORT"] = String(PORT)
        env["PARENT_PID"] = String(ProcessInfo.processInfo.processIdentifier) // the server exits if this app goes away
        process.environment = env
        process.currentDirectoryURL = resources.appendingPathComponent("app")
        let logFile = logsFolder.appendingPathComponent("server.log")
        if !fm.fileExists(atPath: logFile.path) { fm.createFile(atPath: logFile.path, contents: nil) }
        if let handle = try? FileHandle(forWritingTo: logFile) {
            handle.seekToEndOfFile()
            process.standardOutput = handle
            process.standardError = handle
        }
        process.terminationHandler = { [weak self] _ in
            DispatchQueue.main.async {
                guard let self = self else { return }
                self.server = nil
                if self.stopping { self.setStatus("Server stopped", running: false); return }
                self.restarts += 1
                if self.restarts <= 3 {
                    self.setStatus("Restarting…", running: false)
                    DispatchQueue.main.asyncAfter(deadline: .now() + 2) { self.launchServer() }
                } else {
                    self.setStatus("Server stopped (see Open Logs)", running: false)
                }
            }
        }
        do {
            try process.run()
            server = process
            setStatus("Starting…", running: true)
            waitUntilUp(tries: 30)
        } catch {
            setStatus("Couldn't start: \(error.localizedDescription)", running: false)
        }
    }

    private func waitUntilUp(tries: Int) {
        health { up in
            if up { self.restarts = 0; self.setStatus("Running · localhost:\(PORT)", running: true) }
            else if tries > 0 && self.server != nil { DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) { self.waitUntilUp(tries: tries - 1) } }
        }
    }

    private func health(_ done: @escaping (Bool) -> Void) {
        var request = URLRequest(url: URL(string: "http://127.0.0.1:\(PORT)/health")!)
        request.timeoutInterval = 1.5
        URLSession.shared.dataTask(with: request) { data, response, _ in
            let ok = (response as? HTTPURLResponse)?.statusCode == 200 && data != nil
            DispatchQueue.main.async { done(ok) }
        }.resume()
    }

    @objc private func toggleServer(_ sender: Any?) {
        if let server = server {
            stopping = true
            server.terminate()
        } else {
            restarts = 0
            startServer()
        }
    }

    // MARK: actions

    @objc private func installExtension(_ sender: Any?) {
        let alert = NSAlert()
        alert.messageText = "Add Talk to Website to Chrome"
        alert.informativeText = """
        1. In Chrome, open chrome://extensions and turn on Developer mode (top right).
        2. Click "Load unpacked" and choose the "Chrome Extension" folder that's shown in Finder.
        3. Pin the extension, open a website (e.g. sephora.com) and click its icon to turn it on for that site.
        4. Hold ⌥ Space and talk, or click the orb.

        Keep this app running: it's the assistant's server. After updating the app, click reload on the extension in chrome://extensions.
        """
        alert.addButton(withTitle: "Open Chrome Extensions")
        alert.addButton(withTitle: "Show Folder Only")
        alert.addButton(withTitle: "Later")
        NSApp.activate(ignoringOtherApps: true)
        let choice = alert.runModal()
        if choice == .alertThirdButtonReturn { return }
        NSWorkspace.shared.activateFileViewerSelecting([extensionFolder])
        if choice == .alertFirstButtonReturn { open(["-a", "Google Chrome", "chrome://extensions"]) }
    }

    @objc private func editPrompts(_ sender: Any?) {
        NSWorkspace.shared.open(URL(string: "http://localhost:\(PORT)/settings")!)
    }

    @objc private func openLogs(_ sender: Any?) {
        NSWorkspace.shared.open(logsFolder)
    }

    @objc private func howTo(_ sender: Any?) {
        let alert = NSAlert()
        alert.messageText = "Using Talk to Website"
        alert.informativeText = """
        • Turn it on for a site: click the extension's icon in Chrome (the badge shows "on").
        • Talk: hold ⌥ Space while you speak, or press and hold the orb. Click the orb for a hands-free conversation; click again to end it.
        • Hover the orb for Chat, Mute and Stop.
        • Ask it to search, compare, add to bag or answer questions like "can I return this?". It asks before adding to the bag or checking out.
        • Chat panel → Learn: teaches it a site's help pages (Sephora's are included).
        """
        alert.addButton(withTitle: "OK")
        NSApp.activate(ignoringOtherApps: true)
        alert.runModal()
    }

    @objc private func quit(_ sender: Any?) {
        stopping = true
        server?.terminate()
        NSApp.terminate(nil)
    }

    private func open(_ args: [String]) {
        let p = Process()
        p.executableURL = URL(fileURLWithPath: "/usr/bin/open")
        p.arguments = args
        try? p.run()
    }
}

let app = NSApplication.shared
let delegate = AppDelegate()
// `kill` (SIGTERM) or logging out: quit properly, which stops the server too
signal(SIGTERM, SIG_IGN)
let sigterm = DispatchSource.makeSignalSource(signal: SIGTERM, queue: .main)
sigterm.setEventHandler { NSApp.terminate(nil) }
sigterm.resume()
app.delegate = delegate
app.setActivationPolicy(.accessory)
app.run()
