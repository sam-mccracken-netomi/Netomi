# Talk to Website

A voice assistant that operates any website for you. A small fluid orb sits in the corner of the page. Hold a key and say "search for a red lipstick", "find me a one-way flight to Chicago" or "add the cheapest one to my cart". It works the site the way a person would: it searches, clicks, fills in forms, picks options and reads results. If it needs details (dates, cities, sizes) it asks, and it tells you what it did. The conversation and any task in progress carry on across page loads.

## Run it

You need Node 20+, Chrome, and an OpenAI key with access to `gpt-live-1` and a planner model (default `gpt-6.1-sol`).

```bash
cp .env.example .env     # set OPENAI_API_KEY
npm install
npm start                # the relay, on http://localhost:5179
```

Then load the extension (recommended):

1. `chrome://extensions` → Developer mode → **Load unpacked** → choose `extension/`.
2. Open any site and click the extension's toolbar icon. A badge reading "on" appears and the orb shows up. It's now on for that **site**: every page of it, in any tab. Click the icon again to turn it off for the site.
3. The first time you talk, a tab asks for microphone access once, for the extension itself. After that it works on any site.

After changing the code, run `npm run build` (`npm start` runs it too) and reload the extension.

Other ways to load it: the bookmarklet on http://localhost:5179, pasting the bundle from http://localhost:5179/widget.js into the console, or a `<script src="…/widget.js">` tag on a site you control. In these "page mode" setups the voice runs inside the page, so the site's CSP has to allow the relay. A public site reaching `localhost` also triggers Chrome's one-time "access your local network" prompt. After a full page load, the conversation resumes on the next page if it has the widget. The extension has none of these limits.

## Mac app (to share with others)

`sh scripts/package-mac.sh` builds `dist/TalkToWebsite.dmg` (about 42 MB). It holds **Talk to Website.app**, a menu-bar app with the server and its Node runtime inside, so the recipient needs no Node, npm or terminal.

- **The menu:** server status, Start/Stop, **Install Chrome Extension…**, **Settings…** (opens the settings page in the browser: knowledge source, Netomi bot, prompts), **Open Logs**, **How to Use…** and Quit. It stays out of the Dock.
- **The server** runs while the app is open, restarts itself if it crashes (up to 3 times), and stops whenever the app goes away, even after a force-quit.
- **Data** lives in `~/Library/Application Support/Talk to Website/`: prompts, knowledge bases (the ones in `data/knowledge/` ship as a starting set, Sephora's included), logs, and the **Chrome Extension** folder.
- **Chrome extension:** on first launch the app explains how to add it, opens `chrome://extensions` and shows the folder. Chrome only takes extensions from outside the Web Store through Developer mode → **Load unpacked**.
- **For recipients:**
  - The app is unsigned, so the first time they open it, macOS blocks it. They go to System Settings → Privacy & Security and click **Open Anyway** (once).
  - Apple Silicon Macs only.
  - Instructions are in "Read Me First.txt" in the disk image.
- **⚠️ The OpenAI key from `.env` is inside the app.** Anyone with the app can read it and spend on that account. Share it only with people you trust, and rotate the key afterwards.
- If you run the app alongside `npm start`, it uses whichever server is already on port 5179.

## Using it

| | |
|---|---|
| **Hold ⌥ Space** (Alt+Space) | Push to talk. Release to hear the answer. Works while you're typing in a field: the page never sees the shortcut. |
| **Press and hold the orb** | Push to talk with the mouse or a finger. |
| **Click the orb** | Hands-free conversation (open mic). Click again to end it. Use headphones. |
| **Hover the orb** | A small dock: **Chat** (one click opens the transcript), **Mute** (the conversation stays connected, it just can't hear you), **Stop** (ends it). Mute and Stop appear only while a conversation is live. |
| **Talk over it** | It stops right away and listens (barge-in): in about 220 ms hands-free, and the instant you press with push-to-talk. GPT-Live alone takes about 1.2 s, so the client cuts the voice itself and drops the rest of the interrupted sentence until the model goes quiet. A false alarm (a cough, or speaker echo) resumes within about 0.5 s. `node test/barge-test.mjs` measures it. |

**The orb** is a WebGL shader written by hand, with no library, so nothing extra loads into the host page. It's a glass sphere with slowly flowing liquid colour, driven by the real audio: your mic while it listens, its voice while it speaks. Loudness swells the orb, brightens its core and ripples its rim. The rhythm of the speech speeds up the flow. Each state has its own colours and the orb blends smoothly between them: dim indigo when idle, a soft ring when a conversation is warm, bright blue while listening, a fast violet swirl while thinking, violet and pink while speaking, grey when muted, red on an error. Without WebGL it falls back to a CSS gradient orb. With reduced motion it barely moves.

**Waiting for an answer sounds natural.** When it hands a request to the agent, the voice reacts in a few words ("Sure.", "Good question.") without promising a wait or hinting at the answer, so a fast answer follows straight on. Once the agent starts working on the page or the help center (or 5 s after the request, at the latest), it says one short holding line ("Pulling a few up."); answers from the knowledge base, ready in about 3 s, skip it. The answer is handed over only after the voice has finished that line, so the two don't run together, and it picks up from what was said: no second filler, and a light correction if anything said earlier doesn't fit. A spoken progress note comes only on tasks past 12 s.

**When something doesn't happen.** If the voice says it will do something ("I'll pick a few for you") but never hands it to the agent, the relay notices 2.5 s after the voice stops talking with no handoff since the visitor spoke. It then runs the request itself and answers through the voice (logged as `missed_handoff`). A planner step that hasn't answered in 7 s gets a second, identical request, and whichever answers first is used (steps usually take 2–4 s, but one occasionally takes 20 s; logged as `hedged`). A step that fails is retried up to three times.

**Report a problem.** When something goes wrong, open the chat panel and click the flag, or say "report this session". Type what happened, and optionally your name (it remembers it, and starts from the signed-in name; blank sends it as anonymous), then press Send (or ⌘/Ctrl+Enter); this works after the conversation has ended too. The relay finds the conversation it belongs to (the site's most recent one) and posts it to the issue tracker set in `.env` as `REPORTS_URL`, as `{ reporter, issue, logs }`: `logs` is the readable timeline below, followed by the raw logs as JSON. Nothing is kept locally unless the tracker can't be reached; then it's kept in `logs/reports/` and retried every 5 minutes (settings → Reports & data shows what's waiting). Without `REPORTS_URL`, reports are saved in `logs/reports/`:
- `<id>.txt`: your note, the transcript, and a timeline of what the voice said and what the agent did, with each step's timing, errors and reconnects.
- `<id>.json`: everything, including every log file the conversation spans (a reconnect starts a new one), the relay's own log lines from that time, and the settings in use (without the Netomi bot IDs).

Settings → Problem reports lists them, with links to read each one or download its logs. Reports stay on this computer: pages can send one, but only the extension and this machine can read them back.

**Captions** (Settings → Captions) show what it says while it speaks: **No text**, a **Chat bubble** beside the orb (the default), or **Subtitles** across the bottom of the screen, like a film. The words appear phrase by phrase at the pace of the voice (all at once when the voice is muted), fade a moment after it stops, and are hidden while the chat panel is open. Subtitles sit on a translucent, blurred strip, so the page shows through. Besides captions, the only text beside the orb is a short note when something goes wrong (no mic access, server unreachable).

**One conversation, in the tab you're looking at.** With the site open in several tabs, only the active one has the live orb; the others show the transcript and a resting orb. Switch to another tab of the site (or open a link in a new tab) and the conversation, and any task in progress, moves there and carries on. Close its tab and another open tab of the site takes over. Tabs of another site don't take it over.

## Options

Pass options with `window.TalkWidgetConfig = {...}` before the script loads, or as `data-*` attributes on the script tag:

| Option | Default | |
|---|---|---|
| `server` | the script's own host, else `ws://localhost:5179` | relay URL |
| `shortcut` | `Alt+Space` | e.g. `Ctrl+Shift+K`, `Alt+J`. On Windows, Alt+Space opens the window menu, so pick another there. |
| `name` | `Assistant` | shown in the panel, and the name the voice uses |
| `accent` | `#6e56ff` | |
| `idleTimeoutSec` | `60` | push-to-talk: hang up after this much quiet (the next press reconnects) |
| `handsFreeIdleSec` | `120` | |
| `mutedIdleSec` | `300` | a muted conversation stays connected this long |

Server settings go in `.env`: `PORT`, `ALLOWED_ORIGINS` (set this before exposing the server anywhere), `MAX_SESSIONS`, `MAX_SESSION_MIN`, `VOICE`, `ASSISTANT_NAME`, `PLANNER_MODEL` (default `gpt-6.1-sol`), `PLANNER_EFFORT` (default `low`).

## How website tasks work

```
 you ──voice──► GPT-Live (gpt-live-1) ──"delegate"──► server: browser agent (gpt-6.1-sol)
                    ▲                                    │  ▲
                    └──── result to say ◄────────────────┘  │ snapshot / act (over the same socket)
                                                            ▼
                                       page agent in the tab: sees the page, clicks, types
```

1. **GPT-Live talks; the app operates the site.** The voice is told to hand off (delegate) anything that involves the website, including follow-ups like "the second one" and answers to the agent's questions. A delegation carries only an id, so the server rebuilds the request from the live transcript: your words since the voice last spoke.
2. **The agent sees each page fresh.** It doesn't crawl the whole site up front, which would be slow and stale on dynamic sites. Each step it gets a compact snapshot of the current page, built in about 25 ms and usually 1–4k tokens:
   - every visible button, link and field, with its label, value and state;
   - for repeated buttons like "Add to bag", the product card each one belongs to;
   - headings, alerts and form errors, any open dialog, and the main text.

   The planner either acts (several actions per step, e.g. fill the whole form, then submit) or replies (done, needs your input, or can't). Each step is a fresh, stateless call, so old snapshots don't pile up.
3. **It acts like a person.** Real pointer, mouse and keyboard event sequences. Typing goes in character by character, so React fields and autocompletes keep up. Native selects are set the way the browser would set them. Each target is scrolled into view and briefly ringed so you can watch. After every action it waits for the page to settle.
4. **It asks when it should.** Missing details get one short question covering everything that's missing. It won't place an order, pay or complete a booking without your explicit go-ahead, and it never types passwords or card numbers.
5. **Context survives page loads.** The transcript, the agent's memory of earlier tasks and the task in progress live on the server. In the extension, the voice lives in an **offscreen document** that outlives the page. The widget is re-injected as soon as each new page's DOM is ready, the agent waits for it, takes a fresh look and carries on. In page mode the server holds the conversation for 45 s, and the next page reattaches to it with the same id.
6. **Slow pages don't end a task.** Each snapshot says when a page still looks like it's loading (spinners, skeletons, almost no content), and the agent has a `wait` action that returns once it's ready (up to 15 s at a time). A new page gets up to ~45 s, with a spoken "still loading" after 12 s. If it's slower still, the voice says it'll carry on once the page is ready; when the page arrives (within 3 minutes, unless the visitor asked for something else), the task resumes from where it stopped. `DOC_DELAY_MS=60000 node test/voice-task.mjs …` checks this on a real site.
7. **Long tasks narrate.** The orb switches to a working state. After about 7 s the voice gives a short progress note, then the result.

| Part | File |
|---|---|
| Voice: mic, speaker, push-to-talk, session, resume | `client/voice.js` |
| Page agent: snapshot and actions | `client/page-agent.js` |
| Widget UI: orb, dock, chat, shortcut | `client/ui.js` (the three are bundled into `/widget.js`) |
| Relay server and conversation registry | `server/index.mjs` |
| Conversation: transcript, delegations, page RPC, reattach | `server/conversation.mjs` |
| Browser agent (planner loop) | `server/browser-agent.mjs`, `server/openai.mjs` |
| What the voice is told | `server/persona.mjs` |
| GPT-Live session | `server/live.mjs` |
| Chrome extension: background routing, offscreen voice, mic permission | `extension/` |

Each conversation writes `logs/session-*.jsonl`: what was heard and said, each delegation and the request rebuilt from it, every planner step (tool, actions, timing, tokens), action results, and page loads (detach, attach, page_ready).

## Memory and being proactive

- **Browsing history, kept per site, even with the voice off.** On every page of an enabled site, the widget notes what it is, without calling a model:
  - a product's name, brand and price, from the structured data sites publish for search engines (JSON-LD, Open Graph);
  - searches, with their query terms;
  - cart, checkout and other pages.

  In-app navigation without a full page load is caught too. The last 50 entries are kept for 30 days. The agent sees them with their URLs, so "take me back to the earlier product" and "compare the ones I looked at" work.
- **First click on a site:** a one-line greeting that fits the site and what you're viewing, offering one specific thing. Example: "want a quick comparison between the Statue of Liberty and the Eiffel Tower?"
- **Coming back later:** no new greeting, but a welcome back that names where you left off. Example: "Welcome back, we were on the Eiffel Tower page. Want to keep reading?"
- **No greeting when it shouldn't:** starting with push-to-talk (you're already talking), or a page load mid-conversation (it just continues).
- **Mid-conversation:** when you open another product yourself after viewing others, it may offer to compare. That's at most once every 3 minutes, never right after you spoke, and never on pages the agent itself opened.
- **No leakage between sites:**
  - History and transcripts are stored under the site's key: `sephora.com` covers `www.` and its other subdomains.
  - In the extension that's extension storage, plus a separate voice per site in the offscreen document. In page mode it's the site's own localStorage.
  - A tab only ever shows its own site's conversation, and taking the active tab to another site ends the conversation.
  - The server only gets the current site's history.
- **Start afresh:**
  - **One site:** in the chat panel, click the trash button, then **Start afresh**. This ends the conversation and forgets that site's transcript, the conversation it would resume, and its browsing history, so the next click gets a first-visit greeting.
  - **Every site:** on the settings page (the gear in the chat panel), click **Forget all sites**.
  - Sites stay turned on, and knowledge bases and the voice-mute setting are kept. The server's conversation logs (`logs/`) aren't touched.

## Site knowledge (help and policy pages)

Ask "can I return this?" on a product page and you get the answer **without leaving the page**. The voice gives the gist, and a frosted-glass card in the middle of the screen shows the details and their source. The card shows only for information that came from outside the current page. It leaves after 20 s, waits while you hover over it, and closes with ✕ or Esc.

- **Teach it a site:** open the chat panel (hover the orb, then Chat) and click **Learn**. The extension crawls the site's help pages **in your own browser**, through your tab. That matters because big retailers block automated crawlers: Sephora answers 403 to plain requests and "Access Denied" to headless Chrome.
  - It starts from seed pages (Sephora's customer-service, returns, shipping, Beauty Insider and similar pages) plus help-looking links in the current page's header and footer, and follows help links two levels deep, up to 60 pages.
  - Pages that only render with JavaScript are read in a background tab.
  - The panel shows progress, then "Knows N help pages". Click **Refresh** to re-learn.
- **The index:** `data/knowledge/<site>.json` (`server/knowledge.mjs`). Passages are split by heading, embedded with `text-embedding-3-small` at 512 dimensions, and searched hybrid (meaning plus exact words) in memory. No vector database: a help centre is about 1–2k passages, searched in a few ms; the query embedding takes about 300 ms.
- **Answering:** the search runs alongside the agent's first look at the page. When it finds a strong match, the first step uses the faster `gpt-6-luna` (about 2.5 s, as grounded as `gpt-6.1-sol` in testing; `gpt-4.1` made up a policy, so it's out). In testing the card appeared about **4.3 s** after the visitor stopped talking. The agent answers only from what the passages say, including saying so when the policy doesn't cover the question.

### Netomi answers

The answers can also come from a Netomi bot, through its Stream Proxy (`server/netomi.mjs`). This is adapted from `streamproxy-chat/streamProxyChat.mjs` and uses the same token call, request body and stream parsing.

- **Settings page → Knowledge answers:**
  - **Local** is the help pages learned with Learn.
  - **Netomi** uses the bot.
  - **Both** answers from local passages when they cover the question, and asks Netomi otherwise.
  - Fill in the **Bot ID** and **Bot ref ID**. **Sites** optionally limits the bot to some sites (e.g. `sephora.com`); other sites keep their local knowledge.
  - **Test** asks the bot a question and shows how long each stage took.
  - Saved in `data/settings.json`; applies to the next question.
- **How it's used:** the planner gets an `ask_help_center` tool for policy and service questions. If Netomi has no answer ("I'm not able to help with that"), the agent carries on and looks on the site. The chat panel shows where answers come from.
- **Making a slow API feel fast:** Netomi takes about 1 s for a token, 4–7 s to its first words and 10–13 s to a complete answer. So:
  - **The token is cached** (memory and `data/netomi-tokens.json`; it lasts 30 days) and fetched when the server starts, when settings are saved, and when a conversation starts. That removes ~1 s from every question.
  - **The question goes out immediately.** When a request looks like a help question, Netomi is asked the moment the delegation arrives, while the planner takes its first step (on the fast model, ~1–2 s). When the planner calls `ask_help_center`, the answer is already on its way.
  - **The answer streams.** It goes to the voice once the first whole sentences are in, about 1–2 s after the first words and several seconds before the end. The card then fills in the rest as it arrives. A "can't help" reply is recognised from its first words, so the agent falls back sooner.
  - **Answers are cached for a day** (`data/netomi-cache.json`), matched by meaning (embedding similarity ≥ 0.93). In testing, a reworded repeat ("how does the beauty insider points program work?") was answered in 1.3 s instead of 9.4 s. Follow-ups that lean on the conversation ("what about sale items?") skip the cache. Questions with the same words that matter also match, whatever the filler ("tell me about return policy" = "What is Sephora's return policy?"), which is safer than a lower similarity bar ("return policy for sale items" is 0.87 similar, but a different question).
  - **The common questions are answered ahead of time.** When a conversation starts on a site with Netomi, about ten common questions (returns, shipping, free shipping, tracking, cancelling, payment, rewards, price adjustments, pick-up, gift cards) are asked in the background, once a day per bot, so the first visitor to ask gets the cached answer in about a second instead of ~7.
  - **Nothing extra is said while it waits.** The voice gives one short acknowledgement and then waits; there's no spoken "still checking" for help-center answers (the orb shows it's working), and the card isn't announced.
  - Measured end to end by voice on a product page: the card appeared 9.6 s after the visitor stopped talking. The bot's complete answer took 10–13 s on its own.

## Sales and offers

Besides answering and doing, the assistant can act as a sales associate. At the right moments it brings up an offer or a price drop that fits what the visitor is doing.

- **Collecting offers (per site):** open the chat panel and click **Scan**, next to "Scan <site>'s offers". The extension reads the site's offer and sale pages in your own tab, like Learn does, because Sephora blocks automated browsers.
  - It starts from seed pages (Sephora: Beauty Offers, Sale, Beauty Insider, Rewards, the home page; elsewhere `/offers`, `/deals`, `/sale`…) plus offer-looking links on the current page. It reads up to 25 pages.
  - From each page it keeps the promo banners, the text, and product tiles with their prices. A crossed-out price makes the product a **price drop**.
  - On the relay (`server/offers.mjs`), the planner model reads each page into structured offers: kind, terms, code, minimum spend, who it's for, brands, categories, exclusions and end date. It's told to take only what the page states.
  - The same offer found on two pages is kept once, matched by meaning. The result is stored in `data/offers/<site>.json`.
  - In testing on elfcosmetics.com: 5 pages read in 17 s, giving 8 offers.
- **Reviewing them:** settings page → **Sales & offers** → **Offers found** lists every offer and price drop. **Remove** any that's wrong and it won't be mentioned. Expired offers are kept but never used.
- **Turning it on:** settings page → **Bring up offers and price drops**, plus **How much to pitch**:

  | Level | When it brings offers up | How often |
  |---|---|---|
  | Light | Bag and checkout only: a threshold they're close to, a code that applies, or a product they viewed got cheaper | Once per conversation |
  | Balanced | Also on the home page (what's running sitewide), and the product they're looking at when an offer clearly fits | 2 times, 5 min apart |
  | Proactive | Anywhere they browse: home, categories and other pages, searching and comparing; similar products on sale | 3 times, 3 min apart |
  | Assertive | Also in the greeting itself, with a lower bar for what fits; suggests reaching thresholds; mentions real end dates | 5 times, 2 min apart |

  Pitches are spoken; a card pops up only when there's something to read (a promo code) or when the visitor asks about deals. Offers nobody asked for appear in the planner's answers only at Proactive and Assertive, and within the same spacing as the pitches, so the two never stack.
  A "no thanks" quiets it for the rest of the conversation at Light and Balanced, or for 10 minutes at the higher levels. It never mentions the same offer twice, and never interrupts the visitor or the agent's work.
- **Two ways offers come up** (`server/sales.mjs`):
  - **While the visitor browses by themselves** (the home page, a category or other page, a product, a search, the bag, checkout): offers are ranked for the moment, from the page plus what they've been looking at lately (recent searches, categories and products, and remembered preferences). On the home page, what's running sitewide counts as a good fit. Service pages (sign-in, help, returns, order tracking, policies) are skipped. If the moment isn't right (they just spoke, the agent is working), it tries again on the same page about 15 s later, up to twice. Ranking combines meaning similarity, a brand match, the gap to a minimum spend (from the bag subtotal, or from this item's price), and penalties for offers only some people can get (students, military…). The store's own brand isn't counted as a match. The best one is spoken as a tip and shown on the glass card ("Offer at Sephora"), if it clears the level's bar.
  - **While the agent works a request:** the offers that fit go into the planner's prompt. "What deals do you have?" is answered from them, with a card. After adding to the bag, it can mention a threshold or gift that fits, at most one per reply.
- **Signals from the page** (`TalkPage.describe`): product price, a crossed-out "was" price, the category (from breadcrumbs), and the bag subtotal on cart and checkout pages. Price changes between visits to the same product become "the price dropped since you last looked".
- **Logs:** every moment is logged as `sales_pitch`, `sales_skip` (with the reason) or `sales_wait` (why it held back), so you can tune the levels.
- **Prompts:** two editable prompts in a new **Sales & offers** group: the pitch, and the planner's sales rules.

## Memory: what the assistant learns about the visitor

Like a personal shopper who knows a regular (`server/memory.mjs`).

- **What it keeps:** durable preferences and traits per site: skin type and concerns, shades (with the product), undertone, sizes, brands they like, ingredients they avoid, values, scent preferences, budget per category, who they shop for.
  - **Stated** facts are things they said about themselves ("I have oily skin"). They're used openly ("since you mentioned oily skin…").
  - **Inferred** facts come from what they asked or did (a price filter becomes a budget; the same finish chosen repeatedly becomes a preference). Each has a confidence that only grows with repeated signals. They're used quietly, with a check before relying on them. Guesses under 35% aren't used.
  - A guess never overwrites what they said. A correction replaces the old fact. Shopping for someone else is kept as "shopping for", never as their own traits.
  - Health conditions beyond cosmetic concerns, ethnicity, religion, contact and payment details are never kept.
- **What they do counts too, with the voice off:** the extension records the visitor's own actions on an enabled site, along with the pages they view:
  - filters and sort, from clicks, or from the address (`?filter.v.price.lte=20`, Sephora's `pl`/`ph`/`ref`…);
  - options picked (a shade swatch, a size);
  - add to bag, compare, save or love, and remove.
  - Only real input counts (`isTrusted`), so the agent's own clicks never do.
  - On a product page, a button near the title counts for that product; a button on a "pairs well with" tile counts for that tile's product.
  - New actions and pages are sent to memory every 40 s at most, and soon after an add to bag, so it learns while the voice is off.
  - In testing on e.l.f. with the voice never started: a $20 price filter became "Budget for face makeup: up to $20 (inferred, 70%)", and picking a shade then adding it to the bag became "Face makeup shade: 4 Medium Neutral (inferred, 80%)".
  - The planner also sees the visitor's recent actions ("applied filter Price (max): 20, picked Color: 4 Medium Neutral").
- **How it's built:** after the visitor speaks and pauses (6 s), when the extension sends new browsing and actions, and every couple of minutes during a conversation, the planner model reads the new evidence against what's known. It returns only the changes, or nothing; small talk adds nothing. This runs in the background and never slows a reply. The extraction rules are an editable prompt.
- **Used by:** the voice (from the start of each conversation), the planner (every step), and **preselecting**. When the visitor opens a product by themselves and we know a matching shade, size or similar, the agent selects it (closing pop-ups if needed) and the voice says so. In testing on e.l.f.: *"I've selected 4 Medium Neutral for you, and you can change it anytime."* It only picks clear matches and never maps one brand's shade number to another's.
- **Where to see it:** settings page → **Memory** → **What we know**. Facts are listed per site, as said or inferred with a confidence and the evidence. Each has **Remove**, and there's a button to forget a site's visitor entirely. Switches turn memory and preselecting off. **Start afresh** in the chat panel clears memory too.
- **Privacy:** kept per site in `data/memory/<site>.json`, never shared between sites. The relay only serves it to the extension and to this machine, so no website can read it.
- **Who's signed in:** the extension reads the visitor's name from the header greeting ("Hi, Taylor"), and the full name and email from the site's account page or the sign-in form. It's shown on the **signed in** row in **What we know**, and never put in a prompt.

### Adobe Real-Time CDP sync

With RT-CDP set up, the signed-in email links the visitor to a profile in Adobe Experience Platform (`server/rtcdp.mjs`).

- **Loading:** when the email becomes known, and at the start of each conversation (at most every 5 minutes), the profile's facts are merged into the site's memory. Newer facts win, a guess never replaces something they said, and a fact removed here stays removed. Facts learned on other sites come in too, marked with their site. If the profile brings in something new during a conversation, the voice gets it as background.
- **Writing back:** a few seconds after memory changes (something learned, the account, a removal), the whole record is streamed to the profile, with other sites' facts kept.
  - Every fact has a field of its own, for segments: the memory key in camelCase (`coverage_preference` → `coveragePreference`, `allergies` → `allergies`). A field that doesn't exist yet is added to the "Talk to Website Preferences" field group on the first write, up to 120 fields. Fields can't be removed later, so the learning prompt reuses existing keys.
  - Profile drops a new field's values for about 15 minutes after the field is added. The relay writes again at 5, 15 and 30 minutes, and whenever a profile check finds a fact without its field (at most every 2 minutes).
  - Every fact also goes into `facts[]` (key, label, value, kind, confidence, evidence, site, updated).
- **Setup:** fill in the `AEP_*` values in `.env` (OAuth Server-to-Server credentials, org, sandbox), then run `node scripts/rtcdp-setup.mjs`. It creates the "Talk to Website Preferences" field group, the "Talk to Website Profiles" schema with email as the primary identity, a Profile-enabled dataset, and an authenticated HTTP API streaming connection with its dataflow, then writes their IDs into `.env`. It's safe to run again. Then restart the relay. Wait a few minutes after a fresh setup before the first write: Adobe stores records that arrive before the schema is part of Profile, but doesn't add them to the profile.
- **Trying it:** `node scripts/rtcdp-sample.mjs [email]` writes a sample shopper (John Sample) and reads it back; `--read <email>` only reads. To see a profile in Platform, go to **Customer → Profiles → Browse**, choose the **Email** namespace and enter the address. Our fields are under the tenant's **talkToWebsite** group.
- **Home zip code, from the customer record:** a second dataset, "Talk to Website Customer Records", stands in for a CRM and holds the home address. The assistant only reads it.
  - `node scripts/rtcdp-zip.mjs <email> 75201 Dallas TX` changes it, as a CRM would.
  - The relay re-reads the profile on each page load (at most every 20 s), at the start of a conversation, and on **Refresh** in settings. A change mid-conversation goes to the voice as background.
  - Store locators, nearby stores, pickup and delivery use the zip without asking, and the assistant says which one it used ("near your zip code, 75201 in Dallas").
  - Within one dataset, a new record for the same person replaces the old one, so the address can't share a dataset with the assistant's facts. Across datasets, the profile merges both.
- **Allergies:** "I'm allergic to peppermint" (or "to that", resolved from the product's ingredients) is kept as a stated fact, `allergies`, and written to the typed `allergies` field. Allergies are never inferred.
  - On any product page (opened by the visitor or by the agent), the page's ingredient list is checked against them by the planner model, including Latin names and derivatives (shea butter = Butyrospermum Parkii, fragrance = parfum).
  - The ingredients come from the page's text, even inside a collapsed accordion. If they aren't there, the agent opens the Ingredients section.
  - On a match, the voice warns them once it has finished what it was saying: what the product lists, what they're allergic to, and an alternative as an option.
  - Allergies never filter or swap products, and aren't mentioned otherwise: only when the product in front of them contains one, once, on that product's page.
- **Settings:** **Memory → Sync with Adobe Real-Time CDP** turns it on or off. The **signed in** row shows when it last synced, or the last error. **Forget everything** clears only this computer; **Remove** on a fact removes it from the profile too.

## The info card

- **Where it shows:** settings page → **Info card** → Center, Above the orb, Top right or Bottom center. It applies to the next card.
- **When it goes away:** after 20 s (paused while hovered), as soon as the visitor says something (a go-ahead, another question, "no thanks"), presses the talk key, clicks anywhere on the page, or presses ✕ or Esc.

## Editing the prompts

Open the extension's **Options**, either from the gear icon in the chat panel or by right-clicking the toolbar icon and choosing Options. There are 19 prompts in six groups, one tab per group (a dot marks a customised group; an accent dot, unsaved changes there):

- the voice's system instructions;
- the greetings and nudges;
- the planner's system instructions, plus **Answering questions: only from the site and knowledge base**. Product questions are answered from what the site shows. Anything else (the brand itself, policies, general how-tos, off-topic) is answered only from the knowledge passages or the Netomi help center, never from the model's own knowledge. Without a source, it says it doesn't have that information and offers what it can help with. This prompt is always added after the planner's instructions, so it holds even when those are edited. `{domain}` in either planner prompt is filled in with the site's domain (e.g. `sephora.com`);
- sales and offers;
- memory (what to remember, how to use it, preselecting options);
- how answers are handed to the voice, including **Safe response when the voice service blocks a topic** (see below).

The agent never leaves the site, whatever the prompts say: a `go` to another domain, or a click on a link to one, is refused in code ("Blocked: off-site URL"), and if a script or redirect still takes the page elsewhere, it goes back.

**A guide to each site, learned once.** When the assistant is turned on for a site, the extension reads the site's menus (header, navigation, footer: label → URL, plus whether there's a search box) along with its sitemap, and refreshes them every three days. As it works, it also remembers where finished tasks ended up ("where can I track my package?" → /track-order). The planner gets this guide before it looks at the page: the menu links and earlier routes that match the request, and the main menu. So common requests go straight to the right page instead of being hunted for. On elfcosmetics.com, "Where can I track my package?" went from 4 steps and 13.5 s to 2 steps and 4.8 s. `node test/site-guide.mjs <url> ["request"]` learns a site's guide through the extension and prints what the planner would get.

**Links come only from the site or the knowledge base.** The extension reads each site's sitemap through your tab (robots.txt → sitemap.xml, every three days; kept in `data/sitemaps/`). The planner gets the pages that match a request ("Pages on this site"), so it opens real pages instead of guessing paths. Before anything is spoken or shown on a card, every link is checked (`server/links.mjs`): it stays only if it's one of the site's real pages (in its sitemap, on a page the agent saw, or one the visitor viewed) or it came from a knowledge passage or a Netomi answer. A sentence built around any other link is dropped, and another site's bare domain ("amazon.com") becomes just its name.

GPT-Live's own moderation stops replies on some topics (self-harm, violence, sexual content…) and closes the voice session. The conversation doesn't end: the assistant drops that request (the agent won't act on it), reopens the voice without that turn, and says the safe response, editable in Settings (put your approved knowledge-base response there). After three such blocks in one conversation, it ends.

Edits are saved on the relay in `data/prompts.json`; delete that file to go back to all defaults. They apply right away, except the voice's instructions, which apply from the next conversation. Each prompt has **Reset to default**, and a warning appears if a placeholder it needs (`{name}`, `{say}`, `{note}`) goes missing.

Only the extension, or this machine, can save changes: the relay refuses edits from web pages. The defaults are in `server/prompts.mjs`. `node scripts/show-prompts.mjs` writes everything, rendered with example values, to `docs/PROMPTS.md`.

## Tests and tools

With `npm start` running:

| Command | What it does |
|---|---|
| `node test/extension-task.mjs [url] ["request"] ["follow-up"]` | The real extension in headless Chrome on a live site. Spoken requests (macOS `say`) go into the offscreen voice; checks the task, page loads and spoken answers. Default: Wikipedia, search and a follow-up question. |
| `node test/knowledge-test.mjs [store url] ["question"]` | Learns a store's help pages through the extension, runs sample searches, then asks a policy question by voice on a product page. Checks the spoken answer, the card and that the page didn't change. Default: rarebeauty.com, since Sephora blocks headless Chrome. With `NETOMI=1`, skips learning and has the Netomi bot from the settings answer (for that run only). |
| `node test/memory-test.mjs` | Memory and proactivity on real sites, in the extension: history with the voice off, the first greeting, "take me back to the first one", the welcome back, and a second site with nothing carried over. |
| `node test/site-guide.mjs <url> ["request"] …` | Learns a site's guide (menus and sitemap) through the extension, as a visitor's first page load would, and prints the guide the planner gets for each request. |
| `node test/report-test.mjs [url]` | Report a problem, on Rare Beauty: saying "report this session" opens the report box, and the flag button opens it too. Both notes are saved with the conversation's logs. |
| `node test/one-tab-test.mjs` | One conversation across tabs, on Wikipedia: it moves to a new tab of the site, back when you switch, and carries on when its tab closes. Only one orb is ever live. |
| `node test/forget-test.mjs` | Start afresh in the extension, on Wikipedia: the trash button forgets one site and leaves the others; "Forget all sites" on the settings page clears every site. |
| `node test/voice-task.mjs [url] ["request"] …` | The same in page mode (the widget injected into every page load, as if the site had the script tag). |
| `node test/offers-test.mjs [store url]` | Scan offers through the extension (prints what was found), then with sales on: open a product by hand and check an offer is brought up, and ask "what deals do you have right now?". Default: elfcosmetics.com. `SKIP_SCAN=1` reuses the last scan. |
| `node test/prefs-test.mjs` | Memory and the info card in the extension, on elfcosmetics.com. A saved shade is preselected when the product is opened by hand, and the voice says so. The card shows where the setting puts it and closes on "okay, thanks" and on a click. Settings and memory are restored afterwards. |
| `node test/browse-memory-test.mjs` | Memory from browsing alone, voice never started, on elfcosmetics.com. A price filter in the address, then real clicks on a shade swatch and Add to Bag. Checks the recorded actions and what memory learned. The site's memory is restored afterwards. |
| `node test/task.mjs <url> "request" ["follow-up"]` | The agent alone, no voice: fast and cheap for trying sites and requests. Prints every step and saves screenshots. `NETOMI=1` gives it the Netomi help center. |
| `node test/look.mjs <url>` | Prints exactly what the agent sees on a page. |
| `node test/screenshot.mjs` | The orb in every state, for design checks. |

Big retailers (Sephora, Delta, Target) block **headless** Chrome with bot protection ("Access Denied", "something went wrong"), so automated runs against them stop partway. In testing, the agent got through Delta's whole search form (airport pickers, one-way, calendar) and Sephora's search before being blocked. Your own Chrome with the extension isn't affected.

## Known limits

- **Untrusted events.** Clicks and keys are dispatched by script. Nearly all sites accept them, but a few that check `isTrusted` won't respond.
- **Iframes.** Same-origin iframes are seen and operated. Cross-origin ones, such as many payment fields, are not, and by design it doesn't fill payment details anyway. While focus is inside an iframe, the talk shortcut doesn't fire; the orb still works.
- **Speed.** Each planner step takes about 1.5–2.5 s. Simple searches finish in 5–15 s; a full flight-search form took about 30 s. Speed-ups for later: remember each site's layout (where the search box and cart are), and use a faster model for simple steps.
- **Page mode across page loads** needs the widget on every page, and the browser only allows audio after a click on the new page. The extension has neither problem.
- **Hands-free on speakers** relies on echo cancellation. Push-to-talk or headphones work best.
