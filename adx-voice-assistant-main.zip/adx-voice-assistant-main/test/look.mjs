// What the agent sees: prints the page snapshot for a URL. On pages without the widget,
// injects it over DevTools (which bypasses the site's CSP).
//   node test/look.mjs http://localhost:5179/demo/air/
//   node test/look.mjs https://www.example.com/   (any site)
import { launch, sleep } from "./lib/chrome.mjs";
import { bundle } from "../server/bundle.mjs";

const url = process.argv[2] || "http://localhost:5179/demo/shop/";
const c = await launch({ port: 9344, args: ["--user-agent=Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36"] });
try {
  await c.goto(url);
  await sleep(Number(process.env.WAIT || 1500));
  if (!(await c.evaluate("!!window.__talkWidget"))) await c.evaluate(`window.TalkWidgetConfig = { server: "ws://localhost:5179" }; ${bundle()}`);
  const t0 = Date.now();
  const snap = await c.evaluate("window.__talkWidget.page.snapshot()");
  console.log(snap.text);
  console.error(`\n[${snap.text.length} chars, ~${Math.round(snap.text.length / 4)} tokens, ${Date.now() - t0} ms]`);
} finally { c.close(); }
