// The site knowledge base end to end, with the real extension on a real store:
//  1. "learn" the site's help pages (crawled through the tab, as in the visitor's browser)
//  2. search it directly: relevance and speed
//  3. on a product page, ask a policy question by voice: answered from the knowledge base
//     without leaving the page, spoken, and shown on the glass card
// Sephora blocks headless Chrome, so this runs on another store by default.
//   npm start   # in another terminal
//   node test/knowledge-test.mjs [https://www.rarebeauty.com/] ["question"]
//   NETOMI=1 node test/knowledge-test.mjs <url> "question"   step 3 only, answered by the
//     Netomi bot from the settings page (switched on for that site during the run)
import { execFileSync } from "node:child_process";
import { readFileSync, writeFileSync, mkdirSync } from "node:fs";
import { join } from "node:path";
import { sleep } from "./lib/chrome.mjs";
import { launchWithExtension, attach, findTarget } from "./lib/extension.mjs";
import { ROOT } from "../server/env.mjs";

const START = process.argv[2] || "https://www.rarebeauty.com/";
const QUESTION = process.argv[3] || "Can I return this if I've already opened it?";
const OUT = join(ROOT, "logs", `knowledge-test-${Date.now()}`);
mkdirSync(OUT, { recursive: true });
const HTTP = "http://localhost:5179";
const NETOMI = !!process.env.NETOMI;
const savedSettings = await (await fetch(`${HTTP}/config`)).json();
const results = [];
const check = (name, ok, detail = "") => { results.push(ok); console.log(`${ok ? "PASS" : "FAIL"}  ${name}${detail ? `  (${detail})` : ""}`); };

function pcm(text) {
  const f = join(OUT, "q.wav");
  execFileSync("say", ["-v", "Samantha", "-r", "180", "-o", f + ".aiff", text]);
  execFileSync("afconvert", ["-f", "WAVE", "-d", "LEI16@24000", "-c", "1", f + ".aiff", f]);
  const b = readFileSync(f);
  for (let off = 12; off < b.length; ) { const id = b.toString("ascii", off, off + 4), size = b.readUInt32LE(off + 4); if (id === "data") return b.subarray(off + 8, off + 8 + size); off += 8 + size + (size % 2); }
}
const FAKE_MIC = `(() => { if (window.__fakeMic) return true;
  const ctx = new AudioContext({ sampleRate: 24000 }); const dest = ctx.createMediaStreamDestination();
  window.__fakeMic = { say(b64) { const bin = atob(b64), n = bin.length >> 1, buf = ctx.createBuffer(1, n, 24000), ch = buf.getChannelData(0);
    for (let i = 0; i < n; i++) { let v = bin.charCodeAt(2 * i) | (bin.charCodeAt(2 * i + 1) << 8); if (v >= 32768) v -= 65536; ch[i] = v / 32768; }
    const src = ctx.createBufferSource(); src.buffer = buf; src.connect(dest); ctx.resume(); src.start(); return n / 24000; } };
  navigator.mediaDevices.getUserMedia = async () => (ctx.resume(), new MediaStream(dest.stream.getAudioTracks().map((t) => t.clone()))); return true; })()`;
const READ = `(() => { const r = document.querySelector("talk-to-website")?.shadowRoot; if (!r) return null; const k = r.querySelector(".kcard");
  return { view: r.querySelector(".tw").dataset.state, kb: r.querySelector(".kb-text")?.textContent,
    card: k.classList.contains("on") ? { from: k.querySelector(".k-from").textContent, title: k.querySelector(".k-title").textContent, points: [...k.querySelectorAll("li")].map((l) => l.textContent), link: k.querySelector(".k-open").href } : null,
    messages: [...r.querySelectorAll(".msg")].map((m) => ({ role: m.classList.contains("user") ? "user" : "agent", text: m.textContent })) }; })()`;

const ext = await launchWithExtension({ path: join(ROOT, "extension"), args: ["--mute-audio", "--autoplay-policy=no-user-gesture-required", "--use-fake-ui-for-media-stream", "--window-size=1280,860",
  "--user-agent=Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36"] });
const t0 = Date.now();
const ts = () => `${((Date.now() - t0) / 1000).toFixed(1).padStart(5)}s`;
let page, status = null;
try {
  page = await attach((await findTarget(ext.port, (t) => t.type === "page" && t.url === "about:blank")).webSocketDebuggerUrl);
  await page.send("Page.enable");
  await page.send("Page.navigate", { url: START });
  await sleep(5000);
  // a product page to ask from
  const product = await page.evaluate(`(document.querySelector('a[href*="/products/"]') || {}).href || ""`);
  if (product) { await page.send("Page.navigate", { url: product }); await sleep(5000); }
  const productUrl = await page.evaluate("location.href");
  const site = new URL(productUrl).hostname.replace(/^www\./, "");
  console.log(`${ts()}  product page: ${productUrl}`);

  const sw = await attach((await findTarget(ext.port, (t) => t.type === "service_worker" && t.url.includes(ext.id))).webSocketDebuggerUrl);
  const tabId = await sw.evaluate(`chrome.tabs.query({}).then((ts) => ts.find((t) => t.url && t.url.includes(${JSON.stringify(site)}))?.id)`);
  await sw.evaluate(`toggleTab({ id: ${tabId} }).then(() => true)`);
  const off = await attach((await findTarget(ext.port, (t) => t.url.endsWith("/offscreen.html"))).webSocketDebuggerUrl);
  await off.evaluate(FAKE_MIC);
  for (let i = 0; i < 50 && !(await page.evaluate(READ).catch(() => null)); i++) await sleep(200);

  // NETOMI=1: the Netomi bot from the settings answers for this site, for this run only
  if (NETOMI) {
    const k = savedSettings.knowledge;
    const r = await fetch(`${HTTP}/config`, { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ knowledge: { ...k, mode: "netomi", netomi: { ...k.netomi, sites: [k.netomi.sites, site].filter(Boolean).join(", ") } } }) });
    if (!r.ok || !k.netomi.botId) throw new Error("NETOMI=1: set the bot on the settings page first");
    console.log(`${ts()}  answers from Netomi on ${site} (settings restored afterwards)`);
  }

  // 1. learn
  if (!NETOMI) {
  console.log(`${ts()}  learning ${site}'s help pages…`);
  const l0 = Date.now();
  sw.evaluate(`learnSite(${tabId}).then(() => true)`).catch(() => {});
  for (let i = 0; i < 300; i++) {
    await sleep(1000);
    status = await (await fetch(`${HTTP}/knowledge/${site}/status`)).json();
    const ui = (await page.evaluate(READ).catch(() => null))?.kb;
    if (i % 10 === 0 && ui) console.log(`${ts()}    panel: ${ui}`);
    if (status.pages && status.updatedAt > l0) break;
  }
  const kbFile = JSON.parse(readFileSync(join(ROOT, "data", "knowledge", `${site}.json`), "utf8"));
  console.log(`${ts()}  learned in ${((Date.now() - l0) / 1000).toFixed(0)} s: ${status.pages} pages, ${status.chunks} passages`);
  for (const p of kbFile.pages.slice(0, 40)) console.log(`         · ${p.title}  ${p.url}`);
  check("learns the site's help pages", status.pages >= 3, `${status.pages} pages`);

  // 2. search directly
  for (const q of ["can I return an opened product", "how long does shipping take", "do you ship internationally", "can I change or cancel my order"]) {
    const s0 = Date.now();
    const hits = await (await fetch(`${HTTP}/knowledge/${site}/search?q=${encodeURIComponent(q)}&k=3`)).json();
    console.log(`${ts()}  search "${q}" (${Date.now() - s0} ms): ${hits.map((h) => `${h.title} › ${h.section} [${h.score}]`).join(" | ") || "nothing"}`);
  }
  }

  // 3. ask by voice on the product page
  const [vw, vh] = await page.evaluate("[innerWidth, innerHeight]");
  await page.send("Input.dispatchKeyEvent", { type: "keyDown", modifiers: 1, key: " ", code: "Space", windowsVirtualKeyCode: 32 });
  await sleep(500);
  console.log(`${ts()}  you: "${QUESTION}"`);
  const q0 = Date.now();
  const secs = await off.evaluate(`window.__fakeMic.say(${JSON.stringify(pcm(QUESTION).toString("base64"))})`);
  await sleep(secs * 1000 + 400);
  await page.send("Input.dispatchKeyEvent", { type: "keyUp", key: " ", code: "Space", windowsVirtualKeyCode: 32 });
  const released = Date.now();
  let st, cardAt = 0, n = 0, firstWordAt = 0;
  for (let k = 0; k < 120; k++) {
    await sleep(250);
    st = await page.evaluate(READ).catch(() => null);
    if (st?.card && !cardAt) { cardAt = Date.now(); writeFileSync(join(OUT, "card.png"), Buffer.from((await page.send("Page.captureScreenshot", { format: "png" })).result.data, "base64")); }
    const agents = (st?.messages || []).filter((m) => m.role === "agent").length;
    if (agents >= 2 && !firstWordAt) firstWordAt = Date.now();
    n = agents >= 2 && ["ready", "listening"].includes(st.view) ? n + 1 : 0;
    if (n >= 8) break;
  }
  const said = (st?.messages || []).filter((m) => m.role === "agent").map((m) => m.text).join(" / ");
  console.log(`${ts()}  Nova: ${said}`);
  console.log(`${ts()}  card ${cardAt ? `${((cardAt - released) / 1000).toFixed(1)} s after you stopped talking` : "never shown"}: ${JSON.stringify(st?.card || null)}`);
  const stayed = (await page.evaluate("location.href")) === productUrl;
  console.log(`${ts()}  first answer words ${firstWordAt ? `${((firstWordAt - released) / 1000).toFixed(1)} s after you stopped talking` : "never"}`);
  check("answered by voice", said.length > 20);
  check("shown on the card, with its source", !!cardAt && st?.card?.points?.length >= 1);
  check("stayed on the product page (no trip to the returns page)", stayed);
  writeFileSync(join(OUT, "result.json"), JSON.stringify({ productUrl, status, said, card: st?.card, ms: cardAt ? cardAt - released : null }, null, 2));
} finally {
  if (NETOMI) await fetch(`${HTTP}/config`, { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify(savedSettings) });
  await page?.evaluate(`document.querySelector("talk-to-website")?.shadowRoot.querySelector('[data-act="stop"]')?.click()`).catch(() => {});
  await sleep(500);
  ext.proc.kill();
}
console.log(`\n${results.filter(Boolean).length}/${results.length} passed · ${OUT}`);
