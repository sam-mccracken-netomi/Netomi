// Memory from browsing alone, with the voice never started, with the real extension on a
// real store:
//  1. a category with a price filter in the address (as when the visitor applies one)
//  2. a product: the visitor picks a shade and adds it to the bag (real clicks, isTrusted)
//  → the actions are recorded with the site's history, synced to the relay, and memory
//    learns from them (a budget, a shade). This site's memory is put back afterwards.
//   npm start   # in another terminal
//   node test/browse-memory-test.mjs
import { readFileSync, writeFileSync, existsSync, unlinkSync } from "node:fs";
import { join } from "node:path";
import { sleep } from "./lib/chrome.mjs";
import { launchWithExtension, attach, findTarget } from "./lib/extension.mjs";
import { ROOT, DATA } from "../server/env.mjs";

const SITE = "elfcosmetics.com";
const LISTING = "https://www.elfcosmetics.com/collections/face?filter.v.price.lte=20";
const PRODUCT = "https://www.elfcosmetics.com/products/halo-glow-liquid-filter";
const SHADE = "4 Medium Neutral";
const HTTP = "http://localhost:5179";
const results = [];
const check = (name, ok, detail = "") => { results.push(ok); console.log(`${ok ? "PASS" : "FAIL"}  ${name}${detail ? `  (${detail})` : ""}`); };
const memFile = join(DATA(), "memory", `${SITE}.json`);
const oldMem = existsSync(memFile) ? readFileSync(memFile, "utf8") : null;
if (oldMem) unlinkSync(memFile);

const ext = await launchWithExtension({ path: join(ROOT, "extension"), port: 9395, args: ["--mute-audio", "--window-size=1280,1300",
  "--user-agent=Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36"] });
const t0 = Date.now();
const ts = () => `${((Date.now() - t0) / 1000).toFixed(1).padStart(5)}s`;
let page;
async function go(url) {
  await page.send("Page.navigate", { url });
  for (let i = 0; i < 80; i++) { await sleep(200); if ((await page.evaluate("document.readyState").catch(() => "")) === "complete") break; }
  await sleep(4000);
}
const click = async ([x, y]) => { for (const type of ["mousePressed", "mouseReleased"]) await page.send("Input.dispatchMouseEvent", { type, x, y, button: "left", clickCount: 1 }); };
// the middle of the first visible element matching, scrolled into view
// (instant scrolling: with the site's smooth scrolling the element is still moving when measured)
const where = (js) => page.evaluate(`(() => { const el = (${js}); if (!el) return null; el.scrollIntoView({ block: "center", behavior: "instant" });
  let r = el.getBoundingClientRect(); if (r.top < 0 || r.bottom > innerHeight) { scrollBy({ top: r.top - innerHeight / 2, behavior: "instant" }); r = el.getBoundingClientRect(); }
  if (!r.width) return null;
  const x = r.x + r.width / 2, y = r.y + r.height / 2, hit = document.elementFromPoint(x, y);
  if (hit !== el && !el.contains(hit)) console.warn("talk-test: covered by", hit?.outerHTML.slice(0, 120));
  return [x, y, hit === el || el.contains(hit) ? "" : hit?.outerHTML.slice(0, 120)]; })()`);
// the sign-up pop-ups a shopper would close (this store's SMS one lives in an iframe)
// (they show up a few seconds after the page, at different times: two passes)
const closePopups = async () => {
  for (let pass = 0; pass < 2; pass++) {
    await sleep(1500);
    for (const re of ["/^accept all cookies$/i", "/^no thanks$/i"]) { const p = await where(byText(re)); if (p) { await click(p); await sleep(700); } }
    await page.evaluate(`document.querySelectorAll('iframe[title*="Capture" i], iframe[title*="sign up" i], iframe[id*="attentive" i]').forEach((f) => f.remove())`);
    // the "which country?" dialog closes with Escape, like any dialog
    if (await page.evaluate(`!!document.querySelector('[data-locale-mismatch-overlay], [role="dialog"][data-state="open"]')`)) {
      for (const type of ["keyDown", "keyUp"]) await page.send("Input.dispatchKeyEvent", { type, key: "Escape", code: "Escape", windowsVirtualKeyCode: 27 });
      await sleep(600);
    }
  }
  // a dialog that didn't close can leave scrolling locked
  await page.evaluate(`for (const el of [document.documentElement, document.body]) if (getComputedStyle(el).overflow === "hidden") el.style.setProperty("overflow", "visible", "important")`);
};
// buttons anywhere, shadow roots included (this store's cookie dialog is in one, and it locks scrolling)
const byText = (re) => `(() => { const all = []; const walk = (root) => { for (const el of root.querySelectorAll("*")) { if (el.matches("button, a, [role=button]")) all.push(el); if (el.shadowRoot) walk(el.shadowRoot); } }; walk(document);
  return all.find((b) => ${re}.test((b.getAttribute("aria-label") || b.textContent || "").trim()) && b.getBoundingClientRect().width > 0); })()`;
try {
  page = await attach((await findTarget(ext.port, (t) => t.type === "page" && t.url === "about:blank")).webSocketDebuggerUrl);
  await page.send("Page.enable");
  await go("https://www.elfcosmetics.com/");
  const sw = await attach((await findTarget(ext.port, (t) => t.type === "service_worker" && t.url.includes(ext.id))).webSocketDebuggerUrl);
  const tabId = await sw.evaluate(`chrome.tabs.query({}).then((ts) => ts.find((t) => t.url && t.url.includes(${JSON.stringify(SITE)}))?.id)`);
  await sw.evaluate(`toggleTab({ id: ${tabId} }).then(() => true)`); // on for the site; the voice is never started
  await sleep(1500);
  await closePopups();

  console.log(`${ts()}  a category, filtered to $20 and under: ${LISTING}`);
  await go(LISTING);
  console.log(`${ts()}  a product: pick ${SHADE}, then add to bag`);
  await go(PRODUCT);
  await closePopups();
  const reachable = (js) => page.evaluate(`(() => {
    for (const el of (${js})) {
      el.scrollIntoView({ block: "center", behavior: "instant" });
      const r = el.getBoundingClientRect(), x = r.x + r.width / 2, y = r.y + r.height / 2;
      if (r.width && y > 0 && y < innerHeight && el.contains(document.elementFromPoint(x, y))) return [x, y];
      console.debug("talk-test", Math.round(x), Math.round(y), innerHeight, (document.elementFromPoint(x, y)?.outerHTML || "null").slice(0, 120));
      window.__miss = (window.__miss || []).concat([[Math.round(x), Math.round(y), innerHeight, getComputedStyle(document.documentElement).overflow, getComputedStyle(document.body).overflow, (document.elementFromPoint(x, y)?.outerHTML || "null").slice(0, 140)]]);
    }
    return null;
  })()`);
  const swatch = await reachable(`[...document.querySelectorAll('[aria-label], [title], [data-value], input[type=radio]')].filter((e) => [e.getAttribute("aria-label"), e.getAttribute("title"), e.getAttribute("data-value"), e.value].some((v) => (v || "").trim() === ${JSON.stringify(SHADE)}))`);
  if (swatch) { await sleep(400); await click(swatch); await sleep(1500); }
  console.log(`${ts()}    shade swatch ${swatch ? "clicked" : "not found"}; page: ${await page.evaluate("location.href")}`);
  // the main button, not the sticky bar's copy that waits below the screen
  // (widest first: the "pairs well with" tiles have their own small Add to Bag buttons)
  const bag = await reachable(`[...document.querySelectorAll("button")].filter((b) => /^add to bag$/i.test(b.textContent.trim())).sort((a, b) => b.getBoundingClientRect().width - a.getBoundingClientRect().width)`);
  if (bag) { await sleep(400); await click(bag); await sleep(2500); }
  console.log(`${ts()}    now on ${await page.evaluate("location.href")}`);
  if (!bag || !swatch) console.log(JSON.stringify(await page.evaluate("window.__miss || []"), null, 1).slice(0, 1500));
  console.log(`${ts()}    add to bag ${bag ? "clicked" : "not found"}${bag?.[2] ? ` (covered by ${bag[2]})` : ""}`);

  const events = await sw.evaluate(`chrome.storage.local.get("ttw:${SITE}:events").then((v) => v["ttw:${SITE}:events"] || [])`);
  for (const e of events) console.log(`         event ${e.type} ${e.group ? `${e.group}: ` : ""}${e.value}${e.item ? ` [item: ${e.item}]` : ""}${e.product ? ` · on ${e.product}` : ""}`);
  check("the price filter in the address is recorded", events.some((e) => e.type === "filter" && /price/i.test(e.group) && e.value === "20"));
  check("picking the shade is recorded", events.some((e) => e.type === "option" && e.value.includes(SHADE)));
  check("add to bag is recorded", events.some((e) => e.type === "add_to_cart"));

  // the sync to memory (soon after an add to bag), then the model's update
  let mem = null;
  for (let i = 0; i < 60; i++) {
    await sleep(2000);
    mem = await (await fetch(`${HTTP}/memory/${SITE}`)).json();
    if (mem.facts?.length) break;
  }
  await sleep(4000);
  mem = await (await fetch(`${HTTP}/memory/${SITE}`)).json();
  for (const f of mem.facts || []) console.log(`         memory ${f.label}: ${f.value} [${f.kind} ${f.confidence}] ← ${f.evidence}`);
  check("memory learns from browsing with the voice off", (mem.facts || []).length > 0);
  check("…including the shade they picked", (mem.facts || []).some((f) => f.value.includes(SHADE)));
} catch (e) {
  console.error(e);
  results.push(false);
} finally {
  ext.proc.kill();
  if (oldMem) writeFileSync(memFile, oldMem); else if (existsSync(memFile)) unlinkSync(memFile);
}
console.log(`\n${results.filter(Boolean).length}/${results.length} passed`);
process.exit(results.every(Boolean) ? 0 : 1);
