// Offers and the sales side, with the real extension on a real store:
//  1. Scan: the store's offer and sale pages are read through the tab into offers and
//     price drops (printed, so you can judge them)
//  2. with sales on (level 3 for the run, then the settings are put back): start a
//     conversation, open a product by hand, and see whether an offer is brought up
//  3. ask "what deals do you have right now?": answered from the scanned offers, with a card
// Sephora blocks headless Chrome, so this runs on another store by default.
//   npm start   # in another terminal
//   node test/offers-test.mjs [https://www.elfcosmetics.com/]     SKIP_SCAN=1 reuses the last scan
import { execFileSync } from "node:child_process";
import { readFileSync, readdirSync, statSync, mkdirSync } from "node:fs";
import { join } from "node:path";
import { sleep } from "./lib/chrome.mjs";
import { launchWithExtension, attach, findTarget } from "./lib/extension.mjs";
import { ROOT } from "../server/env.mjs";

const START = process.argv[2] || "https://www.elfcosmetics.com/";
const HTTP = "http://localhost:5179";
const OUT = join(ROOT, "logs", `offers-test-${Date.now()}`);
mkdirSync(OUT, { recursive: true });
const results = [];
const check = (name, ok, detail = "") => { results.push(ok); console.log(`${ok ? "PASS" : "FAIL"}  ${name}${detail ? `  (${detail})` : ""}`); };
const saved = await (await fetch(`${HTTP}/config`)).json();
const put = (sales) => fetch(`${HTTP}/config`, { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ sales }) });

function pcm(text) {
  const f = join(OUT, "q.wav");
  execFileSync("say", ["-v", "Samantha", "-r", "180", "-o", f + ".aiff", text]);
  execFileSync("afconvert", ["-f", "WAVE", "-d", "LEI16@24000", "-c", "1", f + ".aiff", f]);
  const b = readFileSync(f);
  for (let off = 12; off < b.length; ) { const id = b.toString("ascii", off, off + 4), size = b.readUInt32LE(off + 4); if (id === "data") return b.subarray(off + 8, off + 8 + size); off += 8 + size + (size % 2); }
}
const FAKE_MIC = `(() => { if (window.__fakeMic) return true;
  const ctx = new AudioContext({ sampleRate: 24000 }); const dest = ctx.createMediaStreamDestination();
  window.__fakeMic = { say(b64) { const bin = atob(b64), n = bin.length >> 1, buf = ctx.createBuffer(1, n, 24000), ch = buf.getChannelData(0);
    for (let i = 0; i < n; i++) { let v = bin.charCodeAt(2 * i) | (bin.charCodeAt(2 * i + 1) << 8); if (v >= 32768) v -= 65536; ch[i] = v / 32768; }
    const src = ctx.createBufferSource(); src.buffer = buf; src.connect(dest); ctx.resume(); src.start(); return n / 24000; } };
  navigator.mediaDevices.getUserMedia = async () => (ctx.resume(), new MediaStream(dest.stream.getAudioTracks().map((t) => t.clone()))); return true; })()`;
const READ = `(() => { const r = document.querySelector("talk-to-website")?.shadowRoot; if (!r) return null; const k = r.querySelector(".kcard");
  return { view: r.querySelector(".tw").dataset.state, offers: r.querySelector(".offers .kb-text")?.textContent,
    card: k.classList.contains("on") ? { from: k.querySelector(".k-from").textContent, title: k.querySelector(".k-title").textContent, points: [...k.querySelectorAll("li")].map((l) => l.textContent) } : null,
    messages: [...r.querySelectorAll(".msg")].map((m) => ({ role: m.classList.contains("user") ? "user" : "agent", text: m.textContent })) }; })()`;
const latestLog = () => { const d = join(ROOT, "logs"); return readdirSync(d).filter((f) => f.startsWith("session-")).map((f) => join(d, f)).sort((a, b) => statSync(b).mtimeMs - statSync(a).mtimeMs)[0]; };
const logKinds = (file, kinds) => readFileSync(file, "utf8").split("\n").filter(Boolean).map((l) => JSON.parse(l)).filter((e) => kinds.includes(e.kind));

const ext = await launchWithExtension({ path: join(ROOT, "extension"), port: 9371, args: ["--mute-audio", "--autoplay-policy=no-user-gesture-required", "--use-fake-ui-for-media-stream", "--window-size=1280,860",
  "--user-agent=Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36"] });
const t0 = Date.now();
const ts = () => `${((Date.now() - t0) / 1000).toFixed(1).padStart(5)}s`;
let page;
try {
  page = await attach((await findTarget(ext.port, (t) => t.type === "page" && t.url === "about:blank")).webSocketDebuggerUrl);
  await page.send("Page.enable");
  await page.send("Page.navigate", { url: START });
  await sleep(6000);
  const site = new URL(await page.evaluate("location.href")).hostname.replace(/^www\./, "");
  const sw = await attach((await findTarget(ext.port, (t) => t.type === "service_worker" && t.url.includes(ext.id))).webSocketDebuggerUrl);
  const tabId = await sw.evaluate(`chrome.tabs.query({}).then((ts) => ts.find((t) => t.url && t.url.includes(${JSON.stringify(site)}))?.id)`);
  await sw.evaluate(`toggleTab({ id: ${tabId} }).then(() => true)`);
  const off = await attach((await findTarget(ext.port, (t) => t.url.endsWith("/offscreen.html"))).webSocketDebuggerUrl);
  await off.evaluate(FAKE_MIC);
  for (let i = 0; i < 50 && !(await page.evaluate(READ).catch(() => null)); i++) await sleep(200);

  // 1. scan (SKIP_SCAN=1: use what's stored)
  console.log(`${ts()}  scanning ${site}'s offers…`);
  const s0 = process.env.SKIP_SCAN ? 0 : Date.now();
  if (!process.env.SKIP_SCAN) sw.evaluate(`scanOffers(${tabId}).then(() => true)`).catch(() => {});
  let status;
  for (let i = 0; i < 400; i++) {
    await sleep(1000);
    status = await (await fetch(`${HTTP}/offers/${site}/status`)).json();
    const ui = (await page.evaluate(READ).catch(() => null))?.offers;
    if (i % 10 === 0 && ui) console.log(`${ts()}    panel: ${ui}`);
    if (status.updatedAt > s0) break;
  }
  const list = await (await fetch(`${HTTP}/offers/${site}/list`)).json();
  console.log(`${ts()}  scanned in ${((Date.now() - s0) / 1000).toFixed(0)} s: ${list.pages.length} pages, ${list.offers.length} offers, ${list.drops.length} price drops`);
  for (const p of list.pages) console.log(`         page  ${p.url}`);
  for (const o of list.offers) console.log(`         offer [${o.kind}] ${o.title}${o.code ? ` · code ${o.code}` : ""}${o.min_spend ? ` · min $${o.min_spend}` : ""}${o.ends ? ` · ends ${o.ends}` : ""}\n               ${o.summary}`);
  for (const d of list.drops.slice(0, 8)) console.log(`         drop  ${d.pct}% ${d.name}: $${d.price} (was $${d.was})`);
  check("scan finds offers", list.offers.length >= 1, `${list.offers.length} offers, ${list.drops.length} drops`);

  // 2. a conversation, with sales on; then a product opened by hand
  await put({ enabled: true, level: 3 });
  const [vw, vh] = await page.evaluate("[innerWidth, innerHeight]");
  for (const type of ["mousePressed", "mouseReleased"]) await page.send("Input.dispatchMouseEvent", { type, x: vw - 48, y: vh - 48, button: "left", clickCount: 1 });
  await sleep(16000); // the greeting, and the quiet start
  // a product that's for sale (some links on a home page are stale): one on sale if the scan found any
  const product = list.drops[0]?.url || (await (async () => {
    const links = await page.evaluate(`[...new Set([...document.querySelectorAll('a[href*="/product"], a[href*="/products/"], a[href*="/p/"]')].map((a) => a.href.split("?")[0]))].slice(0, 12)`);
    for (const href of links) {
      const r = await fetch(href, { headers: { "User-Agent": "Mozilla/5.0" } }).catch(() => null);
      if (r?.ok && !/not found/i.test((await r.text()).match(/<title>([^<]*)/i)?.[1] || "")) return href;
    }
    return links[0];
  })());
  console.log(`${ts()}  opening a product by hand: ${product}`);
  await page.send("Page.navigate", { url: product });
  let pitched = null;
  const log = latestLog();
  for (let i = 0; i < 40 && !pitched; i++) {
    await sleep(1000);
    pitched = logKinds(log, ["sales_pitch"])[0] || null;
  }
  for (const e of logKinds(log, ["sales_pitch", "sales_skip", "sales_wait", "page_ready"])) console.log(`         log ${e.t}s ${e.kind} ${JSON.stringify({ ...e, t: undefined, kind: undefined }).slice(0, 220)}`);
  await sleep(9000);
  let st = await page.evaluate(READ).catch(() => null);
  console.log(`${ts()}  card: ${JSON.stringify(st?.card)}`);
  console.log(`${ts()}  said: ${(st?.messages || []).filter((m) => m.role === "agent").map((m) => m.text).slice(-2).join(" / ")}`);
  check("an offer is brought up on the product page", !!pitched, pitched ? `${pitched.type}: ${pitched.title} (${pitched.score})` : "no pitch; see sales_skip above");

  // 3. "what deals do you have right now?"
  const before = (st?.messages || []).filter((m) => m.role === "agent").length;
  console.log(`${ts()}  you: "What deals do you have right now?"`);
  const secs = await off.evaluate(`window.__fakeMic.say(${JSON.stringify(pcm("What deals do you have right now?").toString("base64"))})`);
  await sleep(secs * 1000 + 300);
  let n = 0;
  for (let k = 0; k < 120; k++) {
    await sleep(500);
    st = await page.evaluate(READ).catch(() => null);
    const agents = (st?.messages || []).filter((m) => m.role === "agent").length;
    n = agents >= before + 2 && ["ready", "listening"].includes(st.view) ? n + 1 : 0;
    if (n >= 6) break;
  }
  const answer = (st?.messages || []).filter((m) => m.role === "agent").slice(before).map((m) => m.text).join(" / ");
  console.log(`${ts()}  said: ${answer}`);
  console.log(`${ts()}  card: ${JSON.stringify(st?.card)}`);
  const used = logKinds(log, ["offers_used"]);
  console.log(`${ts()}  offers cited: ${JSON.stringify(used.map((u) => u.titles))}`);
  check("answers \"what deals?\" from the scanned offers", used.length > 0 && answer.length > 20);
} catch (e) {
  console.error(e);
  results.push(false);
} finally {
  await put(saved.sales);
  await page?.evaluate(`document.querySelector("talk-to-website")?.shadowRoot.querySelector('[data-act="stop"]')?.click()`).catch(() => {});
  await sleep(500);
  ext.proc.kill();
}
console.log(`\n${results.filter(Boolean).length}/${results.length} passed · ${OUT}`);
process.exit(results.every(Boolean) ? 0 : 1);
