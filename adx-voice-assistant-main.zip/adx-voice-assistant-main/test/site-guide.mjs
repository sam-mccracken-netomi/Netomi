// Learns a site's guide through the real extension, as a visitor's first page load would:
// its menus and sitemap, read in the tab and kept on the relay; then prints the guide the
// planner would get for a few requests.
//   npm start   # in another terminal
//   node test/site-guide.mjs <url> ["request"] ...
import { join } from "node:path";
import { sleep } from "./lib/chrome.mjs";
import { launchWithExtension, attach, findTarget } from "./lib/extension.mjs";
import { ROOT } from "../server/env.mjs";
import { siteOf } from "../server/browser-agent.mjs";

const [url = "https://www.elfcosmetics.com/", ...requests] = process.argv.slice(2);
const site = siteOf(url);
const HTTP = "http://localhost:5179";
const ext = await launchWithExtension({ path: join(ROOT, "extension"), port: 9363, args: ["--mute-audio", "--window-size=1280,860"] });
let ok = false;
try {
  const page = await attach((await findTarget(ext.port, (t) => t.type === "page" && t.url === "about:blank")).webSocketDebuggerUrl);
  await page.send("Page.enable");
  await page.send("Page.navigate", { url });
  await sleep(3000);
  const sw = await attach((await findTarget(ext.port, (t) => t.type === "service_worker" && t.url.includes(ext.id))).webSocketDebuggerUrl);
  const tabId = await sw.evaluate(`chrome.tabs.query({}).then((ts) => ts.find((t) => t.url && t.url.startsWith(${JSON.stringify(new URL(url).origin)}))?.id)`);
  const before = await (await fetch(`${HTTP}/sitemap/${site}/status`)).json();
  if (before.updatedAt) await sw.evaluate(`mapping.delete(${JSON.stringify(site)}); fetch("${HTTP}/sitemap/${site}/status").then(() => true)`);
  await sw.evaluate(`toggleTab({ id: ${tabId} }).then(() => true)`);
  // a fresh read even if it was learned before
  await sleep(1500);
  await sw.evaluate(`(async () => { mapping.delete(${JSON.stringify(site)}); const [m, r] = await Promise.all([inTab(${tabId}, grabNav, []), inTab(${tabId}, grabSitemaps, [])]); await fetch("${HTTP}/sitemap/${site}/ingest", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ urls: r?.urls || [], nav: m?.nav || [], search: !!m?.search }) }); return true; })()`);
  const st = await (await fetch(`${HTTP}/sitemap/${site}/status`)).json();
  console.log(`${site}: ${st.urls} sitemap pages, ${st.nav} menu links, ${st.routes} learned routes`);
  ok = st.nav > 0;
} catch (e) { console.error(e); } finally { ext.proc.kill(); }
const { sitemap } = await import("../server/sitemap.mjs");
for (const r of requests) console.log(`\n--- ${r}\n${sitemap.guide(site, r) || "(no guide)"}`);
process.exit(ok ? 0 : 1);
