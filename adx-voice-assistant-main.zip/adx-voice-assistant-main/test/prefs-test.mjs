// Memory in use, and the info card, with the real extension on a real store:
//  1. a saved preference (a shade) → opening that product by hand preselects it, and the
//     voice says so
//  2. the card shows where the settings place it, and goes away when the visitor says
//     something ("okay, thanks") or clicks the page
// The memory, sales and placement settings are set for the run and put back afterwards.
//   npm start   # in another terminal
//   node test/prefs-test.mjs
import { execFileSync } from "node:child_process";
import { readFileSync, writeFileSync, existsSync, unlinkSync, readdirSync, statSync, mkdirSync } from "node:fs";
import { join } from "node:path";
import { sleep } from "./lib/chrome.mjs";
import { launchWithExtension, attach, findTarget } from "./lib/extension.mjs";
import { ROOT, DATA } from "../server/env.mjs";

const HOME = "https://www.elfcosmetics.com/";
const PRODUCT = "https://www.elfcosmetics.com/products/halo-glow-liquid-filter";
const SHADE = "4 Medium Neutral";
const HTTP = "http://localhost:5179";
const OUT = join(ROOT, "logs", `prefs-test-${Date.now()}`);
mkdirSync(OUT, { recursive: true });
const results = [];
const check = (name, ok, detail = "") => { results.push(ok); console.log(`${ok ? "PASS" : "FAIL"}  ${name}${detail ? `  (${detail})` : ""}`); };

// the run's memory and settings (the old ones go back at the end)
const memFile = join(DATA(), "memory", "elfcosmetics.com.json");
const oldMem = existsSync(memFile) ? readFileSync(memFile, "utf8") : null;
mkdirSync(join(DATA(), "memory"), { recursive: true });
writeFileSync(memFile, JSON.stringify({ site: "elfcosmetics.com", lastVisitAt: Date.now() + 864e5, updatedAt: Date.now(), facts: [
  { key: "complexion_shade", label: "Halo Glow shade", value: `${SHADE} (e.l.f. Halo Glow Liquid Filter)`, kind: "stated", confidence: 1, evidence: `said: "I use ${SHADE} in Halo Glow"`, updatedAt: Date.now() },
] }));
const saved = await (await fetch(`${HTTP}/config`)).json();
const put = (part) => fetch(`${HTTP}/config`, { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify(part) });
await put({ memory: { enabled: true, preselect: true }, sales: { enabled: true, level: 2 }, ui: { cardPlacement: "top-right" } });

function pcm(text, name) {
  const f = join(OUT, `${name}.wav`);
  execFileSync("say", ["-v", "Samantha", "-r", "180", "-o", f + ".aiff", text]);
  execFileSync("afconvert", ["-f", "WAVE", "-d", "LEI16@24000", "-c", "1", f + ".aiff", f]);
  const b = readFileSync(f);
  for (let off = 12; off < b.length; ) { const id = b.toString("ascii", off, off + 4), size = b.readUInt32LE(off + 4); if (id === "data") return b.subarray(off + 8, off + 8 + size); off += 8 + size + (size % 2); }
}
const FAKE_MIC = `(() => { if (window.__fakeMic) return true;
  const ctx = new AudioContext({ sampleRate: 24000 }); const dest = ctx.createMediaStreamDestination();
  window.__fakeMic = { say(b64) { const bin = atob(b64), n = bin.length >> 1, buf = ctx.createBuffer(1, n, 24000), ch = buf.getChannelData(0);
    for (let i = 0; i < n; i++) { let v = bin.charCodeAt(2 * i) | (bin.charCodeAt(2 * i + 1) << 8); if (v >= 32768) v -= 65536; ch[i] = v / 32768; }
    const src = ctx.createBufferSource(); src.buffer = buf; src.connect(dest); ctx.resume(); src.start(); return n / 24000; } };
  navigator.mediaDevices.getUserMedia = async () => (ctx.resume(), new MediaStream(dest.stream.getAudioTracks().map((t) => t.clone()))); return true; })()`;
const READ = `(() => { const r = document.querySelector("talk-to-website")?.shadowRoot; if (!r) return null; const k = r.querySelector(".kcard");
  return { view: r.querySelector(".tw").dataset.state, card: k.classList.contains("on") ? { place: k.dataset.place, title: k.querySelector(".k-title").textContent, rect: (({ left, top, right, bottom }) => ({ left, top, right, bottom }))(k.getBoundingClientRect()) } : null,
    messages: [...r.querySelectorAll(".msg")].map((m) => ({ role: m.classList.contains("user") ? "user" : "agent", text: m.textContent })) }; })()`;
const latestLog = () => { const d = join(ROOT, "logs"); return readdirSync(d).filter((f) => f.startsWith("session-")).map((f) => join(d, f)).sort((a, b) => statSync(b).mtimeMs - statSync(a).mtimeMs)[0]; };
const events = (file, kinds) => readFileSync(file, "utf8").split("\n").filter(Boolean).map((l) => JSON.parse(l)).filter((e) => kinds.includes(e.kind));

const ext = await launchWithExtension({ path: join(ROOT, "extension"), port: 9391, args: ["--mute-audio", "--autoplay-policy=no-user-gesture-required", "--use-fake-ui-for-media-stream", "--window-size=1280,860",
  "--user-agent=Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36"] });
const t0 = Date.now();
const ts = () => `${((Date.now() - t0) / 1000).toFixed(1).padStart(5)}s`;
let page, off;
const read = () => page.evaluate(READ).catch(() => null);
const agentCount = async () => ((await read())?.messages || []).filter((m) => m.role === "agent").length;
async function speak(text, name) {
  const secs = await off.evaluate(`window.__fakeMic.say(${JSON.stringify(pcm(text, name).toString("base64"))})`);
  await sleep(secs * 1000 + 300);
}
async function settle(before, maxS = 60) {
  let n = 0;
  for (let k = 0; k < maxS * 2; k++) {
    await sleep(500);
    const st = await read();
    const agents = (st?.messages || []).filter((m) => m.role === "agent").length;
    n = st && agents > before && ["ready", "listening"].includes(st.view) ? n + 1 : 0;
    if (n >= 4) break;
  }
}
try {
  page = await attach((await findTarget(ext.port, (t) => t.type === "page" && t.url === "about:blank")).webSocketDebuggerUrl);
  await page.send("Page.enable");
  await page.send("Page.navigate", { url: HOME });
  await sleep(6000);
  const sw = await attach((await findTarget(ext.port, (t) => t.type === "service_worker" && t.url.includes(ext.id))).webSocketDebuggerUrl);
  const tabId = await sw.evaluate(`chrome.tabs.query({}).then((ts) => ts.find((t) => t.url && t.url.includes("elfcosmetics.com"))?.id)`);
  await sw.evaluate(`toggleTab({ id: ${tabId} }).then(() => true)`);
  off = await attach((await findTarget(ext.port, (t) => t.url.endsWith("/offscreen.html"))).webSocketDebuggerUrl);
  await off.evaluate(FAKE_MIC);
  for (let i = 0; i < 50 && !(await read()); i++) await sleep(200);

  // 1. a conversation; then the product, opened by hand
  const [vw, vh] = await page.evaluate("[innerWidth, innerHeight]");
  for (const type of ["mousePressed", "mouseReleased"]) await page.send("Input.dispatchMouseEvent", { type, x: vw - 48, y: vh - 48, button: "left", clickCount: 1 });
  await settle(0, 20);
  await sleep(9000); // past the quiet start
  const log = latestLog();
  const n1 = await agentCount();
  console.log(`${ts()}  opening ${PRODUCT} by hand (saved shade: ${SHADE})`);
  await page.send("Page.navigate", { url: PRODUCT });
  let done = null;
  for (let i = 0; i < 90 && !done; i++) {
    await sleep(1000);
    const evs = events(log, ["preselect", "task_done"]);
    const p = evs.findIndex((e) => e.kind === "preselect");
    done = (p >= 0 && evs.slice(p + 1).find((e) => e.kind === "task_done")) || null;
  }
  await settle(n1, 30);
  for (const e of events(log, ["preselect", "step", "acted", "task_done", "sales_skip", "sales_pitch"])) console.log(`         log ${e.t}s ${e.kind} ${JSON.stringify({ ...e, t: undefined, kind: undefined }).slice(0, 200)}`);
  const url = await page.evaluate("location.href");
  const selected = await page.evaluate(`document.body.innerText.includes(${JSON.stringify(SHADE)}) && decodeURIComponent(location.search.replace(/\\+/g, " "))`);
  const said = ((await read())?.messages || []).filter((m) => m.role === "agent").slice(n1).map((m) => m.text).join(" / ");
  console.log(`${ts()}  page: ${url}\n${ts()}  said: ${said}`);
  check("the saved shade is preselected", String(selected).includes(SHADE), String(selected));
  check("the voice says it was preselected", /4 medium neutral|medium neutral|preference/i.test(said), said.slice(0, 100));

  // 2. a card, where the settings put it; "okay, thanks" closes it
  const n2 = await agentCount();
  console.log(`${ts()}  you: "What deals do you have right now?"`);
  await speak("What deals do you have right now?", "deals");
  let card = null;
  for (let i = 0; i < 80 && !card; i++) { await sleep(500); card = (await read())?.card || null; }
  await settle(n2, 40);
  console.log(`${ts()}  card: ${JSON.stringify(card)}`);
  check("the card shows top right (the setting)", card?.place === "top-right" && card.rect.right > vw - 60 && card.rect.top < 60, JSON.stringify(card?.rect));
  console.log(`${ts()}  you: "Okay, thanks."`);
  await speak("Okay, thanks.", "thanks");
  let gone = false;
  for (let i = 0; i < 20 && !gone; i++) { await sleep(500); gone = !(await read())?.card; }
  check("saying something closes the card", gone);

  // a click on the page closes it too
  await settle(await agentCount() - 1, 20);
  const n3 = await agentCount();
  console.log(`${ts()}  you: "Is there a code for free shipping?"`);
  await speak("Is there anything for free shipping?", "ship");
  card = null;
  for (let i = 0; i < 80 && !card; i++) { await sleep(500); card = (await read())?.card || null; }
  await settle(n3, 40);
  if (card) {
    for (const type of ["mousePressed", "mouseReleased"]) await page.send("Input.dispatchMouseEvent", { type, x: 200, y: 400, button: "left", clickCount: 1 });
    await sleep(800);
    check("clicking the page closes the card", !(await read())?.card);
  } else check("clicking the page closes the card", false, "no card to close");
} catch (e) {
  console.error(e);
  results.push(false);
} finally {
  await page?.evaluate(`document.querySelector("talk-to-website")?.shadowRoot.querySelector('[data-act="stop"]')?.click()`).catch(() => {});
  await sleep(9000); // the conversation's last memory update lands before the old memory goes back
  ext.proc.kill();
  await put({ memory: saved.memory, sales: saved.sales, ui: saved.ui });
  if (oldMem) writeFileSync(memFile, oldMem); else if (existsSync(memFile)) unlinkSync(memFile);
}
console.log(`\n${results.filter(Boolean).length}/${results.length} passed · ${OUT}`);
process.exit(results.every(Boolean) ? 0 : 1);
