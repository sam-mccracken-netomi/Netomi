// Runs a website task with the real planner and page agent, no voice: Chrome opens the
// site, the widget's page agent is injected over DevTools (bypassing the site's CSP), and
// the browser agent works the request. Follow-up requests continue the same task memory.
//   node test/task.mjs https://www.sephora.com/ "search for red lipstick" "add the first one to my basket"
//   HEADFUL=1 to watch it. NETOMI=1 answers policy questions with the Netomi bot from the
//   settings page. Screenshots after each request in logs/task-*/.
import { writeFileSync, mkdirSync } from "node:fs";
import { join } from "node:path";
import { launch, sleep } from "./lib/chrome.mjs";
import { bundle } from "../server/bundle.mjs";
import { BrowserAgent } from "../server/browser-agent.mjs";
import { loadEnv, ROOT } from "../server/env.mjs";
import { createNetomi } from "../server/netomi.mjs";
import { createKnowledge } from "../server/knowledge.mjs";
import { getSettings } from "../server/settings.mjs";

loadEnv();
const [url, ...requests] = process.argv.slice(2);
if (!url || !requests.length) { console.error('usage: node test/task.mjs <url> "<request>" ["<follow-up>" ...]'); process.exit(2); }
const OUT = join(ROOT, "logs", `task-${Date.now()}`);
mkdirSync(OUT, { recursive: true });

const c = await launch({ port: 9345, args: [...(process.env.HEADFUL ? [] : []), "--user-agent=Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36"], width: 1366, height: 900 });
const WIDGET = `window.TalkWidgetConfig = { server: "ws://localhost:5179" }; ${bundle()}`;
let epoch = 0;
// the page navigated away, or the new page doesn't have the widget injected yet
const gone = (e) => /context was destroyed|navigated|Cannot find context|Target closed|Execution context|__talkWidget|reading 'page'/i.test(e.message);

async function ensureWidget() {
  for (let i = 0; i < 100; i++) {
    try {
      if ((await c.evaluate("document.readyState")) !== "loading") {
        if (!(await c.evaluate("!!window.__talkWidget"))) await c.evaluate(WIDGET);
        if (await c.evaluate("!!window.__talkWidget")) return true;
      }
    } catch {}
    await sleep(200);
  }
  return false;
}

const page = {
  async snapshot() {
    try { return await c.evaluate("window.__talkWidget.page.snapshot()"); }
    catch (e) { if (gone(e)) throw Object.assign(new Error("navigated"), { navigated: true }); throw e; }
  },
  async act(actions) {
    try { return await c.evaluate(`window.__talkWidget.page.act(${JSON.stringify(actions)})`); }
    catch (e) { if (gone(e)) throw Object.assign(new Error("navigated"), { navigated: true }); throw e; }
  },
  epoch: () => epoch,
  async waitForPage(ms) { await sleep(800); const ok = await ensureWidget(); epoch++; return ok; },
};

const netomi = process.env.NETOMI ? createNetomi() : null;
const knowledge = createKnowledge({ apiKey: process.env.OPENAI_API_KEY }); // the site's local knowledge base, if learned
const bot = getSettings().knowledge.netomi;
const netomiConversation = `task-${Date.now()}`;
if (netomi && !bot.botId) throw new Error("NETOMI=1: set the bot on the settings page first");
const t0 = Date.now();
const agent = new BrowserAgent({
  apiKey: process.env.OPENAI_API_KEY, model: process.env.PLANNER_MODEL || "gpt-6.1-sol", effort: process.env.PLANNER_EFFORT || "low", page,
  fast: { model: process.env.PLANNER_FAST_MODEL || "gpt-6-luna", effort: "low" },
  log: (kind, d) => {
    const t = ((Date.now() - t0) / 1000).toFixed(1).padStart(5);
    if (kind === "step") console.log(`${t}s  step ${d.n} (${d.ms} ms, ${d.tokens} tok) ${d.tool} ${d.tool === "act" ? `${d.args.why}: ${JSON.stringify(d.args.actions)}` : JSON.stringify(d.args)}`);
    else if (kind === "acted") console.log(`${t}s    → ${d.results.join(" · ")}${d.navigating ? " [navigating]" : ""}`);
    else if (kind === "look_failed") console.log(`${t}s    (look failed: ${d.error})`);
    else if (kind === "help_answer") console.log(`${t}s    help center (${d.ms} ms${d.cached ? ", cached" : ""}${d.done ? "" : ", still streaming"}): ${d.answered ? d.text : "no answer"}`);
  },
});
try {
  await c.goto(url);
  await sleep(Number(process.env.WAIT || 2500));
  await ensureWidget();
  const recent = [];
  for (const [i, request] of requests.entries()) {
    console.log(`\n=== "${request}"`);
    const s = Date.now();
    recent.push({ role: "user", text: request });
    const brand = await c.evaluate(`(document.querySelector('meta[property="og:site_name"]')?.content || location.hostname.replace(/^www\\./, "").split(".")[0])`).catch(() => undefined);
    // NETOMI=1: the help center is the Netomi bot from the settings, asked at once as the server does
    let help = null;
    if (netomi) {
      let early = netomi.ask(request, bot, { conversationId: netomiConversation });
      help = { likely: true, ask: (q) => { const a = early || netomi.ask(q, bot, { conversationId: netomiConversation }); early = null; return a; } };
    }
    const site = new URL(await c.evaluate("location.href")).hostname.replace(/^www\./, "");
    const kb = knowledge.has(site) ? knowledge.search(site, request, 5) : Promise.resolve([]);
    const out = await agent.run(request, { recent, brand, help, knowledge: kb });
    console.log(`=== ${out.status.toUpperCase()} in ${((Date.now() - s) / 1000).toFixed(1)} s: ${out.say}`);
    recent.push({ role: "agent", text: out.say });
    const shot = await c.send("Page.captureScreenshot", { format: "png" });
    writeFileSync(join(OUT, `${i + 1}.png`), Buffer.from(shot.result.data, "base64"));
  }
  console.log(`\nscreenshots in ${OUT}`);
} finally { c.close(); }
