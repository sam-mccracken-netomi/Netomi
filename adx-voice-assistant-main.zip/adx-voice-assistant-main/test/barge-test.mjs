// Barge-in: how fast the assistant's voice actually stops when you talk over it, measured
// at the speaker output (page mode on a real site; a fake mic plays the spoken lines).
//  1. hands-free: ask for a long story, then talk over it
//  2. push-to-talk: ask for a long story, press, say a few words, let go quickly; the rest of
//     the interrupted sentence must not come back after the release
//   npm start   # in another terminal
//   node test/barge-test.mjs
import { execFileSync } from "node:child_process";
import { readFileSync, mkdirSync } from "node:fs";
import { join } from "node:path";
import { launch, sleep } from "./lib/chrome.mjs";
import { bundle } from "../server/bundle.mjs";
import { ROOT } from "../server/env.mjs";

const OUT = join(ROOT, "logs", `barge-test-${Date.now()}`);
mkdirSync(OUT, { recursive: true });
const pcm = (text, name) => {
  const f = join(OUT, `${name}.wav`);
  execFileSync("say", ["-v", "Samantha", "-r", "185", "-o", f + ".aiff", text]);
  execFileSync("afconvert", ["-f", "WAVE", "-d", "LEI16@24000", "-c", "1", f + ".aiff", f]);
  const b = readFileSync(f);
  for (let o = 12; o < b.length; ) { const id = b.toString("ascii", o, o + 4), sz = b.readUInt32LE(o + 4); if (id === "data") return b.subarray(o + 8, o + 8 + sz).toString("base64"); o += 8 + sz + (sz % 2); }
};
const FAKE_MIC = `(() => { const ctx = new AudioContext({ sampleRate: 24000 }); const dest = ctx.createMediaStreamDestination();
  window.__fakeMic = { say(b64) { const bin = atob(b64), n = bin.length >> 1, buf = ctx.createBuffer(1, n, 24000), ch = buf.getChannelData(0);
    for (let i = 0; i < n; i++) { let v = bin.charCodeAt(2 * i) | (bin.charCodeAt(2 * i + 1) << 8); if (v >= 32768) v -= 65536; ch[i] = v / 32768; }
    const src = ctx.createBufferSource(); src.buffer = buf; src.connect(dest); ctx.resume(); src.start(); return n / 24000; } };
  navigator.mediaDevices.getUserMedia = async () => (ctx.resume(), new MediaStream(dest.stream.getAudioTracks().map((t) => t.clone()))); })();`;

const c = await launch({ port: 9356, args: ["--mute-audio", "--autoplay-policy=no-user-gesture-required", "--use-fake-ui-for-media-stream", "--disable-features=LocalNetworkAccessChecks,BlockInsecurePrivateNetworkRequests,PrivateNetworkAccessSendPreflights"] });
const results = [];
const t00 = Date.now();
const say = (m) => console.log(`${((Date.now() - t00) / 1000).toFixed(1).padStart(5)}s  ${m}`);
const check = (name, ok, detail) => { results.push(ok); console.log(`${ok ? "PASS" : "FAIL"}  ${name}  (${detail})`); };
const level = () => c.evaluate("window.__talkWidget.outLevel()");
const key = (type) => c.send("Input.dispatchKeyEvent", { type, modifiers: type === "keyDown" ? 1 : 0, key: " ", code: "Space", windowsVirtualKeyCode: 32 });
async function untilTalking(ms = 30000) { // the voice has been audibly talking for ~2.5 s
  let run = 0; const t = Date.now();
  while (Date.now() - t < ms) { await sleep(100); run = (await level()) > 0.15 ? run + 100 : Math.max(0, run - 50); if (run >= 2500) return true; }
  return false;
}
async function stopTime(from, ms = 4000) { // first time the output stays quiet for 200 ms
  let quietSince = 0;
  while (Date.now() - from < ms) {
    const l = await level(), t = Date.now();
    if (l < 0.08) { quietSince ||= t; if (t - quietSince >= 200) return quietSince - from; } else quietSince = 0;
    await sleep(15);
  }
  return null;
}
async function loudMsDuring(ms) { let loud = 0; const t = Date.now(); while (Date.now() - t < ms) { if ((await level()) > 0.15) loud += 25; await sleep(25); } return loud; }

try {
  await c.send("Page.setBypassCSP", { enabled: true });
  await c.send("Page.addScriptToEvaluateOnNewDocument", { source: FAKE_MIC });
  await c.send("Page.addScriptToEvaluateOnNewDocument", { source: `window.TalkWidgetConfig = { server: "ws://localhost:5179", name: "Nova" }; document.addEventListener("DOMContentLoaded", function () { ${bundle()} });` });
  say("opening the page");
  await c.goto("https://en.wikipedia.org/wiki/Sea");
  await c.waitFor("!!window.__talkWidget && !!window.__fakeMic");
  const story = pcm("Tell me a long story about a sailor and the sea, please. Make it long.", "story");
  const over = pcm("Stop, stop. What time is it in Tokyo right now?", "over");
  const brief = pcm("Wait, stop.", "brief");

  // 1. hands-free
  say("hands-free: asking for a story");
  await c.evaluate("window.__talkWidget.start()");
  await sleep(2500);
  await c.evaluate(`window.__fakeMic.say(${JSON.stringify(story)})`);
  if (!(await untilTalking())) throw new Error("the story never started");
  say("hands-free: talking over it");
  const t1 = Date.now();
  await c.evaluate(`window.__fakeMic.say(${JSON.stringify(over)})`);
  const stop1 = await stopTime(t1);
  check("hands-free: talking over it stops the voice", stop1 != null && stop1 < 600, `${stop1} ms after you started talking; GPT-Live alone takes ~1200 ms`);
  const replied = await untilTalking(20000);
  const msgs = await c.evaluate("window.__talkWidget.state.messages");
  check("hands-free: then it answers the interruption", replied && /tokyo|time|pm|am/i.test(msgs.filter((m) => m.role === "agent").at(-1)?.text || ""), msgs.filter((m) => m.role === "agent").at(-1)?.text.slice(0, 70));
  await c.evaluate("window.__talkWidget.stop()");
  await sleep(1500);

  // 2. push-to-talk with a quick press
  say("push-to-talk: asking for a story");
  await key("keyDown"); await sleep(400);
  const s2 = await c.evaluate(`window.__fakeMic.say(${JSON.stringify(story)})`);
  await sleep(s2 * 1000 + 450); await key("keyUp");
  if (!(await untilTalking())) throw new Error("the story never started (push-to-talk)");
  say("push-to-talk: pressing over it");
  const t2 = Date.now();
  await key("keyDown");
  const stop2 = await stopTime(t2);
  const s3 = await c.evaluate(`window.__fakeMic.say(${JSON.stringify(brief)})`);
  await sleep(s3 * 1000 + 150);
  await key("keyUp"); // let go well before the model would have stopped by itself
  const leaked = await loudMsDuring(900);
  check("push-to-talk: pressing stops the voice", stop2 != null && stop2 < 300, `${stop2} ms`);
  check("push-to-talk: the interrupted sentence doesn't come back after letting go", leaked <= 150, `${leaked} ms of the old voice in the 0.9 s after release`);
} finally {
  await c.evaluate("window.__talkWidget && window.__talkWidget.stop()").catch(() => {});
  await sleep(300);
  c.close();
}
console.log(`\n${results.filter(Boolean).length}/${results.length} passed`);
