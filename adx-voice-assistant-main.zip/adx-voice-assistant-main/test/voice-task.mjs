// Voice end to end on a real website: spoken requests (macOS `say`) go through GPT-Live,
// get delegated to the browser agent, which operates the site across full page loads,
// and the answers come back by voice. Nothing plays on the speakers (Chrome is muted).
//
// The widget is injected into every page load, as if the site had the script tag; a fake
// microphone (controlled from here) feeds each line at the right moment, since Chrome's
// file-backed fake mic would restart from the top on every new page. The site's CSP is
// bypassed, as a site that installs the widget would allow the relay.
//
//   npm start   # in another terminal
//   node test/voice-task.mjs [url] ["first request"] ["follow-up"] ...
//   DOC_DELAY_MS=60000: later pages are that slow to load (TAIL_MS: keep listening at the end)
import { execFileSync } from "node:child_process";
import { readFileSync, writeFileSync, mkdirSync, existsSync } from "node:fs";
import { join } from "node:path";
import { launch, sleep } from "./lib/chrome.mjs";
import { bundle } from "../server/bundle.mjs";
import { ROOT } from "../server/env.mjs";

const [url = "https://en.wikipedia.org/wiki/Main_Page", ...lines] = process.argv.slice(2);
const TURNS = lines.length ? lines : ["Can you search Wikipedia for the Eiffel Tower?", "How tall is it?"];
const OUT = join(ROOT, "logs", `voice-task-${Date.now()}`);
mkdirSync(OUT, { recursive: true });

function pcm(text, i) {
  const f = join(OUT, `turn${i}.wav`);
  if (!existsSync(f)) {
    execFileSync("say", ["-v", "Samantha", "-r", "180", "-o", f + ".aiff", text]);
    execFileSync("afconvert", ["-f", "WAVE", "-d", "LEI16@24000", "-c", "1", f + ".aiff", f]);
  }
  const b = readFileSync(f);
  for (let off = 12; off < b.length; ) {
    const id = b.toString("ascii", off, off + 4), size = b.readUInt32LE(off + 4);
    if (id === "data") return b.subarray(off + 8, off + 8 + size);
    off += 8 + size + (size % 2);
  }
}

const FAKE_MIC = `(() => {
  const ctx = new AudioContext({ sampleRate: 24000 });
  const dest = ctx.createMediaStreamDestination();
  window.__fakeMic = { say(b64) {
    const bin = atob(b64), n = bin.length >> 1, buf = ctx.createBuffer(1, n, 24000), ch = buf.getChannelData(0);
    for (let i = 0; i < n; i++) { let v = bin.charCodeAt(2 * i) | (bin.charCodeAt(2 * i + 1) << 8); if (v >= 32768) v -= 65536; ch[i] = v / 32768; }
    const src = ctx.createBufferSource(); src.buffer = buf; src.connect(dest); ctx.resume(); src.start(); return n / 24000;
  } };
  const orig = navigator.mediaDevices.getUserMedia.bind(navigator.mediaDevices);
  navigator.mediaDevices.getUserMedia = async (c) => c && c.audio ? (ctx.resume(), new MediaStream(dest.stream.getAudioTracks().map((t) => t.clone()))) : orig(c);
})();`;
const WIDGET = `window.TalkWidgetConfig = { server: "ws://localhost:5179", name: "Nova" };
document.addEventListener("DOMContentLoaded", function () { ${bundle()} });`;

const c = await launch({ port: 9346, args: ["--mute-audio", "--autoplay-policy=no-user-gesture-required", "--use-fake-ui-for-media-stream",
  // a public site reaching localhost needs Local Network Access permission, which a person
  // grants with one click; headless Chrome can't show the prompt
  "--disable-features=LocalNetworkAccessChecks,BlockInsecurePrivateNetworkRequests,PrivateNetworkAccessSendPreflights"], width: 1280, height: 860 });
const t0 = Date.now();
const ts = () => `${((Date.now() - t0) / 1000).toFixed(1).padStart(5)}s`;
const problems = [];
c.on((m) => { if (m.method === "Runtime.exceptionThrown") problems.push(m.params.exceptionDetails.exception?.description || m.params.exceptionDetails.text); });
const key = (type) => c.send("Input.dispatchKeyEvent", { type, modifiers: type === "keyDown" ? 1 : 0, key: " ", code: "Space", windowsVirtualKeyCode: 32 });
const state = () => c.evaluate("window.__talkWidget && window.__talkWidget.state").catch(() => null);

try {
  // a site that installs the widget allows its server in its CSP; simulate that here
  // (the extension needs no such thing: its connection lives in the offscreen document)
  await c.send("Page.setBypassCSP", { enabled: true });
  await c.send("Page.addScriptToEvaluateOnNewDocument", { source: FAKE_MIC });
  await c.send("Page.addScriptToEvaluateOnNewDocument", { source: WIDGET });
  await c.goto(url);
  await c.waitFor("!!window.__talkWidget");
  // DOC_DELAY_MS: every later page is that slow to arrive (a slow site), to check that a
  // task waits for it and carries on
  if (process.env.DOC_DELAY_MS) {
    c.on((m) => { if (m.method === "Fetch.requestPaused") setTimeout(() => c.send("Fetch.continueRequest", { requestId: m.params.requestId }).catch(() => {}), Number(process.env.DOC_DELAY_MS)); });
    await c.send("Fetch.enable", { patterns: [{ resourceType: "Document", requestStage: "Request" }] });
  }
  const urls = [await c.evaluate("location.href")];
  for (const [i, text] of TURNS.entries()) {
    await c.waitFor("!!window.__fakeMic && !!window.__talkWidget");
    const before = ((await state())?.messages || []).filter((m) => m.role === "agent").length;
    console.log(`${ts()}  you: "${text}"`);
    await key("keyDown");
    await sleep(i === 0 ? 400 : 150); // the first press opens the mic and the session
    const secs = await c.evaluate(`window.__fakeMic.say(${JSON.stringify(pcm(text, i).toString("base64"))})`);
    await sleep(secs * 1000 + 500);
    await key("keyUp");
    // wait for the agent to finish and the voice to say something new
    let st, settled = 0;
    for (let k = 0; k < 240; k++) {
      await sleep(500);
      st = await state();
      const href = await c.evaluate("location.href").catch(() => null);
      if (href && href !== urls.at(-1)) { urls.push(href); console.log(`${ts()}  page → ${href}`); }
      const agents = (st?.messages || []).filter((m) => m.role === "agent");
      const quiet = st && !st.working && st.view !== "speaking" && st.view !== "working" && st.view !== "thinking";
      settled = agents.length > before && quiet ? settled + 1 : 0;
      if (settled >= 4) break;
    }
    const said = (st?.messages || []).filter((m) => m.role === "agent").slice(before).map((m) => m.text).join(" / ");
    console.log(`${ts()}  Nova: ${said || "(nothing)"}`);
    const shot = await c.send("Page.captureScreenshot", { format: "png" });
    writeFileSync(join(OUT, `${i + 1}.png`), Buffer.from(shot.result.data, "base64"));
  }
  // TAIL_MS: keep listening after the last line (e.g. for what's said after a recovery)
  if (process.env.TAIL_MS) await sleep(Number(process.env.TAIL_MS));
  const st = await state();
  writeFileSync(join(OUT, "result.json"), JSON.stringify({ urls, state: st, problems }, null, 2));
  console.log(`\ntranscript:`);
  for (const m of st.messages) console.log(`  ${m.role === "user" ? "you " : "Nova"}: ${m.text}`);
  console.log(`\npages: ${urls.join("  →  ")}`);
  if (problems.length) console.log("page errors:", problems);
  console.log(`screenshots in ${OUT}`);
} finally {
  await c.evaluate("window.__talkWidget && window.__talkWidget.stop()").catch(() => {});
  await sleep(300);
  c.close();
}
