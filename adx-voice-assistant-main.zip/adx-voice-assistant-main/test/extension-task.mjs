// The Chrome extension end to end on a real website: the unpacked extension is loaded,
// turned on for the tab (as a toolbar click would), and spoken requests go through the
// offscreen document's voice → GPT-Live → the browser agent → the page, across full page
// loads, with the answers spoken back. Chrome is muted; a fake mic in the offscreen
// document plays each line (macOS `say`).
//
//   npm start   # in another terminal
//   node test/extension-task.mjs [url] ["request"] ["follow-up"] ...
import { execFileSync } from "node:child_process";
import { readFileSync, writeFileSync, mkdirSync, existsSync } from "node:fs";
import { join } from "node:path";
import { sleep } from "./lib/chrome.mjs";
import { launchWithExtension, attach, findTarget } from "./lib/extension.mjs";
import { ROOT } from "../server/env.mjs";

const [url = "https://en.wikipedia.org/wiki/Main_Page", ...lines] = process.argv.slice(2);
const TURNS = lines.length ? lines : ["Search Wikipedia for the Golden Gate Bridge, please.", "When did it open?"];
const OUT = join(ROOT, "logs", `extension-task-${Date.now()}`);
mkdirSync(OUT, { recursive: true });

function pcm(text, i) {
  const f = join(OUT, `turn${i}.wav`);
  if (!existsSync(f)) {
    execFileSync("say", ["-v", "Samantha", "-r", "180", "-o", f + ".aiff", text]);
    execFileSync("afconvert", ["-f", "WAVE", "-d", "LEI16@24000", "-c", "1", f + ".aiff", f]);
  }
  const b = readFileSync(f);
  for (let off = 12; off < b.length; ) {
    const id = b.toString("ascii", off, off + 4), size = b.readUInt32LE(off + 4);
    if (id === "data") return b.subarray(off + 8, off + 8 + size);
    off += 8 + size + (size % 2);
  }
}

const FAKE_MIC = `(() => {
  const ctx = new AudioContext({ sampleRate: 24000 });
  const dest = ctx.createMediaStreamDestination();
  window.__fakeMic = { say(b64) {
    const bin = atob(b64), n = bin.length >> 1, buf = ctx.createBuffer(1, n, 24000), ch = buf.getChannelData(0);
    for (let i = 0; i < n; i++) { let v = bin.charCodeAt(2 * i) | (bin.charCodeAt(2 * i + 1) << 8); if (v >= 32768) v -= 65536; ch[i] = v / 32768; }
    const src = ctx.createBufferSource(); src.buffer = buf; src.connect(dest); ctx.resume(); src.start(); return n / 24000;
  } };
  navigator.mediaDevices.getUserMedia = async () => (ctx.resume(), new MediaStream(dest.stream.getAudioTracks().map((t) => t.clone())));
})(); true`;

// the widget's view, read from its (open) shadow DOM: the page's own world can see it
const READ = `(() => { const r = document.querySelector("talk-to-website")?.shadowRoot; if (!r) return null;
  return { view: r.querySelector(".tw").dataset.state, status: r.querySelector(".status").textContent,
    caption: r.querySelector(".subs.on span")?.textContent || r.querySelector(".cap.on")?.textContent || "",
    captionKind: r.querySelector(".subs.on") ? "subtitles" : r.querySelector(".cap.on") ? "bubble" : "",
    messages: [...r.querySelectorAll(".msg")].map((m) => ({ role: m.classList.contains("user") ? "user" : "agent", text: m.textContent })) }; })()`;

const ext = await launchWithExtension({ path: join(ROOT, "extension"), args: ["--mute-audio", "--autoplay-policy=no-user-gesture-required", "--use-fake-ui-for-media-stream", "--window-size=1280,860"] });
const t0 = Date.now();
const ts = () => `${((Date.now() - t0) / 1000).toFixed(1).padStart(5)}s`;
let page, sw, off;
try {
  const pt = await findTarget(ext.port, (t) => t.type === "page" && t.url === "about:blank");
  page = await attach(pt.webSocketDebuggerUrl);
  await page.send("Page.enable");
  await page.send("Page.navigate", { url });
  await sleep(2500);
  const swt = await findTarget(ext.port, (t) => t.type === "service_worker" && t.url.includes(ext.id));
  sw = await attach(swt.webSocketDebuggerUrl);
  const tabId = await sw.evaluate(`chrome.tabs.query({}).then((ts) => ts.find((t) => t.url && t.url.startsWith(${JSON.stringify(new URL(url).origin)}))?.id)`);
  await sw.evaluate(`toggleTab({ id: ${tabId} }).then(() => true)`);
  const ot = await findTarget(ext.port, (t) => t.url.endsWith("/offscreen.html"));
  if (!ot) throw new Error("no offscreen document");
  off = await attach(ot.webSocketDebuggerUrl);
  await off.evaluate(FAKE_MIC);
  for (let i = 0; i < 50 && !(await page.evaluate(READ).catch(() => null)); i++) await sleep(200);
  console.log(`${ts()}  extension on for tab ${tabId}; orb: ${JSON.stringify((await page.evaluate(READ))?.view)}`);

  const urls = [url];
  const key = (type) => page.send("Input.dispatchKeyEvent", { type, modifiers: type === "keyDown" ? 1 : 0, key: " ", code: "Space", windowsVirtualKeyCode: 32 });
  for (const [i, text] of TURNS.entries()) {
    const before = ((await page.evaluate(READ).catch(() => null))?.messages || []).filter((m) => m.role === "agent").length;
    console.log(`${ts()}  you: "${text}"`);
    await key("keyDown");
    await sleep(i === 0 ? 500 : 150);
    const secs = await off.evaluate(`window.__fakeMic.say(${JSON.stringify(pcm(text, i).toString("base64"))})`);
    await sleep(secs * 1000 + 500);
    await key("keyUp");
    let st, settled = 0, lastCaption = "", captionShot = false;
    for (let k = 0; k < 240; k++) {
      await sleep(500);
      st = await page.evaluate(READ).catch(() => null);
      const href = await page.evaluate("location.href").catch(() => null);
      if (href && href !== urls.at(-1)) { urls.push(href); console.log(`${ts()}  page → ${href}`); }
      // captions (Settings → Captions): print each new line, keep a screenshot of the first
      if (st?.caption && st.caption !== lastCaption) {
        lastCaption = st.caption;
        console.log(`${ts()}  caption (${st.captionKind}): ${st.caption}`);
        if (!captionShot && st.caption.length > 50) { captionShot = true; const c = await page.send("Page.captureScreenshot", { format: "png" }); writeFileSync(join(OUT, `caption-${i + 1}.png`), Buffer.from(c.result.data, "base64")); }
      }
      const agents = (st?.messages || []).filter((m) => m.role === "agent");
      settled = st && agents.length > before && ["ready", "listening", "idle"].includes(st.view) ? settled + 1 : 0;
      if (settled >= 4) break;
    }
    console.log(`${ts()}  Nova: ${(st?.messages || []).filter((m) => m.role === "agent").slice(before).map((m) => m.text).join(" / ") || "(nothing)"}`);
    const shot = await page.send("Page.captureScreenshot", { format: "png" });
    writeFileSync(join(OUT, `${i + 1}.png`), Buffer.from(shot.result.data, "base64"));
  }
  const st = await page.evaluate(READ);
  writeFileSync(join(OUT, "result.json"), JSON.stringify({ urls, state: st }, null, 2));
  console.log(`\ntranscript (from the orb's chat panel on the final page):`);
  for (const m of st.messages) console.log(`  ${m.role === "user" ? "you " : "Nova"}: ${m.text}`);
  console.log(`\npages: ${urls.join("  →  ")}\nscreenshots in ${OUT}`);
} finally {
  await off?.evaluate("true");
  await sw?.evaluate(`chrome.runtime.sendMessage ? true : true`).catch(() => {});
  ext.proc.kill();
}
