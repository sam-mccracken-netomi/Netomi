// One conversation, in the active tab of the site, with the real extension on a real website:
//  1. start talking in tab A of wikipedia.org
//  2. open the site in tab B: the conversation moves to B (its orb is live, A's rests)
//  3. switch back to A: it moves back; there's only ever one live orb
//  4. close A: B carries on
//   npm start   # in another terminal
//   node test/one-tab-test.mjs
import { join } from "node:path";
import { sleep } from "./lib/chrome.mjs";
import { launchWithExtension, attach, findTarget } from "./lib/extension.mjs";
import { ROOT } from "../server/env.mjs";

const A_URL = "https://en.wikipedia.org/wiki/Eiffel_Tower", B_URL = "https://en.wikipedia.org/wiki/Golden_Gate_Bridge";
const ext = await launchWithExtension({ path: join(ROOT, "extension"), port: 9362, args: ["--mute-audio", "--autoplay-policy=no-user-gesture-required", "--use-fake-ui-for-media-stream", "--window-size=1280,860"] });
const results = [];
const check = (name, ok, detail = "") => { results.push(ok); console.log(`${ok ? "PASS" : "FAIL"}  ${name}${detail ? `  (${detail})` : ""}`); };
const SHADOW = `document.querySelector("talk-to-website").shadowRoot`;
const view = (p) => p.evaluate(`${SHADOW}.querySelector(".tw").dataset.state`).catch(() => "?");
const widget = async (p) => { for (let i = 0; i < 60 && !(await p.evaluate(`!!document.querySelector("talk-to-website")`).catch(() => false)); i++) await sleep(250); };
let sw;

try {
  const a = await attach((await findTarget(ext.port, (t) => t.type === "page" && t.url === "about:blank")).webSocketDebuggerUrl);
  await a.send("Page.enable");
  await a.send("Page.navigate", { url: A_URL });
  await sleep(2500);
  sw = await attach((await findTarget(ext.port, (t) => t.type === "service_worker" && t.url.includes(ext.id))).webSocketDebuggerUrl);
  const tabA = await sw.evaluate(`chrome.tabs.query({}).then((ts) => ts.find((t) => t.url && t.url.includes("Eiffel"))?.id)`);
  await sw.evaluate(`toggleTab({ id: ${tabA} }).then(() => true)`);
  await widget(a);
  await sleep(1000);

  // 1. talk in A
  const [vw, vh] = await a.evaluate("[innerWidth, innerHeight]");
  for (const type of ["mousePressed", "mouseReleased"]) await a.send("Input.dispatchMouseEvent", { type, x: vw - 48, y: vh - 48, button: "left", clickCount: 1 });
  for (let i = 0; i < 40 && (await view(a)) === "idle"; i++) await sleep(500);
  await sleep(4000);
  check("tab A: the conversation is live", (await view(a)) !== "idle", await view(a));

  // 2. open the site in a new tab B
  const tabB = await sw.evaluate(`chrome.tabs.create({ url: ${JSON.stringify(B_URL)}, active: true }).then((t) => t.id)`);
  const b = await attach((await findTarget(ext.port, (t) => t.type === "page" && t.url.includes("Golden_Gate"))).webSocketDebuggerUrl);
  await widget(b);
  await sleep(2500);
  let agent = await sw.evaluate("agentTab");
  check("tab B (active) has the conversation", agent === tabB, `agentTab=${agent}`);
  check("tab B's orb is live", (await view(b)) !== "idle", await view(b));
  check("tab A's orb rests", (await view(a)) === "idle", await view(a));
  const voices = await sw.evaluate(`chrome.runtime.getContexts({ contextTypes: ["OFFSCREEN_DOCUMENT"] }).then((c) => c.length)`);
  check("one voice, not one per tab", voices === 1, `${voices}`);

  // 3. switch back to A
  await sw.evaluate(`chrome.tabs.update(${tabA}, { active: true }).then(() => true)`);
  await sleep(2000);
  agent = await sw.evaluate("agentTab");
  check("switching back: tab A has it again", agent === tabA, `agentTab=${agent}`);
  check("tab A's orb is live again", (await view(a)) !== "idle", await view(a));
  check("tab B's orb rests", (await view(b)) === "idle", await view(b));

  // 4. close A: B carries on
  await sw.evaluate(`chrome.tabs.remove(${tabA}).then(() => true)`);
  await sleep(2500);
  agent = await sw.evaluate("agentTab");
  check("closing A: tab B carries on", agent === tabB && (await view(b)) !== "idle", `agentTab=${agent}, B=${await view(b)}`);
} catch (e) {
  console.error(e);
  results.push(false);
} finally {
  ext.proc.kill();
}
console.log(`\n${results.filter(Boolean).length}/${results.length} passed`);
process.exit(results.every(Boolean) ? 0 : 1);
