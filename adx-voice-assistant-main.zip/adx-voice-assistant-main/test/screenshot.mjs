// Screenshots of the orb in every state, with no session and no audio, for checking the
// look: node test/screenshot.mjs (server running). Output: logs/orb-<time>/
import { spawn } from "node:child_process";
import { writeFileSync, mkdirSync, mkdtempSync } from "node:fs";
import { join } from "node:path";
import { tmpdir } from "node:os";
import { ROOT } from "../server/env.mjs";

const PORT = Number(process.env.PORT || 5179);
const CHROME = process.env.CHROME || "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome";
const OUT = join(ROOT, "logs", `orb-${Date.now()}`);
mkdirSync(OUT, { recursive: true });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const chrome = spawn(CHROME, ["--headless=new", "--remote-debugging-port=9342", `--user-data-dir=${mkdtempSync(join(tmpdir(), "orb-"))}`, "--no-first-run", "--enable-unsafe-swiftshader", "--use-angle=swiftshader", "about:blank"], { stdio: "ignore" });
let target;
for (let i = 0; i < 50 && !target; i++) { await sleep(200); try { target = (await (await fetch("http://127.0.0.1:9342/json/list")).json()).find((x) => x.type === "page"); } catch {} }
const cdp = new WebSocket(target.webSocketDebuggerUrl);
await new Promise((r) => (cdp.onopen = r));
let seq = 0;
const pending = new Map();
cdp.onmessage = (m) => { const msg = JSON.parse(m.data); if (msg.id && pending.has(msg.id)) { pending.get(msg.id)(msg); pending.delete(msg.id); } };
const send = (method, params = {}) => new Promise((r) => { const id = ++seq; pending.set(id, r); cdp.send(JSON.stringify({ id, method, params })); });
const evaluate = async (e) => (await send("Runtime.evaluate", { expression: e, returnByValue: true })).result?.result?.value;
await send("Emulation.setDeviceMetricsOverride", { width: 1000, height: 640, deviceScaleFactor: 2, mobile: false });
await send("Page.navigate", { url: `http://localhost:${PORT}/` });
for (let i = 0; i < 50 && !(await evaluate("!!window.__talkWidget")); i++) await sleep(100);
const W = 1000, H = 640;
const clip = (x, y, w, h) => ({ x, y, width: w, height: h, scale: 1 });
const shot = async (name, c) => writeFileSync(join(OUT, `${name}.png`), Buffer.from((await send("Page.captureScreenshot", { format: "png", clip: c })).result.data, "base64"));
const orbClip = clip(W - 22 - 52 - 30, H - 22 - 52 - 30, 112, 112);
console.log("webgl:", await evaluate("!document.querySelector('talk-to-website').shadowRoot.querySelector('.tw').classList.contains('nogl')"));
for (const [state, level] of [["idle"], ["ready"], ["listening", 0], ["listening", 0.15], ["listening", 0.9], ["thinking"], ["working"], ["speaking", 0.7], ["muted"], ["error"]]) {
  await evaluate(`window.__talkWidget.preview(${JSON.stringify(state)}, ${level ?? null})`);
  await sleep(1500);
  await shot(`${state}${level != null ? "-" + level : ""}`, orbClip);
}
// hover dock (as if a session were up) and the chat panel
await evaluate(`(() => { const r = document.querySelector('talk-to-website').shadowRoot; r.querySelector('.tw').classList.add('hover'); window.__talkWidget.preview('listening', .5); })()`);
await sleep(600);
await shot("dock", clip(W - 260, H - 110, 260, 110));
await evaluate(`(() => { document.querySelector('talk-to-website').shadowRoot.querySelector('.tw').classList.remove('hover'); window.__talkWidget.openChat(true); })()`);
await sleep(600);
await shot("panel", clip(W - 420, H - 560, 420, 560));
cdp.close(); chrome.kill();
console.log("screenshots in", OUT);
