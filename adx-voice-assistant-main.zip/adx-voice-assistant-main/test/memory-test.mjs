// Memory and proactivity, with the real extension on real websites:
//  1. browse a few pages with the voice off: they're recorded for this site
//  2. click the orb: a greeting that fits the site and what they're viewing
//  3. "take me back to the first one": the agent uses the browsing history
//  4. stop, click again later: a welcome back that picks up where they left off
//  5. another site: a fresh start, nothing from the first site
// Chrome is muted; a fake mic in the offscreen document plays the spoken line.
//   npm start   # in another terminal
//   node test/memory-test.mjs
import { execFileSync } from "node:child_process";
import { readFileSync, writeFileSync, mkdirSync } from "node:fs";
import { join } from "node:path";
import { sleep } from "./lib/chrome.mjs";
import { launchWithExtension, attach, findTarget } from "./lib/extension.mjs";
import { ROOT } from "../server/env.mjs";

const SITE_A = ["https://en.wikipedia.org/wiki/Eiffel_Tower", "https://en.wikipedia.org/wiki/Golden_Gate_Bridge", "https://en.wikipedia.org/wiki/Statue_of_Liberty"];
const SITE_B = "https://en.wikivoyage.org/wiki/Paris";
const OUT = join(ROOT, "logs", `memory-test-${Date.now()}`);
mkdirSync(OUT, { recursive: true });
const W = 1280, H = 860;

function pcm(text, name) {
  const f = join(OUT, `${name}.wav`);
  execFileSync("say", ["-v", "Samantha", "-r", "180", "-o", f + ".aiff", text]);
  execFileSync("afconvert", ["-f", "WAVE", "-d", "LEI16@24000", "-c", "1", f + ".aiff", f]);
  const b = readFileSync(f);
  for (let off = 12; off < b.length; ) {
    const id = b.toString("ascii", off, off + 4), size = b.readUInt32LE(off + 4);
    if (id === "data") return b.subarray(off + 8, off + 8 + size);
    off += 8 + size + (size % 2);
  }
}
const FAKE_MIC = `(() => { if (window.__fakeMic) return true;
  const ctx = new AudioContext({ sampleRate: 24000 }); const dest = ctx.createMediaStreamDestination();
  window.__fakeMic = { say(b64) { const bin = atob(b64), n = bin.length >> 1, buf = ctx.createBuffer(1, n, 24000), ch = buf.getChannelData(0);
    for (let i = 0; i < n; i++) { let v = bin.charCodeAt(2 * i) | (bin.charCodeAt(2 * i + 1) << 8); if (v >= 32768) v -= 65536; ch[i] = v / 32768; }
    const src = ctx.createBufferSource(); src.buffer = buf; src.connect(dest); ctx.resume(); src.start(); return n / 24000; } };
  navigator.mediaDevices.getUserMedia = async () => (ctx.resume(), new MediaStream(dest.stream.getAudioTracks().map((t) => t.clone()))); return true; })()`;
const READ = `(() => { const r = document.querySelector("talk-to-website")?.shadowRoot; if (!r) return null;
  return { view: r.querySelector(".tw").dataset.state, messages: [...r.querySelectorAll(".msg")].map((m) => ({ role: m.classList.contains("user") ? "user" : "agent", text: m.textContent })) }; })()`;

const ext = await launchWithExtension({ path: join(ROOT, "extension"), args: ["--mute-audio", "--autoplay-policy=no-user-gesture-required", "--use-fake-ui-for-media-stream", `--window-size=${W},${H}`] });
const t0 = Date.now();
const ts = () => `${((Date.now() - t0) / 1000).toFixed(1).padStart(5)}s`;
const results = [];
const check = (name, ok, detail = "") => { results.push([name, ok]); console.log(`${ok ? "PASS" : "FAIL"}  ${name}${detail ? `  (${detail})` : ""}`); };
let page, sw, off;

async function go(url) {
  await page.send("Page.navigate", { url });
  for (let i = 0; i < 80; i++) { await sleep(200); if ((await page.evaluate("document.readyState").catch(() => "")) === "complete") break; }
  for (let i = 0; i < 50 && !(await page.evaluate(READ).catch(() => null)); i++) await sleep(200);
  await sleep(1600); // the visit is recorded ~1 s after load
}
const read = () => page.evaluate(READ).catch(() => null);
const agentLines = async () => ((await read())?.messages || []).filter((m) => m.role === "agent").map((m) => m.text);
async function settle(before, maxS = 60) {
  let n = 0;
  for (let k = 0; k < maxS * 2; k++) {
    await sleep(500);
    const st = await read();
    const agents = (st?.messages || []).filter((m) => m.role === "agent").length;
    n = st && agents > before && ["ready", "listening", "idle"].includes(st.view) ? n + 1 : 0;
    if (n >= 4) break;
  }
  return (await agentLines()).slice(before);
}
async function clickOrb() {
  const [vw, vh] = await page.evaluate("[innerWidth, innerHeight]"); // the viewport, not the window
  for (const type of ["mousePressed", "mouseReleased"]) await page.send("Input.dispatchMouseEvent", { type, x: vw - 48, y: vh - 48, button: "left", clickCount: 1 });
}
async function speak(text, name) {
  const pcmB64 = pcm(text, name).toString("base64");
  const secs = await off.evaluate(`window.__fakeMic.say(${JSON.stringify(pcmB64)})`);
  await sleep(secs * 1000 + 300);
}
const visitsOf = (site) => sw.evaluate(`chrome.storage.local.get("ttw:${site}:visits").then((v) => v["ttw:${site}:visits"] || [])`);

try {
  page = await attach((await findTarget(ext.port, (t) => t.type === "page" && t.url === "about:blank")).webSocketDebuggerUrl);
  await page.send("Page.enable");
  await page.send("Page.navigate", { url: SITE_A[0] });
  await sleep(2500);
  sw = await attach((await findTarget(ext.port, (t) => t.type === "service_worker" && t.url.includes(ext.id))).webSocketDebuggerUrl);
  const tabId = await sw.evaluate(`chrome.tabs.query({}).then((ts) => ts.find((t) => t.url && t.url.includes("wikipedia.org"))?.id)`);
  await sw.evaluate(`toggleTab({ id: ${tabId} }).then(() => true)`); // turn it on for wikipedia.org
  off = await attach((await findTarget(ext.port, (t) => t.url.endsWith("/offscreen.html"))).webSocketDebuggerUrl);
  await off.evaluate(FAKE_MIC);

  // 1. browse with the voice off
  console.log(`${ts()}  browsing wikipedia.org with the voice off`);
  for (const u of SITE_A) await go(u);
  const visits = await visitsOf("wikipedia.org");
  check("pages viewed with the voice off are recorded for the site", SITE_A.every((u) => visits.some((v) => v.url === u)), `${visits.length} visits: ${visits.map((v) => v.heading || v.title).join(" · ")}`);

  // 2. first click on this site: a proactive greeting
  console.log(`${ts()}  click the orb (first conversation on wikipedia.org)`);
  await clickOrb();
  const greet = (await settle(0, 30)).join(" ");
  console.log(`${ts()}  Nova: ${greet}`);
  check("first click: a greeting that fits the site and page", /statue|liberty|wikipedia|bridge|eiffel/i.test(greet), greet.slice(0, 60));

  // 3. the browsing history answers "the first one"
  const before = (await agentLines()).length;
  console.log(`${ts()}  you: "Take me back to the first article I looked at."`);
  await speak("Take me back to the first article I looked at.", "back");
  const reply = (await settle(before, 90)).join(" / ");
  const now = await page.evaluate("location.href").catch(() => "");
  console.log(`${ts()}  Nova: ${reply}\n${ts()}  page: ${now}`);
  check("\"take me back to the first article\" goes to the Eiffel Tower", /Eiffel_Tower/.test(now));

  // 4. stop, start again: a welcome back
  await page.evaluate(`document.querySelector("talk-to-website").shadowRoot.querySelector('[data-act="stop"]').click()`);
  await sleep(3000);
  const n4 = (await agentLines()).length;
  console.log(`${ts()}  stopped; click the orb again`);
  await clickOrb();
  const back = (await settle(n4, 30)).join(" ");
  console.log(`${ts()}  Nova: ${back}`);
  check("returning: a welcome back, not a first greeting", /back|again|left off|earlier|continue|pick up|eiffel/i.test(back), back.slice(0, 60));
  await page.evaluate(`document.querySelector("talk-to-website").shadowRoot.querySelector('[data-act="stop"]').click()`);
  await sleep(1500);

  // 5. another site: nothing carries over
  await page.send("Page.navigate", { url: SITE_B });
  await sleep(3000);
  await sw.evaluate(`chrome.tabs.query({}).then((ts) => toggleTab({ id: ts.find((t) => t.url && t.url.includes("wikivoyage"))?.id })).then(() => true)`);
  for (let i = 0; i < 50 && !(await read()); i++) await sleep(200);
  await sleep(1800);
  const carried = (await read())?.messages.length || 0;
  check("another site: its chat starts empty", carried === 0, `${carried} messages shown`);
  console.log(`${ts()}  click the orb on wikivoyage.org`);
  await clickOrb();
  const fresh = (await settle(0, 30)).join(" ");
  console.log(`${ts()}  Nova: ${fresh}`);
  check("another site: a first greeting with nothing from the other site", fresh && !/eiffel|golden gate|statue|liberty|welcome back|left off/i.test(fresh), fresh.slice(0, 60));
  const bVisits = await visitsOf("wikivoyage.org");
  check("another site: its own history only", bVisits.length >= 1 && bVisits.every((v) => v.url.includes("wikivoyage")), `${bVisits.length} visits`);
  const shot = await page.send("Page.captureScreenshot", { format: "png" });
  writeFileSync(join(OUT, "final.png"), Buffer.from(shot.result.data, "base64"));
} finally {
  await page?.evaluate(`document.querySelector("talk-to-website")?.shadowRoot.querySelector('[data-act="stop"]')?.click()`).catch(() => {});
  await sleep(500);
  ext.proc.kill();
}
console.log(`\n${results.filter(([, ok]) => ok).length}/${results.length} passed · logs in ${OUT}`);
process.exit(results.every(([, ok]) => ok) ? 0 : 1);
