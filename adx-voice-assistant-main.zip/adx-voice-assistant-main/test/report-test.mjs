// "Report a problem", end to end in the extension on a real website: a spoken request, then
// "report this session" by voice (the widget's report box opens) and a note sent from it,
// then the flag button in the chat panel and a second note. Checks that the relay saved both,
// with this conversation's logs.
//
//   npm start   # in another terminal
//   node test/report-test.mjs [url]
import { execFileSync } from "node:child_process";
import { readFileSync, writeFileSync, mkdirSync, existsSync } from "node:fs";
import { join } from "node:path";
import { sleep } from "./lib/chrome.mjs";
import { launchWithExtension, attach, findTarget } from "./lib/extension.mjs";
import { ROOT } from "../server/env.mjs";

const [url = "https://www.rarebeauty.com/"] = process.argv.slice(2);
const OUT = join(ROOT, "logs", `report-test-${Date.now()}`);
mkdirSync(OUT, { recursive: true });
const HTTP = "http://localhost:5179";

function pcm(text, i) {
  const f = join(OUT, `turn${i}.wav`);
  if (!existsSync(f)) {
    execFileSync("say", ["-v", "Samantha", "-r", "180", "-o", f + ".aiff", text]);
    execFileSync("afconvert", ["-f", "WAVE", "-d", "LEI16@24000", "-c", "1", f + ".aiff", f]);
  }
  const b = readFileSync(f);
  for (let off = 12; off < b.length; ) {
    const id = b.toString("ascii", off, off + 4), size = b.readUInt32LE(off + 4);
    if (id === "data") return b.subarray(off + 8, off + 8 + size);
    off += 8 + size + (size % 2);
  }
}
const FAKE_MIC = `(() => {
  const ctx = new AudioContext({ sampleRate: 24000 });
  const dest = ctx.createMediaStreamDestination();
  window.__fakeMic = { say(b64) {
    const bin = atob(b64), n = bin.length >> 1, buf = ctx.createBuffer(1, n, 24000), ch = buf.getChannelData(0);
    for (let i = 0; i < n; i++) { let v = bin.charCodeAt(2 * i) | (bin.charCodeAt(2 * i + 1) << 8); if (v >= 32768) v -= 65536; ch[i] = v / 32768; }
    const src = ctx.createBufferSource(); src.buffer = buf; src.connect(dest); ctx.resume(); src.start(); return n / 24000;
  } };
  navigator.mediaDevices.getUserMedia = async () => (ctx.resume(), new MediaStream(dest.stream.getAudioTracks().map((t) => t.clone())));
})(); true`;
const R = `document.querySelector("talk-to-website")?.shadowRoot`;
const READ = `(() => { const r = ${R}; if (!r) return null; return { view: r.querySelector(".tw").dataset.state,
  box: !r.querySelector(".report").hidden, status: r.querySelector(".report-status").textContent,
  agents: r.querySelectorAll(".msg.agent").length, last: [...r.querySelectorAll(".msg.agent")].at(-1)?.textContent || "" }; })()`;
const sendNote = (note) => `(() => { const r = ${R}; const t = r.querySelector(".report textarea"); t.value = ${JSON.stringify(note)}; r.querySelector('[data-act="report-send"]').click(); return true; })()`;

let pass = 0, fail = 0;
const check = (ok, what) => { console.log(`${ok ? "PASS" : "FAIL"}  ${what}`); ok ? pass++ : fail++; };
const before = (await (await fetch(`${HTTP}/reports`)).json()).reports.length;

const ext = await launchWithExtension({ path: join(ROOT, "extension"), args: ["--mute-audio", "--autoplay-policy=no-user-gesture-required", "--use-fake-ui-for-media-stream", "--window-size=1280,860"] });
let page, sw, off;
try {
  const pt = await findTarget(ext.port, (t) => t.type === "page" && t.url === "about:blank");
  page = await attach(pt.webSocketDebuggerUrl);
  await page.send("Page.enable");
  await page.send("Page.navigate", { url });
  await sleep(2500);
  sw = await attach((await findTarget(ext.port, (t) => t.type === "service_worker" && t.url.includes(ext.id))).webSocketDebuggerUrl);
  const tabId = await sw.evaluate(`chrome.tabs.query({}).then((ts) => ts.find((t) => t.url && t.url.startsWith(${JSON.stringify(new URL(url).origin)}))?.id)`);
  await sw.evaluate(`toggleTab({ id: ${tabId} }).then(() => true)`);
  off = await attach((await findTarget(ext.port, (t) => t.url.endsWith("/offscreen.html"))).webSocketDebuggerUrl);
  await off.evaluate(FAKE_MIC);
  for (let i = 0; i < 50 && !(await page.evaluate(READ).catch(() => null)); i++) await sleep(200);

  const key = (type) => page.send("Input.dispatchKeyEvent", { type, modifiers: type === "keyDown" ? 1 : 0, key: " ", code: "Space", windowsVirtualKeyCode: 32 });
  async function say(text, i, until) {
    const n0 = (await page.evaluate(READ)).agents;
    console.log(`you: "${text}"`);
    await key("keyDown");
    await sleep(i === 0 ? 500 : 150);
    const secs = await off.evaluate(`window.__fakeMic.say(${JSON.stringify(pcm(text, i).toString("base64"))})`);
    await sleep(secs * 1000 + 500);
    await key("keyUp");
    let st, settled = 0;
    for (let k = 0; k < 120; k++) {
      await sleep(500);
      st = await page.evaluate(READ).catch(() => null);
      if (until?.(st)) break;
      settled = st && st.agents > n0 && ["ready", "listening", "idle"].includes(st.view) ? settled + 1 : 0;
      if (settled >= 4) break;
    }
    console.log(`  voice: ${st?.last}`);
    return st;
  }
  async function waitSent() {
    for (let k = 0; k < 40; k++) { await sleep(300); const st = await page.evaluate(READ); if (/^Sent|Couldn't/.test(st.status)) return st.status; }
    return "(no answer)";
  }

  await say("What kinds of blush do you have?", 0);
  // by voice: the box opens
  let st = await say("Report this session.", 1, (s) => s?.box);
  for (let k = 0; k < 20 && !st.box; k++) { await sleep(500); st = await page.evaluate(READ); }
  check(st.box, "saying \"report this session\" opens the report box");
  const shot = await page.send("Page.captureScreenshot", { format: "png" });
  writeFileSync(join(OUT, "report-box.png"), Buffer.from(shot.result.data, "base64"));
  await page.evaluate(sendNote("Test report by voice: the blush answer took a while."));
  let status = await waitSent();
  check(/^Sent, with this conversation's logs/.test(status), `sent from the voice-opened box: ${status}`);

  // the flag button
  await sleep(3000);
  await page.evaluate(`(() => { const r = ${R}; if (!r.querySelector(".tw").classList.contains("open")) r.querySelector('[data-act="chat"]').click(); r.querySelector('[data-act="report"]').click(); return true; })()`);
  await sleep(400);
  check((await page.evaluate(READ)).box, "the flag button opens the report box");
  await page.evaluate(sendNote("Test report from the flag button."));
  status = await waitSent();
  check(/^Sent/.test(status), `sent from the flag button: ${status}`);

  const list = (await (await fetch(`${HTTP}/reports`)).json()).reports;
  check(list.length === before + 2, `two new reports listed (${list.length - before})`);
  const txt = await (await fetch(`${HTTP}/reports/${encodeURIComponent(list[1].id)}.txt`)).text();
  check(txt.includes("Test report by voice") && txt.includes("What kinds of blush") && txt.includes("task_done"), "the report has the note, the transcript and the task timeline");
  check(/report_open|-- report/.test(txt) || txt.includes("Report this session"), "the timeline shows the report request");
  console.log(`\nreport: ${HTTP}/reports/${list[1].id}.txt\nscreenshot: ${join(OUT, "report-box.png")}`);
} finally {
  ext.proc.kill();
}
console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
