// Start afresh, with the real extension on real websites:
//  1. browse and talk on wikipedia.org (a greeting puts something in the transcript)
//  2. the chat panel's trash button → "Start afresh": the conversation ends, and the
//     transcript, resume state and browsing history of wikipedia.org are gone; another
//     site's history is untouched
//  3. the settings page's "Forget all sites" clears the other site too
//   npm start   # in another terminal
//   node test/forget-test.mjs
import { join } from "node:path";
import { sleep } from "./lib/chrome.mjs";
import { launchWithExtension, attach, findTarget } from "./lib/extension.mjs";
import { ROOT } from "../server/env.mjs";

const PAGES = ["https://en.wikipedia.org/wiki/Eiffel_Tower", "https://en.wikipedia.org/wiki/Golden_Gate_Bridge"];
const ext = await launchWithExtension({ path: join(ROOT, "extension"), port: 9361, args: ["--mute-audio", "--autoplay-policy=no-user-gesture-required", "--use-fake-ui-for-media-stream", "--window-size=1280,860"] });
const results = [];
const check = (name, ok, detail = "") => { results.push(ok); console.log(`${ok ? "PASS" : "FAIL"}  ${name}${detail ? `  (${detail})` : ""}`); };
const SHADOW = `document.querySelector("talk-to-website").shadowRoot`;
let page, sw, off;

async function go(url) {
  await page.send("Page.navigate", { url });
  for (let i = 0; i < 80; i++) { await sleep(200); if ((await page.evaluate("document.readyState").catch(() => "")) === "complete") break; }
  for (let i = 0; i < 50 && !(await page.evaluate(`!!document.querySelector("talk-to-website")`).catch(() => false)); i++) await sleep(200);
  await sleep(1600); // the visit is recorded ~1 s after load
}
const state = () => page.evaluate(`(() => { const r = ${SHADOW}; return { view: r.querySelector(".tw").dataset.state, msgs: r.querySelectorAll(".msg").length, empty: !!r.querySelector(".log .empty") }; })()`);
const stored = () => sw.evaluate(`chrome.storage.local.get(null).then((all) => Object.keys(all).filter((k) => k.startsWith("ttw:")))`);
const offKeys = () => off.evaluate(`Object.keys(localStorage).filter((k) => k.startsWith("ttw:"))`);

try {
  page = await attach((await findTarget(ext.port, (t) => t.type === "page" && t.url === "about:blank")).webSocketDebuggerUrl);
  await page.send("Page.enable");
  await page.send("Page.navigate", { url: PAGES[0] });
  await sleep(2500);
  sw = await attach((await findTarget(ext.port, (t) => t.type === "service_worker" && t.url.includes(ext.id))).webSocketDebuggerUrl);
  const tabId = await sw.evaluate(`chrome.tabs.query({}).then((ts) => ts.find((t) => t.url && t.url.includes("wikipedia.org"))?.id)`);
  await sw.evaluate(`toggleTab({ id: ${tabId} }).then(() => true)`);
  off = await attach((await findTarget(ext.port, (t) => t.url.endsWith("/offscreen.html"))).webSocketDebuggerUrl);
  for (const u of PAGES) await go(u);
  // another site's history, which must survive starting afresh on wikipedia.org
  await sw.evaluate(`chrome.storage.local.set({ "ttw:wikivoyage.org:visits": [{ url: "https://en.wikivoyage.org/wiki/Paris", title: "Paris", kind: "page", at: Date.now() }] }).then(() => true)`);

  // 1. talk: click the orb, wait for the greeting
  const [vw, vh] = await page.evaluate("[innerWidth, innerHeight]");
  for (const type of ["mousePressed", "mouseReleased"]) await page.send("Input.dispatchMouseEvent", { type, x: vw - 48, y: vh - 48, button: "left", clickCount: 1 });
  let st;
  for (let i = 0; i < 60; i++) { await sleep(500); st = await state(); if (st.msgs > 0 && st.view !== "idle") break; }
  await sleep(3000);
  console.log("before:", JSON.stringify(await state()), "\n  extension storage:", (await stored()).join(", "), "\n  voice storage:", (await offKeys()).join(", "));
  check("a conversation is going, with a transcript", st.msgs > 0 && st.view !== "idle");

  // 2. trash → confirm → start afresh
  await page.evaluate(`${SHADOW}.querySelector('[data-act="chat"]').click()`);
  await page.evaluate(`${SHADOW}.querySelector('[data-act="forget"]').click()`);
  const prompt = await page.evaluate(`(() => { const a = ${SHADOW}.querySelector(".afresh"); return a.hidden ? null : a.textContent; })()`);
  check("the trash button asks first", !!prompt, prompt?.slice(0, 80));
  await page.evaluate(`${SHADOW}.querySelector('[data-act="forget-yes"]').click()`);
  await sleep(1500);
  const after = await state(), ext1 = await stored(), off1 = await offKeys();
  console.log("after:", JSON.stringify(after), "\n  extension storage:", ext1.join(", "), "\n  voice storage:", off1.join(", "));
  check("the conversation ended", after.view === "idle");
  check("the transcript is empty", after.msgs === 0 && after.empty);
  check("wikipedia.org's browsing history is gone", !ext1.some((k) => k.startsWith("ttw:wikipedia.org:")));
  check("wikipedia.org's transcript and resume state are gone", !off1.some((k) => k.startsWith("ttw:wikipedia.org:") && !k.endsWith(":voiceMuted")));
  check("another site's history is untouched", ext1.includes("ttw:wikivoyage.org:visits"));

  // a reload doesn't bring anything back
  await go(PAGES[1]);
  const reloaded = await state();
  check("after a page load the transcript stays empty", reloaded.msgs === 0, JSON.stringify(reloaded));

  // 3. the settings page: forget all sites
  const opts = await attach((await (async () => {
    await sw.evaluate(`chrome.tabs.create({ url: chrome.runtime.getURL("options.html") }).then(() => true)`);
    return findTarget(ext.port, (t) => t.url.endsWith("/options.html"));
  })()).webSocketDebuggerUrl);
  await sleep(1000);
  const shown = await opts.evaluate(`!document.getElementById("history").hidden`);
  check("the settings page offers \"Forget all sites\"", shown);
  await opts.evaluate(`window.confirm = () => true; document.getElementById("forgetAll").click(); true`);
  await sleep(1500);
  const ext2 = await stored();
  console.log("after forget all:", ext2.join(", ") || "(nothing)");
  check("every site's history is gone", ext2.length === 0);
} catch (e) {
  console.error(e);
  results.push(false);
} finally {
  ext.proc.kill();
}
console.log(`\n${results.filter(Boolean).length}/${results.length} passed`);
process.exit(results.every(Boolean) ? 0 : 1);
